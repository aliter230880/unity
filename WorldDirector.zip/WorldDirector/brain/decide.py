"""The decision layer: read again, fix, or stop.

Reading is not a goal in itself. Once the brain has findings, something has to decide
what they mean: are they fixable with a known, reversible action, or does the brain
only know that something is wrong? This module makes that call, and it makes it
explicitly - the decision, its reason and what it would need are part of the answer.

It never acts. Preparing and authorising is the brain's job; changing the scene stays
in the editor, behind the permit gates.

Standard library only.
"""
from __future__ import annotations

# A scene report older than this is not evidence for changing a scene.
STALE_REPORT_SECONDS = 900

DECISION_IDLE = "idle"
DECISION_OBSERVE = "observe"
DECISION_FIX = "fix"


def decide(findings, fix_plan=None, subject: str = "", known_findings: int = 0,
           report_age_seconds: int | None = None, map_context: dict | None = None) -> dict:
    """Turn what was found *and what the brain already knows* into one decision.

    A pass that only refreshed the scene report must not conclude that nothing is wrong:
    the diagnostics read earlier may have found plenty. ``known_findings`` carries that
    count, so the decision reflects the state of the brain, not of one lucky pass.
    """
    plan = fix_plan if isinstance(fix_plan, dict) else {}
    fixes = [item for item in (plan.get("fixes") or []) if isinstance(item, dict)]
    unresolved = list(plan.get("unresolved_findings") or [])
    findings = list(findings or [])
    if isinstance(known_findings, bool):
        # A boolean is not a count, the same rule the request validator follows.
        known = 0
    else:
        try:
            known = max(0, int(known_findings or 0))
        except (TypeError, ValueError):
            known = 0
    total = len(findings) if findings else known

    if total == 0:
        # A stale plan must never drive a fix: nothing known and nothing seen, no action.
        return {
            "action": DECISION_IDLE,
            "reason": "nothing is broken and nothing is waiting",
            "fixes": [],
            "count": 0,
            "risks": [],
            "needs_backup": False,
            "requires": {},
            "plan_id": plan.get("plan_id") or "",
            "unresolved": sorted(set(unresolved)),
            "note": "",
        }

    if fixes and isinstance(report_age_seconds, int) and not isinstance(report_age_seconds, bool) \
            and report_age_seconds > STALE_REPORT_SECONDS:
        # Safety over eagerness: the plan may be perfect for a scene that has since changed.
        return {
            "action": DECISION_OBSERVE,
            "reason": "the scene report is %d s old; refresh it before trusting a fix"
                      % report_age_seconds,
            "fixes": [str(item.get("id")) for item in fixes],
            "count": 0,
            "risks": [],
            "needs_backup": False,
            "requires": {},
            "blocked_by": "stale-report",
            "plan_id": plan.get("plan_id") or "",
            "unresolved": sorted(set(unresolved)),
            "note": "run the scene probe again, then decide",
        }

    if fixes:
        risks = sorted({str(item.get("risk") or "unknown") for item in fixes})
        scene = (map_context or {}) if isinstance(map_context, dict) else {}
        warnings = []
        impact = {}
        try:
            observed = int(scene.get("observed", 0))
            objects = int(scene.get("objects", 0))
            dependents = int(scene.get("dependents", 0))
        except (TypeError, ValueError):
            observed = objects = dependents = 0
        if objects and observed == 0:
            warnings.append("nothing in this scene is observable, so the director cannot act on it")
        if dependents:
            impact["dependents"] = dependents
            warnings.append("%d thing(s) depend on this scene" % dependents)
        if objects:
            impact["objects"] = objects
            impact["observed"] = observed
        return {
            "action": DECISION_FIX,
            "reason": "%d ready fix(es) cover %d known finding(s)" % (len(fixes), total),
            "fixes": [str(item.get("id")) for item in fixes],
            "count": len(fixes),
            "risks": risks,
            "needs_backup": True,
            "requires": {"tool": "outputs.write_text", "path": "scene/fix-plan.json",
                         "subject": subject},
            "blocked_by": "",
            "warnings": warnings,
            "impact": impact,
            "plan_id": plan.get("plan_id") or "",
            "unresolved": sorted(set(unresolved)),
            "note": "the fixer runs inside the editor, dry run first; this only prepares and "
                    "authorises the plan",
        }

    if total:
        return {
            "action": DECISION_OBSERVE,
            "reason": "%d finding(s) have no known fix yet" % total,
            "fixes": [],
            "count": 0,
            "risks": [],
            "needs_backup": False,
            "requires": {},
            "plan_id": plan.get("plan_id") or "",
            "unresolved": sorted(set(unresolved)),
            "note": "keep reading; a human decides what these mean",
        }

    return {
        "action": DECISION_IDLE,
        "reason": "nothing is broken and nothing is waiting",
        "fixes": [],
        "count": 0,
        "risks": [],
        "needs_backup": False,
        "requires": {},
        "plan_id": plan.get("plan_id") or "",
        "unresolved": sorted(set(unresolved)),
        "note": "",
    }
