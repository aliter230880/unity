"""Command line entry point for the AICore toolbox (phase 2, read-only).

Usage (from ``AICore/WorldDirector``)::

    python brain\\toolbox.py list [--json]
    python brain\\toolbox.py describe <tool>
    python brain\\toolbox.py run <tool> [--arg name=value]... [--json]

Every tool in phase 2 is read-only. ``--allow-write`` exists only to make the
refusal explicit and is itself refused: write tools arrive in phase 3, behind
approval.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import tools  # noqa: E402 - imported after sys.path setup so the CLI runs directly


def _parse_arg(values: list[str], parser: argparse.ArgumentParser) -> dict:
    params: dict = {}
    for item in values or []:
        if "=" not in item:
            parser.error(f"--arg expects name=value, got: {item}")
        name, _, value = item.partition("=")
        name = name.strip()
        if not name:
            parser.error(f"--arg expects name=value, got: {item}")
        if name in params:
            parser.error(f"--arg {name} given more than once")
        params[name] = value
    return params


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="toolbox.py",
        description="AICore toolbox: list, describe and run typed tools. "
                    "Phase 2 tools are read-only; nothing in the project is modified.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    listing = sub.add_parser("list", help="List every registered tool.")
    listing.add_argument("--json", action="store_true", help="Print the machine-readable schema.")

    describe = sub.add_parser("describe", help="Show one tool contract in full.")
    describe.add_argument("tool")
    describe.add_argument("--json", action="store_true")

    run = sub.add_parser("run", help="Run one read-only tool.")
    run.add_argument("tool")
    run.add_argument("--arg", action="append", default=[], metavar="NAME=VALUE",
                     help="Tool parameter. Repeat for several parameters.")
    run.add_argument("--json", action="store_true", help="Print the raw JSON result.")
    run.add_argument("--project", default=None,
                     help="Project root for tools that read or write inside a project.")
    run.add_argument("--allow-write", action="store_true",
                     help="Required to run a write tool; the tool still needs an approval "
                          "token from AICORE_APPROVAL_TOKEN.")
    return parser


def _print_listing(as_json: bool) -> None:
    if as_json:
        print(json.dumps(tools.schema(), indent=2, ensure_ascii=False))
        return
    print("AICore toolbox %s - read-only" % tools.TOOLBOX_VERSION)
    for spec in tools.specs():
        required = [item.name for item in spec.parameters if item.required]
        optional = [item.name for item in spec.parameters if not item.required]
        print("\n  %s  [%s]" % (spec.name, spec.category))
        print("    %s" % spec.summary)
        if required:
            print("    required: %s" % ", ".join(required))
        if optional:
            print("    optional: %s" % ", ".join(optional))
    print("\nRun: python brain\\toolbox.py run <tool> --arg name=value")


def _print_description(tool_name: str, as_json: bool) -> None:
    spec = tools.get(tool_name)
    if as_json:
        print(json.dumps(spec.as_dict(), indent=2, ensure_ascii=False))
        return
    print("%s  [%s]" % (spec.name, spec.category))
    print("  %s" % spec.summary)
    if spec.parameters:
        print("  parameters:")
        for parameter in spec.parameters:
            flag = "required" if parameter.required else "optional"
            default = "" if parameter.default is None else " default=%r" % (parameter.default,)
            print("    %-12s %-11s %-9s%s  %s"
                  % (parameter.name, parameter.kind, flag, default, parameter.description))
    else:
        print("  parameters: none")
    if spec.returns:
        print("  returns: %s" % spec.returns)
    print("  reversible: %s" % ("yes" if spec.reversible else "no"))
    if spec.requires:
        print("  requires: %s" % ", ".join(spec.requires))
    if spec.notes:
        print("  notes: %s" % spec.notes)


def _print_result(result: tools.ToolResult, as_json: bool) -> None:
    if as_json:
        print(json.dumps(result.as_dict(), indent=2, ensure_ascii=False))
        return
    if not result.ok:
        print("FAILED %s: %s" % (result.tool, result.error), file=sys.stderr)
        return
    data = result.data if isinstance(result.data, dict) else {"result": result.data}
    mode = "read-only" if result.read_only else "WRITE"
    print("%s: ok in %d ms (%s)" % (result.tool, result.duration_ms, mode))
    for key, value in data.items():
        if isinstance(value, list):
            print("  %s: %d item(s)" % (key, len(value)))
        elif isinstance(value, dict):
            print("  %s: %s" % (key, json.dumps(value, ensure_ascii=False)))
        else:
            print("  %s: %s" % (key, value))


def main(argv: list[str] | None = None) -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):  # pragma: no cover - exotic consoles
            pass
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "list":
        _print_listing(args.json)
        return 0

    if args.command == "describe":
        try:
            _print_description(args.tool, args.json)
        except tools.ToolError as error:
            print(str(error), file=sys.stderr)
            return 1
        return 0

    if args.command == "run":
        params = _parse_arg(args.arg, parser)
        result = tools.execute(args.tool, params, allow_write=args.allow_write,
                               project_root=args.project)
        _print_result(result, args.json)
        return 0 if result.ok else 1

    parser.error("unknown command")  # pragma: no cover
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
