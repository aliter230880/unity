"""Owner charter: the constitution the director may not rewrite.

The charter is loaded once at process start. The brain may recommend a change;
it cannot enlarge its own verbs, catalogs or kinds. Standard library only.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

KNOWN_ACTIONS = ("spawn", "move", "activate", "deactivate")
DEFAULT_FORBIDDEN_KINDS = ("player",)


def _as_tuple(value: Any, fallback: tuple[str, ...] = ()) -> tuple[str, ...]:
    if value is None:
        return fallback
    if not isinstance(value, list) or any(not isinstance(item, str) or not item.strip() for item in value):
        raise ValueError("charter lists must contain non-empty strings.")
    return tuple(item.strip() for item in value)


class Charter:
    """Declarative gates in front of every proposed action."""

    def __init__(self, allowed_actions: tuple[str, ...] = KNOWN_ACTIONS,
                 forbidden_kinds: tuple[str, ...] = DEFAULT_FORBIDDEN_KINDS,
                 allowed_catalogs: tuple[str, ...] = (),
                 forbidden_catalogs: tuple[str, ...] = (),
                 can_self_expand: bool = False,
                 note: str = ""):
        if not allowed_actions:
            raise ValueError("charter.allowed_actions must not be empty.")
        unknown = [item for item in allowed_actions if item not in KNOWN_ACTIONS]
        if unknown:
            raise ValueError("charter cannot grant unknown verbs: " + ", ".join(unknown))
        self.allowed_actions = allowed_actions
        self.forbidden_kinds = tuple(item.lower() for item in forbidden_kinds)
        self.allowed_catalogs = allowed_catalogs
        self.forbidden_catalogs = forbidden_catalogs
        self.can_self_expand = bool(can_self_expand)
        self.note = note if isinstance(note, str) else ""

    def describe(self) -> dict:
        return {
            "allowed_actions": list(self.allowed_actions),
            "forbidden_kinds": list(self.forbidden_kinds),
            "allowed_catalogs": list(self.allowed_catalogs),
            "forbidden_catalogs": list(self.forbidden_catalogs),
            "can_self_expand": self.can_self_expand,
            "note": self.note,
        }

    def refuse_reason(self, action: dict, catalog_kind: str = "") -> str | None:
        if not isinstance(action, dict):
            return "charter: action is not an object"
        verb = action.get("type")
        if verb not in self.allowed_actions:
            return "charter forbids verb %s" % verb
        catalog = action.get("catalog_id") or ""
        if catalog in self.forbidden_catalogs:
            return "charter forbids catalog %s" % catalog
        if self.allowed_catalogs and catalog not in self.allowed_catalogs:
            return "charter does not list catalog %s" % catalog
        if catalog_kind and catalog_kind.lower() in self.forbidden_kinds:
            return "charter forbids kind %s" % catalog_kind.lower()
        return None

    def filter_actions(self, actions: list, catalog: list | None = None) -> tuple[list, list[str]]:
        kinds = {}
        for entry in catalog or []:
            if isinstance(entry, dict) and isinstance(entry.get("id"), str):
                kinds[entry["id"]] = str(entry.get("kind") or "")
        kept, reasons = [], []
        for action in actions:
            reason = self.refuse_reason(action, kinds.get((action or {}).get("catalog_id"), ""))
            if reason:
                reasons.append(reason)
            else:
                kept.append(action)
        return kept, reasons

    @classmethod
    def from_mapping(cls, payload: Any) -> "Charter":
        if not isinstance(payload, dict):
            raise ValueError("charter file must be a JSON object.")
        return cls(
            allowed_actions=_as_tuple(payload.get("allowed_actions"), KNOWN_ACTIONS),
            forbidden_kinds=_as_tuple(payload.get("forbidden_kinds"), DEFAULT_FORBIDDEN_KINDS),
            allowed_catalogs=_as_tuple(payload.get("allowed_catalogs")),
            forbidden_catalogs=_as_tuple(payload.get("forbidden_catalogs")),
            can_self_expand=bool(payload.get("can_self_expand", False)),
            note=str(payload.get("note") or ""),
        )

    @classmethod
    def load(cls, path: str | Path | None = None, env: dict | None = None) -> "Charter":
        env = os.environ if env is None else env
        configured = path or env.get("AICORE_CHARTER") or ""
        if configured:
            file = Path(configured)
            if not file.is_file():
                raise ValueError("AICORE_CHARTER does not exist: %s" % file)
            return cls.from_mapping(json.loads(file.read_text(encoding="utf-8")))
        builtin = Path(__file__).resolve().parent / "charter.city111.json"
        if builtin.is_file():
            return cls.from_mapping(json.loads(builtin.read_text(encoding="utf-8")))
        return cls()
