"""Typed tool registry for AICore (phase 2: the brain gets hands, still read-only).

A *tool* is a named, typed, described capability. The brain may propose work, but
only a declared tool can execute it, and only with declared parameters. Phase 2
deliberately ships READ-ONLY tools only:

    unity.console.tail      read the Unity editor console
    unity.project.inventory read the project layout
    project.diagnostics     run the phase 1 observer without writing anything
    brain.knowledge.facts   read knowledge facts out of the brain database
    brain.observations.recent  read recent observations out of the brain database

Tools that mutate the world are declared by category and **refused** by the
dispatcher until phase 3 enables them explicitly. Nothing in this module writes
to the project, the logs, or the brain database.

Standard library only. No network. No subprocess.
"""
from __future__ import annotations

import dataclasses
import hashlib
import hmac
import json
import os
import shutil
import sqlite3
import sys
import time
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

import approval  # noqa: E402 - same directory, stdlib only
import diagnostics  # noqa: E402 - same directory, stdlib only
import toolplan  # noqa: E402 - same directory, stdlib only

TOOLBOX_VERSION = "1.0"

READ = "read"
WRITE = "write"
CATEGORIES = (READ, WRITE)

STRING = "string"
INTEGER = "integer"
BOOLEAN = "boolean"
PATH_KIND = "path"
STRING_LIST = "string_list"
KINDS = (STRING, INTEGER, BOOLEAN, PATH_KIND, STRING_LIST)

DEFAULT_DB = _HERE / "state" / "brain.sqlite3"

CONSOLE_LEVELS = ("error", "warning", "info")
MAX_CONSOLE_LINES = 5000


class ToolError(ValueError):
    """Raised when a tool cannot run or was called incorrectly."""


@dataclass(frozen=True)
class Parameter:
    name: str
    kind: str
    required: bool = True
    default: Any = None
    description: str = ""

    def as_dict(self) -> dict:
        return {"name": self.name, "kind": self.kind, "required": self.required,
                "default": self.default, "description": self.description}


@dataclass(frozen=True)
class ToolSpec:
    """The contract of one tool: name, category, parameters, reversibility."""

    name: str
    category: str
    summary: str
    parameters: tuple[Parameter, ...] = ()
    returns: str = ""
    reversible: bool = True
    requires: tuple[str, ...] = ()
    notes: str = ""

    def as_dict(self) -> dict:
        return {"name": self.name, "category": self.category, "summary": self.summary,
                "parameters": [item.as_dict() for item in self.parameters],
                "returns": self.returns, "reversible": self.reversible,
                "requires": list(self.requires), "notes": self.notes}


@dataclass
class ToolResult:
    tool: str
    ok: bool
    data: Any = None
    error: str = ""
    duration_ms: int = 0
    read_only: bool = True

    def as_dict(self) -> dict:
        return {"tool": self.tool, "ok": self.ok, "data": self.data, "error": self.error,
                "duration_ms": self.duration_ms, "read_only": self.read_only}


_SPECS: dict[str, ToolSpec] = {}
_HANDLERS: dict[str, Callable[[dict], Any]] = {}


def tool(spec: ToolSpec) -> Callable[[Callable[[dict], Any]], Callable[[dict], Any]]:
    """Register a handler under a spec. Duplicate names are a programming error."""
    if spec.name in _SPECS:
        raise ToolError(f"Tool already registered: {spec.name}")
    if spec.category not in CATEGORIES:
        raise ToolError(f"Unknown category for {spec.name}: {spec.category}")
    seen: set[str] = set()
    for parameter in spec.parameters:
        if parameter.kind not in KINDS:
            raise ToolError(f"{spec.name}: parameter {parameter.name} has unknown kind {parameter.kind}")
        if parameter.name in seen:
            raise ToolError(f"{spec.name}: duplicate parameter {parameter.name}")
        seen.add(parameter.name)

    def decorate(handler: Callable[[dict], Any]) -> Callable[[dict], Any]:
        _SPECS[spec.name] = spec
        _HANDLERS[spec.name] = handler
        return handler

    return decorate


# ---------------------------------------------------------------------------------------
# parameter validation
# ---------------------------------------------------------------------------------------

def _coerce(parameter: Parameter, value: Any) -> Any:
    kind = parameter.kind
    if kind == INTEGER:
        if isinstance(value, bool) or not isinstance(value, int):
            try:
                value = int(str(value).strip())
            except (TypeError, ValueError):
                raise ToolError(f"{parameter.name} must be an integer, got {value!r}")
        return value
    if kind == BOOLEAN:
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in ("true", "1", "yes", "on"):
            return True
        if text in ("false", "0", "no", "off"):
            return False
        raise ToolError(f"{parameter.name} must be a boolean, got {value!r}")
    if kind == STRING_LIST:
        if isinstance(value, (list, tuple)):
            return [str(item) for item in value]
        if isinstance(value, str):
            return [item.strip() for item in value.split(",") if item.strip()]
        raise ToolError(f"{parameter.name} must be a list of strings")
    if kind == PATH_KIND:
        if not str(value).strip():
            raise ToolError(f"{parameter.name} must be a non-empty path")
        return str(value)
    if not isinstance(value, str):
        raise ToolError(f"{parameter.name} must be a string, got {type(value).__name__}")
    return value


def validate_parameters(spec: ToolSpec, params: dict) -> dict:
    """Reject unknown keys, fill defaults, coerce kinds. Raises ToolError."""
    known = {parameter.name for parameter in spec.parameters}
    unknown = sorted(set(params) - known)
    if unknown:
        raise ToolError(f"{spec.name}: unknown parameter(s): {', '.join(unknown)}")
    cleaned: dict[str, Any] = {}
    for parameter in spec.parameters:
        if parameter.name in params:
            cleaned[parameter.name] = _coerce(parameter, params[parameter.name])
        elif parameter.required:
            raise ToolError(f"{spec.name}: missing required parameter '{parameter.name}'")
        else:
            cleaned[parameter.name] = parameter.default
    return cleaned


# ---------------------------------------------------------------------------------------
# shared read-only helpers
# ---------------------------------------------------------------------------------------

def _require_project_root(value: Any) -> Path:
    if not value:
        raise ToolError("project_root is required")
    root = Path(str(value)).expanduser()
    if not root.is_dir():
        raise ToolError(f"project root is not a directory: {root}")
    return root


def _tail_lines(path: Path, count: int) -> list[str]:
    with open(path, "r", encoding="utf-8", errors="replace", newline="") as handle:
        return [line.rstrip("\r\n") for line in deque(handle, maxlen=count)]


def _console_level(line: str) -> str:
    lowered = line.lower()
    if "exception" in lowered or " error" in lowered or lowered.startswith("error"):
        return "error"
    if "warning" in lowered or lowered.startswith("warn"):
        return "warning"
    return "info"


def _readonly_connection(db_path: Path) -> sqlite3.Connection:
    if not db_path.is_file():
        raise ToolError(f"brain database not found: {db_path}")
    connection = sqlite3.connect("file:%s?mode=ro" % db_path.as_posix().replace("?", "%3f"), uri=True)
    connection.row_factory = sqlite3.Row
    return connection


def _table_names(connection: sqlite3.Connection) -> set[str]:
    rows = connection.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
    return {row["name"] for row in rows}


# ---------------------------------------------------------------------------------------
# tools
# ---------------------------------------------------------------------------------------

@tool(ToolSpec(
    name="unity.console.tail",
    category=READ,
    summary="Read the tail of the Unity editor console (the only place runtime log output lives).",
    parameters=(
        Parameter("file", STRING, required=False, default="Editor.log",
                  description="Editor.log or Editor-prev.log inside the per-user Unity editor folder."),
        Parameter("lines", INTEGER, required=False, default=200,
                  description="How many trailing lines to read (1..5000)."),
        Parameter("level", STRING, required=False, default=None,
                  description="Optional filter: error | warning | info."),
    ),
    returns="source path, number of lines returned, and the lines themselves",
    reversible=True,
    notes="Reads the machine-level console; it does not belong to one project.",
))
def _unity_console_tail(params: dict) -> dict:
    directory = diagnostics.editor_log_dir()
    if directory is None:
        raise ToolError("Cannot locate the editor console: LOCALAPPDATA/USERPROFILE is not set")
    name = params.get("file") or "Editor.log"
    if name not in diagnostics.EDITOR_LOG_NAMES:
        raise ToolError("file must be one of: %s" % ", ".join(diagnostics.EDITOR_LOG_NAMES))
    path = directory / name
    if not path.is_file():
        raise ToolError(f"console log not found: {path}")
    lines = params.get("lines") or 200
    if lines < 1 or lines > MAX_CONSOLE_LINES:
        raise ToolError(f"lines must be between 1 and {MAX_CONSOLE_LINES}")
    level = params.get("level")
    if level is not None and level not in CONSOLE_LEVELS:
        raise ToolError("level must be one of: %s" % ", ".join(CONSOLE_LEVELS))
    collected = _tail_lines(path, lines)
    if level:
        collected = [line for line in collected if _console_level(line) == level]
    return {"source": str(path), "lines_requested": lines, "lines_returned": len(collected),
            "level": level, "lines": collected}


@tool(ToolSpec(
    name="unity.project.inventory",
    category=READ,
    summary="Read the project layout: assets, scenes, meta pairs, build settings, packages.",
    parameters=(Parameter("project_root", PATH_KIND, description="Unity project root."),),
    returns="inventory summary plus structured findings",
    reversible=True,
))
def _unity_project_inventory(params: dict) -> dict:
    root = _require_project_root(params.get("project_root"))
    summary, findings = diagnostics.inventory_project(root)
    return {"project_root": str(root), "summary": summary,
            "findings": [dataclasses.asdict(item) for item in findings]}


@tool(ToolSpec(
    name="project.diagnostics",
    category=READ,
    summary="Run the phase 1 observer over logs and the project layout, writing no files.",
    parameters=(
        Parameter("project_root", PATH_KIND, description="Unity project root."),
        Parameter("logs", STRING_LIST, required=False, default=None,
                  description="Log files; when omitted the editor console and project Logs are discovered."),
    ),
    returns="findings, summary and the list of analysed logs",
    reversible=True,
    notes="out_dir is never passed, so no report files are created.",
))
def _project_diagnostics(params: dict) -> dict:
    root = _require_project_root(params.get("project_root"))
    logs = params.get("logs") or diagnostics.default_console_logs(root)
    logs = [str(item) for item in logs if str(item).strip()]
    if not logs:
        raise ToolError("no logs to analyse and none could be discovered")
    report = diagnostics.run(str(root), logs, out_dir=None)
    return {"project_root": str(root), "summary": report["summary"],
            "logs": report["logs"], "findings": report["findings"]}


@tool(ToolSpec(
    name="brain.knowledge.facts",
    category=READ,
    summary="Read knowledge facts from the brain database (read-only connection).",
    parameters=(
        Parameter("db", PATH_KIND, required=False, default=None,
                  description="Brain database path; defaults to brain/state/brain.sqlite3."),
        Parameter("world", STRING, required=False, default=None, description="Optional world filter."),
        Parameter("category", STRING, required=False, default=None, description="Optional category filter."),
        Parameter("limit", INTEGER, required=False, default=50, description="Maximum rows (1..500)."),
    ),
    returns="facts with key, value, category, confidence and updated timestamp",
    reversible=True,
))
def _brain_knowledge_facts(params: dict) -> dict:
    db_path = Path(params.get("db") or DEFAULT_DB)
    limit = params.get("limit") or 50
    if limit < 1 or limit > 500:
        raise ToolError("limit must be between 1 and 500")
    connection = _readonly_connection(db_path)
    try:
        if "facts" not in _table_names(connection):
            return {"database": str(db_path), "facts": [], "note": "no facts table yet"}
        query = "SELECT world, key, value, category, confidence, updated, access_count FROM facts"
        clauses: list[str] = []
        args: list[Any] = []
        if params.get("world"):
            clauses.append("world = ?")
            args.append(params["world"])
        if params.get("category"):
            clauses.append("category = ?")
            args.append(params["category"])
        if clauses:
            query += " WHERE " + " AND ".join(clauses)
        query += " ORDER BY updated DESC LIMIT ?"
        args.append(limit)
        rows = connection.execute(query, args).fetchall()
        return {"database": str(db_path), "count": len(rows),
                "facts": [dict(row) for row in rows]}
    finally:
        connection.close()


@tool(ToolSpec(
    name="brain.observations.recent",
    category=READ,
    summary="Read the most recent observations recorded by the brain (read-only connection).",
    parameters=(
        Parameter("db", PATH_KIND, required=False, default=None,
                  description="Brain database path; defaults to brain/state/brain.sqlite3."),
        Parameter("world", STRING, required=False, default=None, description="Optional world filter."),
        Parameter("session", STRING, required=False, default=None, description="Optional session filter."),
        Parameter("limit", INTEGER, required=False, default=20, description="Maximum rows (1..200)."),
    ),
    returns="observation ids with world, session, created timestamp and digest",
    reversible=True,
))
def _brain_observations_recent(params: dict) -> dict:
    db_path = Path(params.get("db") or DEFAULT_DB)
    limit = params.get("limit") or 20
    if limit < 1 or limit > 200:
        raise ToolError("limit must be between 1 and 200")
    connection = _readonly_connection(db_path)
    try:
        if "observations" not in _table_names(connection):
            return {"database": str(db_path), "observations": [], "note": "no observations table yet"}
        query = "SELECT world, session, observation, digest, created FROM observations"
        clauses: list[str] = []
        args: list[Any] = []
        if params.get("world"):
            clauses.append("world = ?")
            args.append(params["world"])
        if params.get("session"):
            clauses.append("session = ?")
            args.append(params["session"])
        if clauses:
            query += " WHERE " + " AND ".join(clauses)
        query += " ORDER BY created DESC LIMIT ?"
        args.append(limit)
        rows = connection.execute(query, args).fetchall()
        return {"database": str(db_path), "count": len(rows),
                "observations": [dict(row) for row in rows]}
    finally:
        connection.close()


# ---------------------------------------------------------------------------------------
# dispatcher
# ---------------------------------------------------------------------------------------

WRITE_SUBDIR = ("AICore", "outputs")
BACKUP_SUBDIR = ("AI", "backups")
WRITE_LOG = ("AI", "aicore-writes.log")
MAX_WRITE_BYTES = 262144


@dataclass(frozen=True)
class ToolContext:
    """What the dispatcher knows about the caller; set around every handler call."""

    project_root: Path | None = None
    db_path: Path | None = None
    confine: bool = True
    operators: Any = None


def _as_directory(value: Any) -> approval.OperatorDirectory:
    """A bare secret means a single-operator brain; anything else is used as is."""
    if isinstance(value, approval.OperatorDirectory):
        return value
    return approval.OperatorDirectory.single(value or "")


_CONTEXT = ToolContext()


def current_context() -> ToolContext:
    """The context of the running tool call.

    The server is single-threaded by design, so this is a plain module value rather
    than a thread-local.
    """
    return _CONTEXT


def _write_root(context: ToolContext) -> Path:
    if context.project_root is None:
        raise ToolError("write tools need a configured project root")
    root = context.project_root.joinpath(*WRITE_SUBDIR).resolve()
    return root


def _confined_target(raw: Any, context: ToolContext) -> Path:
    root = _write_root(context)
    if not isinstance(raw, str) or not raw.strip():
        raise ToolError("path must be a non-empty string")
    candidate = Path(raw).expanduser()
    target = candidate.resolve() if candidate.is_absolute() else (root / candidate).resolve()
    if not _path_inside(target, root):
        raise ToolError("path must stay inside AICore/outputs")
    if target == root:
        raise ToolError("path must name a file, not the outputs directory")
    return target


def _revert_original(raw: Any, context: ToolContext) -> tuple[Path, Path]:
    """Resolve a backup to (backup file, original file), refusing anything off the allowlist."""
    if context.project_root is None:
        raise ToolError("revert needs a configured project root")
    backups_root = context.project_root.joinpath(*BACKUP_SUBDIR).resolve()
    if not isinstance(raw, str) or not raw.strip():
        raise ToolError("backup must be a non-empty path")
    candidate = Path(raw).expanduser()
    source = candidate.resolve() if candidate.is_absolute() else (backups_root / candidate).resolve()
    if not _path_inside(source, backups_root) or source == backups_root:
        raise ToolError("backup must stay inside AI/backups")
    if not source.is_file():
        raise ToolError("backup not found: %s" % source)
    parts = source.relative_to(backups_root).parts
    if len(parts) < 2:
        raise ToolError("backup does not describe a file inside the project")
    original = context.project_root.joinpath(*parts[1:]).resolve()
    if not _path_inside(original, _write_root(context)):
        raise ToolError("refusing to restore outside AICore/outputs")
    return source, original


def _permit_target(tool: str, params: dict, context: ToolContext) -> str:
    """The exact resolved file a permit must name for this operation."""
    if tool == "outputs.write_text":
        return str(_confined_target(params.get("path"), context))
    if tool == "outputs.revert":
        _source, original = _revert_original(params.get("backup") or params.get("path"), context)
        return str(original)
    raise ToolError("no approval permits are defined for %r" % tool)


def _require_permit(supplied: Any, tool: str, params: dict, context: ToolContext) -> dict:
    """A write needs a permit that names this tool and this exact target."""
    target = _permit_target(tool, params, context)
    try:
        return approval.verify(context.operators, supplied, tool, target,
                               registry=permit_registry(context))
    except approval.ApprovalError as error:
        raise ToolError(str(error))


def _backup_file(target: Path, context: ToolContext) -> str | None:
    """Copy an existing file aside before it is touched. None when there is nothing to save.

    The destination is always unique: a second backup of the same file inside the same
    second must never overwrite the first one, or a revert chain would silently lose its
    oldest state.
    """
    if not target.is_file():
        return None
    relative = target.relative_to(context.project_root)
    stamp = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
    index = 0
    while True:
        name = stamp if index == 0 else "%s-%d" % (stamp, index)
        destination = context.project_root.joinpath(*BACKUP_SUBDIR) / name / relative
        if not destination.exists():
            break
        index += 1
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(target, destination)
    return str(destination)


def _log_write(entry: dict, context: ToolContext) -> None:
    path = context.project_root.joinpath(*WRITE_LOG)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a", encoding="utf-8") as handle:
        handle.write(json.dumps(entry, ensure_ascii=False, sort_keys=True) + "\n")


@tool(ToolSpec(
    name="outputs.write_text",
    category=WRITE,
    summary="Write a text file inside AICore/outputs, with dry-run, backup and approval.",
    parameters=(
        Parameter("path", STRING, description="File path relative to AICore/outputs."),
        Parameter("content", STRING, description="Exact text to write."),
        Parameter("overwrite", BOOLEAN, required=False, default=False,
                  description="Allow replacing an existing file."),
        Parameter("dry_run", BOOLEAN, required=False, default=True,
                  description="Report what would happen without writing. Defaults to true."),
        Parameter("approval", STRING, required=False, default=None,
                  description="Approval token; required when dry_run is false."),
    ),
    returns="dry-run preview, or the written path, byte count and backup path",
    reversible=True,
    requires=("AICORE_APPROVAL_TOKEN configured on the brain",),
    notes="Confined to AICore/outputs. Overwrites always create a backup first.",
))
def _outputs_write_text(params: dict) -> dict:
    context = current_context()
    target = _confined_target(params.get("path"), context)
    content = params.get("content") or ""
    payload = content.encode("utf-8")
    if len(payload) > MAX_WRITE_BYTES:
        raise ToolError("content exceeds %d bytes" % MAX_WRITE_BYTES)
    exists = target.is_file()
    if exists and not params.get("overwrite"):
        raise ToolError("file already exists; pass overwrite=true to replace it")
    planned = {"path": str(target), "bytes": len(payload), "existed": exists}
    if params.get("dry_run", True):
        return {"dry_run": True, "would_write": planned,
                "note": "nothing was written; set dry_run=false with approval to apply"}
    permit = _require_permit(params.get("approval"), "outputs.write_text", params, context)
    backup = _backup_file(target, context)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(payload)
    _log_write({"action": "write_text", "path": str(target), "bytes": len(payload),
                "backup": backup, "subject": permit.get("sub", ""),
                "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}, context)
    return {"dry_run": False, "written": str(target), "bytes": len(payload), "backup": backup}


@tool(ToolSpec(
    name="outputs.revert",
    category=WRITE,
    summary="Restore a file from an AICore backup, with the same dry-run and approval gates.",
    parameters=(
        Parameter("backup", STRING, description="Backup path returned by a previous write."),
        Parameter("dry_run", BOOLEAN, required=False, default=True,
                  description="Report what would happen without restoring. Defaults to true."),
        Parameter("approval", STRING, required=False, default=None,
                  description="Approval token; required when dry_run is false."),
    ),
    returns="the restored path and the backup taken before restoring",
    reversible=True,
    requires=("AICORE_APPROVAL_TOKEN configured on the brain",),
    notes="Only backups under AI/backups that point inside AICore/outputs are accepted.",
))
def _outputs_revert(params: dict) -> dict:
    context = current_context()
    source, original = _revert_original(params.get("backup"), context)
    if params.get("dry_run", True):
        return {"dry_run": True, "would_restore": str(original), "from": str(source),
                "note": "nothing was restored; set dry_run=false with approval to apply"}
    permit = _require_permit(params.get("approval"), "outputs.revert", params, context)
    backup = _backup_file(original, context)
    original.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, original)
    _log_write({"action": "revert", "path": str(original), "from": str(source),
                "backup": backup, "subject": permit.get("sub", ""),
                "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}, context)
    return {"dry_run": False, "restored": str(original), "from": str(source), "backup": backup}

WRITE_TOOL_NAMES = ("outputs.revert", "outputs.write_text")

_PERMIT_REGISTRIES: dict[str, approval.PermitRegistry] = {}
_MEMORY_REGISTRY = approval.PermitRegistry()


def permit_registry(context: ToolContext) -> approval.PermitRegistry:
    """Where spent permits are remembered: the brain database, or memory if there is none."""
    if context.db_path is None:
        return _MEMORY_REGISTRY
    key = str(context.db_path)
    registry = _PERMIT_REGISTRIES.get(key)
    if registry is None:
        registry = approval.PermitRegistry(key)
        _PERMIT_REGISTRIES[key] = registry
    return registry


@tool(ToolSpec(
    name="brain.approval.issue",
    category=READ,
    summary="Mint a single-operation approval permit: one tool, one target, short expiry.",
    parameters=(
        Parameter("tool", STRING, description="Write tool the permit is for."),
        Parameter("path", STRING, description="Target as the write will name it (for a revert: the backup path)."),
        Parameter("ttl_seconds", INTEGER, required=False, default=300,
                  description="Permit lifetime in seconds (1..3600)."),
        Parameter("subject", STRING, description="Who is asking for this permit (operator id)."),
        Parameter("master", STRING, description="Master approval secret that signs the permit."),
    ),
    returns="the permit token, its target digest and expiry",
    reversible=True,
    requires=("AICORE_APPROVAL_TOKEN configured on the brain",),
    notes="The master secret only issues; it is not itself a licence to write.",
))
def _approval_issue(params: dict) -> dict:
    context = current_context()
    directory = context.operators
    if directory is None or not (directory.names() or directory.open_names):
        raise ToolError("approval is not configured on this brain; issuing is disabled")
    tool = params.get("tool")
    if tool not in WRITE_TOOL_NAMES:
        raise ToolError("permits are only issued for write tools: %s" % ", ".join(sorted(WRITE_TOOL_NAMES)))
    probe = {"path": params.get("path"), "backup": params.get("path")}
    target = _permit_target(tool, probe, context)
    ttl = params.get("ttl_seconds") or approval.DEFAULT_TTL_SECONDS
    try:
        return approval.issue(directory, params.get("subject"), params.get("master"),
                              tool, target, ttl)
    except approval.ApprovalError as error:
        raise ToolError(str(error))


@tool(ToolSpec(
    name="brain.fixplans",
    category=READ,
    summary="Read the fix plans the brain has prepared and kept.",
    parameters=(
        Parameter("db", PATH_KIND, required=False, default=None,
                  description="Brain database path; defaults to the configured one."),
        Parameter("world", STRING, required=False, default=None, description="Optional world filter."),
        Parameter("limit", INTEGER, required=False, default=10, description="Maximum plans (1..50)."),
    ),
    returns="prepared plans with the time they were prepared",
    reversible=True,
    notes="Reading only; the brain stores these in its own database, not in the project.",
))
def _brain_fixplans(params: dict) -> dict:
    context = current_context()
    if params.get("db"):
        db_path = Path(params["db"])
    elif context.db_path is not None:
        db_path = Path(context.db_path)
    else:
        db_path = DEFAULT_DB
    limit = params.get("limit") or 10
    if limit < 1 or limit > 50:
        raise ToolError("limit must be between 1 and 50")
    connection = _readonly_connection(db_path)
    try:
        if "fix_plans" not in _table_names(connection):
            return {"database": str(db_path), "plans": [],
                    "note": "no fix plan has been prepared yet"}
        query = "SELECT world, session, plan_id, plan, prepared FROM fix_plans"
        args: list = []
        if params.get("world"):
            query += " WHERE world = ?"
            args.append(params["world"])
        query += " ORDER BY prepared DESC LIMIT ?"
        args.append(limit)
        rows = connection.execute(query, args).fetchall()
        return {"database": str(db_path), "count": len(rows),
                "plans": [{"world": row["world"], "session": row["session"],
                           "plan_id": row["plan_id"], "prepared": row["prepared"],
                           "plan": json.loads(row["plan"])} for row in rows]}
    finally:
        connection.close()


@tool(ToolSpec(
    name="brain.tools.recommend",
    category=READ,
    summary="Ask the planner which read-only tools to run next, given the current state.",
    parameters=(
        Parameter("project_root", PATH_KIND, required=False, default=None,
                  description="Project root; defaults to the configured one."),
        Parameter("budget", INTEGER, required=False, default=3,
                  description="How many suggestions to return (1..8)."),
        Parameter("scene_report", PATH_KIND, required=False, default=None,
                  description="Explicit scene report path; defaults to the project location."),
    ),
    returns="an ordered list of tool calls with a reason for each",
    reversible=True,
    notes="Rule based and reproducible: it chooses tools, it never runs them.",
))
def _brain_tools_recommend(params: dict) -> dict:
    context = current_context()
    root = params.get("project_root") or context.project_root
    if root is None:
        raise ToolError("project_root is required, or configure one on the brain")
    root = Path(str(root))
    state = {"findings": [], "scene_report_age": None, "console_errors": None}
    logs = diagnostics.default_console_logs(root)
    if logs:
        report = diagnostics.run(str(root), logs, out_dir=None)
        state["findings"] = report["findings"]
    directory = diagnostics.editor_log_dir()
    if directory is not None:
        console = directory / "Editor.log"
        if console.is_file():
            state["console_errors"] = sum(1 for line in _tail_lines(console, 400)
                                          if _console_level(line) == "error")
    report_path = Path(params["scene_report"]) if params.get("scene_report") else \
        root / "AICore" / "outputs" / "scene" / "scene-report.json"
    if report_path.is_file():
        state["scene_report_age"] = int(max(0, time.time() - report_path.stat().st_mtime))
    available = {spec.name for spec in specs()}
    result = toolplan.recommend(state, available,
                               budget=params.get("budget") or toolplan.DEFAULT_BUDGET)
    result["project_root"] = str(root)
    return result

SCENE_FIX_MAP = {
    "scene.multiple-AudioListener": {"action": "remove-extra-singletons",
                                     "component": "AudioListener", "risk": "low"},
    "scene.duplicate-transform-names": {"action": "remove-duplicate-rigs", "risk": "medium"},
    "scene.lodgroup-present": {"action": "remove-lod-groups", "component": "LODGroup", "risk": "low"},
    "scene.rect-stretch-size": {"action": "zero-stretched-size-delta", "risk": "low"},
    "scene.stretched-rect-with-sizedelta": {"action": "zero-stretched-size-delta", "risk": "low"},
    "scene.no-camera": {"action": "add-camera", "risk": "low"},
    "scene.missing-scripts": {"action": "strip-missing-scripts", "risk": "medium"},
}


@tool(ToolSpec(
    name="brain.approval.revoke",
    category=WRITE,
    summary="Revoke one approval permit by nonce, or every permit issued before now.",
    parameters=(
        Parameter("nonce", STRING, required=False, default=None, description="Permit nonce to revoke."),
        Parameter("before_now", BOOLEAN, required=False, default=False,
                  description="Revoke every permit issued up to now."),
        Parameter("subject", STRING, required=False, default=None,
                  description="Who is revoking (recorded in the log)."),
        Parameter("master", STRING, description="Master approval secret."),
    ),
    returns="what was revoked, and which ledger holds it",
    reversible=False,
    requires=("AICORE_APPROVAL_TOKEN configured on the brain",),
    notes="Revocation is an operator action: it needs the master secret, not a permit.",
))
def _approval_revoke(params: dict) -> dict:
    context = current_context()
    directory = context.operators
    if directory is None or not (directory.names() or directory.open_names):
        raise ToolError("approval is not configured on this brain; revocation is disabled")
    supplied = params.get("master") or ""
    if not directory.authorises(params.get("subject") or "master", supplied):
        raise ToolError("the approval secret is missing or does not belong to this operator")
    nonce = params.get("nonce")
    before = time.time() if params.get("before_now") else None
    if not nonce and before is None:
        raise ToolError("pass nonce=<permit nonce> or before_now=true")
    registry = permit_registry(context)
    result = registry.revoke(nonce=nonce, before=before)
    result["ledger"] = registry.path or "in-memory"
    if context.project_root is not None:
        _log_write({"action": "revoke_permit", "nonce": nonce, "before": before,
                    "subject": params.get("subject") or "",
                    "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}, context)
    return result


@tool(ToolSpec(
    name="project.map",
    category=READ,
    summary="Read the project map: scenes, objects, catalogued prefabs and how they connect.",
    parameters=(
        Parameter("project_root", PATH_KIND, required=False, default=None),
        Parameter("report", PATH_KIND, required=False, default=None,
                  description="Map report; defaults to the project location."),
        Parameter("kind", STRING, required=False, default=None,
                  description="Optional filter: scene | object | prefab | asset | catalog."),
        Parameter("relation", STRING, required=False, default=None,
                  description="Optional relation filter, e.g. contains or depends_on."),
        Parameter("limit", INTEGER, required=False, default=50,
                  description="Maximum rows of each kind (1..500)."),
    ),
    returns="map summary, entities and relations",
    reversible=True,
    notes="The editor builds the map; this only reads it.",
))
def _project_map(params: dict) -> dict:
    context = current_context()
    project = params.get("project_root") or (str(context.project_root) if context.project_root else None)
    if not project:
        raise ToolError("project_root is required, or configure one on the brain")
    project_path = Path(str(project)).expanduser().resolve()
    report = Path(params["report"]) if params.get("report") else \
        project_path / "AICore" / "outputs" / "scene" / "project-map.json"
    report = report.expanduser()
    if not report.is_absolute():
        report = project_path / report
    report = report.resolve()
    if context.confine and not _path_inside(report, project_path):
        raise ToolError("report must stay inside the configured project root")
    if not report.is_file():
        raise ToolError("project map not found: %s - build it with the editor first" % report)
    limit = params.get("limit")
    limit = 50 if limit is None else limit
    if limit < 1 or limit > 500:
        raise ToolError("limit must be between 1 and 500")
    try:
        payload = json.loads(report.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise ToolError("project map is unreadable: %s" % error)
    entities = [item for item in (payload.get("entities") or []) if isinstance(item, dict)]
    relations = [item for item in (payload.get("relations") or []) if isinstance(item, dict)]
    if params.get("kind"):
        entities = [item for item in entities if item.get("kind") == params["kind"]]
    if params.get("relation"):
        relations = [item for item in relations if item.get("type") == params["relation"]]
    return {"report": str(report), "summary": payload.get("summary"),
            "generated_utc": payload.get("generated_utc"),
            "entities": entities[:limit], "entity_count": len(entities),
            "relations": relations[:limit], "relation_count": len(relations)}


@tool(ToolSpec(
    name="project.query",
    category=READ,
    summary="Ask the project map questions: what is connected to what, what is observed.",
    parameters=(
        Parameter("db", PATH_KIND, required=False, default=None,
                  description="Brain database; defaults to the configured one."),
        Parameter("world", STRING, required=False, default=None, description="Optional world filter."),
        Parameter("text", STRING, required=False, default=None,
                  description="Match an entity by id, path or name (substring)."),
        Parameter("kind", STRING, required=False, default=None,
                  description="Restrict to scene | object | prefab | asset | catalog."),
        Parameter("relation", STRING, required=False, default=None,
                  description="List relations of this type, e.g. has_missing_script."),
        Parameter("limit", INTEGER, required=False, default=25, description="Rows per answer (1..200)."),
    ),
    returns="matching entities with their relations, or relations of one type, or a summary",
    reversible=True,
    notes="Reads the brain's copy of the map; it never touches the project.",
))
def _project_query(params: dict) -> dict:
    context = current_context()
    db_path = Path(params["db"]) if params.get("db") else \
        (Path(context.db_path) if context.db_path is not None else DEFAULT_DB)
    limit = params.get("limit")
    limit = 25 if limit is None else limit
    if limit < 1 or limit > 200:
        raise ToolError("limit must be between 1 and 200")
    connection = _readonly_connection(db_path)
    try:
        tables = _table_names(connection)
        if "map_entities" not in tables and "relations" not in tables:
            return {"database": str(db_path), "note": "no project map has been recorded yet"}
        world = params.get("world")
        if not world:
            row = connection.execute(
                "SELECT world FROM relations GROUP BY world ORDER BY COUNT(*) DESC LIMIT 1"
            ).fetchone() if "relations" in tables else None
            if row is None and "map_entities" in tables:
                row = connection.execute(
                    "SELECT world FROM map_entities GROUP BY world ORDER BY COUNT(*) DESC LIMIT 1"
                ).fetchone()
            world = row["world"] if row is not None else ""
        world = str(world)
        if params.get("relation"):
            rows = connection.execute(
                "SELECT source_id, target_id, type FROM relations WHERE world=? AND type=? "
                "ORDER BY source_id LIMIT ?", (world, params["relation"], limit)).fetchall()
            return {"database": str(db_path), "world": world, "relation": params["relation"],
                    "count": len(rows),
                    "relations": [{"source": row["source_id"], "target": row["target_id"],
                                   "type": row["type"]} for row in rows]}
        if params.get("text") or params.get("kind"):
            query = "SELECT id, path, kind, name FROM map_entities WHERE world=?"
            args: list = [world]
            if params.get("text"):
                query += " AND (id LIKE ? OR path LIKE ? OR name LIKE ?)"
                like = "%" + params["text"] + "%"
                args.extend([like, like, like])
            if params.get("kind"):
                query += " AND kind=?"
                args.append(params["kind"])
            query += " ORDER BY id LIMIT ?"
            args.append(limit)
            entities = connection.execute(query, args).fetchall()
            answer = []
            for entity in entities:
                links = connection.execute(
                    "SELECT source_id, target_id, type FROM relations WHERE world=? "
                    "AND (source_id=? OR target_id=?) ORDER BY type LIMIT ?",
                    (world, entity["id"], entity["id"], limit)).fetchall()
                answer.append({"entity": {"id": entity["id"], "path": entity["path"],
                                          "kind": entity["kind"], "name": entity["name"]},
                               "relations": [{"source": row["source_id"],
                                              "target": row["target_id"], "type": row["type"]}
                                             for row in links]})
            return {"database": str(db_path), "world": world, "count": len(answer),
                    "entities": answer}
        kinds = connection.execute(
            "SELECT kind, COUNT(*) AS n FROM map_entities WHERE world=? GROUP BY kind",
            (world,)).fetchall() if "map_entities" in tables else []
        types = connection.execute(
            "SELECT type, COUNT(*) AS n FROM relations WHERE world=? GROUP BY type",
            (world,)).fetchall() if "relations" in tables else []
        entities_by_kind = {row["kind"]: row["n"] for row in kinds}
        relations_by_type = {row["type"]: row["n"] for row in types}
        if not entities_by_kind and not relations_by_type:
            return {"database": str(db_path), "world": world,
                    "note": "no project map has been recorded yet"}
        return {"database": str(db_path), "world": world,
                "summary": {"entities": entities_by_kind,
                            "relations": relations_by_type}}
    finally:
        connection.close()


@tool(ToolSpec(
    name="scene.fixplan",
    category=READ,
    summary="Turn scene findings into a concrete fix plan the editor fixer can execute.",
    parameters=(
        Parameter("project_root", PATH_KIND, required=False, default=None),
        Parameter("report", PATH_KIND, required=False, default=None,
                  description="Scene report to read; defaults to the project location."),
        Parameter("scene", STRING, required=False, default=None,
                  description="Scene asset path the plan applies to."),
    ),
    returns="a fix plan: ordered fixes, each naming the finding it resolves",
    reversible=True,
    requires=("a scene report produced by the editor probe",),
    notes="This tool only plans. Applying the plan happens in the editor, not here.",
))
def _scene_fixplan(params: dict) -> dict:
    context = current_context()
    project = params.get("project_root") or (str(context.project_root) if context.project_root else None)
    if not project:
        raise ToolError("project_root is required, or configure one on the brain")
    project_path = Path(str(project)).expanduser().resolve()
    report_path = Path(params["report"]) if params.get("report") else \
        project_path / "AICore" / "outputs" / "scene" / "scene-report.json"
    report_path = report_path.expanduser()
    if not report_path.is_absolute():
        report_path = project_path / report_path
    report_path = report_path.resolve()
    if context.confine and not _path_inside(report_path, project_path):
        raise ToolError("report must stay inside the configured project root")
    if not report_path.is_file():
        raise ToolError("scene report not found: %s - run the editor probe first" % report_path)
    try:
        payload = json.loads(report_path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise ToolError("scene report is unreadable: %s" % error)
    fixes = []
    unresolved = []
    for finding in payload.get("findings") or []:
        if not isinstance(finding, dict):
            continue
        finding_id = str(finding.get("id"))
        spec = SCENE_FIX_MAP.get(finding_id)
        if spec is None:
            unresolved.append(finding_id)
            continue
        fixes.append({"id": "fix." + finding_id, "finding": finding_id,
                      "action": spec["action"], "component": spec.get("component", ""),
                      "severity": finding.get("severity", ""), "risk": spec["risk"],
                      "reversible": True, "evidence": finding.get("evidence", "")})
    fixes.sort(key=lambda item: (diagnostics.SEVERITY_RANK.get(item["severity"], 9), item["id"]))
    scene = params.get("scene") or payload.get("scene") or ""
    plan_seed = "%s|%s" % (scene, report_path.name)
    return {"plan_id": "fix_" + hashlib.sha256(plan_seed.encode("utf-8")).hexdigest()[:16],
            "scene": scene, "source_report": str(report_path),
            "generated_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "fixes": fixes, "unresolved_findings": sorted(set(unresolved)),
            "note": "planning only: apply with AICoreSceneFixer inside the editor, dry-run first"}


SEVERITIES = ("critical", "error", "warning", "info")


@tool(ToolSpec(
    name="unity.scene.report",
    category=READ,
    summary="Read the scene report produced by the editor probe (AICoreSceneProbe).",
    parameters=(
        Parameter("report", PATH_KIND, required=False, default=None,
                  description="Explicit path to scene-report.json."),
        Parameter("project_root", PATH_KIND, required=False, default=None,
                  description="Unity project root; used to locate the default report path."),
        Parameter("severity", STRING, required=False, default=None,
                  description="Optional filter: critical | error | warning | info."),
        Parameter("limit", INTEGER, required=False, default=50,
                  description="Maximum findings to return (1..500)."),
    ),
    returns="probe summary, report metadata and findings",
    reversible=True,
    requires=("the editor probe has run at least once",),
    notes="The editor probe writes the report; this tool only reads it.",
))
def _unity_scene_report(params: dict) -> dict:
    explicit = params.get("report")
    if explicit:
        path = Path(explicit)
    elif params.get("project_root"):
        path = Path(params["project_root"]) / "AICore" / "outputs" / "scene" / "scene-report.json"
    else:
        raise ToolError("pass report=<path> or project_root=<path>")
    if not path.is_file():
        raise ToolError(
            "scene report not found: %s - run the editor probe (menu "
            "AICore/Probe/Write Scene Report, or -executeMethod "
            "AliTerra.AICore.Editor.AICoreSceneProbe.RunBatch)" % path)
    severity = params.get("severity")
    if severity is not None and severity not in SEVERITIES:
        raise ToolError("severity must be one of: %s" % ", ".join(SEVERITIES))
    limit = params.get("limit") or 50
    if limit < 1 or limit > 500:
        raise ToolError("limit must be between 1 and 500")
    try:
        with open(path, "r", encoding="utf-8") as handle:
            payload = json.load(handle)
    except (OSError, ValueError) as error:
        raise ToolError("scene report is unreadable: %s" % error)
    if not isinstance(payload, dict) or "findings" not in payload:
        raise ToolError("scene report has an unexpected shape")
    findings = list(payload.get("findings") or [])
    if severity:
        findings = [item for item in findings if item.get("severity") == severity]
    stat = path.stat()
    return {"report": str(path), "generated_utc": payload.get("generated_utc"),
            "unity_version": payload.get("unity_version"),
            "report_age_seconds": int(max(0, time.time() - stat.st_mtime)),
            "summary": payload.get("summary"), "count": len(findings),
            "findings": findings[:limit]}


def specs() -> list[ToolSpec]:
    return [_SPECS[name] for name in sorted(_SPECS)]


def get(name: str) -> ToolSpec:
    spec = _SPECS.get(name)
    if spec is None:
        raise ToolError(f"unknown tool: {name}")
    return spec


def schema() -> dict:
    return {"toolbox_version": TOOLBOX_VERSION, "read_only": True,
            "tools": [spec.as_dict() for spec in specs()]}


def execute_scoped(name: str, params: dict | None = None, *, project_root=None,
                    db_path=None, confine: bool = True,
                    allow_write: bool = False,
                    approval: str | None = None) -> ToolResult:
    """Run one tool, optionally confining every caller-supplied path to a root.

    ``confine`` is what makes an HTTP bridge safe: when it is on, the caller cannot
    point a tool at an arbitrary directory. ``project_root`` and ``db`` are forced to
    the configured values, and every other path parameter must resolve inside the root.
    """
    try:
        spec = get(name)
    except ToolError as error:
        return ToolResult(tool=name, ok=False, read_only=True, error=str(error))
    if spec.category != READ and not allow_write:
        return ToolResult(tool=name, ok=False, read_only=False,
                          error=f"'{name}' is a {spec.category} tool; only read-only tools are exposed")
    names = {parameter.name for parameter in spec.parameters}
    try:
        root = Path(str(project_root)).expanduser().resolve() if project_root else None
        database = Path(str(db_path)).expanduser().resolve() if db_path else None
        needs_root = any(parameter.kind == PATH_KIND and parameter.name != "db"
                         for parameter in spec.parameters)
        if confine and root is None and needs_root:
            raise ToolError("this tool needs a path and the brain has no configured project root; "
                            "start it with --project")
        supplied = dict(params or {})
        if root is not None and "project_root" in names and "project_root" not in supplied:
            supplied["project_root"] = str(root)
        if database is not None and "db" in names and "db" not in supplied:
            supplied["db"] = str(database)
        cleaned = validate_parameters(spec, supplied)
        if root is not None and "project_root" in names:
            cleaned["project_root"] = str(root)
        if database is not None and "db" in names:
            cleaned["db"] = str(database)
        if root is not None:
            for parameter in spec.parameters:
                if parameter.kind != PATH_KIND or parameter.name in ("project_root", "db"):
                    continue
                value = cleaned.get(parameter.name)
                if value is None:
                    continue
                candidate = Path(str(value)).expanduser()
                if not candidate.is_absolute():
                    candidate = root / candidate
                candidate = candidate.resolve()
                if not _path_inside(candidate, root):
                    raise ToolError("%s must stay inside the configured project root" % parameter.name)
                cleaned[parameter.name] = str(candidate)
    except ToolError as error:
        return ToolResult(tool=name, ok=False, read_only=spec.category == READ, error=str(error))
    global _CONTEXT
    if approval is None:
        approval = os.environ.get("AICORE_APPROVAL_TOKEN") or None
    previous_context = _CONTEXT
    _CONTEXT = ToolContext(project_root=root, db_path=database, confine=confine,
                           operators=_as_directory(approval))
    started = time.perf_counter()
    try:
        data = _HANDLERS[name](cleaned)
    except ToolError as error:
        return ToolResult(tool=name, ok=False, read_only=spec.category == READ, error=str(error),
                          duration_ms=int((time.perf_counter() - started) * 1000))
    except Exception as error:  # pragma: no cover - defensive
        return ToolResult(tool=name, ok=False, read_only=spec.category == READ,
                          error=f"{type(error).__name__}: {error}",
                          duration_ms=int((time.perf_counter() - started) * 1000))
    return ToolResult(tool=name, ok=True, data=data, read_only=spec.category == READ,
                      duration_ms=int((time.perf_counter() - started) * 1000))


def _path_inside(child: Path, parent: Path) -> bool:
    """True when child is parent itself or sits underneath it."""
    try:
        child.relative_to(parent)
        return True
    except ValueError:
        return False


def execute(name: str, params: dict | None = None, *, allow_write: bool = False,
            project_root=None) -> ToolResult:
    """Run one tool from the command line: no path confinement, but the same gates.

    Write tools still need ``allow_write`` and a valid approval token, and they still
    refuse to touch anything outside ``AICore/outputs``.
    """
    return execute_scoped(name, params, project_root=project_root, confine=False,
                          allow_write=allow_write)


def main(argv: list[str] | None = None) -> int:  # pragma: no cover - convenience
    payload = sys.argv[1:] if argv is None else argv
    print(json.dumps(schema(), indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
