"""Command line entry point for the AICore read-only diagnostics observer.

Usage (from ``AICore/WorldDirector``)::

    python brain\\diagnose.py --project "<root>" [--logs <file>[,<file>...]] --out "<dir>" \\
        [--persist] [--db "<path>"] [--world "<id>"] [--json]

Default behaviour is strictly read-only: the project is inspected, the logs are
read, and the only writes are ``diagnose-<UTC>.json`` plus ``diagnose-<UTC>.md``
inside ``--out``. Nothing is written to the brain database unless ``--persist``
is passed together with ``--db`` and ``--world``.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import diagnostics  # noqa: E402 - imported after sys.path setup so the CLI is runnable directly


def _split_logs(values: list[str]) -> list[str]:
    paths: list[str] = []
    for value in values:
        for item in value.split(","):
            item = item.strip()
            if item:
                paths.append(item)
    return paths


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="diagnose.py",
        description="Read-only AICore diagnostic observer: parse Unity logs and inspect "
                    "the project layout, then write a report. Nothing in the project is modified.",
    )
    parser.add_argument("--project", required=True,
                        help="Unity project root (the directory containing Assets/ and ProjectSettings/).")
    # --logs is optional: without it the observer discovers the Unity editor console.
    parser.add_argument("--logs", action="append", default=None, metavar="PATH[,PATH...]",
                        help="Log file(s) to analyse. Repeat the flag or separate paths with commas.")
    parser.add_argument("--out", required=True,
                        help="Directory for the generated diagnose-<UTC>.json/.md reports.")
    parser.add_argument("--persist", action="store_true",
                        help="Also store findings as facts in the brain database (opt-in writes).")
    parser.add_argument("--db", default=None, help="Path to the brain SQLite database (required with --persist).")
    parser.add_argument("--world", default=None, help="World id for knowledge facts (required with --persist).")
    parser.add_argument("--json", action="store_true",
                        help="Print the full JSON report to stdout instead of the short summary.")
    return parser


def summary_lines(report: dict) -> list[str]:
    summary = report["summary"]
    lines = [
        "Диагностика AICore (только чтение)",
        f"  проект: {report['project_root']}",
        f"  логи: {len(report['logs'])} файл(ов), {sum(item['lines'] for item in report['logs'])} строк",
        f"  редактор: {report['project'].get('editor_version') or '—'}",
        f"  находки: {summary['findings']} "
        f"(critical {summary['critical']}, error {summary['error']}, "
        f"warning {summary['warning']}, info {summary['info']})",
    ]
    for finding in report["findings"][:10]:
        location = finding["evidence"][0] if finding["evidence"] else None
        where = f"{location['file']}:{location['line']}" if location else "—"
        repeat = f" x{finding['occurrences']}" if finding["occurrences"] > 1 else ""
        lines.append(f"  [{finding['severity']}] {finding['category']}: {finding['title']}"
                     f"{repeat} ({where})")
    if len(report["findings"]) > 10:
        lines.append(f"  … ещё {len(report['findings']) - 10} находок в отчёте")
    if "artifacts" in report:
        lines.append(f"  отчёт: {report['artifacts']['json']}")
        lines.append(f"  отчёт: {report['artifacts']['markdown']}")
    if report.get("persist", {}).get("enabled"):
        persist = report["persist"]
        lines.append(f"  память: {persist['facts_written']} факт(ов) в {persist['database']} "
                     f"(world={persist['world']})")
    return lines


def main(argv: list[str] | None = None) -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):  # pragma: no cover - exotic consoles
            pass
    parser = build_parser()
    args = parser.parse_args(argv)
    log_paths = _split_logs(args.logs or [])
    if not log_paths:
        log_paths = diagnostics.default_console_logs(args.project)
    if not log_paths:
        parser.error("Nothing to analyse: pass --logs or run Unity so its console exists.")
    if args.persist and not args.db:
        parser.error("--persist requires --db.")
    if args.persist and not args.world:
        parser.error("--persist requires --world.")
    missing = [path for path in log_paths if not Path(path).is_file()]
    if missing:
        print(f"Log file not found: {', '.join(missing)}", file=sys.stderr)
        return 1
    try:
        report = diagnostics.run(args.project, log_paths, out_dir=args.out,
                                 db_path=args.db, world=args.world, persist=args.persist)
    except diagnostics.DiagnosticsError as error:
        print(f"Diagnostics refused the request: {error}", file=sys.stderr)
        return 1
    if args.json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        print("\n".join(summary_lines(report)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
