"""AICore local world director. Python 3.13+, standard library only.

Protocols v1/v2: bounded population maintenance, persistent goals/knowledge,
transactional replay and attributed placement feedback. No model training,
arbitrary code execution or arbitrary asset generation.
"""
from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import math
import os
import random
from pathlib import Path
import re
import sqlite3
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any

from goals import GoalManager, GoalError, validate_goal, MAX_GOALS
from knowledge import KnowledgeBase, KnowledgeError, validate_fact, validate_relation, CATEGORIES
from planner import MultiObjectivePlanner, validate_capabilities
import decide
import director_stage
import graphview
import llm as llm_core
import policy as policy_module
import schedule
import toolplan
import tools as toolbox
from copy import deepcopy
from urllib.parse import urlsplit, parse_qs

MAX_BODY = 1_048_576
ID = re.compile(r"[A-Za-z0-9_.:\-]{1,96}\Z")
STRATEGIES = ("compact", "spread")


class ProtocolError(ValueError):
    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.status = status


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ProtocolError(message)


def identifier(value: Any, label: str, optional: bool = False) -> None:
    require(isinstance(value, str) and ((optional and value == "") or bool(ID.fullmatch(value))),
            f"Invalid {label}.")


def integer(value: Any, label: str, low: int, high: int) -> None:
    require(type(value) is int and low <= value <= high, f"Invalid {label}.")


def number(value: Any, label: str) -> None:
    require(type(value) in (int, float), f"Invalid {label}.")
    try:
        finite = math.isfinite(value) and abs(value) <= 3.4e38
    except OverflowError:
        finite = False
    require(finite, f"Nonfinite or oversized {label}.")


def position(value: Any, label: str) -> None:
    require(isinstance(value, dict) and set(value) == {"x", "y", "z"}, f"Invalid {label}.")
    for axis in "xyz":
        number(value[axis], label + "." + axis)


def text(value: Any, label: str, limit: int) -> None:
    require(isinstance(value, str) and len(value) <= limit, f"Invalid {label}.")


def array(value: Any, label: str, limit: int) -> None:
    require(isinstance(value, list) and len(value) <= limit, f"Invalid {label}.")
    require(all(isinstance(item, dict) for item in value), f"Invalid {label} item.")


def validate_request(data: Any, expected_version: int = 1) -> dict:
    require(isinstance(data, dict), "Request must be an object.")
    require(type(data.get("protocol_version")) is int and data["protocol_version"] == expected_version,
            f"protocol_version {expected_version} is required for this endpoint.")
    for name in ("world_id", "session_id", "observation_id"):
        identifier(data.get(name), name)
    text(data.get("goal"), "goal", 2000)
    identifier(data.get("target_catalog_id"), "target_catalog_id", optional=True)
    integer(data.get("target_count"), "target_count", 0, 100)
    position(data.get("anchor"), "anchor")
    for name in ("allow_mutations", "entities_truncated"):
        require(type(data.get(name)) is bool, f"{name} must be a boolean.")
    require(type(data.get("allow_reactivation", False)) is bool, "allow_reactivation must be a boolean.")
    limits = data.get("limits")
    require(isinstance(limits, dict), "Execution limits are required.")
    for name in ("min", "max"):
        position(limits.get(name), "limits." + name)
    require(all(limits["min"][a] < limits["max"][a] for a in "xyz"), "Invalid bounds.")
    integer(limits.get("max_owned_entities"), "max_owned_entities", 0, 2_147_483_647)
    integer(limits.get("owned_entity_count"), "owned_entity_count", 0, 2_147_483_647)
    integer(limits.get("action_budget"), "action_budget", 0, 8)
    for name, limit in (("entities", 512), ("catalog", 128), ("results", 32), ("events", 32), ("feedback", 32)):
        array(data.get(name), name, limit)
    catalog_ids = set()
    for entry in data["catalog"]:
        identifier(entry.get("id"), "catalog.id")
        identifier(entry.get("kind"), "catalog.kind")
        require(entry["id"] not in catalog_ids, "Duplicate catalog ID.")
        catalog_ids.add(entry["id"])
    require(not data["target_catalog_id"] or data["target_catalog_id"] in catalog_ids, "Target is not in catalog.")
    require(data["target_count"] == 0 or bool(data["target_catalog_id"]), "A positive target needs a catalog ID.")
    entity_ids = set()
    for entry in data["entities"]:
        identifier(entry.get("id"), "entity.id")
        for name in ("catalog_id", "kind"):
            identifier(entry.get(name), "entity." + name)
        position(entry.get("position"), "entity.position")
        require(type(entry.get("active")) is bool and type(entry.get("owned")) is bool, "Entity flags must be booleans.")
        require(type(entry.get("reactivatable", False)) is bool, "entity.reactivatable must be a boolean.")
        require(entry["id"] not in entity_ids, "Duplicate entity ID.")
        entity_ids.add(entry["id"])
    observed_owned = sum(e["owned"] for e in data["entities"])
    require(observed_owned <= limits["owned_entity_count"],
            "Observed owned entities exceed reported ownership count.")
    require(data["entities_truncated"] or observed_owned == limits["owned_entity_count"],
            "Complete snapshot ownership count must match reported ownership count.")
    for entry in data["results"]:
        identifier(entry.get("action_id"), "result.action_id")
        require(entry.get("status") in ("executed", "failed", "rejected"), "Invalid action result status.")
        text(entry.get("message"), "result.message", 2000)
    for entry in data["events"]:
        identifier(entry.get("kind"), "event.kind")
        number(entry.get("value"), "event.value")
    for entry in data["feedback"]:
        identifier(entry.get("action_id"), "feedback.action_id")
        number(entry.get("reward"), "feedback.reward")
    if expected_version == 2:
        array(data.get("goals"), "goals", MAX_GOALS)
        array(data.get("knowledge_updates", []), "knowledge_updates", 100)
        array(data.get("relations", []), "relations", 50)
        require(not data.get("world_state"), "Use explicit knowledge_updates; world_state is not implemented.")
        seen_goals, seen_catalogs = set(), set()
        try:
            validate_capabilities(data.get("capabilities", {}))
            for raw_goal in data["goals"]:
                goal = validate_goal(raw_goal)
                require(goal["goal_id"] not in seen_goals, "Duplicate goal ID.")
                require(goal["catalog_id"] in catalog_ids, "Goal catalog is not approved.")
                require(goal["catalog_id"] not in seen_catalogs, "Conflicting goals for the same catalog.")
                seen_goals.add(goal["goal_id"])
                seen_catalogs.add(goal["catalog_id"])
            for fact in data.get("knowledge_updates", []):
                validate_fact(fact)
            for relation in data.get("relations", []):
                validate_relation(relation)
        except (GoalError, KnowledgeError, ValueError, OverflowError) as error:
            raise ProtocolError(str(error)) from error
    return data


def reject_constant(value: str) -> None:
    raise ProtocolError("Nonfinite JSON constant is forbidden.")


def unique_object(pairs: list) -> dict:
    result = {}
    for key, value in pairs:
        require(key not in result, "Duplicate JSON key.")
        result[key] = value
    return result


def decode_request(raw: bytes, expected_version: int = 1) -> dict:
    require(len(raw) <= MAX_BODY, "Request is too large.")
    try:
        data = json.loads(raw.decode("utf-8"), parse_constant=reject_constant, object_pairs_hook=unique_object)
    except (UnicodeDecodeError, json.JSONDecodeError, RecursionError, ValueError) as error:
        if isinstance(error, ProtocolError):
            raise
        raise ProtocolError("Invalid UTF-8 JSON.") from error
    return validate_request(data, expected_version)


def canonical(data: Any) -> str:
    return json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False)


def _as_int(value: Any) -> int | None:
    """Best-effort integer, used when reading numbers out of published knowledge."""
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        try:
            return int(value.strip())
        except ValueError:
            return None
    return None


class Brain:
    """Transactionally cache plans and learn only from attributed executed actions.

    IDs are scoped by world AND session. Reusing an observation ID with different
    contents is a conflict, never a second plan. No request can execute system code.
    """
    def __init__(self, database: str | Path):
        # Optional LLM planning core (AICORE_LLM, off by default). Validated before
        # any resource is opened so a bad environment fails startup cleanly.
        try:
            llm_config = llm_core.LLMConfig.from_env()
        except ValueError as error:
            raise SystemExit(str(error))
        self.path = str(database)
        self.lock = threading.RLock()
        self.db = sqlite3.connect(self.path, timeout=5, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=FULL")
        # Bounded storage; on exhaustion fail closed rather than forget replay IDs.
        self.db.execute("PRAGMA max_page_count=16384")
        self.db.executescript("""
            CREATE TABLE IF NOT EXISTS observations (
                world TEXT, session TEXT, observation TEXT, digest TEXT NOT NULL,
                response TEXT NOT NULL, events TEXT NOT NULL,
                created TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY(world, session, observation));
            CREATE TABLE IF NOT EXISTS actions (
                world TEXT, session TEXT, action TEXT, catalog TEXT, strategy TEXT,
                type TEXT, status TEXT, reward REAL,
                PRIMARY KEY(world, session, action));
            CREATE INDEX IF NOT EXISTS action_learning ON actions(world, catalog, strategy);
            CREATE TABLE IF NOT EXISTS learning (
                world TEXT, catalog TEXT, strategy TEXT, samples INTEGER NOT NULL,
                reward_sum REAL NOT NULL, PRIMARY KEY(world, catalog, strategy));
        """)
        self.db.commit()
        # Extended systems: goal management and knowledge base
        self.goals = GoalManager(self.db)
        self.knowledge = KnowledgeBase(self.db)
        # LLM proposals pass the same gates as the deterministic planner; on any
        # failure the deterministic planner runs instead.
        self.llm = (llm_core.LLMPlanner(llm_config) if llm_config.backend != "off" else None)
        director_stage.attach(self)

    def close(self) -> None:
        with self.lock:
            self.db.close()

    def tick(self, request: dict) -> dict:
        data = validate_request(request)
        encoded = canonical(data)
        digest = hashlib.sha256(encoded.encode("utf-8")).hexdigest()
        scope = (data["world_id"], data["session_id"])
        key = (*scope, data["observation_id"])
        with self.lock:
            try:
                self.db.execute("BEGIN IMMEDIATE")
                previous = self.db.execute(
                    "SELECT digest,response FROM observations WHERE world=? AND session=? AND observation=?", key).fetchone()
                if previous:
                    if previous["digest"] != digest:
                        raise ProtocolError("Observation ID already exists with different contents.", 409)
                    self.db.commit()
                    return json.loads(previous["response"])
                warnings = self._ingest(data, scope)
                actions, summary, strategy = self._plan(data, warnings)
                actions = self._backfill_catalog(actions, data, warnings)
                plan_id = "p_" + hashlib.sha256(
                    (canonical(key) + "|" + os.urandom(6).hex()).encode()).hexdigest()[:32]
                for index, action in enumerate(actions):
                    action["id"] = plan_id + "_" + str(index)
                    self.db.execute("INSERT INTO actions(world,session,action,catalog,strategy,type) VALUES(?,?,?,?,?,?)",
                                    (*scope, action["id"], action["catalog_id"], strategy, action["type"]))
                response = {"plan_id": plan_id, "observation_id": data["observation_id"],
                            "source": "local_population_v1", "summary": summary,
                            "actions": actions, "warnings": list(dict.fromkeys(warnings))[:32]}
                self.db.execute("INSERT INTO observations(world,session,observation,digest,response,events) VALUES(?,?,?,?,?,?)",
                                (*key, digest, canonical(response), canonical(data["events"])))
                self.db.commit()
                return response
            except BaseException:
                self.db.rollback()
                raise

    def tick_v2(self, request: dict) -> dict:
        """Atomic v2 tick: authoritative goals, memory, results and replay commit together."""
        data = validate_request(request, expected_version=2)
        digest = hashlib.sha256(canonical(data).encode("utf-8")).hexdigest()
        scope = (data["world_id"], data["session_id"])
        key = (*scope, data["observation_id"])
        with self.lock:
            try:
                self.db.execute("BEGIN IMMEDIATE")
                previous = self.db.execute(
                    "SELECT digest,response FROM observations WHERE world=? AND session=? AND observation=?", key).fetchone()
                if previous:
                    if previous["digest"] != digest:
                        raise ProtocolError("Observation ID already exists with different contents.", 409)
                    self.db.commit()
                    return json.loads(previous["response"])
                self.goals.sync(*scope, [validate_goal(g) for g in data["goals"]])
                for fact in data.get("knowledge_updates", []):
                    self.knowledge.upsert_fact(scope[0], fact, commit=False)
                for relation in data.get("relations", []):
                    self.knowledge.upsert_relation(scope[0], relation, commit=False)
                warnings = self._ingest(data, scope)
                actions, summary = self._plan_multi(data, scope, warnings)
                actions = self._backfill_catalog(actions, data, warnings)
                # Protocol cap: the game rejects plans with more than MaxActions(8) items,
                # and a rejected-but-committed response poisons the retry loop forever.
                cap = min(int(data["limits"].get("action_budget", 8)), 8)
                if len(actions) > cap:
                    warnings.append("Trimmed plan from %d to %d actions to fit the protocol cap."
                                    % (len(actions), cap))
                    actions = actions[:cap]
                plan_id = "p2_" + hashlib.sha256(
                    (canonical(key) + "|" + os.urandom(6).hex()).encode()).hexdigest()[:32]
                for index, action in enumerate(actions):
                    action["id"] = plan_id + "_" + str(index)
                    strategy = action.pop("_strategy", "")
                    self.db.execute(
                        "INSERT INTO actions(world,session,action,catalog,strategy,type) VALUES(?,?,?,?,?,?)",
                        (*scope, action["id"], action["catalog_id"], strategy, action["type"]))
                memory = self.knowledge.world_summary(scope[0])
                response = {
                    "plan_id": plan_id, "observation_id": data["observation_id"],
                    "source": "multi_objective_v2", "summary": summary[:4000], "actions": actions,
                    "warnings": list(dict.fromkeys(warnings))[:32], "goal_stats": self.goals.stats(*scope),
                    "knowledge_summary": {k: memory[k] for k in ("fact_count", "relation_count", "pattern_count", "categories")},
                    "tool_calls": self._recommend_tools(data, scope)}
                self.db.execute(
                    "INSERT INTO observations(world,session,observation,digest,response,events) VALUES(?,?,?,?,?,?)",
                    (*key, digest, canonical(response), canonical(data["events"])))
                self.db.commit()
                return response
            except BaseException:
                self.db.rollback()
                raise

    def _plan_multi(self, data: dict, scope: tuple, warnings: list) -> tuple[list, str]:
        if data["entities_truncated"]:
            warnings.append("Snapshot is incomplete; refusing to infer population.")
            return [], "No action on a truncated world snapshot."
        # Satisfaction is an observed state, not a neural or gameplay reward.
        goals = self.goals.all_goals(*scope)
        for goal in goals:
            count = sum(e["owned"] and e["active"] and e["catalog_id"] == goal["catalog_id"] for e in data["entities"])
            status, _ = self.goals.check_satisfaction(*scope, goal, count)
            if status != goal["status"]:
                self.goals.update_status(*scope, goal["goal_id"], status, commit=False)
            goal["status"] = status
        if not data["allow_mutations"]:
            return [], "Observing only; mutation permission is off."
        if not goals:
            return [], "No explicit goals; observing only."
        capabilities = validate_capabilities(data.get("capabilities", {}))["action_types"]
        if not capabilities or data["limits"]["action_budget"] == 0:
            return [], "No action budget or permitted capabilities."
        if self.llm is not None:
            try:
                knowledge = self.knowledge.query_facts(scope[0], limit=32)
            except Exception:
                knowledge = None
            llm_actions, llm_summary, llm_warnings = self.llm.plan(
                data, goals, capabilities, knowledge=knowledge)
            warnings.extend(llm_warnings)
            if llm_actions is not None:
                # Guard: the LLM may over-deliver on goals already met.
                satisfied_catalogs = {g["catalog_id"] for g in goals if g["status"] == "satisfied"}
                excess = [a for a in llm_actions
                          if a["type"] == "spawn" and a.get("catalog_id") in satisfied_catalogs]
                if excess:
                    warnings.append("Dropped %d spawn(s): goal already satisfied." % len(excess))
                    llm_actions = [a for a in llm_actions if a not in excess]
                    llm_summary = (llm_summary + " | %d over-spawn(s) dropped" % len(excess)).strip(" |")
                if not llm_actions:  # a satisfied world still walks its NPCs
                    llm_actions = self._plan_wander(data, capabilities)
                    if llm_actions:
                        llm_summary = (llm_summary + " | wander: %d walker(s)"
                                       % len(llm_actions)).strip(" |")
                return llm_actions, "[%s] %s" % (self.llm.describe(), llm_summary)
            warnings.append("LLM planning core produced no valid plan; deterministic planner used.")
        projected = deepcopy(data)
        # Reuse the vetted single-target planner and reserve resources across goals.
        allocations = MultiObjectivePlanner.allocate_budget(goals, data["limits"]["action_budget"])
        actions, summaries = [], []
        for goal in allocations:
            if goal["status"] != "active" or not goal["allocated_budget"]:
                continue
            projected["target_catalog_id"] = goal["catalog_id"]
            projected["target_count"] = goal["target_count"]
            projected["limits"]["action_budget"] = goal["allocated_budget"]
            projected["allow_reactivation"] = data.get("allow_reactivation", False) and "activate" in capabilities
            if "spawn" not in capabilities:
                projected["limits"]["max_owned_entities"] = projected["limits"]["owned_entity_count"]
            proposed, summary, strategy = self._plan(projected, warnings)
            summaries.append(goal["goal_id"] + ": " + summary)
            for action in proposed:
                if action["type"] not in capabilities:
                    warnings.append("Action omitted because the game did not advertise its capability.")
                    continue
                action["goal_id"] = goal["goal_id"]
                action["_strategy"] = strategy if action["type"] == "spawn" else ""
                actions.append(action)
                if action["type"] == "spawn":
                    projected["limits"]["owned_entity_count"] += 1
                    kind = next(c["kind"] for c in data["catalog"] if c["id"] == action["catalog_id"])
                    projected["entities"].append({"id": "projected-" + str(len(actions)),
                        "catalog_id": action["catalog_id"], "kind": kind, "owned": True,
                        "active": True, "position": action["position"]})
                elif action["type"] in ("activate", "deactivate"):
                    target = next(e for e in projected["entities"] if e["id"] == action["target_id"])
                    target["active"] = action["type"] == "activate"
        leftover = max(0, data["limits"]["action_budget"] - len(actions))
        wander = self._plan_wander(data, capabilities, leftover)
        actions.extend(wander)
        if wander:
            summaries.append("npc.mobility: %d walker(s) moving" % len(wander))
        return actions, " | ".join(summaries) if summaries else "All enabled goals are satisfied or paused."

    WANDER_STEP = 4.0
    WANDER_JITTER = 1.5

    def _plan_wander(self, data: dict, capabilities: tuple, remaining: int | None = None) -> list:
        """Stage A: short steps toward already-placed owned props so NPCs stay
        on the mesh the city already occupies, never a random point in bounds."""
        budget = data["limits"]["action_budget"] if remaining is None else remaining
        if "move" not in capabilities or budget <= 0:
            return []
        walkers = [e for e in data["entities"]
                   if e.get("owned") and e.get("active") and e.get("kind") == "npc"]
        if not walkers:
            return []
        lo, hi = data["limits"]["min"], data["limits"]["max"]

        def _inside(entity: dict) -> bool:
            point = entity.get("position") or {}
            try:
                return all(lo[axis] <= float(point[axis]) <= hi[axis] for axis in "xyz")
            except (KeyError, TypeError, ValueError):
                return False

        anchors = [e for e in data["entities"]
                   if e.get("owned") and e.get("kind") != "npc" and e.get("kind") != "player"
                   and e.get("position") and _inside(e)]
        chosen = random.sample(walkers, min(2, len(walkers), int(budget)))
        moves = []
        for entity in chosen:
            current = entity.get("position") or {"x": 0.0, "y": 0.0, "z": 0.0}
            target = self._wander_target(current, anchors, lo, hi)
            moves.append({"type": "move", "catalog_id": entity["catalog_id"],
                          "target_id": entity["id"], "position": target,
                          "goal_id": "npc.mobility", "_strategy": "wander",
                          "reason": "Stage A: short step toward existing city props."})
        return moves

    def _wander_target(self, current: dict, anchors: list, lo: dict, hi: dict) -> dict:
        cx = float(current.get("x", 0.0))
        cz = float(current.get("z", 0.0))
        cy = float(current.get("y", 0.0))
        far = []
        for anchor in anchors:
            point = anchor.get("position") or {}
            dx = float(point.get("x", 0.0)) - cx
            dz = float(point.get("z", 0.0)) - cz
            distance = math.hypot(dx, dz)
            if distance > 2.0:
                far.append((distance, dx, dz))
        if far:
            distance, dx, dz = min(far, key=lambda item: item[0])
            scale = min(self.WANDER_STEP / distance, 1.0)
            tx, tz = cx + dx * scale, cz + dz * scale
        else:
            angle = random.random() * 6.283185307179586
            radius = self.WANDER_JITTER if anchors else self.WANDER_STEP
            tx = cx + math.cos(angle) * radius
            tz = cz + math.sin(angle) * radius
        return {
            "x": round(max(lo["x"], min(hi["x"], tx)), 2),
            "y": round(max(lo["y"], min(hi["y"], cy)), 2),
            "z": round(max(lo["z"], min(hi["z"], tz)), 2),
        }

    def _backfill_catalog(self, actions: list, data: dict, warnings: list) -> list:
        """Guarantee catalog_id on every action before INSERT: the LLM core
        may emit move/deactivate plans without it (target entities always know)."""
        by_target = {e["id"]: e["catalog_id"] for e in data["entities"]}
        kept = []
        for action in actions:
            if not action.get("catalog_id"):
                guess = by_target.get(action.get("target_id"))
                if guess:
                    action["catalog_id"] = guess
                else:
                    warnings.append("Dropped %s action: no catalog_id and unknown target."
                                    % action.get("type", "?"))
                    continue
            kept.append(action)
        return kept

    def _ingest(self, data: dict, scope: tuple) -> list[str]:
        warnings = []
        for result in data["results"]:
            row = self.db.execute("SELECT status FROM actions WHERE world=? AND session=? AND action=?",
                                  (*scope, result["action_id"])).fetchone()
            if row is None:
                warnings.append("Unknown result ignored; it may belong to an older database.")
            elif row["status"] is None:
                self.db.execute("UPDATE actions SET status=? WHERE world=? AND session=? AND action=?",
                                (result["status"], *scope, result["action_id"]))
            elif row["status"] != result["status"]:
                warnings.append("Conflicting result ignored; first terminal status retained.")
        for rating in data["feedback"]:
            row = self.db.execute("SELECT * FROM actions WHERE world=? AND session=? AND action=?",
                                  (*scope, rating["action_id"])).fetchone()
            if row is None or row["status"] != "executed":
                warnings.append("Feedback requires an executed action in this world/session; ignored.")
                continue
            if row["reward"] is not None:
                continue
            reward = max(-1.0, min(1.0, float(rating["reward"])))
            if reward != rating["reward"]:
                warnings.append("Feedback reward was clamped to [-1, 1].")
            self.db.execute("UPDATE actions SET reward=? WHERE world=? AND session=? AND action=?",
                            (reward, *scope, rating["action_id"]))
            if row["type"] == "spawn" and row["strategy"] in STRATEGIES:
                self.db.execute("""INSERT INTO learning VALUES(?,?,?,?,?)
                    ON CONFLICT(world,catalog,strategy) DO UPDATE SET
                    samples=samples+1,reward_sum=reward_sum+excluded.reward_sum""",
                                (scope[0], row["catalog"], row["strategy"], 1, reward))
        return warnings

    def _strategy(self, world: str, catalog: str) -> str:
        rows = {row["strategy"]: row for row in self.db.execute(
            "SELECT * FROM learning WHERE world=? AND catalog=?", (world, catalog))}
        issued = {row["strategy"]: row["count"] for row in self.db.execute(
            "SELECT strategy,COUNT(*) AS count FROM actions WHERE world=? AND catalog=? AND type='spawn' GROUP BY strategy",
            (world, catalog))}
        total = sum(row["samples"] for row in rows.values())
        def score(strategy: str) -> tuple:
            row = rows.get(strategy)
            # Explore unrated strategies, alternating by issued count if no feedback exists.
            if row is None:
                return (1, -issued.get(strategy, 0))
            mean = row["reward_sum"] / row["samples"]
            return (0, mean + math.sqrt(2 * math.log(max(2, total)) / row["samples"]))
        return max(STRATEGIES, key=score)

    @staticmethod
    def _inside(point: dict, limits: dict) -> bool:
        return all(limits["min"][a] <= point[a] <= limits["max"][a] for a in "xyz")

    @staticmethod
    def _ground_y(data: dict) -> float:
        """Prefer street-level Y from live entities; never copy a floating anchor."""
        heights = [float(e["position"]["y"]) for e in data.get("entities", [])
                   if e.get("active") and isinstance(e.get("position"), dict)
                   and -2.0 <= float(e["position"].get("y", 99)) <= 4.0]
        if heights:
            heights.sort()
            return round(heights[len(heights) // 2], 2)
        return 0.0

    def _plan(self, data: dict, warnings: list[str]) -> tuple[list, str, str]:
        if not data["allow_mutations"]:
            return [], "Observing only; mutation permission is off.", ""
        if data["entities_truncated"]:
            warnings.append("Snapshot is incomplete; refusing to infer population.")
            return [], "No action on a truncated world snapshot.", ""
        target = data["target_catalog_id"]
        if not target:
            return [], "No explicit population target configured.", ""
        limits = data["limits"]
        budget = limits["action_budget"]
        entry = next(item for item in data["catalog"] if item["id"] == target)
        if entry["kind"].lower() == "player":
            warnings.append("Player catalogs cannot be controlled.")
            return [], "Protected catalog; no actions.", ""
        population = sorted((e for e in data["entities"] if e["owned"] and e["active"]
                             and e["catalog_id"] == target), key=lambda e: e["id"])
        difference = data["target_count"] - len(population)
        if difference == 0:
            return [], f"Target satisfied: {len(population)} active owned entities.", ""
        if budget == 0:
            return [], "Waiting for execution budget.", ""
        if difference < 0:
            eligible = [e for e in population if e["kind"].lower() != "player" and self._inside(e["position"], limits)]
            actions = [{"type": "deactivate", "catalog_id": target, "target_id": e["id"],
                        "reason": "Reduce active owned population to the explicit target."}
                       for e in eligible[:min(-difference, budget)]]
            warnings.append("Deactivated roots still consume the ownership cap; no automatic deletion.")
            return actions, f"Proposing {len(actions)} deactivations.", ""
        reactivations = []
        if data.get("allow_reactivation", False):
            reactivations = sorted((e for e in data["entities"] if e["owned"] and not e["active"]
                                    and e.get("reactivatable", False) and e["catalog_id"] == target
                                    and e["kind"].lower() != "player" and self._inside(e["position"], limits)),
                                   key=lambda e: e["id"])[:min(difference, budget)]
        actions = [{"type": "activate", "catalog_id": target, "target_id": e["id"],
                    "reason": "Reuse an inactive owned entity to meet the explicit population target."}
                   for e in reactivations]
        capacity = max(0, limits["max_owned_entities"] - limits["owned_entity_count"])
        remaining = min(difference - len(reactivations), budget - len(reactivations))
        count = min(remaining, capacity)
        if remaining > capacity:
            warnings.append("Ownership cap reached, including inactive roots.")
        strategy = self._strategy(data["world_id"], target) if count else ""
        decoration = entry["kind"].lower() != "npc"
        spacing = (8.0 if strategy == "compact" else 14.0) if decoration else (2.0 if strategy == "compact" else 5.0)
        occupied = [e["position"] for e in data["entities"] if e["active"]]
        occupied.extend(e["position"] for e in reactivations)
        ground_y = self._ground_y(data)
        seeds = [e["position"] for e in data["entities"]
                 if e["active"] and -2.0 <= float(e["position"].get("y", 0)) <= 4.0]
        if not seeds:
            seeds = [{"x": data["anchor"]["x"], "y": ground_y, "z": data["anchor"]["z"]}]
        spawn_count = 0
        # Street-level placement: keep Y on observed ground, spread on XZ.
        # Not a collider/navmesh guarantee — Unity SnapToGround is the hard snap.
        for slot in range(512):
            if spawn_count >= count:
                break
            seed = seeds[slot % len(seeds)]
            radius = spacing * math.sqrt((slot // len(seeds)) + 1)
            angle = slot * 2.399963229728653
            point = {"x": float(seed["x"]) + radius * math.cos(angle),
                     "y": ground_y,
                     "z": float(seed["z"]) + radius * math.sin(angle)}
            if not self._inside(point, limits):
                continue
            if any(sum((point[a] - other[a]) ** 2 for a in "xyz") < (spacing * 0.6) ** 2 for other in occupied):
                continue
            actions.append({"type": "spawn", "catalog_id": target, "target_id": "", "position": point,
                            "reason": f"Maintain explicit population target using {strategy} street-level placement."})
            occupied.append(point)
            spawn_count += 1
        if spawn_count < count:
            warnings.append("Not enough bounded point-separated positions; fewer spawns proposed.")
        placement = f" ({strategy})" if spawn_count else ""
        summary = (f"Active owned population {len(population)}/{data['target_count']}; proposing "
                   f"{len(reactivations)} activations and {spawn_count} spawns{placement}.")
        if len(actions) < difference:
            summary += " Population deficit remains."
        return actions, summary, strategy

    def _recommend_tools(self, data: dict, scope: tuple) -> list:
        """Which read-only tools the plan suggests running, from what the brain knows.

        The brain does not guess: failed results of this very tick make it want the
        diagnostics, and numbers published as knowledge (console errors, scene report
        age) decide the rest. Selection itself lives in toolplan.
        """
        failed = [item for item in data.get("results", [])
                  if isinstance(item, dict)
                  and str(item.get("status", "")).lower() in ("failed", "rejected", "error")]
        facts = {}
        try:
            for row in self.knowledge.query_facts(scope[0], "", "", 200):
                facts[str(row.get("key"))] = row.get("value")
        except sqlite3.Error:
            facts = {}
        state = {"findings": [{"severity": "error"} for _ in failed],
                 "console_errors": _as_int(facts.get("console.errors")),
                 "scene_report_age": _as_int(facts.get("scene.report.age_seconds")),
                 "diagnostics_seen": "diagnostics.last_run" in facts}
        available = {spec.name for spec in toolbox.specs()}
        try:
            return toolplan.recommend(state, available, budget=3)["recommended"]
        except ValueError:
            return []

    def store_fix_plan(self, world: str, session: str, plan: dict) -> str:
        """Keep a prepared plan in the brain's own database. Returns its id, or ""."""
        plan_id = str((plan or {}).get("plan_id") or "")
        if not plan_id:
            return ""
        with self.lock:
            self.db.execute(
                "CREATE TABLE IF NOT EXISTS fix_plans "
                "(world TEXT, session TEXT, plan_id TEXT, plan TEXT, prepared REAL, "
                "PRIMARY KEY (world, session, plan_id))")
            self.db.execute(
                "INSERT OR REPLACE INTO fix_plans(world, session, plan_id, plan, prepared) "
                "VALUES(?,?,?,?,?)",
                (world, session, plan_id, canonical(plan), time.time()))
            self.db.commit()
        return plan_id

    def pending_fix_plans(self, world: str, limit: int = 10) -> list:
        """The plans that were prepared and not yet superseded."""
        with self.lock:
            self.db.execute(
                "CREATE TABLE IF NOT EXISTS fix_plans "
                "(world TEXT, session TEXT, plan_id TEXT, plan TEXT, prepared REAL, "
                "PRIMARY KEY (world, session, plan_id))")
            rows = self.db.execute(
                "SELECT session, plan_id, plan, prepared FROM fix_plans WHERE world=? "
                "ORDER BY prepared DESC LIMIT ?", (world, limit)).fetchall()
        return [{"session": row["session"], "plan_id": row["plan_id"],
                 "prepared": row["prepared"], "plan": json.loads(row["plan"])} for row in rows]

    def _ensure_map_tables(self) -> None:
        self.db.execute(
            "CREATE TABLE IF NOT EXISTS map_entities "
            "(world TEXT, id TEXT, path TEXT, kind TEXT, name TEXT, mapped REAL, "
            "PRIMARY KEY (world, id))")
        self.db.execute(
            "CREATE TABLE IF NOT EXISTS fix_plans "
            "(world TEXT, session TEXT, plan_id TEXT, plan TEXT, prepared REAL, "
            "PRIMARY KEY (world, session, plan_id))")

    def store_map_entities(self, world: str, entities: list) -> int:
        """Keep the entities the map reported, so questions can name them."""
        now = time.time()
        stored = 0
        with self.lock:
            self._ensure_map_tables()
            for item in entities:
                if not isinstance(item, dict):
                    continue
                entity_id = str(item.get("id") or "")
                if not entity_id or len(entity_id) > 96:
                    continue
                self.db.execute(
                    "INSERT OR REPLACE INTO map_entities(world, id, path, kind, name, mapped) "
                    "VALUES(?,?,?,?,?,?)",
                    (world, entity_id, str(item.get("path") or ""), str(item.get("kind") or ""),
                     str(item.get("name") or ""), now))
                stored += 1
            self.db.commit()
        return stored

    def find_map_entities(self, world: str, text: str = "", kind: str = "",
                          limit: int = 50) -> list:
        with self.lock:
            self._ensure_map_tables()
            query = ("SELECT id, path, kind, name FROM map_entities WHERE world = ?")
            args = [world]
            if text:
                query += " AND (id LIKE ? OR path LIKE ? OR name LIKE ?)"
                like = "%" + text + "%"
                args.extend([like, like, like])
            if kind:
                query += " AND kind = ?"
                args.append(kind)
            query += " ORDER BY id LIMIT ?"
            args.append(limit)
            rows = self.db.execute(query, args).fetchall()
        return [{"id": row["id"], "path": row["path"], "kind": row["kind"],
                 "name": row["name"]} for row in rows]

    def related(self, world: str, entity_id: str, limit: int = 100) -> list:
        """Every relation that touches this entity, in either direction."""
        with self.lock:
            rows = self.db.execute(
                "SELECT source_id, target_id, type FROM relations "
                "WHERE world = ? AND (source_id = ? OR target_id = ?) "
                "ORDER BY type, source_id, target_id LIMIT ?",
                (world, entity_id, entity_id, limit)).fetchall()
        out = []
        for row in rows:
            out.append({"source": row["source_id"], "target": row["target_id"],
                        "type": row["type"],
                        "direction": "out" if row["source_id"] == entity_id else "in"})
        return out

    def map_summary(self, world: str) -> dict:
        with self.lock:
            self._ensure_map_tables()
            kinds = self.db.execute(
                "SELECT kind, COUNT(*) AS n FROM map_entities WHERE world = ? GROUP BY kind",
                (world,)).fetchall()
            types = self.db.execute(
                "SELECT type, COUNT(*) AS n FROM relations WHERE world = ? GROUP BY type",
                (world,)).fetchall()
        return {"entities": {row["kind"]: row["n"] for row in kinds},
                "relations": {row["type"]: row["n"] for row in types}}

    def stats(self) -> dict:
        with self.lock:
            return {"observations": self.db.execute("SELECT COUNT(*) FROM observations").fetchone()[0],
                    "actions": self.db.execute("SELECT COUNT(*) FROM actions").fetchone()[0],
                    "rated_actions": self.db.execute("SELECT COUNT(*) FROM actions WHERE reward IS NOT NULL").fetchone()[0],
                    "learning": [dict(row) for row in self.db.execute("SELECT * FROM learning ORDER BY world,catalog,strategy")]}


def ingest_project_map(brain, project_root, world: str, limit: int = 200,
                       report: str | None = None) -> dict:
    """Record the project map as knowledge relations.

    Read-only for the project: the map is written by the editor, and the only thing that
    changes here is the brain's own knowledge.
    """
    if project_root is None:
        return {"mapped": False, "reason": "no project root is configured"}
    path = Path(report) if report else \
        Path(str(project_root)) / "AICore" / "outputs" / "scene" / "project-map.json"
    if not path.is_file():
        return {"mapped": False, "reason": "no project map has been built yet"}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        return {"mapped": False, "reason": "the project map is unreadable: %s" % error}
    relations = payload.get("relations") or []
    entities = payload.get("entities") or []
    kept_entities = brain.store_map_entities(world, entities)
    stored = 0
    rejected = 0
    with brain.lock:
        for item in relations[:limit]:
            if not isinstance(item, dict):
                rejected += 1
                continue
            relation = {"source_id": str(item.get("source", "")),
                        "target_id": str(item.get("target", "")),
                        "type": str(item.get("type", "")), "strength": 1.0}
            try:
                validate_relation(relation)
                brain.knowledge.upsert_relation(world, relation, commit=False)
                stored += 1
            except (KnowledgeError, ValueError):
                rejected += 1
        brain.db.commit()
    return {"mapped": True, "report": str(path), "stored": stored, "rejected": rejected,
            "entities": len(entities), "kept_entities": kept_entities,
            "relations": len(relations),
            "truncated": bool((payload.get("summary") or {}).get("truncated"))}


def run_observation(brain, project_root, scope_db, world: str, session: str,
                    budget: int = 3, logs_override: list | None = None,
                    operators=None, act: bool = False,
                    fix_report: str | None = None) -> dict:
    """Run the readings the planner asks for, then record what came back.

    Read-only by construction: the planner only ever proposes read tools, and the
    single write is into the brain's own knowledge base.
    """
    scope = (world, session)
    calls = brain._recommend_tools({"results": []}, scope)[:budget]
    executed = []
    facts = []
    skipped = []
    findings_seen = []
    report_seen = None
    report_age_seen = None
    for call in calls:
        name = call["tool"]
        params = dict(call.get("params") or {})
        if name == "project.diagnostics" and logs_override:
            params["logs"] = logs_override
        if name == "brain.knowledge.facts":
            skipped.append(name)
            continue
        result = toolbox.execute_scoped(name, params, project_root=project_root,
                                        db_path=scope_db, confine=True,
                                        approval=operators)
        entry = {"tool": name, "ok": result.ok, "reason": call.get("reason", ""),
                 "error": result.error}
        executed.append(entry)
        if not result.ok:
            continue
        data = result.data if isinstance(result.data, dict) else {}
        stamp = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        if name == "project.diagnostics":
            summary = data.get("summary") or {}
            findings_seen = list(data.get("findings") or [])
            facts.extend([
                {"key": "diagnostics.last_run", "value": stamp, "category": "system", "confidence": 0.9},
                {"key": "diagnostics.findings", "value": int(summary.get("findings", 0)),
                 "category": "system", "confidence": 0.9},
                {"key": "diagnostics.critical", "value": int(summary.get("critical", 0)),
                 "category": "system", "confidence": 0.9},
                {"key": "diagnostics.error", "value": int(summary.get("error", 0)),
                 "category": "system", "confidence": 0.9},
            ])
        elif name == "unity.console.tail":
            facts.append({"key": "console.errors", "value": int(data.get("lines_returned", 0)),
                          "category": "system", "confidence": 0.8})
        elif name == "unity.scene.report":
            report_seen = data.get("report") or report_seen
            report_age_seen = _as_int(data.get("report_age_seconds"))
            facts.append({"key": "scene.report.age_seconds", "value": int(data.get("report_age_seconds", 0)),
                          "category": "system", "confidence": 0.8})
        elif name == "unity.project.inventory":
            facts.append({"key": "inventory.findings", "value": len(data.get("findings") or []),
                          "category": "system", "confidence": 0.8})
        entry["facts"] = len(facts)
    decision = None
    if act:
        decision, plan_data = _decide_what_to_do(brain, project_root, scope_db, operators,
                                                 findings_seen, fix_report or report_seen,
                                                 world, report_age_seen)
        if decision["action"] == decide.DECISION_FIX:
            prepared = brain.store_fix_plan(world, session, plan_data) if plan_data else ""
            decision["prepared"] = bool(prepared)
            decision["prepared_plan_id"] = prepared
            facts.extend([
                {"key": "fix.pending", "value": str(decision["plan_id"]), "category": "system",
                 "confidence": 0.8},
                {"key": "fix.actions", "value": int(decision["count"]), "category": "system",
                 "confidence": 0.8},
                {"key": "fix.risks", "value": ",".join(decision["risks"]), "category": "system",
                 "confidence": 0.6},
            ])
    mapped = ingest_project_map(brain, project_root, world)
    if mapped.get("mapped"):
        facts.extend([
            {"key": "map.entities", "value": int(mapped["entities"]), "category": "system",
             "confidence": 0.8},
            {"key": "map.relations", "value": int(mapped["stored"]), "category": "system",
             "confidence": 0.8},
        ])
    warnings = brain.knowledge.upsert_facts(world, facts) if facts else []
    result = {"world_id": world, "session_id": session, "budget": budget,
              "map": mapped,
              "tools": executed, "skipped": skipped,
              "facts_written": len(facts) - len(warnings),
              "facts_rejected": warnings, "recommended": [call["tool"] for call in calls]}
    if decision is not None:
        result["decision"] = decision
    return result


def _decide_what_to_do(brain, project_root, scope_db, operators, findings, fix_report,
                       world: str = "", report_age=None) -> tuple:
    """Ask for a fix plan and decide: fix, keep reading, or stop."""
    known = 0
    try:
        for row in brain.knowledge.query_facts(world, "", "", 200):
            if row.get("key") == "diagnostics.findings":
                known = _as_int(row.get("value")) or 0
    except sqlite3.Error:
        known = 0
    plan_params = {"scene": ""}
    if fix_report:
        plan_params["report"] = fix_report
    plan = toolbox.execute_scoped("scene.fixplan", plan_params, project_root=project_root,
                                  db_path=scope_db, confine=True, approval=operators)
    plan_data = plan.data if plan.ok and isinstance(plan.data, dict) else {}
    scene_context = None
    scene_path = (plan_data or {}).get("scene") or ""
    if scene_path:
        try:
            with brain.lock:
                rows = brain.db.execute(
                    "SELECT source_id, target_id, type FROM relations WHERE world = ?",
                    (world,)).fetchall()
            relations = [{"source": row["source_id"], "target": row["target_id"],
                          "type": row["type"]} for row in rows]
            scene_context = graphview.summarise(
                graphview.identifier("scene", scene_path), relations)
        except sqlite3.Error:
            scene_context = None
    decision = decide.decide(findings, plan_data, known_findings=known,
                             report_age_seconds=report_age, map_context=scene_context)
    if decision.get("action") == decide.DECISION_FIX:
        try:
            auto = policy_module.AutoApprovalPolicy.from_environment(os.environ)
            decision["auto_approval"] = auto.evaluate(
                plan_data,
                applied_recently=policy_module.count_recent_applies(
                    Path(str(project_root)) / "AI" / "aicore-writes.log"
                    if project_root is not None else Path("__none__")),
                map_context=scene_context)
        except (OSError, ValueError, sqlite3.Error):
            decision["auto_approval"] = {"allowed": False,
                                         "reasons": ["the policy could not be evaluated"]}
    decision["plan_ready"] = bool(plan.ok)
    if not plan.ok:
        decision["plan_error"] = plan.error
    return decision, plan_data


MAX_PUBLISHED_FACTS = 64


def _knowledge_publish(raw: bytes, brain) -> dict:
    """Store the facts a client can see live. Narrow by design."""
    try:
        payload = json.loads(raw.decode("utf-8"), parse_constant=reject_constant,
                             object_pairs_hook=unique_object)
    except ValueError as error:
        raise ProtocolError("Knowledge body is not valid JSON: %s" % error, 400)
    require(isinstance(payload, dict), "Knowledge body must be a JSON object.")
    unknown = sorted(set(payload) - {"world_id", "facts"})
    require(not unknown, "Unknown field(s) in the knowledge body: " + ", ".join(unknown))
    world = payload.get("world_id")
    identifier(world, "world_id")
    facts = payload.get("facts")
    require(isinstance(facts, list) and facts, "facts must be a non-empty list.")
    require(len(facts) <= MAX_PUBLISHED_FACTS,
            "at most %d facts may be published at once." % MAX_PUBLISHED_FACTS)
    accepted = []
    rejected = []
    for index, fact in enumerate(facts):
        try:
            accepted.append(validate_fact(fact))
        except KnowledgeError as error:
            rejected.append({"index": index, "error": str(error)})
    warnings = brain.knowledge.upsert_facts(world, accepted) if accepted else []
    summary = brain.knowledge.world_summary(world)
    return {"world_id": world, "accepted": len(accepted) - len(warnings),
            "rejected": rejected, "warnings": warnings,
            "fact_count": summary["fact_count"]}


def _observe(raw: bytes, brain, project_root, scope_db, logs_override, operators=None) -> dict:
    """Run the readings the planner asks for, then record what came back.

    Read-only by construction: the planner only ever proposes read tools, and the
    single write is into the brain's own knowledge base.
    """
    try:
        payload = json.loads(raw.decode("utf-8"), parse_constant=reject_constant,
                             object_pairs_hook=unique_object)
    except ValueError as error:
        raise ProtocolError("Observe body is not valid JSON: %s" % error, 400)
    require(isinstance(payload, dict), "Observe body must be a JSON object.")
    unknown = sorted(set(payload) - {"world_id", "session_id", "budget", "logs",
                                      "act", "fix_report"})
    require(not unknown, "Unknown field(s) in the observe body: " + ", ".join(unknown))
    act = bool(payload.get("act", False))
    fix_report = payload.get("fix_report")
    require(fix_report is None or isinstance(fix_report, str),
            "fix_report must be a path string.")
    world = payload.get("world_id")
    session = payload.get("session_id")
    identifier(world, "world_id")
    identifier(session, "session_id")
    budget = payload.get("budget", 3)
    integer(budget, "budget", 1, 8)
    requested = payload.get("logs")
    require(requested is None or (isinstance(requested, list) and len(requested) <= 16),
            "logs must be a list of at most 16 paths.")
    if requested:
        root = Path(str(project_root)).resolve() if project_root else None
        if root is None:
            raise ProtocolError("log paths cannot be used: the brain has no configured project root.", 400)
        logs_override = []
        for item in requested:
            candidate = Path(str(item)).expanduser()
            if not candidate.is_absolute():
                candidate = root / candidate
            candidate = candidate.resolve()
            try:
                candidate.relative_to(root)
            except ValueError:
                raise ProtocolError("log paths must stay inside the project root.", 400)
            logs_override.append(str(candidate))

    return run_observation(brain, project_root, scope_db, world, session, budget, logs_override,
                           operators=operators, act=act, fix_report=fix_report)


def _tool_call(raw: bytes, project_root, scope_db, approval_token, operators=None) -> dict:
    """Run one read-only tool through the HTTP bridge, confined to the configured root."""
    try:
        payload = json.loads(raw.decode("utf-8"), parse_constant=reject_constant,
                             object_pairs_hook=unique_object)
    except ValueError as error:
        raise ProtocolError("Tool call body is not valid JSON: %s" % error, 400)
    require(isinstance(payload, dict), "Tool call must be a JSON object.")
    unknown = sorted(set(payload) - {"tool", "params"})
    require(not unknown, "Unknown field(s) in the tool call: " + ", ".join(unknown))
    name = payload.get("tool")
    require(isinstance(name, str) and 0 < len(name) <= 96,
            "tool must be a non-empty string of at most 96 characters.")
    parameters = payload.get("params", {})
    require(isinstance(parameters, dict), "params must be a JSON object.")
    result = toolbox.execute_scoped(name, parameters, project_root=project_root,
                                    db_path=scope_db, confine=True, allow_write=True,
                                    approval=operators if operators is not None else approval_token)
    return result.as_dict()


def chat_lines() -> dict:
    """Variative street dialogue lines for the city walkers (local, no model needed)."""
    import random
    import time
    h = time.localtime().tm_hour
    if 5 <= h < 12:
        day = "Доброе утро!"
    elif 12 <= h < 18:
        day = "Добрый день!"
    elif 18 <= h < 23:
        day = "Добрый вечер!"
    else:
        day = "Доброй ночи!"
    openers = [day, "Привет!", "Здравствуйте!", "Приветствую!", "О, кого я вижу!", "Салют!"]
    replies = ["Привет.", "Здравствуйте.", "И вам!", "Привет-привет!", "Рад видеть!",
               "А, это вы!", "Ой, здравствуйте!"]
    middles = [
        ["Как дела?", "Отлично!", "А у вас?", "Тоже хорошо."],
        ["Куда спешите?", "На работу.", "Успехов!", "Спасибо."],
        ["Погода сегодня отличная.", "Да, гулять одно удовольствие!"],
        ["Слышали, на перекрёстке опять ремонт?", "Да, объезжаю дворами."],
        ["Как пройти к площади?", "Прямо, потом направо.", "Спасибо!", "Не за что."],
        ["Кофе не хотите?", "С удовольствием, но позже."],
        ["Видели новые автобусы?", "Ещё нет, расскажете?"],
        ["Откуда вы?", "Из соседнего района.", "И как у вас там?"],
        ["Чем занимаетесь?", "Работаю в мастерской.", "Здорово!"],
        ["Говорят, ярмарка будет в субботу.", "Пойдём обязательно."],
        ["Люблю этот город.", "Да, уютный."],
        ["Вы часто здесь гуляете?", "Каждый вечер."],
        ["Как добраться до вокзала?", "Трамваем, две остановки.", "Благодарю!"],
        ["Видели закат вчера?", "Невероятный был!"],
        ["Что посоветуете на обед?", "Попробуйте в пекарне напротив.", "Спасибо, зайду."],
    ]
    closers = [["Ладно, мне пора.", "Удачи!"],
               ["Пока!", "До встречи!"],
               ["Всего доброго!", "И вам!"],
               ["Ну, я побежал.", "Бегите!", "Ещё увидимся."],
               []]
    lines = [random.choice(openers), random.choice(replies)]
    lines += list(random.choice(middles))
    lines += list(random.choice(closers))
    return {"lines": lines, "topic": "street", "source": "brain",
            "at": int(time.time()), "variants": len(openers) * len(replies) * len(middles) * len(closers)}


class LocalServer(HTTPServer):
    # Serial requests deliberately bound CPU, memory, and concurrent database work.
    allow_reuse_address = True
    request_queue_size = 8

    def get_request(self):
        sock, address = super().get_request()
        sock.settimeout(5)
        return sock, address


def make_server(brain: Brain, token: str, port: int = 8765, *,
                project_root: Path | None = None, scope_db: Path | None = None,
                approval_token: str | None = None,
                operators=None,
                observe_logs: list | None = None,
                bind: str = "127.0.0.1") -> LocalServer:
    require(isinstance(token, str) and 16 <= len(token) <= 4096 and
            all(32 < ord(c) < 127 for c in token), "Token must be 16-4096 printable ASCII characters without spaces.")

    class Handler(BaseHTTPRequestHandler):
        server_version = "AICore/0.3"
        sys_version = ""

        def log_message(self, format, *args):
            # Do not log request contents, URLs, or bearer tokens.
            pass

        def reply(self, code: int, body: dict):
            encoded = canonical(body).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(encoded)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("Connection", "close")
            self.end_headers()
            try:
                self.wfile.write(encoded)
            except (BrokenPipeError, ConnectionResetError):
                pass

        def authorized(self) -> bool:
            headers = self.headers.get_all("Authorization", [])
            if len(headers) != 1 or not hmac.compare_digest(headers[0].encode("utf-8"), ("Bearer " + token).encode("utf-8")):
                self.reply(401, {"error": "Authentication required."})
                return False
            # No CORS/browser access; Unity's client does not send Origin.
            if self.headers.get("Origin") is not None:
                self.reply(403, {"error": "Browser-origin requests are not allowed."})
                return False
            return True

        def do_GET(self):
            if not self.authorized():
                return
            try:
                parsed = urlsplit(self.path)
                if self.path == "/health":
                    self.reply(200, {"status": "ok", "protocol_versions": [1, 2],
                        "planner": "multi_objective", "model_training": False,
                        "capabilities": ["population_goals", "knowledge_storage", "placement_feedback"],
                        "action_types": ["spawn", "move", "activate", "deactivate"]})
                elif self.path == "/v1/stats":
                    self.reply(200, brain.stats())
                elif self.path == "/v1/tools":
                    self.reply(200, toolbox.schema())
                elif parsed.path in ("/v1/goals", "/v1/knowledge"):
                    require(len(parsed.query) <= 2048, "Query is too long.")
                    params = parse_qs(parsed.query, keep_blank_values=True, max_num_fields=8)
                    require(all(len(v) == 1 for v in params.values()), "Duplicate query parameter.")
                    params = {k: v[0] for k, v in params.items()}
                    world = params.get("world", "")
                    identifier(world, "world")
                    with brain.lock:
                        if parsed.path == "/v1/goals":
                            session = params.get("session", "")
                            identifier(session, "session")
                            body = {"goals": brain.goals.all_goals(world, session), "stats": brain.goals.stats(world, session)}
                        else:
                            raw_limit = params.get("limit", "50")
                            require(raw_limit.isascii() and raw_limit.isdigit() and len(raw_limit) <= 3,
                                    "limit must be 1-200.")
                            limit = int(raw_limit)
                            integer(limit, "limit", 1, 200)
                            category, search = params.get("category", ""), params.get("q", "")
                            require(not category or category in CATEGORIES, "Unknown fact category.")
                            text(search, "query", 256)
                            memory = brain.knowledge.world_summary(world)
                            body = {"facts": brain.knowledge.query_facts(world, search, category, limit),
                                    "summary": {k: memory[k] for k in ("fact_count", "relation_count", "pattern_count", "categories")}}
                    self.reply(200, body)
                elif parsed.path == "/v1/chat":
                    self.reply(200, chat_lines())
                else:
                    self.reply(404, {"error": "Unknown endpoint."})
            except (ValueError, OverflowError) as error:
                self.reply(400, {"error": str(error)})
            except sqlite3.Error:
                self.reply(503, {"error": "Storage unavailable."})

        def do_POST(self):
            if not self.authorized():
                return
            if self.path not in ("/v1/tick", "/v2/tick", "/v1/tools/call", "/v1/observe",
                                  "/v1/knowledge"):
                self.reply(404, {"error": "Unknown endpoint."})
                return
            if self.headers.get("Transfer-Encoding") is not None:
                self.reply(400, {"error": "Transfer encoding is unsupported."})
                return
            lengths = self.headers.get_all("Content-Length", [])
            if len(lengths) != 1 or not lengths[0].isascii() or not lengths[0].isdigit() or len(lengths[0]) > 10:
                self.reply(411, {"error": "One valid Content-Length is required."})
                return
            size = int(lengths[0])
            if size <= 0 or size > MAX_BODY:
                self.reply(413, {"error": "Request size limit exceeded."})
                return
            if self.headers.get_content_type() != "application/json":
                self.reply(415, {"error": "Content-Type application/json required."})
                return
            try:
                raw = self.rfile.read(size)
                require(len(raw) == size, "Incomplete request body.")
                if self.path == "/v1/tools/call":
                    self.reply(200, _tool_call(raw, project_root, scope_db, approval_token, operators))
                elif self.path == "/v1/knowledge":
                    self.reply(200, _knowledge_publish(raw, brain))
                elif self.path == "/v1/observe":
                    self.reply(200, _observe(raw, brain, project_root, scope_db, observe_logs, operators))
                elif self.path == "/v2/tick":
                    self.reply(200, brain.tick_v2(decode_request(raw, expected_version=2)))
                else:
                    self.reply(200, brain.tick(decode_request(raw)))
            except ProtocolError as error:
                self.reply(error.status, {"error": str(error)})
            except (TimeoutError, ConnectionError):
                self.close_connection = True
            except sqlite3.Error as error:
                import sys
                print("storage error on %s: %s" % (self.path, error), file=sys.stderr, flush=True)
                self.reply(503, {"error": "Storage unavailable or full; no new plan committed."})
            except Exception:
                import traceback
                traceback.print_exc()
                self.reply(500, {"error": "Planner error; request was not acknowledged."})

    require(bind in ("127.0.0.1", "0.0.0.0"),
            "bind must be 127.0.0.1 (default) or 0.0.0.0 (containers, host-mapped loopback only).")
    return LocalServer((bind, port), Handler)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--db", type=Path, default=Path(__file__).resolve().parent / "state" / "brain.sqlite3")
    parser.add_argument("--observe-every", type=float, default=0.0,
                        help="Run the observation loop every N seconds (0 disables it)."
                             " Requires --project so the tools have a confined root.")
    parser.add_argument("--observe-world", default="sandbox")
    parser.add_argument("--observe-session", default="scheduler")
    parser.add_argument("--observe-budget", type=int, default=3)
    parser.add_argument("--project", type=Path, default=None,
                        help="Unity project root the tool bridge may read. Without it, tools needing a "
                             "path are refused over HTTP.")
    parser.add_argument("--bind", default="127.0.0.1",
                        choices=["127.0.0.1", "0.0.0.0"],
                        help="127.0.0.1 by default. 0.0.0.0 is for containers where the host maps the "
                             "port back to its own loopback; never expose it directly to a network.")
    args = parser.parse_args()
    token = os.environ.get("AICORE_TOKEN", "")
    if not token:
        parser.error("Set AICORE_TOKEN to a random local token of at least 16 characters. Never use cloud API credentials.")
    if not 1 <= args.port <= 65535:
        parser.error("Port must be between 1 and 65535.")
    try:
        require(16 <= len(token) <= 4096 and all(32 < ord(c) < 127 for c in token), "Invalid AICORE_TOKEN.")
    except ProtocolError as error:
        parser.error(str(error))
    args.db.parent.mkdir(parents=True, exist_ok=True)
    brain = Brain(args.db)
    configured = os.environ.get("AICORE_OPERATORS")
    operators = None
    if configured:
        operators = approval.OperatorDirectory.parse(configured)
        if operators is None or not operators.names():
            parser.error("AICORE_OPERATORS must look like name:secret,name:secret")
    server = make_server(brain, token, args.port, project_root=args.project, scope_db=args.db,
                         approval_token=os.environ.get("AICORE_APPROVAL_TOKEN") or None,
                         operators=operators, bind=args.bind)
    scheduler = None
    if args.observe_every and args.observe_every > 0:
        if args.project is None:
            parser.error("--observe-every needs --project, so the tools stay confined.")
        if not 1 <= args.observe_budget <= 8:
            parser.error("--observe-budget must be between 1 and 8.")
        scheduler = schedule.ObservationScheduler(
            lambda: run_observation(brain, args.project, args.db, args.observe_world,
                                    args.observe_session, budget=args.observe_budget),
            args.observe_every).start()
    print(f"AICore listening at http://{args.bind}:{args.port}; database: {args.db}", flush=True)
    if args.bind == "0.0.0.0":
        print("WARNING: bound to 0.0.0.0. This is a container pattern: map the port to the host's "
              "loopback only (127.0.0.1:8765:8765) or tunnel it; never route it to a network.", flush=True)
    if scheduler is not None:
        print(f"Observing every {args.observe_every:g}s as "
              f"{args.observe_world}/{args.observe_session}", flush=True)
    print("Bounded population goals, knowledge storage and placement feedback. Ctrl+C to stop.", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        if scheduler is not None:
            scheduler.stop()
        server.server_close()
        brain.close()


if __name__ == "__main__":
    main()
