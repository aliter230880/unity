"""Optional LLM planning core: a language model proposes typed actions.

The LLM never gains a new capability. It sees a compact summary of the world
state and may propose the same four typed actions the deterministic planner
would (spawn / move / activate / deactivate). Every proposal then passes a
server-side gate that mirrors the client's rules: advertised capabilities,
approved catalog ids, owned targets, bounds, ownership cap, action budget.
Anything the gate rejects is dropped; if nothing survives, the deterministic
planner runs instead. The Unity client re-validates the plan a third time
before executing anything.

Off by default. Enable with environment variables:

  AICORE_LLM=ollama|openai|off      (default off; anything else fails startup)
  AICORE_LLM_MODEL=<model name>     (required when enabled)
  AICORE_LLM_URL=<base url>         (ollama: http://127.0.0.1:11434
                                     openai: https://api.deepseek.com/v1 etc.)
  AICORE_LLM_API_KEY=<key>          (required for the openai backend)
  AICORE_LLM_TIMEOUT=<seconds>      (default 10; one attempt, no retries)
  AICORE_LLM_MAX_TOKENS=<int>       (default 1024)
  AICORE_LLM_ALLOW_EMPTY=1          (accept an empty "no action" plan instead
                                     of falling back; default: fall back)

Standard library only. The HTTP call is a single bounded POST through urllib;
the transport is injectable so the tests never touch a network.
"""
from __future__ import annotations

import json
import math
import os
import urllib.request

CORE_ACTIONS = ("spawn", "move", "activate", "deactivate")
MAX_ACTIONS = 8          # mirrors ActionValidation.MaxActions on the client
MAX_ENTITIES_IN_PROMPT = 64
MAX_KNOWLEDGE_IN_PROMPT = 32
MAX_KNOWLEDGE_VALUE = 200
MAX_REASON_LENGTH = 2000

SYSTEM_PROMPT = (
    "You are the planning core of a bounded game-world director. You propose "
    "typed actions for a Unity executor that validates and applies them. "
    "Reply with ONLY a JSON array, no prose and no markdown. Each element: "
    '{"type": "spawn|move|activate|deactivate", "catalog_id": string, '
    '"target_id": string, "position": {"x": number, "y": number, "z": number}, '
    '"reason": string, "goal_id": string}. Rules: use only the catalog ids and '
    "owned entity ids given to you; positions must lie inside bounds; spawn "
    "needs catalog_id and a position with an empty target_id; move, activate "
    "and deactivate need the target_id of an owned entity (move also needs a "
    "position); activate only for entities listed as inactive and "
    "reactivatable, and only when allow_reactivation is true; propose at most "
    "the stated number of actions; an empty array [] is a valid answer when no "
    "action helps the goals.")


class LLMConfig:
    def __init__(self, backend: str, url: str, model: str, api_key: str,
                 timeout: float, max_tokens: int, allow_empty: bool):
        self.backend = backend
        self.url = url
        self.model = model
        self.api_key = api_key
        self.timeout = timeout
        self.max_tokens = max_tokens
        self.allow_empty = allow_empty

    @classmethod
    def from_env(cls, env=None) -> "LLMConfig":
        env = os.environ if env is None else env
        backend = (env.get("AICORE_LLM", "off") or "off").strip().lower()
        if backend not in ("off", "ollama", "openai"):
            raise ValueError("AICORE_LLM must be off, ollama or openai.")
        if backend == "off":
            return cls("off", "", "", "", 0.0, 0, False)
        model = (env.get("AICORE_LLM_MODEL", "") or "").strip()
        if not model:
            raise ValueError("AICORE_LLM_MODEL is required when AICORE_LLM is enabled.")
        default_url = "http://127.0.0.1:11434" if backend == "ollama" else ""
        url = (env.get("AICORE_LLM_URL", "") or default_url).strip().rstrip("/")
        if not url:
            raise ValueError("AICORE_LLM_URL is required for the openai backend.")
        api_key = env.get("AICORE_LLM_API_KEY", "") or ""
        if backend == "openai" and not api_key:
            raise ValueError("AICORE_LLM_API_KEY is required for the openai backend.")
        try:
            timeout = float(env.get("AICORE_LLM_TIMEOUT", "10"))
            max_tokens = int(env.get("AICORE_LLM_MAX_TOKENS", "1024"))
        except ValueError:
            raise ValueError("AICORE_LLM_TIMEOUT / AICORE_LLM_MAX_TOKENS must be numbers.")
        if not 1 <= timeout <= 60 or not 16 <= max_tokens <= 8192:
            raise ValueError("AICORE_LLM_TIMEOUT must be 1..60 and AICORE_LLM_MAX_TOKENS 16..8192.")
        allow_empty = (env.get("AICORE_LLM_ALLOW_EMPTY", "") or "").strip() in ("1", "true", "yes")
        return cls(backend, url, model, api_key, timeout, max_tokens, allow_empty)


def http_transport(config: LLMConfig):
    """A single bounded POST; injected transports replace it in tests.

    The opener bypasses any machine-wide proxy: loopback LLM traffic must never
    be routed through it (the same trap the docs warn about for curl).
    """
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    def send(payload: dict) -> dict:
        if config.backend == "ollama":
            endpoint = config.url + "/api/chat"
        else:  # OpenAI-compatible: the configured URL is the API base
            endpoint = config.url.rstrip("/") + ("/chat/completions"
                         if config.url.rstrip("/").endswith("/v1") else "/v1/chat/completions")
        body = json.dumps(payload).encode("utf-8")
        headers = {"Content-Type": "application/json"}
        if config.backend == "openai":
            headers["Authorization"] = "Bearer " + config.api_key
        request = urllib.request.Request(endpoint, data=body, headers=headers, method="POST")
        with opener.open(request, timeout=config.timeout) as response:
            return json.loads(response.read().decode("utf-8"))
    return send


def parse_json_array(text: str) -> list | None:
    """Extract the first JSON array from a model reply (fences and prose tolerated)."""
    if not isinstance(text, str):
        return None
    text = text.strip()
    candidates = [text]
    if "```" in text:
        fenced = [chunk.strip() for chunk in text.replace("```json", "```").split("```")]
        if len(fenced) > 1:
            candidates.append(fenced[1])
    start, end = text.find("["), text.rfind("]")
    if start != -1 and end > start:
        candidates.append(text[start:end + 1])
    for candidate in candidates:
        try:
            value = json.loads(candidate)
        except ValueError:
            continue
        if isinstance(value, list):
            return value
        return None
    return None


class LLMPlanner:
    def __init__(self, config: LLMConfig, transport=None):
        self.config = config
        self.transport = transport or http_transport(config)

    def describe(self) -> str:
        return "%s@%s" % (self.config.model, self.config.backend)

    # ---- prompt assembly -------------------------------------------------

    def summarize_world(self, data: dict, goals: list, knowledge: list | None = None) -> dict:
        counts: dict[str, int] = {}
        for entity in data["entities"]:
            counts[entity["catalog_id"]] = counts.get(entity["catalog_id"], 0) + 1
        owned = [e for e in data["entities"] if e.get("owned")]
        listed = owned[:MAX_ENTITIES_IN_PROMPT]
        limits = data["limits"]
        return {
            "world": data["world_id"],
            "goal_text": (data.get("goal") or "")[:500],
            "goals": [{"goal_id": g["goal_id"], "catalog_id": g["catalog_id"],
                       "target_count": g.get("target_count", 0),
                       "priority": g.get("priority", 1), "status": g.get("status", "active"),
                       "current_count": sum(1 for e in data["entities"]
                                            if e.get("owned") and e.get("active")
                                            and e["catalog_id"] == g["catalog_id"])}
                      for g in goals],
            "limits": {"action_budget": min(limits["action_budget"], MAX_ACTIONS),
                       "owned_entity_count": limits["owned_entity_count"],
                       "max_owned_entities": limits["max_owned_entities"],
                       "min": limits["min"], "max": limits["max"]},
            "allow_reactivation": bool(data.get("allow_reactivation")),
            "catalog": [{"id": c["id"], "kind": c["kind"]} for c in data["catalog"]],
            "owned_entities": [{"id": e["id"], "catalog_id": e["catalog_id"],
                                "active": bool(e.get("active")),
                                "reactivatable": bool(e.get("reactivatable")),
                                "position": {a: round(float(e["position"][a]), 1) for a in "xyz"}}
                               for e in listed],
            "entity_counts_total": counts,
            "entities_summarized": max(0, len(owned) - len(listed)),
            "max_actions": min(limits["action_budget"], MAX_ACTIONS),
            "knowledge": [{"key": str(f.get("key", ""))[:96],
                           "value": str(f.get("value", ""))[:MAX_KNOWLEDGE_VALUE],
                           "category": f.get("category", "custom"),
                           "confidence": f.get("confidence", 0.5)}
                          for f in (knowledge or [])[:MAX_KNOWLEDGE_IN_PROMPT]
                          if isinstance(f, dict)],
        }

    def _messages(self, data: dict, goals: list, knowledge: list | None = None) -> list[dict]:
        return [{"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": json.dumps(self.summarize_world(data, goals, knowledge))}]

    def _payload(self, messages: list[dict]) -> dict:
        if self.config.backend == "ollama":
            return {"model": self.config.model, "messages": messages, "stream": False,
                    "keep_alive": "30m",  # stay resident: no cold reload per tick
                    "options": {"temperature": 0.2, "num_predict": self.config.max_tokens}}
        return {"model": self.config.model, "messages": messages,
                "max_tokens": self.config.max_tokens, "temperature": 0.2}

    def _content(self, response: dict) -> str | None:
        try:
            if self.config.backend == "ollama":
                return response["message"]["content"]
            return response["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError):
            return None

    # ---- the plan --------------------------------------------------------

    def plan(self, data: dict, goals: list, capabilities: list[str], knowledge: list | None = None):
        """Return (actions, summary, warnings); actions=None means fall back."""
        try:
            response = self.transport(self._payload(self._messages(data, goals, knowledge)))
        except Exception as error:  # bounded: one attempt, any failure falls back
            return None, "", ["LLM planner unreachable (%s)." % type(error).__name__]
        content = self._content(response)
        if not content:
            return None, "", ["LLM response had no content."]
        raw = parse_json_array(content)
        if raw is None:
            return None, "", ["LLM response was not a JSON array."]
        actions, warnings = validate_actions(raw, data, goals, capabilities)
        if not actions:
            if not raw and self.config.allow_empty:
                return [], "LLM proposed no action.", warnings
            return None, "", warnings + ["LLM proposed no executable action; deterministic planner used."]
        return actions, "LLM proposed %d action(s)." % len(actions), warnings


# ---- the gate: server-side mirror of the client's action rules ------------

def _finite(point) -> bool:
    return (isinstance(point, dict)
            and all(isinstance(point.get(a), (int, float)) and math.isfinite(point[a]) for a in "xyz"))


def _inside(point: dict, limits: dict) -> bool:
    return all(limits["min"][a] <= point[a] <= limits["max"][a] for a in "xyz")


def validate_actions(raw, data: dict, goals: list, capabilities: list[str]) -> tuple[list, list]:
    """Filter proposals down to the ones the client would accept; never invent."""
    warnings: list[str] = []
    if not isinstance(raw, list):
        return [], ["LLM response was not a JSON array."]
    if len(raw) > MAX_ACTIONS:
        return [], ["LLM proposed more than %d actions." % MAX_ACTIONS]
    limits = data["limits"]
    catalog = {c["id"] for c in data["catalog"]}
    owned = {e["id"]: e for e in data["entities"] if e.get("owned")}
    active_goals = {g["goal_id"] for g in goals if g.get("status") == "active"}
    budget = min(limits["action_budget"], MAX_ACTIONS)
    capacity = max(0, limits["max_owned_entities"] - limits["owned_entity_count"])
    actions: list[dict] = []
    spawn_count = 0

    def drop(reason: str) -> None:
        warnings.append("LLM action dropped: " + reason)

    for item in raw:
        if not isinstance(item, dict):
            drop("not an object.")
            continue
        kind = item.get("type")
        if kind not in capabilities:
            drop("type %r is not an advertised capability." % kind)
            continue
        reason = str(item.get("reason", ""))[:MAX_REASON_LENGTH]
        goal_id = item.get("goal_id") or ""
        if goal_id and goal_id not in active_goals:
            goal_id = ""
        if kind == "spawn":
            catalog_id = item.get("catalog_id", "")
            if catalog_id not in catalog or item.get("target_id"):
                drop("unknown catalog id or spawn with a target.")
                continue
            position = item.get("position")
            if not _finite(position) or not _inside(position, limits):
                drop("spawn position is not finite or outside bounds.")
                continue
            if spawn_count >= capacity:
                drop("ownership cap reached.")
                continue
            spawn_count += 1
            actions.append({"type": "spawn", "catalog_id": catalog_id, "target_id": "",
                            "position": {a: float(position[a]) for a in "xyz"},
                            "reason": reason, "goal_id": goal_id, "_strategy": "llm"})
        else:
            entity = owned.get(item.get("target_id", ""))
            if entity is None:
                drop("target is unknown or not owned by this director.")
                continue
            catalog_id = item.get("catalog_id") or entity["catalog_id"]
            if catalog_id != entity["catalog_id"] or catalog_id not in catalog:
                drop("action catalog id does not match the target.")
                continue
            if kind == "activate" and (entity.get("active") or not entity.get("reactivatable")
                                       or not data.get("allow_reactivation")):
                drop("activation needs an inactive, reactivatable entity and permission.")
                continue
            if kind == "deactivate" and not entity.get("active"):
                drop("target is already inactive.")
                continue
            action = {"type": kind, "catalog_id": catalog_id, "target_id": entity["id"],
                      "reason": reason, "goal_id": goal_id}
            if kind == "move":
                position = item.get("position")
                if not _finite(position) or not _inside(position, limits):
                    drop("move position is not finite or outside bounds.")
                    continue
                action["position"] = {a: float(position[a]) for a in "xyz"}
            actions.append(action)

    if len(actions) > budget:
        warnings.append("LLM plan cut to the advertised action budget.")
        actions = actions[:budget]
    return actions, warnings
