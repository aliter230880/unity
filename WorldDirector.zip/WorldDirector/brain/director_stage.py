"""Stages 0–2 and B, attached onto Brain at construction.

server.py only needs: import director_stage; director_stage.attach(self)
If server.py is overwritten, re-insert that one line. Logic lives here.
"""
from __future__ import annotations

import sqlite3
import time

import atmosphere as atmosphere_module
import charter as charter_module
from knowledge import KnowledgeError
from planner import validate_capabilities

_INSTALLED = False
SCHEMA = """
CREATE TABLE IF NOT EXISTS outcomes (
    world TEXT, catalog TEXT, type TEXT, status TEXT,
    samples INTEGER NOT NULL, PRIMARY KEY(world, catalog, type, status));
CREATE TABLE IF NOT EXISTS world_clock (
    world TEXT PRIMARY KEY, hour REAL NOT NULL, updated REAL NOT NULL);
"""


def attach(brain) -> None:
    global _INSTALLED
    brain.db.executescript(SCHEMA)
    if not hasattr(brain, "charter") or brain.charter is None:
        brain.charter = charter_module.Charter.load()
    if not _INSTALLED:
        _install(type(brain))
        _INSTALLED = True


def _install(cls) -> None:
    original_plan = cls._plan
    original_plan_multi = cls._plan_multi
    original_ingest = cls._ingest

    def wrapped_plan(self, data, warnings):
        target = data.get("target_catalog_id") or ""
        payload = data
        if target and _spawn_blocked(self, data["world_id"], target):
            owned = sum(1 for entity in data["entities"]
                        if entity.get("owned") and entity.get("active")
                        and entity.get("catalog_id") == target)
            payload = dict(data)
            payload["target_count"] = owned
            warnings.append("Spawn of %s paused: the world rejected it repeatedly." % target)
        actions, summary, strategy = original_plan(self, payload, warnings)
        actions, notes = _apply_charter(self, actions, data.get("catalog"))
        warnings.extend(notes)
        return actions, summary, strategy

    def wrapped_plan_multi(self, data, scope, warnings):
        if not data.get("allow_mutations"):
            hour = _world_hour(self, data, scope[0])
            if hour is not None:
                _, _, facts = atmosphere_module.plan(data, hour, (), 0)
                _remember_atmosphere(self, scope[0], facts)
        actions, summary = original_plan_multi(self, data, scope, warnings)
        if not data.get("allow_mutations"):
            return actions, summary
        leftover = max(0, data["limits"]["action_budget"] - len(actions))
        try:
            capabilities = validate_capabilities(data.get("capabilities", {}))["action_types"]
        except ValueError:
            capabilities = []
        lights, notes = _plan_atmosphere(self, data, scope, capabilities, leftover)
        warnings.extend(notes)
        if lights:
            actions = _merge_actions(actions, lights)
            summary = (summary + " | atmosphere.lights: %d light(s)" % len(lights)).strip(" |")
        actions, charter_notes = _apply_charter(self, actions, data.get("catalog"))
        warnings.extend(charter_notes)
        return actions, summary

    def wrapped_ingest(self, data, scope):
        pending = []
        for result in data.get("results") or []:
            row = self.db.execute(
                "SELECT * FROM actions WHERE world=? AND session=? AND action=?",
                (*scope, result["action_id"])).fetchone()
            if row is not None and row["status"] is None:
                pending.append((row["catalog"] or "", row["type"] or "", result["status"]))
        warnings = original_ingest(self, data, scope)
        for catalog, action_type, status in pending:
            _record_outcome(self, scope[0], catalog, action_type, status)
        return warnings

    cls._plan = wrapped_plan
    cls._plan_multi = wrapped_plan_multi
    cls._ingest = wrapped_ingest


def _apply_charter(brain, actions, catalog):
    kept, reasons = brain.charter.filter_actions(actions, catalog)
    return kept, ["Charter refused: " + item for item in reasons]


def _merge_actions(first, second):
    seen, merged = set(), []
    for action in list(first or []) + list(second or []):
        target = action.get("target_id")
        if action.get("type") == "spawn" or not target:
            merged.append(action)
            continue
        key = (action.get("type"), target)
        if key in seen:
            continue
        seen.add(key)
        merged.append(action)
    return merged


def _world_hour(brain, data, world):
    hour = atmosphere_module.event_hour(data.get("events") or [])
    lights_present = any(atmosphere_module.looks_like_light(entity)
                         for entity in data.get("entities") or [])
    catalog_light = atmosphere_module.catalog_has_light(data.get("catalog") or [])
    if hour is None and not lights_present and not catalog_light:
        return None
    if hour is None:
        row = brain.db.execute("SELECT hour FROM world_clock WHERE world=?", (world,)).fetchone()
        hour = (row["hour"] if row is not None else atmosphere_module.DEFAULT_HOUR)
        if row is not None:
            hour = atmosphere_module.wrap_hour(hour + atmosphere_module.HOUR_STEP)
    brain.db.execute(
        "INSERT INTO world_clock(world,hour,updated) VALUES(?,?,?) "
        "ON CONFLICT(world) DO UPDATE SET hour=excluded.hour, updated=excluded.updated",
        (world, hour, time.time()))
    return hour


def _remember_atmosphere(brain, world, facts):
    mapping = (("atmosphere.hour", "weather"),
               ("atmosphere.phase", "weather"),
               ("atmosphere.lights_on", "population"))
    for key, category in mapping:
        if key not in facts:
            continue
        try:
            brain.knowledge.upsert_fact(world, {
                "key": key, "value": facts[key], "category": category, "confidence": 0.9,
            }, commit=False)
        except (KnowledgeError, sqlite3.Error):
            pass


def _plan_atmosphere(brain, data, scope, capabilities, remaining):
    hour = _world_hour(brain, data, scope[0])
    if hour is None:
        return [], []
    actions, notes, facts = atmosphere_module.plan(data, hour, capabilities, remaining)
    _remember_atmosphere(brain, scope[0], facts)
    return actions, notes


def _record_outcome(brain, world, catalog, action_type, status):
    if not catalog or not action_type or not status:
        return
    brain.db.execute(
        "INSERT INTO outcomes(world,catalog,type,status,samples) VALUES(?,?,?,?,1) "
        "ON CONFLICT(world,catalog,type,status) DO UPDATE SET samples=samples+1",
        (world, catalog, action_type, status))
    _remember_lesson(brain, world, catalog, action_type)


def _spawn_blocked(brain, world, catalog) -> bool:
    rows = brain.db.execute(
        "SELECT status, samples FROM outcomes WHERE world=? AND catalog=? AND type='spawn'",
        (world, catalog)).fetchall()
    counts = {row["status"]: row["samples"] for row in rows}
    failed = counts.get("rejected", 0) + counts.get("failed", 0)
    return counts.get("executed", 0) == 0 and failed >= 5


def _remember_lesson(brain, world, catalog, action_type):
    rows = brain.db.execute(
        "SELECT status, samples FROM outcomes WHERE world=? AND catalog=? AND type=?",
        (world, catalog, action_type)).fetchall()
    if not rows:
        return
    summary = " ".join("%s=%d" % (row["status"], row["samples"]) for row in rows)
    try:
        brain.knowledge.upsert_fact(world, {
            "key": "lesson.%s.%s" % (catalog, action_type),
            "value": summary[:2000], "category": "system", "confidence": 0.8,
        }, commit=False)
    except (KnowledgeError, sqlite3.Error):
        pass
