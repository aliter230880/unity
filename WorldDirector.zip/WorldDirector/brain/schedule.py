"""A small, testable scheduler for periodic observation.

The brain should not need a human to ask it to look at the project. This runs a
tick function on an interval in a daemon thread, keeps the last result, and never
lets one failing tick kill the loop.

Standard library only.
"""
from __future__ import annotations

import threading
import time
from typing import Any, Callable


class ObservationScheduler:
    """Runs ``tick`` every ``interval_seconds`` until stopped."""

    def __init__(self, tick: Callable[[], Any], interval_seconds: float,
                 clock: Callable[[], float] = time.monotonic):
        if interval_seconds <= 0:
            raise ValueError("interval_seconds must be positive")
        if not callable(tick):
            raise ValueError("tick must be callable")
        self.tick = tick
        self.interval_seconds = float(interval_seconds)
        self.clock = clock
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._lock = threading.Lock()
        self.runs = 0
        self.failures = 0
        self.last_result: Any = None
        self.last_error: str = ""
        self.last_run_at: float | None = None

    # -- one step ---------------------------------------------------------------------
    def run_once(self) -> Any:
        """Run the tick once. Errors are recorded, never raised."""
        try:
            result = self.tick()
        except Exception as error:  # a bad tick must not stop the loop
            with self._lock:
                self.failures += 1
                self.last_error = "%s: %s" % (type(error).__name__, error)
                self.last_run_at = self.clock()
            return None
        with self._lock:
            self.runs += 1
            self.last_result = result
            self.last_error = ""
            self.last_run_at = self.clock()
        return result

    # -- thread -----------------------------------------------------------------------
    def start(self) -> "ObservationScheduler":
        if self._thread is not None and self._thread.is_alive():
            return self
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, name="aicore-observe",
                                        daemon=True)
        self._thread.start()
        return self

    def _loop(self) -> None:
        while not self._stop.is_set():
            self.run_once()
            self._stop.wait(self.interval_seconds)

    def stop(self, timeout: float = 5.0) -> None:
        self._stop.set()
        thread = self._thread
        if thread is not None and thread.is_alive():
            thread.join(timeout)
        self._thread = None

    @property
    def running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def stats(self) -> dict:
        with self._lock:
            return {"running": self.running, "interval_seconds": self.interval_seconds,
                    "runs": self.runs, "failures": self.failures,
                    "last_error": self.last_error, "last_run_at": self.last_run_at}


# Outcomes that mean "nothing happened": the loop may slow down for these.
QUIET_OUTCOMES = ("converged", "refused-by-decision", "idle")


class BackoffSchedule:
    """How long to wait after an outcome.

    A watcher that polls at full speed while nothing is happening is just noise. This one waits
    longer after every quiet outcome and snaps back to the base interval as soon as something
    actually changed - and it never waits longer than the ceiling.
    """

    def __init__(self, base_seconds: float, factor: float = 2.0,
                 maximum_seconds: float | None = None):
        if not isinstance(base_seconds, (int, float)) or isinstance(base_seconds, bool) \
                or base_seconds <= 0:
            raise ValueError("base_seconds must be positive")
        if not isinstance(factor, (int, float)) or isinstance(factor, bool) or factor < 1:
            raise ValueError("factor must be at least 1")
        self.base_seconds = float(base_seconds)
        self.factor = float(factor)
        ceiling = maximum_seconds if maximum_seconds is not None else self.base_seconds * (self.factor ** 5)
        if ceiling < self.base_seconds:
            raise ValueError("maximum_seconds cannot be below base_seconds")
        self.maximum_seconds = float(ceiling)
        self.interval = self.base_seconds
        self.quiet_streak = 0

    def next_interval(self, outcome: str) -> float:
        """The wait to use *after* this outcome, and the new current interval."""
        if str(outcome) in QUIET_OUTCOMES:
            self.quiet_streak += 1
            self.interval = min(self.maximum_seconds,
                                self.base_seconds * (self.factor ** self.quiet_streak))
        else:
            self.quiet_streak = 0
            self.interval = self.base_seconds
        return self.interval

    def describe(self) -> dict:
        return {"base_seconds": self.base_seconds, "factor": self.factor,
                "maximum_seconds": self.maximum_seconds, "interval": self.interval,
                "quiet_streak": self.quiet_streak}
