"""Deterministic tool selection: the planner picks tools from the catalogue.

Given real state (diagnostic findings, scene-report age, console errors) this
chooses *which read-only tools to run next*, with a reason for each choice. It is
rule based on purpose: no language model, no randomness, fully reproducible.

The rules are ordered by urgency, deduplicated, and capped by a budget. Only
tools that actually exist in the registry are ever proposed.
"""
from __future__ import annotations

from typing import Any

DEFAULT_BUDGET = 3
MAX_BUDGET = 8


def _finding_severities(findings: Any) -> set:
    severities = set()
    for item in findings or []:
        if isinstance(item, dict):
            severity = item.get("severity")
            if isinstance(severity, str):
                severities.add(severity)
    return severities


def _count(findings: Any, severity: str) -> int:
    return sum(1 for item in findings or []
               if isinstance(item, dict) and item.get("severity") == severity)


def recommend(state: dict, available: set, budget: int = DEFAULT_BUDGET) -> dict:
    """Return an ordered list of ``{tool, params, reason}`` suggestions.

    ``state`` carries what is known right now:
      findings          - the latest diagnostic findings (list of dicts)
      scene_report_age  - seconds since the scene report was written, or None
      console_errors    - number of error lines in the editor console
      scenes_loaded     - number of loaded scenes in the scene report
    """
    if isinstance(budget, bool) or not isinstance(budget, int) or budget < 1 or budget > MAX_BUDGET:
        raise ValueError("budget must be between 1 and %d" % MAX_BUDGET)

    findings = state.get("findings") or []
    severities = _finding_severities(findings)
    console_errors = state.get("console_errors")
    scene_age = state.get("scene_report_age")

    ordered: list[tuple[str, dict, str]] = []

    if severities & {"critical", "error"}:
        ordered.append((
            "project.diagnostics", {},
            "%d critical/error finding(s) were reported; re-read the logs and the project layout"
            % (_count(findings, "critical") + _count(findings, "error"))))

    if not state.get("diagnostics_seen", False):
        ordered.append((
            "project.diagnostics", {},
            "the brain has never read this project's diagnostics"))

    if scene_age is None:
        ordered.append(("unity.scene.report", {},
                        "no scene report has been produced yet, so the live scene is unobserved"))
    elif scene_age > 300:
        ordered.append(("unity.scene.report", {},
                        "the scene report is %d seconds old" % scene_age))

    if isinstance(console_errors, int) and console_errors > 0:
        ordered.append(("unity.console.tail", {"level": "error"},
                        "the editor console holds %d error line(s)" % console_errors))

    if findings:
        ordered.append(("unity.project.inventory", {},
                        "the project layout has not been checked alongside the findings"))

    ordered.append(("brain.knowledge.facts", {"limit": 20},
                    "check what the brain already knows before planning further"))

    chosen: list[dict] = []
    seen: set[str] = set()
    for tool, params, reason in ordered:
        if tool in seen or tool not in available:
            continue
        seen.add(tool)
        chosen.append({"tool": tool, "params": params, "reason": reason})
        if len(chosen) >= budget:
            break

    return {"recommended": chosen, "budget": budget,
            "considered": [tool for tool, _params, _reason in ordered],
            "based_on": {"findings": len(findings), "severities": sorted(severities),
                         "console_errors": console_errors, "scene_report_age": scene_age,
                         "diagnostics_seen": bool(state.get("diagnostics_seen", False))}}
