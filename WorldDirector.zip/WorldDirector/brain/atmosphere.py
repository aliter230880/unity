"""Stage B: comfort of the world — day/night, lights, occupancy.

No new verbs. Night activates owned lights; day deactivates them.
Spawn of new lamps is the owner's population goal, never invented here.
"""
from __future__ import annotations

from typing import Any

DAY_HOURS = 24.0
NIGHT_START = 20.0
NIGHT_END = 6.0
HOUR_STEP = 0.25
DEFAULT_HOUR = 12.0
MAX_LIGHT_ACTIONS = 4
LIGHT_HINTS = ("lamp", "light", "lantern", "streetlight", "torch", "glow", "bulb")


def wrap_hour(value: float) -> float:
    return value % DAY_HOURS


def is_night(hour: float) -> bool:
    hour = wrap_hour(hour)
    return hour >= NIGHT_START or hour < NIGHT_END


def phase_name(hour: float) -> str:
    return "night" if is_night(hour) else "day"


def looks_like_light(entity: dict) -> bool:
    if not isinstance(entity, dict):
        return False
    kind = str(entity.get("kind") or "").lower()
    catalog = str(entity.get("catalog_id") or "").lower()
    if kind == "light":
        return True
    return any(hint in kind or hint in catalog for hint in LIGHT_HINTS)


def catalog_has_light(catalog: list) -> bool:
    return any(looks_like_light(entry) or looks_like_light({"kind": entry.get("kind"),
                                                           "catalog_id": entry.get("id")})
               for entry in catalog or [] if isinstance(entry, dict))


def event_hour(events: list) -> float | None:
    hour = None
    for event in events or []:
        if not isinstance(event, dict) or event.get("kind") != "world.hour":
            continue
        value = event.get("value")
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            continue
        if value != value or value in (float("inf"), float("-inf")):
            continue
        hour = wrap_hour(float(value))
    return hour


def occupancy(entities: list) -> dict[str, int]:
    counts = {"lights_on": 0, "lights_off": 0, "props": 0, "npcs": 0, "owned": 0}
    for entity in entities or []:
        if not isinstance(entity, dict) or not entity.get("owned"):
            continue
        counts["owned"] += 1
        kind = str(entity.get("kind") or "").lower()
        if looks_like_light(entity):
            if entity.get("active"):
                counts["lights_on"] += 1
            else:
                counts["lights_off"] += 1
        elif kind == "npc":
            counts["npcs"] += 1
        else:
            counts["props"] += 1
    return counts


def _inside(entity: dict, limits: dict) -> bool:
    point = entity.get("position") or {}
    try:
        return all(limits["min"][axis] <= point[axis] <= limits["max"][axis] for axis in "xyz")
    except (KeyError, TypeError):
        return False


def plan(data: dict, hour: float, capabilities: list | tuple, remaining: int) -> tuple[list, list[str], dict]:
    """Return (actions, notes, facts). Never spawns. Budget is leftover after population/wander."""
    night = is_night(hour)
    counts = occupancy(data.get("entities") or [])
    facts = {
        "atmosphere.hour": round(wrap_hour(hour), 2),
        "atmosphere.phase": phase_name(hour),
        "atmosphere.lights_on": counts["lights_on"],
    }
    notes: list[str] = []
    want = "activate" if night else "deactivate"
    if want not in capabilities:
        notes.append("Atmosphere skipped: %s is not an advertised capability." % want)
        return [], notes, facts
    budget = max(0, min(int(remaining), MAX_LIGHT_ACTIONS))
    if budget == 0:
        return [], notes, facts
    limits = data.get("limits") or {}
    actions = []
    for entity in data.get("entities") or []:
        if len(actions) >= budget:
            break
        if not isinstance(entity, dict) or not entity.get("owned"):
            continue
        if str(entity.get("kind") or "").lower() == "player":
            continue
        if not looks_like_light(entity):
            continue
        if not _inside(entity, limits):
            continue
        if night:
            if entity.get("active") or not entity.get("reactivatable"):
                continue
        elif not entity.get("active"):
            continue
        actions.append({
            "type": want,
            "catalog_id": entity.get("catalog_id") or "",
            "target_id": entity["id"],
            "goal_id": "atmosphere.lights",
            "_strategy": "atmosphere",
            "reason": "Stage B: %s lights at hour %.2f." % (want, hour),
        })
    if not actions and catalog_has_light(data.get("catalog") or []) and counts["lights_on"] + counts["lights_off"] == 0:
        notes.append("Atmosphere: a light is in the catalog but none are owned; spawn is the owner's goal.")
    return actions, notes, facts
