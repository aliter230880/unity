"""When may the brain apply a fix without a person saying yes each time?

Autonomy is a policy, not a switch. This module makes the policy explicit and small: at most
this risk, at most this often, and only in a scene where something is actually observable.
Anything else waits for a human - which is a refusal with a reason, not a silent skip.

The policy never executes anything. It answers one question, and the answer carries its
reasons so that a refusal can be explained to whoever asked.

Standard library only.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

def count_recent_applies(log_path, within_seconds: int = 3600, now=None) -> int:
    """How many times a fix plan was applied recently, read from the audit log."""
    import calendar as _calendar
    import json as _json
    import time as _time
    path = Path(log_path) if not isinstance(log_path, Path) else log_path
    if not path.is_file():
        return 0
    current = _time.time() if now is None else now
    count = 0
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return 0
    for line in lines:
        try:
            entry = _json.loads(line)
        except ValueError:
            continue
        if not isinstance(entry, dict) or entry.get("action") != "apply-fix-plan":
            continue
        stamp = entry.get("utc")
        if not isinstance(stamp, str):
            continue
        try:
            # The log is UTC; reading it as local time would offset the whole window.
            when = _calendar.timegm(_time.strptime(stamp, "%Y-%m-%dT%H:%M:%SZ"))
        except ValueError:
            continue
        if current - when <= within_seconds:
            count += 1
    return count


RISK_ORDER = {"low": 0, "medium": 1, "high": 2, "unknown": 3}
DEFAULT_MAX_RISK = "low"
DEFAULT_MAX_PER_HOUR = 2


class AutoApprovalPolicy:
    """A conservative, declarative rule for acting without a person."""

    def __init__(self, max_risk: str = DEFAULT_MAX_RISK, max_per_hour: int = DEFAULT_MAX_PER_HOUR,
                 require_observed: bool = True, enabled: bool = False):
        self.max_risk = max_risk if max_risk in RISK_ORDER else DEFAULT_MAX_RISK
        self.max_per_hour = max(0, int(max_per_hour))
        self.require_observed = bool(require_observed)
        self.enabled = bool(enabled)

    def describe(self) -> dict:
        return {"enabled": self.enabled, "max_risk": self.max_risk,
                "max_per_hour": self.max_per_hour, "require_observed": self.require_observed}

    def evaluate(self, plan: Any, applied_recently: int = 0,
                 map_context: dict | None = None) -> dict:
        """May this plan be applied without asking? Always returns reasons."""
        reasons = []
        fixes = [item for item in ((plan or {}).get("fixes") or []) if isinstance(item, dict)]

        if not self.enabled:
            reasons.append("auto-approval is switched off")
        if not fixes:
            reasons.append("there is nothing to apply")

        worst = "low"
        for fix in fixes:
            risk = str(fix.get("risk") or "unknown")
            if RISK_ORDER.get(risk, 3) > RISK_ORDER.get(worst, 3):
                worst = risk
        if fixes and RISK_ORDER.get(worst, 3) > RISK_ORDER.get(self.max_risk, 0):
            reasons.append("the plan contains a %s-risk fix, above the %s limit"
                           % (worst, self.max_risk))

        try:
            recent = max(0, int(applied_recently))
        except (TypeError, ValueError):
            recent = 0
        if recent >= self.max_per_hour:
            reasons.append("the hourly budget of %d application(s) is used up" % self.max_per_hour)

        context = map_context if isinstance(map_context, dict) else {}
        if self.require_observed and fixes:
            try:
                objects = int(context.get("objects", 0))
                observed = int(context.get("observed", 0))
            except (TypeError, ValueError):
                objects = observed = 0
            if objects and observed == 0:
                reasons.append("nothing in the scene is observable, so applying a fix would "
                               "achieve nothing")

        return {"allowed": not reasons, "reasons": reasons, "worst_risk": worst if fixes else "",
                "applied_recently": recent, "policy": self.describe()}

    @classmethod
    def from_environment(cls, env: dict) -> "AutoApprovalPolicy":
        """Configuration is explicit: without the flag, nothing is automatic."""
        enabled = str(env.get("AICORE_AUTO_APPROVE", "")).strip().lower() in ("1", "true", "yes", "on")
        risk = str(env.get("AICORE_AUTO_RISK") or DEFAULT_MAX_RISK).strip().lower()
        try:
            per_hour = int(str(env.get("AICORE_AUTO_PER_HOUR") or DEFAULT_MAX_PER_HOUR).strip())
        except ValueError:
            per_hour = DEFAULT_MAX_PER_HOUR
        observed = str(env.get("AICORE_AUTO_REQUIRE_OBSERVED", "1")).strip().lower() not in ("0", "false", "no", "off")
        return cls(max_risk=risk, max_per_hour=per_hour, require_observed=observed, enabled=enabled)
