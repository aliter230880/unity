"""Reading the shape of a scene out of the relation graph.

Findings say what is wrong; the graph says what is there and what depends on it. This is
the small, pure layer that turns relations into the few numbers a decision actually needs:

    how many objects the scene holds,
    how many of them are observable,
    how many have a broken script,
    how many other things depend on this scene.

Keeping it pure and separate means the reasoning is testable without a database, and the
rule that turns these numbers into advice stays in the decision layer where it belongs.

Standard library only.
"""
from __future__ import annotations

from typing import Any

# The identifier scheme the editor's map builder uses. Kept identical on purpose: a scene
# path must produce the same id here as it did there, or the graph cannot be joined.
_ALLOWED = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.:-")
MAX_IDENTIFIER = 96


def identifier(kind: str, path: str) -> str:
    """The map id for an entity. Mirrors AICoreProjectMap.Identifier."""
    raw = "%s.%s" % (kind or "", path or "")
    value = "".join(character if character in _ALLOWED else "_" for character in raw)
    if len(value) <= MAX_IDENTIFIER:
        return value
    # The editor uses the runtime hash for the short form; the short form is only used for
    # very long paths, so a stable digest is used here instead of trying to match it.
    import hashlib
    digest = hashlib.sha256(value.encode("utf-8")).hexdigest()[:8]
    return value[:MAX_IDENTIFIER - 9] + "_" + digest


def _relations(relations: Any) -> list:
    return [item for item in (relations or []) if isinstance(item, dict)]


def summarise(scene_id: str, relations: Any) -> dict:
    """What the graph says about one scene."""
    items = _relations(relations)
    objects = []
    for item in items:
        if item.get("type") == "contains" and item.get("source") == scene_id:
            objects.append(item.get("target"))
    objects = [target for target in objects if target]
    object_set = set(objects)

    observed = set()
    missing_scripts = set()
    for item in items:
        source = item.get("source")
        if source not in object_set:
            continue
        if item.get("type") == "observed":
            observed.add(source)
        elif item.get("type") == "has_missing_script":
            missing_scripts.add(source)

    dependents = [item.get("source") for item in items
                  if item.get("type") == "depends_on" and item.get("target") == scene_id]

    return {
        "scene_id": scene_id,
        "objects": len(objects),
        "observed": len(observed),
        "missing_scripts": len(missing_scripts),
        "dependents": len([item for item in dependents if item]),
    }


def is_populated(context: Any) -> bool:
    """True when the graph actually describes something, rather than being empty."""
    context = context if isinstance(context, dict) else {}
    try:
        return int(context.get("objects", 0)) > 0
    except (TypeError, ValueError):
        return False
