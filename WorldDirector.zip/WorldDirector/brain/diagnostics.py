"""Read-only diagnostics observer for AICore (Phase 1).

The observer answers one question: *what is broken in this Unity project, and what
is the evidence?* It does that by reading two kinds of input and nothing else:

  1. Log files that the caller explicitly passes in (Unity editor logs, batchmode
     logs, validation logs). They are opened for reading and never modified.
  2. The project tree (``Assets/``, ``ProjectSettings/``, ``Packages/``), read-only,
     for structural checks such as orphan ``.meta`` files or duplicate GUIDs.

Hard boundaries of this module:

  - Standard library only. No third-party imports, ever.
  - No network access, no subprocess, no ``Unity.exe``, no ``sqlite3`` connection
    unless the caller opts in with ``persist=True``.
  - No mutation of the project: no file is created, deleted, renamed or rewritten
    except the report files inside the caller-provided ``out_dir`` and, when
    ``persist=True``, fact rows in the caller-provided brain database.

Findings are evidence-bound. A rule fires only when the text is actually there.
The ``ui_conflict`` and ``rig_conflict`` categories are pure text heuristics over
log lines (for example "multiple event systems"): if the log does not say it, no
finding is produced. There is no inference about code the observer never read.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import sqlite3
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Iterator, Sequence

DIAGNOSTICS_VERSION = "1.0"
REPORT_VERSION = "1"
UTC_STAMP_FORMAT = "%Y%m%dT%H%M%SZ"

CATEGORIES = ("compile", "runtime_exception", "missing_asset", "import", "package",
              "environment", "project_layout", "ui_conflict", "rig_conflict")
SEVERITIES = ("critical", "error", "warning", "info")
SEVERITY_RANK = {"critical": 0, "error": 1, "warning": 2, "info": 3}

MAX_SNIPPET = 300
MAX_EVIDENCE_PER_FINDING = 6
MAX_CRASH_LINES = 120
MAX_FRAMES_RECORDED = 4
# knowledge.py rejects fact values longer than 2000 characters.
FACT_VALUE_LIMIT = 1990
FACT_KEY_LIMIT = 256


class DiagnosticsError(ValueError):
    """Raised when the caller asks for something the observer refuses to do."""


# --------------------------------------------------------------------------------------
# Findings
# --------------------------------------------------------------------------------------

@dataclass
class Finding:
    """One diagnosed problem, always carrying its evidence.

    ``evidence`` entries are ``{"file": str, "line": int, "snippet": str}`` where
    ``line`` is the real 1-based line number in the file named by ``file``.
    ``occurrences`` counts how many matching lines were folded into this finding
    (aggregation keeps up to ``MAX_EVIDENCE_PER_FINDING`` example locations).
    """

    finding_id: str
    category: str
    severity: str
    title: str
    detail: str
    evidence: list[dict] = field(default_factory=list)
    suggested_action: str = ""
    confidence: float = 0.5
    rule_id: str = ""
    occurrences: int = 1
    sources: list[str] = field(default_factory=list)
    signature: str = ""

    def __post_init__(self) -> None:
        if self.category not in CATEGORIES:
            raise DiagnosticsError(f"Unknown finding category: {self.category!r}")
        if self.severity not in SEVERITIES:
            raise DiagnosticsError(f"Unknown finding severity: {self.severity!r}")
        if not isinstance(self.confidence, (int, float)) or not 0.0 <= float(self.confidence) <= 1.0:
            raise DiagnosticsError("Finding confidence must be between 0.0 and 1.0.")
        if self.occurrences < 1:
            raise DiagnosticsError("Finding occurrences must be at least 1.")

    @property
    def locations(self) -> list[str]:
        return [f"{item['file']}:{item['line']}" for item in self.evidence]

    def to_dict(self) -> dict:
        return {
            "finding_id": self.finding_id,
            "category": self.category,
            "severity": self.severity,
            "title": self.title,
            "detail": self.detail,
            "evidence": [dict(item) for item in self.evidence],
            "suggested_action": self.suggested_action,
            "confidence": round(float(self.confidence), 2),
            "rule_id": self.rule_id,
            "occurrences": self.occurrences,
            "sources": list(self.sources),
        }


def _digest(text: str) -> str:
    return hashlib.sha1(text.encode("utf-8", "replace")).hexdigest()[:12]


def _clip(text: str, limit: int = MAX_SNIPPET) -> str:
    collapsed = " ".join(str(text).split())
    if len(collapsed) <= limit:
        return collapsed
    return collapsed[: limit - 1] + "\u2026"


def _norm_path(value: Any) -> str:
    return str(value).replace("\\", "/")


def normalize_message(text: str) -> str:
    """Collapse volatile parts of a log line so repeats aggregate into one finding.

    GUIDs, hex addresses, long numbers (pids, byte counts) and floats (durations)
    are replaced by placeholders. Short numbers such as ``error CS0246`` or
    ``Curl error 35`` are preserved on purpose - they are the identity of the
    problem - and rules that key on them also pass an explicit ``key_group``.
    """
    collapsed = " ".join(str(text).split())
    collapsed = re.sub(r"\b[0-9a-fA-F]{32}\b", "<guid>", collapsed)
    collapsed = re.sub(r"\b0x[0-9a-fA-F]+\b", "<hex>", collapsed)
    collapsed = re.sub(r"\d+\.\d+", "<float>", collapsed)
    collapsed = re.sub(r"\b\d{2,}\b", "<num>", collapsed)
    return collapsed


# --------------------------------------------------------------------------------------
# Rule table - log line patterns
# --------------------------------------------------------------------------------------

@dataclass(frozen=True)
class Rule:
    rule_id: str
    category: str
    severity: str
    pattern: "re.Pattern[str]"
    title: str
    detail: str
    action: str
    confidence: float
    key_group: str | None = None


def _rule(rule_id, category, severity, pattern, title, detail, action, confidence,
          key_group=None) -> Rule:
    return Rule(rule_id=rule_id, category=category, severity=severity,
                pattern=re.compile(pattern), title=title, detail=detail,
                action=action, confidence=confidence, key_group=key_group)


# Order matters: the first matching rule wins for a given line, so the most
# specific patterns are listed before the generic ones.
RULES: tuple[Rule, ...] = (
    # --- compile ----------------------------------------------------------------------
    _rule("compile.cs-error", "compile", "error",
          r"\berror\s+(?P<code>CS\d{3,4})\s*:\s*(?P<msg>.+)$",
          "C# compiler error {code}",
          "The C# compiler rejected a script: {code}: {msg}",
          "Fix the reported error and re-run the Unity compile or validation step.",
          0.98, key_group="code"),
    _rule("compile.cs-warning", "compile", "warning",
          r"\bwarning\s+(?P<code>CS\d{3,4})\s*:\s*(?P<msg>.+)$",
          "C# compiler warning {code}",
          "The C# compiler reported a warning: {code}: {msg}",
          "Review the warning; suppress it explicitly only when the intent is deliberate.",
          0.95, key_group="code"),
    _rule("compile.shader-error", "compile", "error",
          r"\bShader error in\s+'(?P<shader>[^']+)'\s*:\s*(?P<msg>.+)$",
          "Shader compile error in {shader}",
          "Shader '{shader}' failed to compile: {msg}",
          "Fix the shader source; open it in the Shader Inspector for the full error list.",
          0.95, key_group="shader"),
    _rule("compile.shader-compilation-failed", "compile", "error",
          r"(?i)\bshader compilation failed\b(?P<msg>.*)$",
          "Shader compilation failed",
          "A shader failed to compile: {msg}",
          "Re-run the build to capture the full shader error, then fix the shader source.",
          0.9),
    # --- runtime exceptions -----------------------------------------------------------
    _rule("runtime.null-reference", "runtime_exception", "error",
          r"\bNullReferenceException\b\s*:?\s*(?P<msg>.*)$",
          "NullReferenceException",
          "A NullReferenceException was logged: {msg}",
          "Reproduce with the stack trace visible and null-check the dereferenced field.",
          0.9),
    _rule("runtime.missing-reference", "runtime_exception", "error",
          r"\bMissingReferenceException\b\s*:?\s*(?P<msg>.*)$",
          "MissingReferenceException",
          "A reference to a destroyed or missing object was used: {msg}",
          "Find which reference was destroyed before use and re-check it, or hold it differently.",
          0.9),
    _rule("runtime.object-disposed", "runtime_exception", "error",
          r"\bObjectDisposedException\b\s*:?\s*(?P<msg>.*)$",
          "ObjectDisposedException",
          "Code used an object after it was disposed: {msg}",
          "Check the shutdown order of the owning subsystem; dispose after the last user stops.",
          0.9),
    # --- environment / network / licensing --------------------------------------------
    _rule("environment.curl-tls", "environment", "error",
          r"\bCurl error\s+(?P<code>\d+)\b[^\n]*(?:Cert verify failed|certificate could not be verified)",
          "TLS certificate verification failed (Curl error {code})",
          "An outbound HTTPS request could not verify the remote certificate. "
          "Unity falls back to a legacy UnityTls path here: {msg}",
          "Check the machine trust store and proxy/TLS-inspection settings; this blocks "
          "package registry and licensing traffic but is unrelated to project source code.",
          0.85, key_group="code"),
    _rule("environment.curl-aborted", "environment", "info",
          r"\bCurl error\s+(?P<code>42)\b[^\n]*(?:Callback aborted|aborted)",
          "Transfer aborted during shutdown (Curl error {code})",
          "An in-flight request was cancelled, which normally happens while the editor shuts "
          "down: {msg}",
          "No action needed unless it is followed by a real failure.",
          0.7, key_group="code"),
    _rule("environment.curl", "environment", "warning",
          r"\bCurl error\s+(?P<code>\d+)\b\s*:?\s*(?P<msg>.*)$",
          "Network request failed (Curl error {code})",
          "An outbound request failed: {msg}",
          "Confirm whether the failing host is reachable from this machine, then retry the "
          "operation that triggered it.",
          0.8, key_group="code"),
    _rule("environment.licensing-error", "environment", "error",
          r"\[Licensing[^\]]*\]\s*(?:Error|Fatal)\s*:\s*(?P<msg>.+)$",
          "Unity licensing error",
          "The licensing client reported an error: {msg}",
          "Fix licensing before trusting any batchmode exit code: an unlicensed editor "
          "terminates early and its exit code does not describe the project.",
          0.9),
    _rule("environment.licensing-client-unavailable", "environment", "warning",
          r"LicensingClient has failed validation(?P<msg>.*)$",
          "Licensing client failed validation",
          "The editor dropped the licensing client handshake and continued without it: {msg}",
          "Treat licensing state as unverified for this run; re-check with a licensed editor.",
          0.8),
    _rule("environment.licensing-token", "environment", "warning",
          r"\[Licensing[^\]]*\]\s*(?P<msg>.*(?:token is unavailable|failed to update|"
          r"Unable to acquire|license denied|refused).*)$",
          "Licensing credential unavailable",
          "The licensing client could not obtain a usable credential: {msg}",
          "Check that the editor is signed in and that the environment variables needed by "
          "the licensing client are present.",
          0.85),
    _rule("environment.d3d12-info-queue", "environment", "info",
          r"(?i)d3d12:\s*failed to query info queue interface(?P<msg>.*)$",
          "D3D12 debug info queue unavailable",
          "The editor could not attach the D3D12 info queue: {msg}",
          "Informational only: it affects GPU validation messages, not project behaviour.",
          0.9),
    # --- package manager --------------------------------------------------------------
    _rule("package.upm-ipc", "package", "critical",
          r'Could not connect to IPC stream\s+"?(?P<stream>Upm-\d+)"?(?P<msg>.*)$',
          "Unity Package Manager IPC connection failed",
          "The editor never reached the package manager process ({stream}): {msg}",
          "Every dependency is unresolved in this state. Start Unity once with the "
          "environment the UPM helper needs, then confirm the IPC handshake before "
          "trusting any build result.",
          0.95),
    _rule("package.upm-start-failed", "package", "critical",
          r"Failed to start the Unity Package Manager local server process(?P<msg>.*)$",
          "Unity Package Manager server did not start",
          "The local UPM server process could not be started: {msg}",
          "Check the launch environment of the helper process (missing environment "
          "variables, blocked executable, antivirus) before re-running Unity.",
          0.95),
    _rule("package.upm-error", "package", "error",
          r"(?i)\[Package Manager\][^\n]*\b(?P<msg>(?:error|failed|failure)\b.{0,200})$",
          "Package Manager reported a failure",
          "The package manager logged a failure: {msg}",
          "Resolve the package error before importing, because a half-resolved package set "
          "produces misleading compile errors.",
          0.85),
    # --- asset import -----------------------------------------------------------------
    _rule("import.worker-failed", "import", "error",
          r"(?i)\[Worker\d*\][^\n]*\b(?P<msg>(?:failed|error|aborted)\b.{0,200})$",
          "Asset import worker failed",
          "An import worker reported a failure: {msg}",
          "Re-import the named asset; if it fails again, move it out of the project to "
          "confirm it is the source of the failure.",
          0.85),
    _rule("import.asset-import-failed", "import", "error",
          r"(?i)\bfailed to import\b(?P<msg>.*)$",
          "Asset import failed",
          "An asset failed to import: {msg}",
          "Delete the asset's library entry and re-import it, then re-check the console.",
          0.8),
    # --- missing assets ---------------------------------------------------------------
    _rule("missing_asset.missing-script", "missing_asset", "error",
          r"(?i)(?:the referenced script|script class cannot be found|missing script)"
          r"(?P<msg>.{0,200})$",
          "Missing or unloadable script",
          "A GameObject references a script that cannot be resolved: {msg}",
          "Restore the script assembly or remove the component; a missing script breaks "
          "every prefab and scene that uses it.",
          0.85),
    _rule("missing_asset.asset-not-found", "missing_asset", "warning",
          r"(?i)\b(?:could not find|failed to load|unable to load|not found)\b[^\n]{0,80}"
          r"\b(?:asset|prefab|scene|script|texture|material|plugin|assembly)\b(?P<msg>.{0,200})$",
          "Asset could not be resolved",
          "The editor could not resolve an asset reference: {msg}",
          "Confirm the asset still exists at the referenced path and that its meta file was "
          "not replaced.",
          0.7),
    # --- heuristic conflict categories (text evidence only) ---------------------------
    _rule("ui.event-system-conflict", "ui_conflict", "warning",
          r"(?i)(?:multiple event ?systems?|duplicate event ?systems?|"
          r"\d+ event ?systems? in the scene|exactly one event ?system|"
          r"event ?system[^\n]{0,60}\b(?:already exists|conflict|duplicate)\b)(?P<msg>.{0,200})$",
          "Conflicting EventSystem setup",
          "The log reports more than one EventSystem or a conflicting EventSystem state: {msg}",
          "Keep exactly one EventSystem per scene and disable the extras, then re-run the "
          "scene that logged this.",
          0.8),
    _rule("rig.duplicate-rig", "rig_conflict", "warning",
          r"(?i)\b(?:duplicated?|multiple)\s+(?:rigs?|animators?|skeletons?|avatar masks?)\b"
          r"(?P<msg>.{0,200})$",
          "Duplicated rig or animator",
          "The log reports duplicated rig/animator objects: {msg}",
          "Deduplicate the rig hierarchy and confirm each avatar has one animator before "
          "rebaking animation.",
          0.7),
    _rule("rig.lod-group-conflict", "rig_conflict", "warning",
          r"(?i)\blod ?group\b[^\n]{0,80}"
          r"\b(?:conflict|duplicate|multiple|missing|invalid|not valid)\b(?P<msg>.{0,200})$",
          "LODGroup conflict",
          "The log reports a LODGroup problem: {msg}",
          "Re-check the LODGroup renderer list and the mesh assignment for the flagged object.",
          0.7),
)

UNHANDLED_RE = re.compile(r"^\s*Unhandled exception\b(?P<msg>.*)$")
EXCEPTION_SIG_RE = re.compile(r"^(?:[A-Z][\w]*\.)*[A-Z][\w]*(?:Exception|Error)\b")
EXCEPTION_INLINE_RE = re.compile(
    r"(?P<exc>(?:[A-Z][\w]*\.)*[A-Z][\w]*(?:Exception|Error))\b\s*:?\s*(?P<msg>.*)$")
UNIT_STACK_FRAME_RE = re.compile(r"^at\s")
CONTINUATION_RE = re.compile(r"^(?:\s|--->|Object name:|Inner [Ee]xception:|Caused by:)")

# Lines that are known-benign Unity shutdown/telemetry noise. They are counted and
# reported in the report's ``ignored`` section with a reason, never as findings.
IGNORED_PATTERNS: tuple[tuple[str, str], ...] = (
    (r"abort_threads: Failed aborting id:", "mono thread-abort noise while the editor exits"),
    (r"m_LastAlloc not NULL", "stack allocator leak report printed during shutdown"),
    (r"Checking for leaked weakptr", "shutdown leak-check header, not a result"),
    (r"^##utp:", "UTF/UTP telemetry payload"),
    (r"\[Licensing[^\]]*\]\s*Trying to connect to existing licensing client channel",
     "normal licensing client handshake"),
    (r"\[Licensing[^\]]*\]\s*Successfully updated license",
     "licensing refresh succeeded"),
    (r"\[Licensing[^\]]*\]\s*Licensing Background thread has ended", "normal licensing shutdown"),
    (r'\[Package Manager\]\s*Connected to IPC stream\s+"?Upm-', "package manager handshake succeeded"),
    (r"Refreshing native plugins compatible for Editor", "routine plugin refresh"),
    (r"Preloading \d+ native plugins for Editor", "routine plugin preload"),
    (r"\[Package Manager\]\s*Done registering packages", "package registration succeeded"),
    (r"\[Package Manager\]\s*Restoring resolved packages state from cache", "routine package cache restore"),
)
IGNORED_COMPILED = tuple((re.compile(pattern), reason) for pattern, reason in IGNORED_PATTERNS)


def _ignored_reason(text: str) -> str | None:
    for pattern, reason in IGNORED_COMPILED:
        if pattern.search(text):
            return reason
    return None


# --------------------------------------------------------------------------------------
# Log parsing
# --------------------------------------------------------------------------------------

def _iter_lines(path: Path) -> Iterator[tuple[int, str]]:
    """Yield ``(line_number, text)`` for a file, tolerating invalid UTF-8.

    Some Unity logs are written to a redirected stream by several processes at once
    and end up with embedded NUL bytes (for example ``b"\\x00Unhandled exception."``).
    NULs are stripped so that line-start anchored rules still match; line numbers are
    unaffected because the split is done by the newline characters of the same file.
    """
    with open(path, "r", encoding="utf-8", errors="replace", newline="") as handle:
        for number, raw in enumerate(handle, 1):
            yield number, raw.replace("\x00", "").lstrip("\ufeff")


def _hash_file(path: Path) -> tuple[str, int, int]:
    digest = hashlib.sha256()
    size = 0
    nul_bytes = 0
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 16), b""):
            size += len(chunk)
            nul_bytes += chunk.count(0)
            digest.update(chunk)
    return digest.hexdigest(), size, nul_bytes


def _evidence(source: str, line: int, snippet: str) -> dict:
    return {"file": source, "line": int(line), "snippet": _clip(snippet)}


def _format(template: str, values: dict) -> str:
    return template.format_map(_SafeDict(values))


class _SafeDict(dict):
    def __missing__(self, key):  # noqa: D105 - deliberately silent for unknown fields
        return ""


def _rule_finding(rule: Rule, match: "re.Match[str]", source: str, line: int,
                  text: str) -> Finding:
    groups = {name: (value or "") for name, value in match.groupdict().items()}
    message = re.sub(r"^[\s.;:,]+", "", groups.get("msg", "") or text)
    values = dict(groups)
    values["msg"] = message
    values["line"] = line
    values["file"] = source
    key_part = normalize_message(groups.get(rule.key_group, "")) if rule.key_group else ""
    signature_body = normalize_message(message if key_part else text)
    signature = f"{rule.rule_id}|{key_part}|{signature_body}"
    return Finding(
        finding_id=f"{rule.rule_id}:{_digest(signature)}",
        category=rule.category,
        severity=rule.severity,
        title=_format(rule.title, values),
        detail=_format(rule.detail, values),
        evidence=[_evidence(source, line, text)],
        suggested_action=_format(rule.action, values),
        confidence=rule.confidence,
        rule_id=rule.rule_id,
        occurrences=1,
        sources=[source],
        signature=signature,
    )


def _crash_finding(crash: dict, source: str) -> Finding:
    signature_line = crash.get("sig") or crash.get("header", "Unhandled exception")
    exception = crash.get("sig", "")
    exception_type = ""
    inline = EXCEPTION_INLINE_RE.search(signature_line)
    if inline:
        exception_type = inline.group("exc").split(".")[-1]
        exception = f"{inline.group('exc')}: {inline.group('msg')}".strip().rstrip(":")
    title = f"Unhandled exception: {exception_type}" if exception_type else "Unhandled exception"
    signature = f"crash|{normalize_message(exception or signature_line)}"
    detail = (
        f"An unhandled .NET exception terminated the process: {signature_line.strip().rstrip('.')}. "
        "The evidence entries are the exception line and the stack frames that follow it "
        "in the log."
    )
    action = (
        "Determine whether the crash happened while working or while shutting down; "
        "it is reported as critical regardless, and it invalidates the exit code of the "
        "command that produced this log."
    )
    return Finding(
        finding_id=f"runtime.unhandled-exception:{_digest(signature)}",
        category="runtime_exception",
        severity="critical",
        title=title,
        detail=detail,
        evidence=[_evidence(source, line, snippet) for line, snippet in crash.get("evidence", [])],
        suggested_action=action,
        confidence=0.95,
        rule_id="runtime.unhandled-exception",
        occurrences=1,
        sources=[source],
        signature=signature,
    )


def scan_log(path: str | os.PathLike) -> dict:
    """Scan one log file. Returns ``{"stats": {...}, "findings": [...], "ignored": [...]}``."""
    log_path = Path(path)
    if not log_path.is_file():
        raise DiagnosticsError(f"Log file does not exist: {log_path}")
    source = _norm_path(log_path)
    raw_findings: list[Finding] = []
    ignored_counts: dict[str, int] = {}
    crash: dict | None = None
    line_count = 0

    for number, raw in _iter_lines(log_path):
        line_count = number
        text = raw.rstrip("\r\n")
        stripped = text.strip()

        if crash is not None:
            if crash["consumed"] < MAX_CRASH_LINES and _is_continuation(text, stripped):
                crash["consumed"] += 1
                if UNIT_STACK_FRAME_RE.match(stripped):
                    crash["frames"] += 1
                    if len(crash["evidence"]) < MAX_FRAMES_RECORDED + 1:
                        crash["evidence"].append((number, stripped))
                elif crash["sig"] is None and EXCEPTION_SIG_RE.match(stripped):
                    crash["sig"] = stripped
                    if len(crash["evidence"]) < MAX_FRAMES_RECORDED + 1:
                        crash["evidence"].append((number, stripped))
                continue
            raw_findings.append(_crash_finding(crash, source))
            crash = None

        if not stripped:
            continue
        reason = _ignored_reason(text)
        if reason:
            ignored_counts[reason] = ignored_counts.get(reason, 0) + 1
            continue
        header = UNHANDLED_RE.match(text)
        if header:
            crashed = _new_crash(number, text, header)
            crash = crashed
            continue
        for rule in RULES:
            match = rule.pattern.search(text)
            if match:
                raw_findings.append(_rule_finding(rule, match, source, number, text))
                break

    if crash is not None:
        raw_findings.append(_crash_finding(crash, source))

    digest, size, nul_bytes = _hash_file(log_path)
    return {
        "stats": {"path": source, "bytes": size, "lines": line_count,
                  "sha256": digest, "nul_bytes": nul_bytes},
        "findings": aggregate(raw_findings),
        "ignored": [{"reason": reason, "count": count}
                    for reason, count in sorted(ignored_counts.items())],
    }


def _new_crash(line: int, text: str, header: "re.Match[str]") -> dict:
    crash = {"header": text.strip(), "header_line": line, "sig": None, "sig_line": None,
             "frames": 0, "consumed": 0,
             "evidence": [(line, text.strip())]}
    tail = header.group("msg").strip()
    if tail:
        inline = EXCEPTION_INLINE_RE.search(tail)
        if inline:
            crash["sig"] = f"{inline.group('exc')}: {inline.group('msg')}".strip().rstrip(":")
            crash["sig_line"] = line
    return crash


def _is_continuation(text: str, stripped: str) -> bool:
    if UNIT_STACK_FRAME_RE.match(stripped):
        return True
    if CONTINUATION_RE.match(text):
        return True
    return bool(EXCEPTION_SIG_RE.match(stripped))


def parse_log(path: str | os.PathLike) -> list[Finding]:
    """Public entry point required by the Phase 1 contract: findings for one log file."""
    return scan_log(path)["findings"]


# --------------------------------------------------------------------------------------
# Aggregation
# --------------------------------------------------------------------------------------

def aggregate(findings: Iterable[Finding]) -> list[Finding]:
    """Fold findings with the same signature into one entry with counted occurrences.

    Evidence keeps up to ``MAX_EVIDENCE_PER_FINDING`` real locations; the total is
    preserved in ``occurrences``. Confidence is nudged upwards for repeated
    messages (a message that appears five times is not a fluke), capped at 0.97.
    """
    buckets: dict[str, Finding] = {}
    for finding in findings:
        key = finding.signature or finding.finding_id
        existing = buckets.get(key)
        if existing is None:
            clone = Finding(**{**finding.__dict__})
            buckets[key] = clone
            continue
        existing.occurrences += finding.occurrences
        for source in finding.sources:
            if source not in existing.sources:
                existing.sources.append(source)
        for item in finding.evidence:
            if len(existing.evidence) < MAX_EVIDENCE_PER_FINDING and item not in existing.evidence:
                existing.evidence.append(item)
    result = []
    for finding in buckets.values():
        if finding.occurrences > 1:
            finding.confidence = round(min(0.97, finding.confidence + 0.02 * (finding.occurrences - 1)), 2)
        finding.evidence.sort(key=lambda item: (item["file"], item["line"]))
        result.append(finding)
    result.sort(key=lambda item: (SEVERITY_RANK[item.severity], -item.occurrences,
                                  item.category, item.finding_id))
    return result


# --------------------------------------------------------------------------------------
# Project inventory (read-only)
# --------------------------------------------------------------------------------------

SKIP_DIRS = frozenset({
    "Library", "Temp", "obj", "Obj", "Logs", "UserSettings", ".git", ".vs", ".vscode",
    ".idea", "Build", "Builds", "Recordings", "MemoryCaptures", "node_modules", ".v2c",
})
GUID_RE = re.compile(r"^\s*guid:\s*([0-9a-fA-F]{32})\s*$")


def _read_text(path: Path, limit: int | None = None) -> str:
    with open(path, "r", encoding="utf-8", errors="replace") as handle:
        return handle.read() if limit is None else handle.read(limit)


def _guid_line(text: str) -> tuple[str | None, int]:
    for number, line in enumerate(text.splitlines(), 1):
        match = GUID_RE.match(line)
        if match:
            return match.group(1).lower(), number
    return None, 1


def _line_of(text: str, needle: str) -> int:
    for number, line in enumerate(text.splitlines(), 1):
        if needle in line:
            return number
    return 1


def _walk_assets(assets_root: Path) -> tuple[list[str], list[str]]:
    files, directories = [], []
    for current, subdirs, names in os.walk(assets_root):
        subdirs[:] = sorted(name for name in subdirs if name not in SKIP_DIRS)
        base = Path(current)
        for name in sorted(names):
            relative = _norm_path(base.joinpath(name).relative_to(assets_root))
            files.append(relative)
        for name in subdirs:
            relative = _norm_path(base.joinpath(name).relative_to(assets_root))
            directories.append(relative)
    return files, directories


def _inventory_finding(rule_id: str, category: str, severity: str, title: str, detail: str,
                       action: str, confidence: float, evidence: list[dict],
                       occurrences: int, sources: list[str], signature: str) -> Finding:
    return Finding(
        finding_id=f"{rule_id}:{_digest(signature)}",
        category=category,
        severity=severity,
        title=title,
        detail=detail,
        evidence=evidence[:MAX_EVIDENCE_PER_FINDING],
        suggested_action=action,
        confidence=confidence,
        rule_id=rule_id,
        occurrences=max(1, occurrences),
        sources=sources,
        signature=signature,
    )


def _parse_build_scenes(text: str) -> tuple[list[tuple[int, str]] | None, int]:
    """Return ``[(line, scene_path), ...]`` and the line of ``m_Scenes``."""
    lines = text.splitlines()
    start = None
    for number, line in enumerate(lines, 1):
        if re.match(r"\s*m_Scenes\s*:", line):
            start = number
            if line.split(":", 1)[1].strip() == "[]":
                return [], number
            break
    if start is None:
        return None, 1
    scenes: list[tuple[int, str]] = []
    for number in range(start + 1, len(lines) + 1):
        line = lines[number - 1]
        if re.match(r"\s*m_\w+\s*:", line):
            break
        match = re.search(r"^\s*path:\s*(\S.*?)\s*$", line)
        if match:
            scenes.append((number, match.group(1)))
    return scenes, start


def inventory_project(project_root: str | os.PathLike) -> tuple[dict, list[Finding]]:
    """Structural checks over the project tree. Returns ``(metadata, findings)``."""
    root = Path(project_root)
    findings: list[Finding] = []
    metadata: dict[str, Any] = {"root": _norm_path(root), "exists": root.is_dir()}

    if not root.is_dir():
        findings.append(_inventory_finding(
            "project_layout.root-missing", "project_layout", "error",
            "Project root does not exist",
            f"The observer was pointed at {_norm_path(root)}, which is not a directory.",
            "Pass the directory that contains Assets/ and ProjectSettings/.",
            0.95, [], 1, [], f"root-missing|{_norm_path(root)}"))
        return metadata, findings

    # --- Assets -----------------------------------------------------------------------
    assets = root / "Assets"
    metadata["assets"] = {"exists": assets.is_dir()}
    if not assets.is_dir():
        findings.append(_inventory_finding(
            "project_layout.assets-missing", "project_layout", "error",
            "Assets directory is missing",
            "A Unity project must contain an Assets/ directory; nothing can be imported without it.",
            "Create Assets/ (Unity recreates it on open) and re-run the observer.",
            0.95, [], 1, [], f"assets-missing|{_norm_path(root)}"))
        asset_files, asset_dirs = [], []
    else:
        asset_files, asset_dirs = _walk_assets(assets)
        payload_files = [name for name in asset_files if not name.endswith(".meta")]
        meta_files = [name for name in asset_files if name.endswith(".meta")]
        scenes = sorted(name for name in payload_files if name.lower().endswith(".unity"))
        metadata["assets"].update({
            "files": len(payload_files), "directories": len(asset_dirs),
            "meta_files": len(meta_files), "scenes": scenes,
        })
        if not payload_files:
            findings.append(_inventory_finding(
                "project_layout.assets-empty", "project_layout", "error",
                "Assets directory contains no assets",
                "Assets/ exists but holds no files other than .meta entries.",
                "Import the package or create the project content that is expected to be there.",
                0.9, [], 1, [], f"assets-empty|{_norm_path(assets)}"))
        elif not scenes:
            findings.append(_inventory_finding(
                "project_layout.assets-without-scenes", "project_layout", "warning",
                "Assets contains no scene",
                f"{len(payload_files)} asset file(s) were found but none of them is a .unity scene.",
                "Add a scene so the project can be built and the runtime behaviour can be tested.",
                0.8, [], 1, [], f"assets-without-scenes|{_norm_path(assets)}"))

        # --- file <-> .meta pairing ---------------------------------------------------
        owners = set(payload_files) | set(asset_dirs)
        orphan_evidence, missing_evidence = [], []
        for name in meta_files:
            owner = name[:-len(".meta")]
            if owner not in owners:
                guid, guid_line = _guid_line(_read_text(assets / name, 4096))
                orphan_evidence.append(_evidence(_norm_path(assets / name), guid_line,
                                                 f"guid: {guid} for missing {owner}"))
        for name in payload_files:
            if f"{name}.meta" not in set(meta_files):
                missing_evidence.append(_evidence(_norm_path(assets / name), 1, name))
        if orphan_evidence:
            findings.append(_inventory_finding(
                "missing_asset.orphan-meta", "missing_asset", "warning",
                "Orphan .meta files in Assets",
                f"{len(orphan_evidence)} .meta file(s) have no matching asset or folder; "
                "their GUIDs are reserved and Unity deletes such metas on the next import.",
                "Delete the listed .meta files (they belong to a removed asset) or restore "
                "the asset that they describe.",
                0.85, orphan_evidence, len(orphan_evidence),
                [_norm_path(assets)],
                "orphan-meta|" + "|".join(item["file"] for item in orphan_evidence)))
        if missing_evidence:
            findings.append(_inventory_finding(
                "missing_asset.missing-meta", "missing_asset", "warning",
                "Assets without .meta files",
                f"{len(missing_evidence)} asset file(s) have no .meta file, so their GUIDs are "
                "not stable and references to them can break.",
                "Let Unity re-import the project so it generates the missing .meta files, then "
                "commit them with the asset.",
                0.85, missing_evidence, len(missing_evidence), [_norm_path(assets)],
                "missing-meta|" + "|".join(item["file"] for item in missing_evidence)))

        # --- duplicate GUIDs ----------------------------------------------------------
        by_guid: dict[str, list[tuple[str, int]]] = {}
        for name in meta_files:
            guid, guid_line = _guid_line(_read_text(assets / name, 4096))
            if guid:
                by_guid.setdefault(guid, []).append((name, guid_line))
        duplicates = {guid: places for guid, places in by_guid.items() if len(places) > 1}
        if duplicates:
            duplicate_evidence = [
                _evidence(_norm_path(assets / name), line, f"guid: {guid} also used by "
                                                           + ", ".join(other for other, _ in places if other != name))
                for guid, places in sorted(duplicates.items())
                for name, line in places
            ]
            findings.append(_inventory_finding(
                "missing_asset.duplicate-guid", "missing_asset", "error",
                "Duplicate asset GUIDs",
                f"{len(duplicates)} GUID(s) are claimed by more than one .meta file; Unity "
                "resolves the conflict arbitrarily, so references silently point at the wrong asset.",
                "Give every .meta file a unique GUID (delete the duplicate asset and re-import it).",
                0.9, duplicate_evidence, len(duplicate_evidence), [_norm_path(assets)],
                "duplicate-guid|" + "|".join(sorted(duplicates))))

    # --- ProjectSettings --------------------------------------------------------------
    settings = root / "ProjectSettings"
    version_file = settings / "ProjectVersion.txt"
    metadata["project_settings"] = {"exists": settings.is_dir(),
                                    "project_version_file": version_file.is_file()}
    if not settings.is_dir():
        findings.append(_inventory_finding(
            "project_layout.project-settings-missing", "project_layout", "error",
            "ProjectSettings directory is missing",
            "Without ProjectSettings/ the editor treats the folder as a new project and rewrites "
            "editor version, packages and build settings.",
            "Restore ProjectSettings/ from source control before opening the project.",
            0.95, [], 1, [], f"project-settings-missing|{_norm_path(root)}"))
    elif not version_file.is_file():
        findings.append(_inventory_finding(
            "environment.project-version-missing", "environment", "warning",
            "ProjectVersion.txt is missing",
            "ProjectSettings/ProjectVersion.txt records the editor version; without it the Hub "
            "cannot pick the right editor and any editor may upgrade the project.",
            "Recreate ProjectVersion.txt with the intended m_EditorVersion.",
            0.85, [], 1, [], f"project-version-missing|{_norm_path(version_file)}"))
    else:
        text = _read_text(version_file)
        match = re.search(r"^\s*m_EditorVersion:\s*(\S+)\s*$", text, re.M)
        revision = re.search(r"^\s*m_EditorVersionWithRevision:\s*(\S+)\s*\((\w+)\)\s*$", text, re.M)
        metadata["editor_version"] = match.group(1) if match else None
        metadata["editor_revision"] = revision.group(2) if revision else None
        if not match:
            findings.append(_inventory_finding(
                "environment.project-version-unparsed", "environment", "warning",
                "Editor version could not be read",
                "ProjectVersion.txt does not contain a parsable m_EditorVersion line.",
                "Rewrite the file with a single m_EditorVersion entry.",
                0.8, [_evidence(_norm_path(version_file), 1, text.strip().splitlines()[0]
                                if text.strip() else "")], 1, [_norm_path(version_file)],
                f"project-version-unparsed|{_norm_path(version_file)}"))

    # --- EditorBuildSettings ----------------------------------------------------------
    build_settings = settings / "EditorBuildSettings.asset"
    metadata["build_settings"] = {"path": _norm_path(build_settings), "exists": build_settings.is_file()}
    if build_settings.is_file():
        text = _read_text(build_settings)
        scenes, scenes_line = _parse_build_scenes(text)
        listed = [path for _, path in (scenes or [])]
        metadata["build_settings"]["scenes"] = listed
        if scenes == []:
            findings.append(_inventory_finding(
                "project_layout.build-settings-empty", "project_layout", "warning",
                "Build settings list no scenes",
                "EditorBuildSettings.asset exists but its m_Scenes list is empty, so a build would "
                "contain no scene.",
                "Add the intended scene(s) to EditorBuildSettings so builds and playmode tests "
                "have an entry point.",
                0.85, [_evidence(_norm_path(build_settings), scenes_line, "m_Scenes: []")],
                1, [_norm_path(build_settings)],
                f"build-settings-empty|{_norm_path(build_settings)}"))
        elif scenes is None:
            findings.append(_inventory_finding(
                "project_layout.build-settings-unparsed", "project_layout", "warning",
                "Build settings could not be parsed",
                "EditorBuildSettings.asset has no m_Scenes section, so the scene list is unknown.",
                "Re-save the build settings from the editor or restore the file from source control.",
                0.7, [], 1, [_norm_path(build_settings)],
                f"build-settings-unparsed|{_norm_path(build_settings)}"))
        else:
            missing_scene_evidence = [
                _evidence(_norm_path(build_settings), line, f"path: {path}")
                for line, path in scenes if not (root / path).is_file()
            ]
            if missing_scene_evidence:
                findings.append(_inventory_finding(
                    "missing_asset.build-scene-missing", "missing_asset", "error",
                    "Scene listed in build settings does not exist",
                    f"{len(missing_scene_evidence)} scene(s) referenced by EditorBuildSettings.asset "
                    "are not present on disk.",
                    "Restore the missing scene files or remove the stale entries.",
                    0.9, missing_scene_evidence, len(missing_scene_evidence),
                    [_norm_path(build_settings)],
                    "build-scene-missing|" + "|".join(item["snippet"] for item in missing_scene_evidence)))
    elif settings.is_dir():
        findings.append(_inventory_finding(
            "project_layout.build-settings-missing", "project_layout", "warning",
            "EditorBuildSettings.asset is missing",
            "ProjectSettings/EditorBuildSettings.asset was not found, so the build scene list is unknown.",
            "Restore the file (or let Unity recreate it) and add the scene list.",
            0.8, [], 1, [], f"build-settings-missing|{_norm_path(build_settings)}"))

    # --- Packages/manifest.json -------------------------------------------------------
    manifest = root / "Packages" / "manifest.json"
    metadata["manifest"] = {"path": _norm_path(manifest), "exists": manifest.is_file()}
    if not manifest.is_file():
        findings.append(_inventory_finding(
            "package.manifest-missing", "package", "error",
            "Packages/manifest.json is missing",
            "Without a manifest the editor resolves a default package set, so the dependency "
            "list in the repository is not what gets loaded.",
            "Restore Packages/manifest.json from source control.",
            0.9, [], 1, [], f"manifest-missing|{_norm_path(manifest)}"))
    else:
        text = _read_text(manifest)
        try:
            data = json.loads(text)
        except (ValueError, UnicodeDecodeError) as error:
            data = None
            findings.append(_inventory_finding(
                "package.manifest-invalid", "package", "error",
                "Packages/manifest.json is not valid JSON",
                f"Parsing the manifest failed: {error}",
                "Fix the JSON syntax; the editor cannot resolve any dependency from a broken manifest.",
                0.95, [_evidence(_norm_path(manifest), 1, text.strip().splitlines()[0]
                                 if text.strip() else "")], 1, [_norm_path(manifest)],
                f"manifest-invalid|{_norm_path(manifest)}"))
        if isinstance(data, dict):
            dependencies = data.get("dependencies")
            if not isinstance(dependencies, dict):
                findings.append(_inventory_finding(
                    "package.manifest-no-dependencies", "package", "warning",
                    "Manifest declares no dependencies",
                    "Packages/manifest.json has no usable \"dependencies\" object.",
                    "Declare the packages the project needs, or confirm that an empty set is intended.",
                    0.8, [_evidence(_norm_path(manifest), _line_of(text, "\"dependencies\""),
                                    "\"dependencies\"")], 1, [_norm_path(manifest)],
                    f"manifest-no-dependencies|{_norm_path(manifest)}"))
            else:
                metadata["manifest"]["dependencies"] = sorted(dependencies)
                metadata["manifest"]["dependency_count"] = len(dependencies)
                if not dependencies:
                    findings.append(_inventory_finding(
                        "package.manifest-empty", "package", "warning",
                        "Manifest dependency list is empty",
                        "Packages/manifest.json declares an empty dependencies object.",
                        "Confirm that a dependency-free project is intended; otherwise restore the list.",
                        0.75, [_evidence(_norm_path(manifest), _line_of(text, "\"dependencies\""),
                                        "\"dependencies\": {}")], 1, [_norm_path(manifest)],
                        f"manifest-empty|{_norm_path(manifest)}"))
                lines = text.splitlines()
                for name, spec in sorted(dependencies.items()):
                    line = next((number for number, value in enumerate(lines, 1)
                                 if f'"{name}"' in value), 1)
                    if not re.match(r"^[a-z0-9][a-z0-9._-]*\.[a-z0-9._-]+$", name):
                        findings.append(_inventory_finding(
                            "package.malformed-dependency-name", "package", "warning",
                            f"Malformed package name: {name}",
                            f"The manifest lists the dependency name {name!r}, which is not a "
                            "reverse-DNS package name.",
                            "Use the exact package name from the registry.",
                            0.7, [_evidence(_norm_path(manifest), line, lines[line - 1])], 1,
                            [_norm_path(manifest)], f"malformed-name|{name}"))
                    if isinstance(spec, str) and re.match(r"^(?:file:|git\+|https?://|\.\.|/)", spec):
                        findings.append(_inventory_finding(
                            "package.non-registry-dependency", "package", "warning",
                            f"Non-registry dependency: {name}",
                            f"{name} resolves to {spec!r}, which depends on a local path or remote "
                            "URL being present at import time.",
                            "Vendor the dependency or pin it to a registry version so the project "
                            "resolves identically on another machine.",
                            0.75, [_evidence(_norm_path(manifest), line, lines[line - 1])], 1,
                            [_norm_path(manifest)], f"non-registry|{name}|{spec}"))

    return metadata, findings


# --------------------------------------------------------------------------------------
# Persistence into the brain knowledge base (opt-in)
# --------------------------------------------------------------------------------------

def fact_category(finding: Finding) -> str:
    """Map a finding to a ``knowledge.py`` fact category.

    ``knowledge.py`` allows ``terrain, economy, population, narrative, performance,
    weather, entity, player, system, custom``. Every Phase 1 finding describes the
    health of the project/system itself, so all of them map to ``system``.
    ``performance`` is deliberately unused: this observer detects no performance
    evidence, and inventing that mapping would be dishonest.
    """
    return "system"


def fact_key(finding: Finding) -> str:
    key = f"diagnostics.{finding.finding_id}"
    return key[:FACT_KEY_LIMIT]


def fact_value(finding: Finding) -> str:
    """Serialise a finding into a fact value that satisfies knowledge.py limits."""
    payload: dict[str, Any] = {
        "severity": finding.severity,
        "category": finding.category,
        "confidence": round(float(finding.confidence), 2),
        "occurrences": finding.occurrences,
        "title": finding.title,
        "detail": finding.detail,
        "action": finding.suggested_action,
        "evidence": finding.locations,
    }
    text = _dump(payload)
    if len(text) <= FACT_VALUE_LIMIT:
        return text
    payload.pop("evidence", None)
    payload["evidence_count"] = len(finding.evidence)
    text = _dump(payload)
    if len(text) <= FACT_VALUE_LIMIT:
        return text
    for budget in (600, 200, 0):
        payload["detail"] = finding.detail[:budget]
        text = _dump(payload)
        if len(text) <= FACT_VALUE_LIMIT:
            return text
    payload = {"severity": finding.severity, "category": finding.category,
               "title": finding.title[:200], "truncated": True}
    return _dump(payload)


def _dump(payload: dict) -> str:
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def persist_findings(findings: Sequence[Finding], db_path: str | os.PathLike, world: str) -> dict:
    """Write findings as facts into the brain database through ``knowledge.KnowledgeBase``.

    The existing knowledge API is used as-is; this module does not alter its schema.
    Limitation worth knowing: ``KnowledgeBase.upsert_fact`` stores a single primitive
    value per key, so a finding is stored as one JSON string (bounded to fit the
    2000-character limit) rather than as a structured row.
    """
    facts = [{"key": fact_key(finding), "value": fact_value(finding),
              "category": fact_category(finding), "confidence": round(float(finding.confidence), 2)}
             for finding in findings]
    facts.append({"key": "diagnostics.summary",
                  "value": _dump({"findings": len(findings),
                                  "critical": _count(findings, "critical"),
                                  "error": _count(findings, "error"),
                                  "warning": _count(findings, "warning"),
                                  "info": _count(findings, "info")}),
                  "category": "system", "confidence": 1.0})
    facts.append({"key": "diagnostics.last_run",
                  "value": _dump(datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")),
                  "category": "system", "confidence": 1.0})

    from knowledge import KnowledgeBase  # local import: same package, no side effects

    connection = sqlite3.connect(str(db_path), timeout=5)
    try:
        connection.row_factory = sqlite3.Row
        knowledge = KnowledgeBase(connection)
        warnings = knowledge.upsert_facts(world, facts)
    finally:
        connection.close()
    return {"enabled": True, "world": world, "database": _norm_path(db_path),
            "facts_written": len(facts) - len(warnings), "facts_rejected": len(warnings),
            "warnings": warnings}


def _count(findings: Sequence[Finding], severity: str) -> int:
    return sum(1 for finding in findings if finding.severity == severity)


# --------------------------------------------------------------------------------------
# Report assembly
# --------------------------------------------------------------------------------------

def build_report(project_root: str | os.PathLike | None,
                 log_paths: Sequence[str | os.PathLike]) -> dict:
    findings: list[Finding] = []
    log_meta = []
    ignored: dict[str, dict[str, Any]] = {}
    for path in log_paths:
        scan = scan_log(path)
        findings.extend(scan["findings"])
        log_meta.append(scan["stats"])
        for entry in scan["ignored"]:
            bucket = ignored.setdefault(entry["reason"], {"reason": entry["reason"], "count": 0})
            bucket["count"] += entry["count"]
    project_meta: dict[str, Any] = {}
    if project_root:
        project_meta, project_findings = inventory_project(project_root)
        findings.extend(project_findings)
    merged = aggregate(findings)
    summary = {severity: _count(merged, severity) for severity in SEVERITIES}
    summary["findings"] = len(merged)
    notes = [
        "This observer is read-only: it writes only the report files and never touches "
        "Assets/, ProjectSettings/, Packages/ or the logs it read.",
        "Unity runtime console output lives in the editor log outside the project "
        "(for example %LOCALAPPDATA%/Unity/Editor/Editor.log); it is only diagnosable "
        "if it was exported into a file that is passed to this observer.",
        "ui_conflict and rig_conflict findings are text heuristics over the supplied "
        "logs: no finding means the logs contained no such evidence, not that the "
        "project is free of conflicts.",
    ]
    nul_logs = [entry["path"] for entry in log_meta if entry.get("nul_bytes")]
    if nul_logs:
        notes.append(
            "Embedded NUL bytes were stripped from "
            + ", ".join(nul_logs)
            + " before matching (interleaved writers); line numbers and byte hashes are "
              "still those of the original file.")
    report = {
        "report_version": REPORT_VERSION,
        "diagnostics_version": DIAGNOSTICS_VERSION,
        "generated_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "read_only": True,
        "project_root": _norm_path(project_root) if project_root else None,
        "logs": log_meta,
        "project": project_meta,
        "summary": summary,
        "findings": [finding.to_dict() for finding in merged],
        "ignored_lines": sorted(ignored.values(), key=lambda item: item["reason"]),
        "notes": notes,
    }
    return report


def render_markdown(report: dict) -> str:
    """Human-readable Russian report with the required severity/evidence table."""
    summary = report["summary"]
    lines = [
        "# Отчёт диагностики AICore (Фаза 1, только чтение)",
        "",
        f"- Дата (UTC): {report['generated_utc']}",
        f"- Корень проекта: {report['project_root'] or '— (инвентарь не запускался)'}",
        f"- Версия редактора: {report['project'].get('editor_version') or '—'}",
        f"- Версия диагностики: {report['diagnostics_version']} (формат отчёта {report['report_version']})",
        "- Режим: только чтение. Ничего в проекте не изменялось.",
        "",
        "## Сводка",
        "",
        f"- critical: {summary['critical']}",
        f"- error: {summary['error']}",
        f"- warning: {summary['warning']}",
        f"- info: {summary['info']}",
        f"- всего находок: {summary['findings']}",
        "",
    ]
    if report["logs"]:
        lines += ["## Прочитанные логи", "",
                  "| файл | строк | байт | sha256 |", "|---|---|---|---|"]
        for entry in report["logs"]:
            lines.append(f"| {entry['path']} | {entry['lines']} | {entry['bytes']} | "
                         f"`{entry['sha256'][:16]}…` |")
        lines.append("")
    lines += ["## Находки", ""]
    if not report["findings"]:
        lines += ["Находок нет: разобранные логи и структура проекта не содержат "
                  "подтверждённых проблем по имеющимся правилам.", ""]
    else:
        lines += ["| серьёзность | категория | что не так | доказательство файл:строка | что делать |",
                  "|---|---|---|---|---|"]
        for finding in report["findings"]:
            evidence = "<br>".join(f"`{item['file']}:{item['line']}`" for item in finding["evidence"])
            repeats = ""
            if finding["occurrences"] > 1:
                repeats = (f" (×{finding['occurrences']}, файлов: {len(finding['sources'])})")
            detail = finding["detail"].replace("|", "\\|")
            lines.append(
                f"| {finding['severity']} | {finding['category']} | "
                f"**{finding['title']}**{repeats}<br>{detail} | {evidence or '—'} | "
                f"{finding['suggested_action'].replace('|', chr(92) + '|')} |")
        lines.append("")
    if report["ignored_lines"]:
        lines += ["## Намеренно проигнорированные строки", "",
                  "Эти строки распознаны как известный шум (список `IGNORED_PATTERNS` в "
                  "`brain/diagnostics.py`) и не считаются находками.", "",
                  "| причина | сколько раз |", "|---|---|"]
        for entry in report["ignored_lines"]:
            lines.append(f"| {entry['reason']} | {entry['count']} |")
        lines.append("")
    lines += ["## Ограничения", ""]
    lines += [f"- {note}" for note in report["notes"]]
    lines += ["", "Полная машиночитаемая версия — в одноимённом `.json` рядом с этим файлом.", ""]
    return "\n".join(lines)


def report_paths(out_dir: str | os.PathLike, stamp: str | None = None) -> tuple[Path, Path]:
    directory = Path(out_dir)
    stamp = stamp or datetime.now(timezone.utc).strftime(UTC_STAMP_FORMAT)
    base = directory / f"diagnose-{stamp}"
    json_path = base.with_suffix(".json")
    counter = 2
    while json_path.exists():
        json_path = directory / f"diagnose-{stamp}-{counter}.json"
        counter += 1
    return json_path, json_path.with_suffix(".md")


def write_report(report: dict, out_dir: str | os.PathLike) -> dict:
    directory = Path(out_dir)
    directory.mkdir(parents=True, exist_ok=True)
    json_path, markdown_path = report_paths(directory)
    json_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n",
                         encoding="utf-8", newline="\n")
    markdown_path.write_text(render_markdown(report), encoding="utf-8", newline="\n")
    return {"json": _norm_path(json_path), "markdown": _norm_path(markdown_path)}


def run(project_root: str | os.PathLike | None = None,
        log_paths: Sequence[str | os.PathLike] = (),
        out_dir: str | os.PathLike | None = None,
        db_path: str | os.PathLike | None = None,
        world: str | None = None,
        persist: bool = False) -> dict:
    """Observe the project and its logs, and return a report dictionary.

    Files are written only when ``out_dir`` is given. The brain database is opened
    only when ``persist`` is true, which also requires ``db_path`` and ``world``.
    """
    if persist and not db_path:
        raise DiagnosticsError("persist=True requires db_path (nothing was written).")
    if persist and not world:
        raise DiagnosticsError("persist=True requires world (nothing was written).")
    started = time.time()
    report = build_report(project_root, list(log_paths))
    report["persist"] = {"enabled": False}
    if persist:
        findings = [_from_dict(item) for item in report["findings"]]
        report["persist"] = persist_findings(findings, db_path, world)
    if out_dir is not None:
        report["artifacts"] = write_report(report, out_dir)
    report["duration_seconds"] = round(time.time() - started, 3)
    return report


def _from_dict(item: dict) -> Finding:
    return Finding(finding_id=item["finding_id"], category=item["category"],
                   severity=item["severity"], title=item["title"], detail=item["detail"],
                   evidence=[dict(entry) for entry in item["evidence"]],
                   suggested_action=item["suggested_action"], confidence=item["confidence"],
                   rule_id=item["rule_id"], occurrences=item["occurrences"],
                   sources=list(item["sources"]),
                   signature=f"{item['rule_id']}|{item['finding_id']}")


# --------------------------------------------------------------------------------------
# Default Unity console logs (find the editor console without being told a path)
# --------------------------------------------------------------------------------------

EDITOR_LOG_ENV = "LOCALAPPDATA"
EDITOR_LOG_NAMES = ("Editor.log", "Editor-prev.log")


def editor_log_dir() -> Path | None:
    """Directory that holds the per-user Unity editor console logs, or None."""
    base = os.environ.get(EDITOR_LOG_ENV) or os.environ.get("USERPROFILE")
    if not base:
        return None
    return Path(base) / "Unity" / "Editor"


def default_console_logs(project_root: str | os.PathLike | None = None) -> list[str]:
    """Existing Unity console logs worth reading, in preference order.

    Read-only discovery: the per-user editor console (``Editor.log`` and
    ``Editor-prev.log``) plus every ``*.log`` directly under the project's
    ``Logs`` directory. Missing paths are skipped and duplicates removed, so the
    result only ever contains files that exist right now."""
    candidates: list[Path] = []
    directory = editor_log_dir()
    if directory is not None:
        candidates.extend(directory / name for name in EDITOR_LOG_NAMES)
    if project_root:
        logs_dir = Path(project_root) / "Logs"
        try:
            if logs_dir.is_dir():
                candidates.extend(sorted(logs_dir.glob("*.log")))
        except OSError:
            pass
    seen: set[str] = set()
    found: list[str] = []
    for candidate in candidates:
        key = str(candidate).casefold()
        if key in seen:
            continue
        seen.add(key)
        try:
            if candidate.is_file():
                found.append(str(candidate))
        except OSError:
            continue
    return found
