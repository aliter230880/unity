"""Action-scoped, expiring, single-use approval permits.

The master approval secret is not a licence to write: it only *signs* permits.
A permit names one tool and one resolved target, stops working after its TTL, and
- when a registry is available - can be spent exactly once and can be revoked.

Token layout: ``base64url(json payload) . hex(hmac_sha256(secret, payload))``
where the payload is
``{"v":1,"tool":...,"target":<digest>,"nonce":...,"iat":...,"exp":...}``.

Standard library only. No network.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
import sqlite3
import time
from typing import Any

VERSION = 1
DEFAULT_TTL_SECONDS = 300
MAX_TTL_SECONDS = 3600
CLOCK_SKEW_SECONDS = 5
NONCE_HEX_BYTES = 12
MAX_SUBJECT_LENGTH = 64


class ApprovalError(ValueError):
    """Raised when a permit cannot be issued or does not authorise the operation."""


def _b64e(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _b64d(text: str) -> bytes:
    return base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))


def _sign(secret: str, payload: bytes) -> str:
    return hmac.new(secret.encode("utf-8"), payload, hashlib.sha256).hexdigest()


def target_digest(target: str) -> str:
    """Stable digest of the target a permit is bound to."""
    return hashlib.sha256(str(target).encode("utf-8")).hexdigest()[:32]


class PermitRegistry:
    """Remembers spent permits and revocations.

    With no path it remembers them in memory, which enforces single use within one
    process. With a path it uses a small SQLite ledger, so single use and
    revocation survive a restart. The brain always passes its own database.
    """

    def __init__(self, path: str | None = None):
        self.path = str(path) if path else None
        self._used: set[str] = set()
        self._revoked: set[str] = set()
        self._revoked_before: float = 0.0
        if self.path:
            self._initialise()

    def _connect(self):
        return sqlite3.connect(self.path, timeout=5)

    def _initialise(self) -> None:
        connection = self._connect()
        try:
            connection.execute(
                "CREATE TABLE IF NOT EXISTS used_permits "
                "(nonce TEXT PRIMARY KEY, tool TEXT, target TEXT, used REAL)")
            connection.execute(
                "CREATE TABLE IF NOT EXISTS revoked_permits "
                "(nonce TEXT PRIMARY KEY, revoked REAL)")
            connection.execute(
                "CREATE TABLE IF NOT EXISTS approval_epoch "
                "(id INTEGER PRIMARY KEY CHECK (id = 1), revoked_before REAL)")
            connection.commit()
        finally:
            connection.close()

    # -- revocation -------------------------------------------------------------------
    def revoke(self, nonce: str | None = None, before: float | None = None) -> dict:
        """Revoke one permit by nonce, or every permit issued before a timestamp."""
        if nonce is None and before is None:
            raise ApprovalError("pass a nonce or a cut-off time to revoke")
        if nonce is not None and not isinstance(nonce, str):
            raise ApprovalError("nonce must be a string")
        if before is not None and not isinstance(before, (int, float)):
            raise ApprovalError("before must be a number")
        if self.path:
            connection = self._connect()
            try:
                revoked = 0
                if nonce is not None:
                    cursor = connection.execute(
                        "INSERT OR IGNORE INTO revoked_permits(nonce, revoked) VALUES(?,?)",
                        (nonce, time.time()))
                    revoked = cursor.rowcount
                if before is not None:
                    connection.execute(
                        "INSERT INTO approval_epoch(id, revoked_before) VALUES(1,?) "
                        "ON CONFLICT(id) DO UPDATE SET revoked_before=MAX(revoked_before, excluded.revoked_before)",
                        (float(before),))
                connection.commit()
            finally:
                connection.close()
            self._revoked_before = max(self._revoked_before, float(before or 0.0))
            return {"nonce": nonce, "revoked_before": before, "stored": True}
        revoked = 0
        if nonce is not None and nonce not in self._revoked:
            self._revoked.add(nonce)
            revoked = 1
        if before is not None:
            self._revoked_before = max(self._revoked_before, float(before))
        return {"nonce": nonce, "revoked_before": before, "stored": False, "revoked": revoked}

    def epoch(self) -> float:
        if not self.path:
            return self._revoked_before
        connection = self._connect()
        try:
            row = connection.execute(
                "SELECT revoked_before FROM approval_epoch WHERE id = 1").fetchone()
        finally:
            connection.close()
        return float(row[0]) if row else 0.0

    def _is_revoked(self, nonce: str, issued_at: float) -> bool:
        if issued_at <= self.epoch():
            return True
        if not self.path:
            return nonce in self._revoked
        connection = self._connect()
        try:
            row = connection.execute(
                "SELECT 1 FROM revoked_permits WHERE nonce = ?", (nonce,)).fetchone()
        finally:
            connection.close()
        return row is not None

    # -- single use -------------------------------------------------------------------
    def spend(self, nonce: str, tool: str, target: str, issued_at: float) -> None:
        """Consume a permit. Raises ApprovalError on replay or revocation."""
        if not isinstance(nonce, str) or not nonce:
            raise ApprovalError("approval permit has no nonce and cannot be spent safely")
        if self._is_revoked(nonce, issued_at):
            raise ApprovalError("approval permit was revoked")
        if not self.path:
            if nonce in self._used:
                raise ApprovalError("approval permit has already been used")
            self._used.add(nonce)
            return
        connection = self._connect()
        try:
            cursor = connection.execute(
                "INSERT OR IGNORE INTO used_permits(nonce, tool, target, used) VALUES(?,?,?,?)",
                (nonce, tool, target, time.time()))
            connection.commit()
            if cursor.rowcount == 0:
                raise ApprovalError("approval permit has already been used")
        finally:
            connection.close()


class OperatorDirectory:
    """Who may issue a permit, and with which secret.

    Two modes:

    * explicit - every operator has its own secret, names are fixed, and the permit's
      signature can only be produced by that operator. Attribution is then
      cryptographic: the permit says who signed it, and only that secret could have.
    * single - one shared secret and free-form names (`open_names`). This is the
      legacy shape: the trail says who *asked*, but anyone holding the secret can
      claim any name.
    """

    def __init__(self, operators: dict | None = None, open_names: bool = False,
                 shared_secret: str | None = None):
        self._secrets: dict[str, str] = dict(operators or {})
        self.open_names = bool(open_names)
        self._shared = shared_secret or ""

    @classmethod
    def single(cls, secret: str | None, name: str = "master") -> "OperatorDirectory":
        """One shared secret, free-form names. An empty secret authorises nobody."""
        return cls(open_names=True, shared_secret=secret or "")

    @classmethod
    def parse(cls, value: str | None) -> "OperatorDirectory | None":
        """Read ``alice:secret1,bob:secret2`` from configuration."""
        if not value:
            return None
        directory = cls()
        for chunk in value.split(","):
            chunk = chunk.strip()
            if not chunk:
                continue
            name, _, secret = chunk.partition(":")
            directory.add(name.strip(), secret.strip())
        return directory

    def add(self, name: str, secret: str) -> None:
        if not name or len(name) > MAX_SUBJECT_LENGTH:
            raise ApprovalError("operator name must be 1..%d characters" % MAX_SUBJECT_LENGTH)
        if not isinstance(secret, str) or not 16 <= len(secret) <= 4096:
            raise ApprovalError("operator secret must be 16..4096 characters")
        if not all(32 < ord(c) < 127 for c in secret):
            raise ApprovalError("operator secret must be printable ASCII without spaces")
        if name in self._secrets:
            raise ApprovalError("operator %r is already configured" % name)
        self._secrets[name] = secret

    def names(self) -> list:
        return sorted(self._secrets)

    def secret_for(self, name: Any) -> str | None:
        """The secret that can sign for this name, or None if the name is unknown."""
        if not isinstance(name, str):
            return None
        if name in self._secrets:
            return self._secrets[name]
        if self.open_names and self._shared:
            return self._shared
        return None

    def authorises(self, name: Any, secret: Any) -> bool:
        """Does this secret belong to this operator?"""
        if not isinstance(secret, str) or not secret:
            return False
        if self.open_names:
            return bool(self._shared) and hmac.compare_digest(secret, self._shared)
        expected = self._secrets.get(name) if isinstance(name, str) else None
        return bool(expected) and hmac.compare_digest(secret, expected)

    def describe(self) -> dict:
        return {"operators": self.names(), "open_names": self.open_names}


def issue(directory: OperatorDirectory | None, operator: Any, secret: Any, tool: Any,
          target: Any, ttl_seconds: int = DEFAULT_TTL_SECONDS, now: float | None = None,
          nonce: str | None = None) -> dict:
    """Mint a permit signed by one operator, for one tool and one target."""
    if directory is None or not directory.secret_for(operator):
        raise ApprovalError("approval is not configured for this operator; no permit can be issued")
    signing = directory.secret_for(operator)
    if not directory.authorises(operator, secret):
        raise ApprovalError("operator secret is missing or wrong")
    if not tool or not isinstance(tool, str):
        raise ApprovalError("tool must be a non-empty string")
    if not target or not isinstance(target, str):
        raise ApprovalError("target must be a non-empty string")
    if isinstance(ttl_seconds, bool) or not isinstance(ttl_seconds, int):
        raise ApprovalError("ttl_seconds must be an integer")
    if ttl_seconds < 1 or ttl_seconds > MAX_TTL_SECONDS:
        raise ApprovalError("ttl_seconds must be between 1 and %d" % MAX_TTL_SECONDS)
    if not isinstance(operator, str) or not operator.strip():
        raise ApprovalError("operator is required: a permit must say who asked for it")
    if len(operator) > MAX_SUBJECT_LENGTH:
        raise ApprovalError("operator must be at most %d characters" % MAX_SUBJECT_LENGTH)
    issued_at = float(time.time() if now is None else now)
    permit_nonce = nonce or secrets.token_hex(NONCE_HEX_BYTES)
    payload = {"v": VERSION, "tool": tool, "target": target_digest(target),
               "nonce": permit_nonce, "sub": operator.strip(),
               "iat": issued_at, "exp": issued_at + ttl_seconds}
    raw = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
    return {"token": _b64e(raw) + "." + _sign(signing, raw), "tool": tool,
            "nonce": permit_nonce, "subject": payload["sub"],
            "expires_at": payload["exp"], "ttl_seconds": ttl_seconds,
            "target_digest": payload["target"]}


def verify(directory: OperatorDirectory | None, token: Any, tool: Any, target: Any,
           now: float | None = None, registry: PermitRegistry | None = None,
           spend: bool = True) -> dict:
    """Check a permit authorises exactly this tool and this target, right now."""
    if directory is None:
        raise ApprovalError("approval is not configured on this brain; the operation was refused")
    if not isinstance(token, str) or not token.strip():
        raise ApprovalError("an approval permit is required; issue one first")
    parts = token.split(".")
    if len(parts) != 2 or not parts[0] or not parts[1]:
        raise ApprovalError("approval permit is malformed")
    try:
        raw = _b64d(parts[0])
    except (ValueError, TypeError):
        raise ApprovalError("approval permit is malformed")
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        raise ApprovalError("approval permit payload is unreadable")
    if not isinstance(payload, dict) or payload.get("v") != VERSION:
        raise ApprovalError("approval permit version is not supported")
    issuer = directory.secret_for(payload.get("sub"))
    if not issuer:
        raise ApprovalError("the permit names an operator this brain does not know")
    if not hmac.compare_digest(_sign(issuer, raw), parts[1]):
        raise ApprovalError("approval permit signature does not match")
    if payload.get("tool") != tool:
        raise ApprovalError("approval permit was issued for %r, not for %r"
                            % (payload.get("tool"), tool))
    if payload.get("target") != target_digest(target):
        raise ApprovalError("approval permit was issued for a different target")
    current = int(time.time() if now is None else now)
    expires = payload.get("exp")
    if isinstance(expires, bool) or not isinstance(expires, (int, float)):
        raise ApprovalError("approval permit has no expiry")
    if current > expires + CLOCK_SKEW_SECONDS:
        raise ApprovalError("approval permit expired at %d" % expires)
    if registry is not None and spend:
        registry.spend(str(payload.get("nonce", "")), tool, target,
                       float(payload.get("iat", 0)))
    return payload
