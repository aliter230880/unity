using System.Collections;
using UnityEngine;

namespace AliTerra.AICore
{
    /// <summary>
    /// Publishes the world's hour so the director can keep lights in phase.
    /// Attach next to a <see cref="WorldDirector"/>. No new verbs: the brain
    /// still only activates and deactivates catalog lights.
    /// </summary>
    [AddComponentMenu("AICore/World Atmosphere")]
    public sealed class WorldAtmosphere : MonoBehaviour
    {
        [Tooltip("Length of one in-game day in real minutes.")]
        [Min(1)] public float dayLengthMinutes = 20f;
        [Tooltip("Seconds between hour publications (minimum 5).")]
        [Min(5)] public float everySeconds = 5f;

        private WorldDirector director;

        private IEnumerator Start()
        {
            while (true)
            {
                yield return new WaitForSeconds(Mathf.Max(5f, everySeconds));
                Publish();
            }
        }

        private void Publish()
        {
            director = FindFirstObjectByType<WorldDirector>();
            if (director == null) return;
            float daySeconds = Mathf.Max(60f, dayLengthMinutes * 60f);
            float hour = (Time.time / daySeconds) * 24f % 24f;
            director.PublishEvent("world.hour", hour);
            director.PublishKnowledge("atmosphere.hour", hour.ToString("0.00"), "weather", 0.9f);
            director.PublishKnowledge("atmosphere.phase", hour >= 20f || hour < 6f ? "night" : "day", "weather", 0.9f);
        }
    }
}
