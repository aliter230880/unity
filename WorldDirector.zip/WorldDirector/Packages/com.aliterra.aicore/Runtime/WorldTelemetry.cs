using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace AliTerra.AICore
{
    /// <summary>
    /// Publishes bounded, deliberate telemetry about the observed world: population
    /// facts, spatial relations between owned entities, and population-change events.
    /// The brain stores these as knowledge (SQLite) and the optional LLM planner sees
    /// them as world context, so it reasons about the world, not just coordinates.
    /// Attach anywhere next to a <see cref="WorldDirector"/>; it finds the director itself.
    /// </summary>
    [AddComponentMenu("AICore/World Telemetry")]
    public sealed class WorldTelemetry : MonoBehaviour
    {
        [Tooltip("Seconds between telemetry passes (minimum 5).")]
        [Min(5)] public float everySeconds = 30f;
        [Tooltip("Maximum spatial relations published per pass (0 disables relations).")]
        [Range(0, 64)] public int maxRelations = 16;
        [Tooltip("Owned entities profiled per pass (nearest-pair work is quadratic in this).")]
        [Range(2, 128)] public int maxEntitiesProfiled = 64;

        private WorldDirector director;
        private int lastPopulation = -1;

        // Performance window, sampled every frame and published once per pass:
        // the brain sees lag as facts, so its plans can react to hitches.
        private float windowFrames;
        private float windowSeconds;
        private float windowMaxMs;
        private int windowHitches;
        private int lastGen0 = -1;
        private const float HitchMs = 50f;

        private void Update()
        {
            float delta = Time.unscaledDeltaTime;
            windowFrames += 1f;
            windowSeconds += delta;
            float ms = delta * 1000f;
            if (ms > windowMaxMs) windowMaxMs = ms;
            if (ms >= HitchMs) windowHitches++;
        }

        private IEnumerator Start()
        {
            while (true)
            {
                yield return new WaitForSeconds(Mathf.Max(5f, everySeconds));
                Publish();
            }
        }

        private void Publish()
        {
            director = FindFirstObjectByType<WorldDirector>();
            if (director == null) return;
            WorldEntity[] snapshot = WorldEntity.Snapshot();
            int total = 0, owned = 0, active = 0, inactive = 0;
            var byCatalog = new Dictionary<string, int>();
            var positions = new List<Vector3>();
            var ids = new List<string>();
            Vector3 min = Vector3.positiveInfinity, max = Vector3.negativeInfinity;
            foreach (WorldEntity entity in snapshot)
            {
                if (entity == null || !entity.gameObject.scene.isLoaded) continue;
                total++;
                string catalog = string.IsNullOrEmpty(entity.catalogId) ? "scene" : entity.catalogId;
                byCatalog[catalog] = byCatalog.ContainsKey(catalog) ? byCatalog[catalog] + 1 : 1;
                if (!entity.IsOwnedBy(director)) continue;
                owned++;
                if (!entity.gameObject.activeInHierarchy) { inactive++; continue; }
                active++;
                if (positions.Count >= maxEntitiesProfiled) continue;
                Vector3 position = entity.transform.position;
                positions.Add(position);
                ids.Add(entity.Id);
                min = Vector3.Min(min, position);
                max = Vector3.Max(max, position);
            }
            director.PublishKnowledge("population.total", total.ToString(), "population", 0.9f);
            director.PublishKnowledge("population.owned", owned.ToString(), "population", 0.9f);
            director.PublishKnowledge("population.active", active.ToString(), "population", 0.9f);
            director.PublishKnowledge("population.inactive", inactive.ToString(), "population", 0.8f);
            director.PublishKnowledge("population.by_catalog", JoinCounts(byCatalog), "population", 0.9f);
            director.PublishKnowledge("system.director_status", director.Status, "system", 0.9f);
            PublishPerformance();
            if (positions.Count > 1)
            {
                Vector3 size = max - min;
                director.PublishKnowledge("population.spread",
                    size.x.ToString("0.0") + "x" + size.y.ToString("0.0") + "x" + size.z.ToString("0.0"),
                    "population", 0.9f);
                director.PublishKnowledge("population.min_pair_distance",
                    MinPairDistance(positions).ToString("0.00"), "population", 0.7f);
                int published = 0;
                for (int i = 0; i < positions.Count && published < maxRelations; i++)
                    for (int j = i + 1; j < positions.Count && published < maxRelations; j++)
                    {
                        float distance = Vector3.Distance(positions[i], positions[j]);
                        if (distance > 8f) continue;  // "near" means near
                        director.PublishRelation(ids[i], ids[j], "near",
                            Mathf.Clamp01(4f / Mathf.Max(1f, distance)));
                        published++;
                    }
            }
            if (lastPopulation >= 0 && lastPopulation != total)
                director.PublishEvent("population.changed", total - lastPopulation);
            lastPopulation = total;
        }

        private void PublishPerformance()
        {
            float frames = Mathf.Max(1f, windowFrames);
            float seconds = Mathf.Max(0.001f, windowSeconds);
            director.PublishKnowledge("performance.fps",
                (frames / seconds).ToString("0.0"), "performance", 0.9f);
            director.PublishKnowledge("performance.frame_ms_avg",
                (seconds * 1000f / frames).ToString("0.0"), "performance", 0.9f);
            director.PublishKnowledge("performance.frame_ms_max",
                windowMaxMs.ToString("0.0"), "performance", 0.85f);
            director.PublishKnowledge("performance.hitches_50ms",
                windowHitches.ToString(), "performance", 0.85f);
            int gen0 = System.GC.CollectionCount(0);
            director.PublishKnowledge("performance.gc_gen0_delta",
                (lastGen0 < 0 ? 0 : Mathf.Max(0, gen0 - lastGen0)).ToString(),
                "performance", 0.8f);
            lastGen0 = gen0;
            windowFrames = 0f;
            windowSeconds = 0f;
            windowMaxMs = 0f;
            windowHitches = 0;
        }

        private static float MinPairDistance(List<Vector3> points)
        {
            float best = float.PositiveInfinity;
            for (int i = 0; i < points.Count; i++)
                for (int j = i + 1; j < points.Count; j++)
                    best = Mathf.Min(best, Vector3.Distance(points[i], points[j]));
            return best;
        }

        private static string JoinCounts(Dictionary<string, int> counts)
        {
            var builder = new StringBuilder();
            foreach (KeyValuePair<string, int> pair in counts)
            {
                if (builder.Length > 0) builder.Append(',');
                builder.Append(pair.Key).Append('=').Append(pair.Value);
            }
            return builder.Length == 0 ? "none" : builder.ToString();
        }
    }
}
