using System;
using UnityEngine;

namespace AliTerra.AICore.Examples
{
    /// <summary>
    /// Recommended token pattern: the local brain bearer token is injected from the
    /// process environment, so it is never serialised into a scene or prefab that
    /// could be committed by accident. Attach this component next to a
    /// <see cref="WorldDirector"/> and leave the director's token field empty or as
    /// a placeholder.
    /// </summary>
    [AddComponentMenu("AICore/Examples/Env Token Source")]
    public sealed class AICoreEnvToken : MonoBehaviour
    {
        [Tooltip("Environment variable carrying the local brain token (AICORE_TOKEN by default).")]
        public string variable = "AICORE_TOKEN";

        private void Awake()
        {
            WorldDirector director = GetComponent<WorldDirector>();
            if (director == null) return;
            string value = Environment.GetEnvironmentVariable(variable);
            if (string.IsNullOrWhiteSpace(value)) return;
            // The director's request loop first runs a frame later, so injecting
            // here is always ahead of the first HTTP request.
            director.token = value;
        }
    }
}
