// AICore sandbox scene builder (phase 8).
//
// Creates a plain, *usable* scene: a camera, a light, a floor and a couple of props,
// with no deliberate defects. This is the counterpart to the fixture polygon - the
// polygon exists to be broken and fixed, this one exists to be worked in.
//
// Batch:
//   Unity.exe -batchmode -nographics -quit -projectPath <project> ^
//     -logFile <log> -executeMethod AliTerra.AICore.Editor.AICoreSandboxBuilder.CreateBatch
//
// Set AICORE_SANDBOX_SCENE to choose the path (default Assets/AICoreSandbox/SandboxScene.unity)
// and AICORE_SANDBOX_BUILDSETTINGS=0 to leave the build settings alone.

using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace AliTerra.AICore.Editor
{
    public static class AICoreSandboxBuilder
    {
        public const string DefaultScenePath = "Assets/AICoreSandbox/SandboxScene.unity";

        public static void CreateBatch()
        {
            try
            {
                string path = Environment.GetEnvironmentVariable("AICORE_SANDBOX_SCENE");
                if (string.IsNullOrEmpty(path))
                {
                    path = DefaultScenePath;
                }
                string summary = Create(path, BuildSettingsWanted());
                Debug.Log("[AICoreSandbox] " + summary);
                if (Application.isBatchMode)
                {
                    EditorApplication.Exit(0);
                }
            }
            catch (Exception error)
            {
                Debug.LogError("[AICoreSandbox] " + error.GetType().Name + ": " + error.Message);
                if (Application.isBatchMode)
                {
                    EditorApplication.Exit(1);
                }
            }
        }

        /// <summary>Marks one object as observable, which is what makes the scene a world.</summary>
        public static void MarkObservableBatch()
        {
            try
            {
                string path = Environment.GetEnvironmentVariable("AICORE_SANDBOX_SCENE");
                if (string.IsNullOrEmpty(path))
                {
                    path = DefaultScenePath;
                }
                string target = Environment.GetEnvironmentVariable("AICORE_MARK_OBJECT");
                if (string.IsNullOrEmpty(target))
                {
                    target = "Prop_Cube";
                }
                Scene scene = EditorSceneManager.OpenScene(path, OpenSceneMode.Single);
                GameObject found = null;
                foreach (GameObject root in scene.GetRootGameObjects())
                {
                    foreach (Transform item in root.GetComponentsInChildren<Transform>(true))
                    {
                        if (item.name == target)
                        {
                            found = item.gameObject;
                            break;
                        }
                    }
                    if (found != null)
                    {
                        break;
                    }
                }
                if (found == null)
                {
                    throw new InvalidOperationException("no object named " + target + " in " + path);
                }
                WorldEntity entity = found.GetComponent<WorldEntity>();
                if (entity == null)
                {
                    entity = found.AddComponent<WorldEntity>();
                }
                EditorSceneManager.MarkSceneDirty(scene);
                if (!EditorSceneManager.SaveScene(scene))
                {
                    throw new InvalidOperationException("the scene could not be saved");
                }
                AssetDatabase.Refresh();
                Debug.Log("[AICoreSandbox] marked " + target + " as observable (kind=" + entity.kind + ")");
                if (Application.isBatchMode)
                {
                    EditorApplication.Exit(0);
                }
            }
            catch (Exception error)
            {
                Debug.LogError("[AICoreSandbox] " + error.GetType().Name + ": " + error.Message);
                if (Application.isBatchMode)
                {
                    EditorApplication.Exit(1);
                }
            }
        }

        /// <summary>Makes prefab templates out of the sandbox props and approves them in a catalog.</summary>
        public static void CreatePrefabsBatch()
        {
            try
            {
                string path = Environment.GetEnvironmentVariable("AICORE_SANDBOX_SCENE");
                if (string.IsNullOrEmpty(path))
                {
                    path = DefaultScenePath;
                }
                Scene scene = EditorSceneManager.OpenScene(path, OpenSceneMode.Single);
                const string folder = "Assets/AICoreSandbox/Prefabs";
                if (!Directory.Exists(folder))
                {
                    Directory.CreateDirectory(folder);
                }
                string[] wanted = { "Prop_Cube", "Prop_Sphere" };
                var prefabPaths = new List<string>();
                foreach (string name in wanted)
                {
                    GameObject source = Find(scene, name);
                    if (source == null)
                    {
                        continue;
                    }
                    // A catalogued template must be observable: one WorldEntity on the root.
                    if (source.GetComponent<WorldEntity>() == null)
                    {
                        source.AddComponent<WorldEntity>();
                    }
                    string prefabPath = folder + "/" + name + ".prefab";
                    PrefabUtility.SaveAsPrefabAsset(source, prefabPath);
                    prefabPaths.Add(prefabPath);
                }
                if (prefabPaths.Count == 0)
                {
                    throw new InvalidOperationException("no props were found to turn into prefabs");
                }

                const string catalogPath = "Assets/AICoreSandbox/PropCatalog.asset";
                // Reuse the asset when it exists: deleting it would mint a new GUID and
                // silently break every scene reference to the catalog.
                PrefabCatalog catalog = AssetDatabase.LoadAssetAtPath<PrefabCatalog>(catalogPath);
                if (catalog == null)
                {
                    catalog = ScriptableObject.CreateInstance<PrefabCatalog>();
                    AssetDatabase.CreateAsset(catalog, catalogPath);
                }
                var serialized = new SerializedObject(catalog);
                SerializedProperty list = serialized.FindProperty("entries");
                list.arraySize = prefabPaths.Count;
                for (int index = 0; index < prefabPaths.Count; index++)
                {
                    SerializedProperty entry = list.GetArrayElementAtIndex(index);
                    string shortName = Path.GetFileNameWithoutExtension(prefabPaths[index]).ToLowerInvariant();
                    entry.FindPropertyRelative("id").stringValue = shortName;
                    entry.FindPropertyRelative("kind").stringValue = "prop";
                    entry.FindPropertyRelative("prefab").objectReferenceValue =
                        AssetDatabase.LoadAssetAtPath<GameObject>(prefabPaths[index]);
                }
                serialized.ApplyModifiedProperties();
                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();

                PrefabCatalog saved = AssetDatabase.LoadAssetAtPath<PrefabCatalog>(catalogPath);
                if (saved == null)
                {
                    throw new InvalidOperationException("the catalog asset was not created");
                }
                PrefabCatalog.Entry[] snapshot;
                string problem;
                if (!saved.TrySnapshot(out snapshot, out problem))
                {
                    throw new InvalidOperationException("the catalog is not valid: " + (problem ?? "unknown"));
                }
                EditorSceneManager.MarkSceneDirty(scene);
                if (!EditorSceneManager.SaveScene(scene))
                {
                    throw new InvalidOperationException("the scene could not be saved");
                }
                Debug.Log("[AICoreSandbox] catalog built with " + snapshot.Length
                          + " approved prefab(s); the scene is saved too, so the marks persist");
                if (Application.isBatchMode)
                {
                    EditorApplication.Exit(0);
                }
            }
            catch (Exception error)
            {
                Debug.LogError("[AICoreSandbox] " + error.GetType().Name + ": " + error.Message);
                if (Application.isBatchMode)
                {
                    EditorApplication.Exit(1);
                }
            }
        }

        public static void AddDirectorBatch()
        {
            try
            {
                string path = Environment.GetEnvironmentVariable("AICORE_SANDBOX_SCENE");
                if (string.IsNullOrEmpty(path))
                {
                    path = DefaultScenePath;
                }
                Scene scene = EditorSceneManager.OpenScene(path, OpenSceneMode.Single);
                // Idempotent: every earlier director and anchor goes, including the root
                // anchors older runs left behind (six of them once).
                foreach (GameObject root in scene.GetRootGameObjects())
                {
                    if (root.name == "AICore Director" || root.name == "AICore Anchor")
                    {
                        UnityEngine.Object.DestroyImmediate(root);
                    }
                }
                var host = new GameObject("AICore Director");
                WorldDirector director = host.AddComponent<WorldDirector>();
                director.endpoint = Value("AICORE_ENDPOINT", "http://127.0.0.1:8765/v2/tick");
                director.worldId = Value("AICORE_WORLD", "sandbox");
                // Deliberately left empty: the bearer token is injected from the environment
                // in play mode so that no secret is ever stored in the scene file.
                director.token = "";
                director.targetCatalogId = Value("AICORE_TARGET_CATALOG", "prop_cube");
                director.targetCount = 2;
                director.catalog = AssetDatabase.LoadAssetAtPath<PrefabCatalog>(
                    "Assets/AICoreSandbox/PropCatalog.asset");
                if (director.catalog == null)
                {
                    throw new InvalidOperationException(
                        "the catalog is missing; run CreatePrefabsBatch first");
                }
                // The anchor is a child, not a second root: one director, one object.
                var anchor = new GameObject("AICore Anchor");
                anchor.transform.SetParent(host.transform, false);
                anchor.transform.localPosition = Vector3.zero;
                director.anchor = anchor.transform;
                string mode = Value("AICORE_MODE", "Observe");
                director.SetMode((DirectorMode)Enum.Parse(typeof(DirectorMode), mode, true));
                director.SetWorldAuthority(Value("AICORE_AUTHORITY", "0") == "1");

                EditorSceneManager.MarkSceneDirty(scene);
                if (!EditorSceneManager.SaveScene(scene))
                {
                    throw new InvalidOperationException("the scene could not be saved");
                }
                AssetDatabase.Refresh();
                Debug.Log("[AICoreSandbox] director added: mode=" + mode + ", catalog="
                          + (director.catalog != null ? director.catalog.name : "none")
                          + ", target=" + director.targetCatalogId + " x" + director.targetCount);
                if (Application.isBatchMode)
                {
                    EditorApplication.Exit(0);
                }
            }
            catch (Exception error)
            {
                Debug.LogError("[AICoreSandbox] " + error.GetType().Name + ": " + error.Message);
                if (Application.isBatchMode)
                {
                    EditorApplication.Exit(1);
                }
            }
        }

        private static string Value(string name, string fallback)
        {
            string value = Environment.GetEnvironmentVariable(name);
            return string.IsNullOrEmpty(value) ? fallback : value;
        }

        private static GameObject Find(Scene scene, string name)
        {
            foreach (GameObject root in scene.GetRootGameObjects())
            {
                foreach (Transform item in root.GetComponentsInChildren<Transform>(true))
                {
                    if (item.name == name)
                    {
                        return item.gameObject;
                    }
                }
            }
            return null;
        }

        private static bool BuildSettingsWanted()
        {
            string setting = Environment.GetEnvironmentVariable("AICORE_SANDBOX_BUILDSETTINGS");
            return string.IsNullOrEmpty(setting) || setting != "0";
        }

        /// <summary>Creates the scene and returns a one-line summary.</summary>
        public static string Create(string scenePath, bool addToBuildSettings)
        {
            if (string.IsNullOrEmpty(scenePath) || !scenePath.StartsWith("Assets/", StringComparison.Ordinal))
            {
                throw new InvalidOperationException("the scene path must be inside Assets/");
            }
            string folder = Path.GetDirectoryName(scenePath).Replace('\\', '/');
            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }

            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            var cameraObject = new GameObject("Main Camera");
            Camera camera = cameraObject.AddComponent<Camera>();
            cameraObject.tag = "MainCamera";
            cameraObject.transform.position = new Vector3(0f, 1.6f, -6f);
            cameraObject.transform.rotation = Quaternion.Euler(6f, 0f, 0f);
            camera.nearClipPlane = 0.05f;
            camera.farClipPlane = 500f;
            cameraObject.AddComponent<AudioListener>();

            var light = new GameObject("Directional Light");
            Light lightComponent = light.AddComponent<Light>();
            lightComponent.type = LightType.Directional;
            lightComponent.intensity = 1.0f;
            light.transform.rotation = Quaternion.Euler(50f, -30f, 0f);

            GameObject floor = GameObject.CreatePrimitive(PrimitiveType.Plane);
            floor.name = "Floor";
            floor.transform.localScale = new Vector3(4f, 1f, 4f);

            GameObject box = GameObject.CreatePrimitive(PrimitiveType.Cube);
            box.name = "Prop_Cube";
            box.transform.position = new Vector3(-1.5f, 0.5f, 0f);

            GameObject sphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            sphere.name = "Prop_Sphere";
            sphere.transform.position = new Vector3(1.5f, 0.5f, 0f);

            if (!EditorSceneManager.SaveScene(scene, scenePath))
            {
                throw new InvalidOperationException("the sandbox scene could not be saved");
            }
            AssetDatabase.Refresh();

            string buildNote = "build settings untouched";
            if (addToBuildSettings)
            {
                EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(scenePath, true) };
                buildNote = "added to the build settings";
            }
            return "sandbox scene created at " + scenePath + " (camera, light, floor, 2 props); " + buildNote;
        }
    }
}
