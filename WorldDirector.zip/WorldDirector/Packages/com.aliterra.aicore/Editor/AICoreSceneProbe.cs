// AICore scene probe (phase 2b, read-only).
//
// Editor-only, read-only observation of the live editor. It never creates,
// moves, renames, enables or deletes anything: it walks the loaded scenes,
// counts components and writes a JSON report to a path the caller chooses.
//
// Written without compile-time references to com.unity.ugui, because this
// project does not depend on it. Conflict-prone types (EventSystem,
// GraphicRaycaster, Selectable, ...) are matched by full type name instead, so
// the probe still detects the real conflict at runtime without the package.
//
// Usage:
//   Menu:  AICore / Probe / Write Scene Report
//   Batch: -executeMethod AliTerra.AICore.Editor.AICoreSceneProbe.RunBatch
//          with AICORE_PROBE_OUT=<absolute path> in the environment.

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace AliTerra.AICore.Editor
{
    public static class AICoreSceneProbe
    {
        public const string ReportVersion = "1";
        public const string DefaultRelativeOut = "AICore/outputs/scene/scene-report.json";

        private const int MaxPathDepth = 12;

        /// <summary>Types that must exist at most once per scene.</summary>
        private static readonly string[] SingletonTypeNames =
        {
            "UnityEngine.EventSystems.EventSystem",
            "UnityEngine.AudioListener",
        };

        /// <summary>Types that are conflict-prone when duplicated inside one hierarchy.</summary>
        private static readonly string[] RigTypeNames =
        {
            "UnityEngine.Animator",
        };

        private sealed class Finding
        {
            public string id;
            public string category;
            public string severity;
            public string title;
            public string detail;
            public string evidence;
            public string action;
        }

        [MenuItem("AICore/Probe/Write Scene Report")]
        public static void WriteSceneReportMenu()
        {
            string projectRoot = Directory.GetParent(Application.dataPath).FullName;
            string outPath = Path.Combine(projectRoot, DefaultRelativeOut.Replace('/', Path.DirectorySeparatorChar));
            string written = WriteReport(outPath);
            Debug.Log(written == null
                ? "[AICoreSceneProbe] report written to " + outPath
                : "[AICoreSceneProbe] failed: " + written);
        }

        /// <summary>Batch entry point used by the toolbox. Reads AICORE_PROBE_OUT.</summary>
        public static void RunBatch()
        {
            string scenePath = Environment.GetEnvironmentVariable("AICORE_PROBE_SCENE");
            if (!string.IsNullOrEmpty(scenePath))
            {
                OpenIfNeeded(scenePath);
            }

            string configured = Environment.GetEnvironmentVariable("AICORE_PROBE_OUT");
            string outPath;
            if (!string.IsNullOrEmpty(configured))
            {
                outPath = Path.GetFullPath(configured);
            }
            else
            {
                string projectRoot = Directory.GetParent(Application.dataPath).FullName;
                outPath = Path.Combine(projectRoot, DefaultRelativeOut.Replace('/', Path.DirectorySeparatorChar));
            }

            string failure = WriteReport(outPath);
            if (failure != null)
            {
                Debug.LogError("[AICoreSceneProbe] " + failure);
                if (Application.isBatchMode)
                {
                    EditorApplication.Exit(1);
                }
                return;
            }

            Debug.Log("[AICoreSceneProbe] report written to " + outPath);
            if (Application.isBatchMode)
            {
                EditorApplication.Exit(0);
            }
        }

        /// <summary>
        /// Detection self-test: builds the conflict cases in the current (unsaved) scene,
        /// runs the report, then exits. Nothing is written to the project - batch mode
        /// never saves the scene, so the temporary objects disappear with the process.
        /// </summary>
        public static void RunSelfTestBatch()
        {
            var first = new GameObject("ProbeListenerA");
            first.AddComponent<AudioListener>();
            var second = new GameObject("ProbeListenerB");
            second.AddComponent<AudioListener>();

            var leftRig = new GameObject("ProbeRigLeft");
            var leftHead = new GameObject("CC_Base_Head");
            leftHead.transform.SetParent(leftRig.transform);
            var rightRig = new GameObject("ProbeRigRight");
            var rightHead = new GameObject("CC_Base_Head");
            rightHead.transform.SetParent(rightRig.transform);

            var lodded = new GameObject("ProbeLodded");
            lodded.AddComponent<LODGroup>();

            string outPath = ResolveOutPath();
            string failure = WriteReport(outPath);
            if (failure != null)
            {
                Debug.LogError("[AICoreSceneProbe] self-test failed: " + failure);
                if (Application.isBatchMode)
                {
                    EditorApplication.Exit(1);
                }
                return;
            }

            Debug.Log("[AICoreSceneProbe] self-test report written to " + outPath);
            if (Application.isBatchMode)
            {
                EditorApplication.Exit(0);
            }
        }

        private static string ResolveOutPath()
        {
            string configured = Environment.GetEnvironmentVariable("AICORE_PROBE_OUT");
            if (!string.IsNullOrEmpty(configured))
            {
                return Path.GetFullPath(configured);
            }
            string projectRoot = Directory.GetParent(Application.dataPath).FullName;
            return Path.Combine(projectRoot, DefaultRelativeOut.Replace('/', Path.DirectorySeparatorChar));
        }

        private static void OpenIfNeeded(string scenePath)
        {
            for (int index = 0; index < SceneManager.sceneCount; index++)
            {
                Scene loaded = SceneManager.GetSceneAt(index);
                if (loaded.isLoaded && loaded.path == scenePath)
                {
                    return;
                }
            }
            EditorSceneManager.OpenScene(scenePath, OpenSceneMode.Single);
        }

        /// <summary>Writes the report. Returns null on success, or a failure message.</summary>
        public static string WriteReport(string outPath)
        {
            try
            {
                string json = BuildReportJson();
                string directory = Path.GetDirectoryName(outPath);
                if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
                {
                    Directory.CreateDirectory(directory);
                }
                File.WriteAllText(outPath, json, new UTF8Encoding(false));
                return null;
            }
            catch (Exception error)
            {
                return error.GetType().Name + ": " + error.Message;
            }
        }

        public static string BuildReportJson()
        {
            var findings = new List<Finding>();
            var typeCounts = new SortedDictionary<string, int>(StringComparer.Ordinal);
            var singletonCounts = new Dictionary<string, int>(StringComparer.Ordinal);
            var singletonFirstPath = new Dictionary<string, string>(StringComparer.Ordinal);
            var boneNames = new SortedDictionary<string, List<string>>(StringComparer.Ordinal);

            int sceneCount = SceneManager.sceneCount;
            int totalObjects = 0;
            int missingScripts = 0;
            int lodGroups = 0;
            int stretchedWithSize = 0;
            int cameras = 0;

            var sceneNames = new List<string>();

            for (int sceneIndex = 0; sceneIndex < sceneCount; sceneIndex++)
            {
                Scene scene = SceneManager.GetSceneAt(sceneIndex);
                sceneNames.Add(scene.name);
                if (!scene.isLoaded)
                {
                    continue;
                }

                foreach (GameObject root in scene.GetRootGameObjects())
                {
                    Walk(root, root.name, 0, typeCounts, singletonCounts, singletonFirstPath,
                         boneNames, ref totalObjects, ref missingScripts, ref lodGroups,
                         ref stretchedWithSize, ref cameras, findings);
                }
            }

            foreach (KeyValuePair<string, int> entry in singletonCounts)
            {
                if (entry.Value <= 1)
                {
                    continue;
                }
                var finding = new Finding
                {
                    id = "scene.multiple-" + ShortName(entry.Key),
                    category = "ui_conflict",
                    severity = "error",
                    title = "More than one " + ShortName(entry.Key) + " in the loaded scenes",
                    detail = "Found " + entry.Value.ToString(CultureInfo.InvariantCulture) +
                             " instances of " + entry.Key +
                             ". Duplicated singletons capture input or audio unpredictably.",
                    evidence = entry.Key + " first at " + PathOf(singletonFirstPath, entry.Key),
                    action = "Keep exactly one " + ShortName(entry.Key) +
                             " per scene and disable the others.",
                };
                findings.Add(finding);
            }

            if (missingScripts > 0)
            {
                findings.Add(new Finding
                {
                    id = "scene.missing-scripts",
                    category = "missing_asset",
                    severity = "error",
                    title = "GameObjects with missing script references",
                    detail = missingScripts.ToString(CultureInfo.InvariantCulture) +
                             " component slot(s) reference a script that no longer resolves.",
                    evidence = "counted across " + totalObjects.ToString(CultureInfo.InvariantCulture) + " objects",
                    action = "Find the objects with a missing script and either restore the script or remove the slot; " +
                             "this is usually the real cause of a silent NullReferenceException at runtime.",
                });
            }

            if (stretchedWithSize > 0)
            {
                findings.Add(new Finding
                {
                    id = "scene.stretched-rect-with-sizedelta",
                    category = "ui_conflict",
                    severity = "warning",
                    title = "Stretched RectTransform keeps a non-zero sizeDelta",
                    detail = stretchedWithSize.ToString(CultureInfo.InvariantCulture) +
                             " RectTransform(s) use stretch anchors and still carry a sizeDelta other than zero, " +
                             "so the element is larger than its parent.",
                    evidence = "see scene.rect-stretch evidence entries in the console output of the probe",
                    action = "Zero the sizeDelta on stretched elements; otherwise hits land outside the drawn control.",
                });
            }

            if (lodGroups > 0)
            {
                findings.Add(new Finding
                {
                    id = "scene.lodgroup-present",
                    category = "rig_conflict",
                    severity = "info",
                    title = "LODGroup present in the scene",
                    detail = lodGroups.ToString(CultureInfo.InvariantCulture) +
                             " LODGroup component(s) found. A LODGroup whose reference point sits on another " +
                             "hierarchy can cull the object completely when it is instantiated elsewhere.",
                    evidence = "counted across the loaded scenes",
                    action = "If a spawned or instanced object disappears, remove the LODGroup from the instance.",
                });
            }

            if (cameras == 0)
            {
                findings.Add(new Finding
                {
                    id = "scene.no-camera",
                    category = "scene_layout",
                    severity = "warning",
                    title = "No camera in the loaded scenes",
                    detail = "A scene without a camera renders nothing.",
                    evidence = "counted across the loaded scenes",
                    action = "Add a camera, or confirm the scene is meant to be loaded additively.",
                });
            }

            var duplicatedBones = new List<string>();
            foreach (KeyValuePair<string, List<string>> entry in boneNames)
            {
                if (entry.Value.Count > 1)
                {
                    duplicatedBones.Add(entry.Key + " x" + entry.Value.Count.ToString(CultureInfo.InvariantCulture));
                }
            }
            if (duplicatedBones.Count > 0)
            {
                findings.Add(new Finding
                {
                    id = "scene.duplicate-transform-names",
                    category = "rig_conflict",
                    severity = "warning",
                    title = "Repeated transform names suggest duplicate rigs",
                    detail = duplicatedBones.Count.ToString(CultureInfo.InvariantCulture) +
                             " transform name(s) appear more than once; a rig usually exists exactly once per avatar.",
                    evidence = string.Join(", ", duplicatedBones.GetRange(0, Math.Min(5, duplicatedBones.Count)).ToArray()),
                    action = "Check for a duplicated or deactivated rig before attaching cosmetics; " +
                             "bone lookup can otherwise bind to the wrong skeleton.",
                });
            }

            var builder = new StringBuilder();
            builder.Append("{\n");
            builder.Append("  \"report_version\": ").Append(Quote(ReportVersion)).Append(",\n");
            builder.Append("  \"probe\": ").Append(Quote("AICoreSceneProbe")).Append(",\n");
            builder.Append("  \"unity_version\": ").Append(Quote(Application.unityVersion)).Append(",\n");
            builder.Append("  \"is_batch_mode\": ").Append(Application.isBatchMode ? "true" : "false").Append(",\n");
            builder.Append("  \"read_only\": true,\n");
            builder.Append("  \"generated_utc\": ").Append(Quote(DateTime.UtcNow.ToString("o", CultureInfo.InvariantCulture))).Append(",\n");

            builder.Append("  \"summary\": {\n");
            builder.Append("    \"scenes_loaded\": ").Append(Num(sceneCount)).Append(",\n");
            builder.Append("    \"scene_names\": ").Append(StringArray(sceneNames)).Append(",\n");
            builder.Append("    \"game_objects\": ").Append(Num(totalObjects)).Append(",\n");
            builder.Append("    \"missing_scripts\": ").Append(Num(missingScripts)).Append(",\n");
            builder.Append("    \"lod_groups\": ").Append(Num(lodGroups)).Append(",\n");
            builder.Append("    \"stretched_rects_with_sizedelta\": ").Append(Num(stretchedWithSize)).Append(",\n");
            builder.Append("    \"cameras\": ").Append(Num(cameras)).Append(",\n");
            builder.Append("    \"findings\": ").Append(Num(findings.Count)).Append("\n");
            builder.Append("  },\n");

            builder.Append("  \"component_counts\": {\n");
            bool firstType = true;
            foreach (KeyValuePair<string, int> entry in typeCounts)
            {
                if (entry.Value < 1)
                {
                    continue;
                }
                if (!firstType)
                {
                    builder.Append(",\n");
                }
                firstType = false;
                builder.Append("    ").Append(Quote(entry.Key)).Append(": ").Append(Num(entry.Value));
            }
            builder.Append("\n  },\n");

            builder.Append("  \"findings\": [\n");
            for (int index = 0; index < findings.Count; index++)
            {
                Finding finding = findings[index];
                builder.Append("    {\n");
                builder.Append("      \"id\": ").Append(Quote(finding.id)).Append(",\n");
                builder.Append("      \"category\": ").Append(Quote(finding.category)).Append(",\n");
                builder.Append("      \"severity\": ").Append(Quote(finding.severity)).Append(",\n");
                builder.Append("      \"title\": ").Append(Quote(finding.title)).Append(",\n");
                builder.Append("      \"detail\": ").Append(Quote(finding.detail)).Append(",\n");
                builder.Append("      \"evidence\": ").Append(Quote(finding.evidence)).Append(",\n");
                builder.Append("      \"suggested_action\": ").Append(Quote(finding.action)).Append("\n");
                builder.Append("    }");
                if (index < findings.Count - 1)
                {
                    builder.Append(",");
                }
                builder.Append("\n");
            }
            builder.Append("  ]\n");
            builder.Append("}\n");
            return builder.ToString();
        }

        private static void Walk(GameObject target, string objectPath, int depth,
                                 SortedDictionary<string, int> typeCounts,
                                 Dictionary<string, int> singletonCounts,
                                 Dictionary<string, string> singletonFirstPath,
                                 SortedDictionary<string, List<string>> boneNames,
                                 ref int totalObjects, ref int missingScripts, ref int lodGroups,
                                 ref int stretchedWithSize, ref int cameras,
                                 List<Finding> findings)
        {
            totalObjects++;

            string path = Truncate(objectPath);
            Component[] components = target.GetComponents<Component>();
            foreach (Component component in components)
            {
                if (component == null)
                {
                    missingScripts++;
                    continue;
                }

                Type type = component.GetType();
                string fullName = type.FullName ?? type.Name;
                if (typeCounts.ContainsKey(fullName))
                {
                    typeCounts[fullName] = typeCounts[fullName] + 1;
                }
                else
                {
                    typeCounts[fullName] = 1;
                }

                for (int index = 0; index < SingletonTypeNames.Length; index++)
                {
                    if (fullName != SingletonTypeNames[index])
                    {
                        continue;
                    }
                    if (singletonCounts.ContainsKey(fullName))
                    {
                        singletonCounts[fullName] = singletonCounts[fullName] + 1;
                    }
                    else
                    {
                        singletonCounts[fullName] = 1;
                        singletonFirstPath[fullName] = path;
                    }
                }

                if (type.Name == "AudioListener")
                {
                    continue;
                }

                if (type.Name == "Camera")
                {
                    cameras++;
                }
                else if (type.Name == "LODGroup")
                {
                    lodGroups++;
                }
                else if (type.Name == "RectTransform")
                {
                    var rect = component as RectTransform;
                    if (rect != null)
                    {
                        bool stretched = rect.anchorMin != rect.anchorMax;
                        bool sized = Mathf.Abs(rect.sizeDelta.x) > 0.01f || Mathf.Abs(rect.sizeDelta.y) > 0.01f;
                        if (stretched && sized)
                        {
                            stretchedWithSize++;
                            if (stretchedWithSize <= 10)
                            {
                                findings.Add(new Finding
                                {
                                    id = "scene.rect-stretch-size",
                                    category = "ui_conflict",
                                    severity = "warning",
                                    title = "Stretched RectTransform with non-zero sizeDelta: " + target.name,
                                    detail = "anchorMin=" + rect.anchorMin.ToString("F3") +
                                             " anchorMax=" + rect.anchorMax.ToString("F3") +
                                             " sizeDelta=" + rect.sizeDelta.ToString("F2"),
                                    evidence = path,
                                    action = "Set sizeDelta to (0, 0) so the rect matches its anchors.",
                                });
                            }
                        }
                    }
                }
            }

            if (depth > 0)
            {
                List<string> paths;
                if (!boneNames.TryGetValue(target.name, out paths))
                {
                    paths = new List<string>();
                    boneNames[target.name] = paths;
                }
                if (paths.Count < 8)
                {
                    paths.Add(path);
                }
            }

            if (depth >= MaxPathDepth)
            {
                return;
            }

            Transform transform = target.transform;
            for (int index = 0; index < transform.childCount; index++)
            {
                Transform child = transform.GetChild(index);
                Walk(child.gameObject, objectPath + "/" + child.name, depth + 1,
                     typeCounts, singletonCounts, singletonFirstPath, boneNames,
                     ref totalObjects, ref missingScripts, ref lodGroups, ref stretchedWithSize,
                     ref cameras, findings);
            }
        }

        private static string PathOf(Dictionary<string, string> map, string key)
        {
            string value;
            return map.TryGetValue(key, out value) ? value : "(unknown)";
        }

        private static string ShortName(string fullName)
        {
            int index = fullName.LastIndexOf('.');
            return index < 0 ? fullName : fullName.Substring(index + 1);
        }

        private static string Truncate(string value)
        {
            const int limit = 240;
            return value.Length <= limit ? value : value.Substring(0, limit) + "...";
        }

        private static string Num(int value)
        {
            return value.ToString(CultureInfo.InvariantCulture);
        }

        private static string StringArray(List<string> values)
        {
            var builder = new StringBuilder("[");
            for (int index = 0; index < values.Count; index++)
            {
                if (index > 0)
                {
                    builder.Append(", ");
                }
                builder.Append(Quote(values[index]));
            }
            builder.Append("]");
            return builder.ToString();
        }

        private static string Quote(string value)
        {
            if (value == null)
            {
                return "null";
            }
            var builder = new StringBuilder(value.Length + 2);
            builder.Append('"');
            foreach (char character in value)
            {
                switch (character)
                {
                    case '"': builder.Append("\\\""); break;
                    case '\\': builder.Append("\\\\"); break;
                    case '\n': builder.Append("\\n"); break;
                    case '\r': builder.Append("\\r"); break;
                    case '\t': builder.Append("\\t"); break;
                    default:
                        if (character < ' ')
                        {
                            builder.Append("\\u").Append(((int)character).ToString("x4", CultureInfo.InvariantCulture));
                        }
                        else
                        {
                            builder.Append(character);
                        }
                        break;
                }
            }
            builder.Append('"');
            return builder.ToString();
        }
    }
}
