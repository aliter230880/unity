// AICore project map (phase 12, editor side, read-only).
//
// The brain knows about reports; this gives it a map: which scenes exist, what they
// contain, which prefabs the catalogue approves, what those depend on, and how it all
// connects. Entities and relations are emitted with identifiers the brain can store
// directly, so ingestion is a copy rather than a translation.
//
// It is bounded on purpose: a real project has too much to map in one pass, and a
// truncated map that says it is truncated is more useful than a slow complete one.
//
// Batch:
//   Unity.exe -batchmode -nographics -quit -projectPath <project> ^
//     -logFile <log> -executeMethod AliTerra.AICore.Editor.AICoreProjectMap.BuildBatch
//   set AICORE_MAP_OUT to choose the output path.

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace AliTerra.AICore.Editor
{
    public static class AICoreProjectMap
    {
        public const string ReportVersion = "1";
        public const string DefaultRelativeOut = "AICore/outputs/scene/project-map.json";

        private const int MaxScenes = 50;
        private const int MaxObjectsPerScene = 500;
        private const int MaxDependencies = 20;
        private const int MaxRelations = 5000;
        private const int MaxIdentifier = 96;

        private sealed class Entity
        {
            public string id;
            public string path;
            public string kind;
            public string name;
        }

        private sealed class Relation
        {
            public string source;
            public string target;
            public string type;
        }

        public static void BuildBatch()
        {
            try
            {
                string outPath = Environment.GetEnvironmentVariable("AICORE_MAP_OUT");
                if (string.IsNullOrEmpty(outPath))
                {
                    string projectRoot = Directory.GetParent(Application.dataPath).FullName;
                    outPath = Path.Combine(projectRoot,
                        DefaultRelativeOut.Replace('/', Path.DirectorySeparatorChar));
                }
                string failure = Build(Path.GetFullPath(outPath));
                if (failure != null)
                {
                    Debug.LogError("[AICoreProjectMap] " + failure);
                    if (Application.isBatchMode)
                    {
                        EditorApplication.Exit(1);
                    }
                    return;
                }
                Debug.Log("[AICoreProjectMap] map written to " + outPath);
                if (Application.isBatchMode)
                {
                    EditorApplication.Exit(0);
                }
            }
            catch (Exception error)
            {
                Debug.LogError("[AICoreProjectMap] " + error.GetType().Name + ": " + error.Message);
                if (Application.isBatchMode)
                {
                    EditorApplication.Exit(1);
                }
            }
        }

        /// <summary>Writes the map. Returns null on success, or a failure message.</summary>
        public static string Build(string outPath)
        {
            try
            {
                var entities = new List<Entity>();
                var relations = new List<Relation>();
                bool truncated = false;
                int sceneCount = 0;

                // -- scenes ---------------------------------------------------------------
                foreach (EditorBuildSettingsScene entry in EditorBuildSettings.scenes)
                {
                    if (!entry.enabled || string.IsNullOrEmpty(entry.path))
                    {
                        continue;
                    }
                    if (sceneCount >= MaxScenes)
                    {
                        truncated = true;
                        break;
                    }
                    sceneCount++;
                    Scene scene = EditorSceneManager.OpenScene(entry.path, OpenSceneMode.Single);
                    Entity sceneEntity = Add(entities, entry.path, "scene", scene.name);
                    relations.Add(RelationOf(sceneEntity.id, "is_loaded_from", "build_settings"));

                    int objects = 0;
                    foreach (GameObject root in scene.GetRootGameObjects())
                    {
                        foreach (Transform item in root.GetComponentsInChildren<Transform>(true))
                        {
                            if (objects >= MaxObjectsPerScene)
                            {
                                truncated = true;
                                break;
                            }
                            objects++;
                            string objectPath = entry.path + "#" + PathOf(item);
                            Entity objectEntity = Add(entities, objectPath, "object", item.name);
                            relations.Add(RelationOf(sceneEntity.id, "contains", objectEntity.id));

                            bool observed = item.GetComponent<WorldEntity>() != null;
                            foreach (Component component in item.GetComponents<Component>())
                            {
                                if (component == null)
                                {
                                    relations.Add(RelationOf(objectEntity.id, "has_missing_script", "true"));
                                    continue;
                                }
                                string typeName = component.GetType().Name;
                                relations.Add(RelationOf(objectEntity.id, "has_component", typeName));
                                if (typeName == "WorldEntity")
                                {
                                    observed = true;
                                }
                            }
                            if (observed)
                            {
                                relations.Add(RelationOf(objectEntity.id, "observed", "true"));
                            }
                        }
                        if (objects >= MaxObjectsPerScene)
                        {
                            break;
                        }
                    }

                    foreach (string dependency in Bounded(AssetDatabase.GetDependencies(entry.path, true)))
                    {
                        Entity asset = Add(entities, dependency, "asset", Path.GetFileName(dependency));
                        relations.Add(RelationOf(sceneEntity.id, "depends_on", asset.id));
                    }
                }

                // -- catalogues and their prefabs ----------------------------------------
                foreach (string guid in AssetDatabase.FindAssets("t:PrefabCatalog"))
                {
                    string catalogPath = AssetDatabase.GUIDToAssetPath(guid);
                    Entity catalog = Add(entities, catalogPath, "catalog", Path.GetFileName(catalogPath));
                    foreach (string prefabPath in CatalogEntries(guid))
                    {
                        if (string.IsNullOrEmpty(prefabPath))
                        {
                            continue;
                        }
                        Entity prefab = Add(entities, prefabPath, "prefab", Path.GetFileName(prefabPath));
                        relations.Add(RelationOf(catalog.id, "catalogues", prefab.id));
                        foreach (string dependency in Bounded(AssetDatabase.GetDependencies(prefabPath, true)))
                        {
                            Entity asset = Add(entities, dependency, "asset", Path.GetFileName(dependency));
                            relations.Add(RelationOf(prefab.id, "depends_on", asset.id));
                        }
                    }
                }

                if (relations.Count > MaxRelations)
                {
                    relations.RemoveRange(MaxRelations, relations.Count - MaxRelations);
                    truncated = true;
                }

                var builder = new StringBuilder();
                builder.Append("{\n");
                builder.Append("  \"report_version\": ").Append(Quote(ReportVersion)).Append(",\n");
                builder.Append("  \"map\": ").Append(Quote("AICoreProjectMap")).Append(",\n");
                builder.Append("  \"unity_version\": ").Append(Quote(Application.unityVersion)).Append(",\n");
                builder.Append("  \"read_only\": true,\n");
                builder.Append("  \"generated_utc\": ").Append(Quote(DateTime.UtcNow.ToString("o", CultureInfo.InvariantCulture))).Append(",\n");
                builder.Append("  \"summary\": {\n");
                builder.Append("    \"scenes\": ").Append(Num(sceneCount)).Append(",\n");
                builder.Append("    \"entities\": ").Append(Num(entities.Count)).Append(",\n");
                builder.Append("    \"relations\": ").Append(Num(relations.Count)).Append(",\n");
                builder.Append("    \"truncated\": ").Append(truncated ? "true" : "false").Append("\n");
                builder.Append("  },\n");

                builder.Append("  \"entities\": [\n");
                for (int index = 0; index < entities.Count; index++)
                {
                    Entity entity = entities[index];
                    builder.Append("    { \"id\": ").Append(Quote(entity.id))
                           .Append(", \"path\": ").Append(Quote(entity.path))
                           .Append(", \"kind\": ").Append(Quote(entity.kind))
                           .Append(", \"name\": ").Append(Quote(entity.name)).Append(" }");
                    builder.Append(index < entities.Count - 1 ? ",\n" : "\n");
                }
                builder.Append("  ],\n");

                builder.Append("  \"relations\": [\n");
                for (int index = 0; index < relations.Count; index++)
                {
                    Relation relation = relations[index];
                    builder.Append("    { \"source\": ").Append(Quote(relation.source))
                           .Append(", \"target\": ").Append(Quote(relation.target))
                           .Append(", \"type\": ").Append(Quote(relation.type)).Append(" }");
                    builder.Append(index < relations.Count - 1 ? ",\n" : "\n");
                }
                builder.Append("  ]\n");
                builder.Append("}\n");

                string directory = Path.GetDirectoryName(outPath);
                if (!string.IsNullOrEmpty(directory))
                {
                    Directory.CreateDirectory(directory);
                }
                File.WriteAllText(outPath, builder.ToString(), new UTF8Encoding(false));
                return null;
            }
            catch (Exception error)
            {
                return error.GetType().Name + ": " + error.Message;
            }
        }

        private static IEnumerable<string> CatalogEntries(string catalogGuid)
        {
            var paths = new List<string>();
            string catalogPath = AssetDatabase.GUIDToAssetPath(catalogGuid);
            var catalog = AssetDatabase.LoadAssetAtPath<PrefabCatalog>(catalogPath);
            if (catalog == null)
            {
                return paths;
            }
            var seen = new HashSet<string>();
            foreach (SerializedProperty entry in Entries(catalog))
            {
                SerializedProperty prefab = entry.FindPropertyRelative("prefab");
                if (prefab == null || prefab.objectReferenceValue == null)
                {
                    continue;
                }
                string path = AssetDatabase.GetAssetPath(prefab.objectReferenceValue);
                if (!string.IsNullOrEmpty(path) && seen.Add(path))
                {
                    paths.Add(path);
                }
            }
            return paths;
        }

        private static IEnumerable<SerializedProperty> Entries(PrefabCatalog catalog)
        {
            var serialized = new SerializedObject(catalog);
            SerializedProperty list = serialized.FindProperty("entries");
            if (list == null || !list.isArray)
            {
                yield break;
            }
            for (int index = 0; index < list.arraySize; index++)
            {
                yield return list.GetArrayElementAtIndex(index);
            }
        }

        private static IEnumerable<string> Bounded(string[] dependencies)
        {
            int served = 0;
            foreach (string dependency in dependencies)
            {
                if (dependency == null || !dependency.StartsWith("Assets/", StringComparison.Ordinal))
                {
                    continue;
                }
                if (served >= MaxDependencies)
                {
                    yield break;
                }
                served++;
                yield return dependency;
            }
        }

        private static Entity Add(List<Entity> entities, string path, string kind, string name)
        {
            string id = Identifier(kind, path);
            foreach (Entity existing in entities)
            {
                if (existing.id == id)
                {
                    return existing;
                }
            }
            var entity = new Entity { id = id, path = path, kind = kind, name = name };
            entities.Add(entity);
            return entity;
        }

        private static Relation RelationOf(string source, string type, string target)
        {
            return new Relation { source = source, target = target, type = type };
        }

        /// <summary>Turns any path into an identifier the brain accepts: [A-Za-z0-9_.:-], at most 96 chars.</summary>
        public static string Identifier(string kind, string path)
        {
            string raw = kind + "." + (path ?? "");
            var builder = new StringBuilder(raw.Length);
            foreach (char character in raw)
            {
                bool allowed = (character >= 'a' && character <= 'z') || (character >= 'A' && character <= 'Z')
                               || (character >= '0' && character <= '9') || character == '.' || character == '_'
                               || character == ':' || character == '-';
                builder.Append(allowed ? character : '_');
            }
            string value = builder.ToString();
            if (value.Length <= MaxIdentifier)
            {
                return value;
            }
            string digest = value.GetHashCode().ToString("x8", CultureInfo.InvariantCulture);
            return value.Substring(0, MaxIdentifier - 9) + "_" + digest;
        }

        private static string PathOf(Transform item)
        {
            var parts = new List<string>();
            Transform current = item;
            while (current != null)
            {
                parts.Insert(0, current.name);
                current = current.parent;
            }
            return string.Join("/", parts.ToArray());
        }

        private static string Num(int value)
        {
            return value.ToString(CultureInfo.InvariantCulture);
        }

        private static string Quote(string value)
        {
            if (value == null)
            {
                return "null";
            }
            var builder = new StringBuilder(value.Length + 2);
            builder.Append('"');
            foreach (char character in value)
            {
                switch (character)
                {
                    case '"': builder.Append("\\\""); break;
                    case '\\': builder.Append("\\\\"); break;
                    case '\n': builder.Append("\\n"); break;
                    case '\r': builder.Append("\\r"); break;
                    case '\t': builder.Append("\\t"); break;
                    default:
                        if (character < ' ')
                        {
                            builder.Append("\\u").Append(((int)character).ToString("x4", CultureInfo.InvariantCulture));
                        }
                        else
                        {
                            builder.Append(character);
                        }
                        break;
                }
            }
            builder.Append('"');
            return builder.ToString();
        }
    }
}
