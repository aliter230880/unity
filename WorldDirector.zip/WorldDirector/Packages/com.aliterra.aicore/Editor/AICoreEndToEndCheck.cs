// AICore end-to-end check (phase 18, editor side).
//
// Proves the contract the way the client actually sees it: a real v2 request goes to a real
// brain over HTTP, and the answer is parsed with the client's own DTO. If the plan loses its
// tool calls, or the response stops satisfying the client's validator, this fails loudly.
//
// It is not Play Mode: the director's networking lives in play, and this check exists to test
// the contract without a running game. Play Mode remains a separate, honest gap.
//
// Batch:
//   set AICORE_BRAIN_URL=http://127.0.0.1:8765
//   set AICORE_TOKEN=***
//   set AICORE_WORLD=<world id>
//   Unity.exe -batchmode -nographics -quit -projectPath <project> ^
//     -logFile <log> -executeMethod AliTerra.AICore.Editor.AICoreEndToEndCheck.RunBatch

using System;
using System.Globalization;
using System.IO;
using System.Net;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace AliTerra.AICore.Editor
{
    public static class AICoreEndToEndCheck
    {
        public const string DefaultUrl = "http://127.0.0.1:8765";

        public static void RunBatch()
        {
            try
            {
                string url = Environment.GetEnvironmentVariable("AICORE_BRAIN_URL");
                if (string.IsNullOrEmpty(url))
                {
                    url = DefaultUrl;
                }
                string token = Environment.GetEnvironmentVariable("AICORE_TOKEN");
                string world = Environment.GetEnvironmentVariable("AICORE_WORLD");
                if (string.IsNullOrEmpty(world))
                {
                    world = "sandbox";
                }
                string failure = Run(url, token, world);
                if (failure != null)
                {
                    Debug.LogError("[AICoreE2E] " + failure);
                    if (Application.isBatchMode)
                    {
                        EditorApplication.Exit(1);
                    }
                    return;
                }
                if (Application.isBatchMode)
                {
                    EditorApplication.Exit(0);
                }
            }
            catch (Exception error)
            {
                Debug.LogError("[AICoreE2E] " + error.GetType().Name + ": " + error.Message);
                if (Application.isBatchMode)
                {
                    EditorApplication.Exit(1);
                }
            }
        }

        /// <summary>Sends one real tick and reads the answer with the client's own DTO.</summary>
        public static string Run(string url, string token, string world)
        {
            if (string.IsNullOrEmpty(url) || string.IsNullOrEmpty(token))
            {
                return "the brain URL and AICORE_TOKEN are both required";
            }
            Uri parsed;
            if (!Uri.TryCreate(url, UriKind.Absolute, out parsed))
            {
                return "the brain URL is not a valid absolute URL: " + url;
            }
            if (parsed.Host != "127.0.0.1" && parsed.Host != "localhost" && parsed.Host != "::1")
            {
                return "refusing to talk to a non-loopback host: " + parsed.Host;
            }

            string request = BuildRequest(world);
            string json;
            try
            {
                json = Post(parsed.GetLeftPart(UriPartial.Authority) + "/v2/tick", token, request);
            }
            catch (WebException error)
            {
                string detail = "";
                if (error.Response != null)
                {
                    using (var reader = new StreamReader(error.Response.GetResponseStream()))
                    {
                        detail = reader.ReadToEnd();
                    }
                }
                return "the brain refused the observation: " + error.Message + " " + detail;
            }

            TickResponse response;
            try
            {
                response = JsonUtility.FromJson<TickResponse>(json);
            }
            catch (Exception error)
            {
                return "the client could not parse the answer: " + error.Message + " :: " + Truncate(json);
            }
            if (!ActionValidation.ValidateResponse(response, "e2e-observation-1", out string problem))
            {
                return "the answer failed the client's own validation: " + problem;
            }

            int calls = response.tool_calls == null ? 0 : response.tool_calls.Length;
            var names = new StringBuilder();
            for (int index = 0; index < calls; index++)
            {
                if (index > 0)
                {
                    names.Append(", ");
                }
                names.Append(response.tool_calls[index].tool);
            }
            Debug.Log("[AICoreE2E] the answer parsed: " + response.actions.Length
                      + " action(s), " + calls + " reading(s)"
                      + (calls > 0 ? " -> " + names : ""));
            return null;
        }

        /// <summary>A minimal but complete v2 observation, the shape the client really sends.</summary>
        public static string BuildRequest(string world)
        {
            var builder = new StringBuilder();
            builder.Append("{");
            builder.Append("\"protocol_version\": 2,");
            builder.Append("\"world_id\": ").Append(Quote(world)).Append(",");
            builder.Append("\"session_id\": \"e2e-session-1\",");
            builder.Append("\"observation_id\": \"e2e-observation-1\",");
            builder.Append("\"goal\": \"Observe the sandbox scene and report what is missing.\",");
            builder.Append("\"target_catalog_id\": \"scene\", \"target_count\": 1,");
            builder.Append("\"anchor\": {\"x\": 0, \"y\": 0, \"z\": 0},");
            builder.Append("\"allow_mutations\": false, \"entities_truncated\": false,");
            builder.Append("\"limits\": {\"min\": {\"x\": -1000, \"y\": -1000, \"z\": -1000},");
            builder.Append(" \"max\": {\"x\": 1000, \"y\": 1000, \"z\": 1000},");
            builder.Append(" \"max_owned_entities\": 100, \"owned_entity_count\": 0, \"action_budget\": 8},");
            builder.Append("\"entities\": [], \"catalog\": [{\"id\": \"scene\", \"kind\": \"prop\"}],");
            builder.Append("\"results\": [], \"events\": [], \"feedback\": [],");
            builder.Append("\"goals\": [], \"relations\": [],");
            // Deliberately empty: a check must not publish anything, or it would overwrite the
            // very facts it is meant to be observing. Publishing is the publisher's job.
            builder.Append("\"knowledge_updates\": [],");
            builder.Append("\"capabilities\": {\"action_types\": [\"spawn\", \"activate\", \"deactivate\"]}");
            builder.Append("}");
            return builder.ToString();
        }

        private static string Post(string url, string token, string payload)
        {
            var request = (HttpWebRequest)WebRequest.Create(url);
            request.Method = "POST";
            request.ContentType = "application/json";
            request.Headers.Add("Authorization", "Bearer " + token);
            request.Timeout = 10000;
            byte[] body = Encoding.UTF8.GetBytes(payload);
            request.ContentLength = body.Length;
            using (Stream stream = request.GetRequestStream())
            {
                stream.Write(body, 0, body.Length);
            }
            using (var response = (HttpWebResponse)request.GetResponse())
            using (var reader = new StreamReader(response.GetResponseStream(), Encoding.UTF8))
            {
                return reader.ReadToEnd();
            }
        }

        private static string Truncate(string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                return "";
            }
            return value.Length <= 200 ? value : value.Substring(0, 200) + "...";
        }

        private static string Quote(string value)
        {
            if (value == null)
            {
                return "null";
            }
            var builder = new StringBuilder(value.Length + 2);
            builder.Append('"');
            foreach (char character in value)
            {
                switch (character)
                {
                    case '"': builder.Append("\\\""); break;
                    case '\\': builder.Append("\\\\"); break;
                    case '\n': builder.Append("\\n"); break;
                    case '\r': builder.Append("\\r"); break;
                    case '\t': builder.Append("\\t"); break;
                    default:
                        if (character < ' ')
                        {
                            builder.Append("\\u").Append(((int)character).ToString("x4", CultureInfo.InvariantCulture));
                        }
                        else
                        {
                            builder.Append(character);
                        }
                        break;
                }
            }
            builder.Append('"');
            return builder.ToString();
        }
    }
}
