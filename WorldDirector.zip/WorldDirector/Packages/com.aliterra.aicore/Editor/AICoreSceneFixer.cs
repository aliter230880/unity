// AICore scene fixer (phase 5, editor side).
//
// The first tool that changes a *scene*. It runs inside the editor because that is
// the only place a scene can be changed; the brain never spawns processes.
//
// Safety, in order:
//   1. dry run is the default (AICORE_FIX_DRY_RUN is not "0");
//   2. applying first copies the scene file into AI/backups/fix-<stamp>/;
//   3. only the fix actions listed below are recognised; anything else is reported as
//      unsupported and left alone;
//   4. the scene must live under Assets/.
//
// Batch:
//   set AICORE_FIXPLAN=<path to fix-plan.json>
//   set AICORE_FIX_DRY_RUN=1|0
//   set AICORE_FIX_OUT=<path to result json>
//   set AICORE_PROBE_OUT=<optional: rescan the scene afterwards>
//   Unity.exe -batchmode -nographics -quit -projectPath <project> ^
//     -logFile <log> -executeMethod AliTerra.AICore.Editor.AICoreSceneFixer.ApplyBatch

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace AliTerra.AICore.Editor
{
    public static class AICoreSceneFixer
    {
        public const string ReportVersion = "1";

        [Serializable]
        private class FixDto
        {
            public string id;
            public string finding;
            public string action;
            public string component;
            public string severity;
            public string risk;
            public bool reversible;
            public string evidence;
        }

        [Serializable]
        private class PlanDto
        {
            public string plan_id;
            public string scene;
            public string source_report;
            public string generated_utc;
            public FixDto[] fixes;
            public string[] unresolved_findings;
            public string note;
        }

        public static void ApplyBatch()
        {
            int code = 0;
            try
            {
                code = Run();
            }
            catch (Exception error)
            {
                Debug.LogError("[AICoreSceneFixer] " + error.GetType().Name + ": " + error.Message);
                code = 1;
            }
            if (Application.isBatchMode)
            {
                EditorApplication.Exit(code);
            }
        }

        private static int Run()
        {
            string planPath = Environment.GetEnvironmentVariable("AICORE_FIXPLAN");
            if (string.IsNullOrEmpty(planPath) || !File.Exists(planPath))
            {
                throw new InvalidOperationException("AICORE_FIXPLAN does not point at a plan file");
            }
            string drySetting = Environment.GetEnvironmentVariable("AICORE_FIX_DRY_RUN");
            bool dryRun = string.IsNullOrEmpty(drySetting) || drySetting != "0";

            PlanDto plan = JsonUtility.FromJson<PlanDto>(File.ReadAllText(planPath, Encoding.UTF8));
            if (plan == null || plan.fixes == null)
            {
                throw new InvalidOperationException("the fix plan could not be read");
            }
            if (string.IsNullOrEmpty(plan.scene) || !plan.scene.StartsWith("Assets/", StringComparison.Ordinal))
            {
                throw new InvalidOperationException("the plan must name a scene under Assets/");
            }

            Scene scene = OpenScene(plan.scene);
            string projectRoot = Directory.GetParent(Application.dataPath).FullName;
            string backup = null;
            if (!dryRun)
            {
                backup = BackupScene(projectRoot, plan.scene);
            }

            var applied = new List<string>();
            var skipped = new List<string>();
            var notes = new List<string>();

            foreach (FixDto fix in plan.fixes)
            {
                string outcome;
                if (dryRun)
                {
                    outcome = Preview(fix);
                }
                else
                {
                    outcome = Apply(fix, notes);
                }
                if (outcome == null)
                {
                    skipped.Add(fix.id + " (" + fix.action + ")");
                }
                else
                {
                    applied.Add(fix.id + ": " + outcome);
                }
            }

            if (!dryRun)
            {
                EditorSceneManager.MarkSceneDirty(scene);
                if (!EditorSceneManager.SaveScene(scene))
                {
                    throw new InvalidOperationException("the scene could not be saved");
                }
                AssetDatabase.Refresh();
            }

            string probe = null;
            string probeOut = Environment.GetEnvironmentVariable("AICORE_PROBE_OUT");
            // A dry run rescans too: it is how you confirm nothing changed.
            if (!string.IsNullOrEmpty(probeOut))
            {
                probe = Path.GetFullPath(probeOut);
                string failure = AICoreSceneProbe.WriteReport(probe);
                if (failure != null)
                {
                    notes.Add("probe failed: " + failure);
                    probe = null;
                }
            }

            WriteResult(applied, skipped, notes, dryRun, plan, backup, probe, scene);
            Debug.Log("[AICoreSceneFixer] " + (dryRun ? "dry run" : "applied")
                      + ": " + applied.Count + " fix(es), " + skipped.Count + " skipped");
            return 0;
        }

        private static Scene OpenScene(string scenePath)
        {
            for (int index = 0; index < SceneManager.sceneCount; index++)
            {
                Scene loaded = SceneManager.GetSceneAt(index);
                if (loaded.path == scenePath)
                {
                    return loaded;
                }
            }
            return EditorSceneManager.OpenScene(scenePath, OpenSceneMode.Single);
        }

        private static string BackupScene(string projectRoot, string scenePath)
        {
            string stamp = DateTime.UtcNow.ToString("yyyyMMdd'T'HHmmss'Z'", CultureInfo.InvariantCulture);
            string source = Path.Combine(projectRoot, scenePath.Replace('/', Path.DirectorySeparatorChar));
            string destination = Path.Combine(projectRoot, "AI", "backups", "fix-" + stamp,
                                              scenePath.Replace('/', Path.DirectorySeparatorChar));
            Directory.CreateDirectory(Path.GetDirectoryName(destination));
            File.Copy(source, destination, true);
            return destination;
        }

        // -- previews -----------------------------------------------------------------
        private static string Preview(FixDto fix)
        {
            switch (fix.action)
            {
                case "remove-extra-singletons":
                    return "would keep one " + fix.component + " and remove the rest";
                case "remove-duplicate-rigs":
                    return "would remove hierarchies that duplicate a transform name";
                case "remove-lod-groups":
                    return "would remove every LODGroup";
                case "zero-stretched-size-delta":
                    return "would zero the sizeDelta of stretched RectTransforms";
                case "add-camera":
                    return "would add a camera";
                case "strip-missing-scripts":
                    return "would clear components whose script no longer resolves";
                default:
                    return null;
            }
        }

        // -- application --------------------------------------------------------------
        private static string Apply(FixDto fix, List<string> notes)
        {
            switch (fix.action)
            {
                case "remove-extra-singletons":
                    return RemoveExtraSingletons(fix.component);
                case "remove-duplicate-rigs":
                    return RemoveDuplicateRigs();
                case "remove-lod-groups":
                    return RemoveComponents("LODGroup");
                case "zero-stretched-size-delta":
                    return ZeroStretchedSizeDelta();
                case "add-camera":
                    return AddCamera();
                case "strip-missing-scripts":
                    return StripMissingScripts();
                default:
                    notes.Add("unsupported action " + fix.action + " for " + fix.id);
                    return null;
            }
        }

        private static IEnumerable<GameObject> Objects()
        {
            for (int index = 0; index < SceneManager.sceneCount; index++)
            {
                Scene scene = SceneManager.GetSceneAt(index);
                if (!scene.isLoaded)
                {
                    continue;
                }
                foreach (GameObject root in scene.GetRootGameObjects())
                {
                    foreach (Transform item in root.GetComponentsInChildren<Transform>(true))
                    {
                        yield return item.gameObject;
                    }
                }
            }
        }

        private static string RemoveExtraSingletons(string typeName)
        {
            if (string.IsNullOrEmpty(typeName))
            {
                return null;
            }
            bool kept = false;
            int removed = 0;
            foreach (GameObject item in Objects())
            {
                var doomed = new List<Component>();
                foreach (Component component in item.GetComponents<Component>())
                {
                    if (component == null || component.GetType().Name != typeName)
                    {
                        continue;
                    }
                    if (!kept)
                    {
                        kept = true;
                        continue;
                    }
                    doomed.Add(component);
                }
                foreach (Component component in doomed)
                {
                    UnityEngine.Object.DestroyImmediate(component, true);
                    removed++;
                }
            }
            return "removed " + removed.ToString(CultureInfo.InvariantCulture) + " extra " + typeName;
        }

        private static string RemoveComponents(string typeName)
        {
            int removed = 0;
            foreach (GameObject item in Objects())
            {
                foreach (Component component in item.GetComponents<Component>())
                {
                    if (component != null && component.GetType().Name == typeName)
                    {
                        UnityEngine.Object.DestroyImmediate(component, true);
                        removed++;
                    }
                }
            }
            return "removed " + removed.ToString(CultureInfo.InvariantCulture) + " " + typeName;
        }

        private static string RemoveDuplicateRigs()
        {
            var names = new Dictionary<string, int>();
            foreach (GameObject item in Objects())
            {
                int count;
                names.TryGetValue(item.name, out count);
                names[item.name] = count + 1;
            }

            var doomedRoots = new List<GameObject>();
            for (int index = 0; index < SceneManager.sceneCount; index++)
            {
                Scene scene = SceneManager.GetSceneAt(index);
                if (!scene.isLoaded)
                {
                    continue;
                }
                var seen = new HashSet<string>();
                foreach (GameObject root in scene.GetRootGameObjects())
                {
                    bool duplicates = false;
                    foreach (Transform item in root.GetComponentsInChildren<Transform>(true))
                    {
                        int count;
                        if (names.TryGetValue(item.name, out count) && count > 1 &&
                            nameSeenElsewhere(seen, item.name))
                        {
                            duplicates = true;
                            break;
                        }
                        seen.Add(item.name);
                    }
                    if (duplicates)
                    {
                        doomedRoots.Add(root);
                    }
                }
            }

            foreach (GameObject root in doomedRoots)
            {
                UnityEngine.Object.DestroyImmediate(root, true);
            }
            return "removed " + doomedRoots.Count.ToString(CultureInfo.InvariantCulture)
                   + " duplicate hierarchy root(s)";
        }

        private static bool nameSeenElsewhere(HashSet<string> seen, string name)
        {
            return seen.Contains(name);
        }

        private static string ZeroStretchedSizeDelta()
        {
            int changed = 0;
            foreach (GameObject item in Objects())
            {
                var rect = item.GetComponent<RectTransform>();
                if (rect == null)
                {
                    continue;
                }
                if (rect.anchorMin == rect.anchorMax)
                {
                    continue;
                }
                if (Mathf.Abs(rect.sizeDelta.x) < 0.01f && Mathf.Abs(rect.sizeDelta.y) < 0.01f)
                {
                    continue;
                }
                rect.sizeDelta = Vector2.zero;
                changed++;
            }
            return "zeroed " + changed.ToString(CultureInfo.InvariantCulture) + " sizeDelta(s)";
        }

        private static string StripMissingScripts()
        {
            var doomed = new List<GameObject>();
            foreach (GameObject item in Objects())
            {
                foreach (Component component in item.GetComponents<Component>())
                {
                    if (component == null)
                    {
                        doomed.Add(item);
                        break;
                    }
                }
            }
            int removed = 0;
            foreach (GameObject item in doomed)
            {
                removed += GameObjectUtility.RemoveMonoBehavioursWithMissingScript(item);
            }
            return "cleared missing scripts on "
                   + doomed.Count.ToString(CultureInfo.InvariantCulture) + " object(s) ("
                   + removed.ToString(CultureInfo.InvariantCulture) + " slot(s) removed)";
        }

        private static string AddCamera()
        {
            var camera = new GameObject("ProbeCamera");
            camera.AddComponent<Camera>();
            camera.transform.position = new Vector3(0f, 1f, -10f);
            return "added a camera";
        }

        // -- result -------------------------------------------------------------------
        private static void WriteResult(List<string> applied, List<string> skipped, List<string> notes,
                                        bool dryRun, PlanDto plan, string backup, string probe,
                                        Scene scene)
        {
            string outPath = Environment.GetEnvironmentVariable("AICORE_FIX_OUT");
            var builder = new StringBuilder();
            builder.Append("{\n");
            builder.Append("  \"report_version\": ").Append(Quote(ReportVersion)).Append(",\n");
            builder.Append("  \"fixer\": ").Append(Quote("AICoreSceneFixer")).Append(",\n");
            builder.Append("  \"dry_run\": ").Append(dryRun ? "true" : "false").Append(",\n");
            builder.Append("  \"plan_id\": ").Append(Quote(plan.plan_id)).Append(",\n");
            builder.Append("  \"scene\": ").Append(Quote(plan.scene)).Append(",\n");
            builder.Append("  \"scene_objects\": ").Append(Count().ToString(CultureInfo.InvariantCulture)).Append(",\n");
            builder.Append("  \"backup\": ").Append(backup == null ? "null" : Quote(backup)).Append(",\n");
            builder.Append("  \"probe_report\": ").Append(probe == null ? "null" : Quote(probe)).Append(",\n");
            builder.Append("  \"applied\": ").Append(StringArray(applied)).Append(",\n");
            builder.Append("  \"skipped\": ").Append(StringArray(skipped)).Append(",\n");
            builder.Append("  \"notes\": ").Append(StringArray(notes)).Append(",\n");
            builder.Append("  \"generated_utc\": ").Append(Quote(DateTime.UtcNow.ToString("o", CultureInfo.InvariantCulture))).Append("\n");
            builder.Append("}\n");
            string json = builder.ToString();
            if (!string.IsNullOrEmpty(outPath))
            {
                string directory = Path.GetDirectoryName(Path.GetFullPath(outPath));
                if (!string.IsNullOrEmpty(directory))
                {
                    Directory.CreateDirectory(directory);
                }
                File.WriteAllText(Path.GetFullPath(outPath), json, new UTF8Encoding(false));
            }
            Debug.Log(json);
        }

        private static int Count()
        {
            int total = 0;
            foreach (GameObject _item in Objects())
            {
                total++;
            }
            return total;
        }

        private static string StringArray(List<string> values)
        {
            var builder = new StringBuilder("[");
            for (int index = 0; index < values.Count; index++)
            {
                if (index > 0)
                {
                    builder.Append(", ");
                }
                builder.Append(Quote(values[index]));
            }
            builder.Append("]");
            return builder.ToString();
        }

        private static string Quote(string value)
        {
            if (value == null)
            {
                return "null";
            }
            var builder = new StringBuilder(value.Length + 2);
            builder.Append('"');
            foreach (char character in value)
            {
                switch (character)
                {
                    case '"': builder.Append("\\\""); break;
                    case '\\': builder.Append("\\\\"); break;
                    case '\n': builder.Append("\\n"); break;
                    case '\r': builder.Append("\\r"); break;
                    case '\t': builder.Append("\\t"); break;
                    default:
                        if (character < ' ')
                        {
                            builder.Append("\\u").Append(((int)character).ToString("x4", CultureInfo.InvariantCulture));
                        }
                        else
                        {
                            builder.Append(character);
                        }
                        break;
                }
            }
            builder.Append('"');
            return builder.ToString();
        }
    }
}
