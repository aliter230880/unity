// AICore live facts (phase 16b, editor side).
//
// Until now the brain learned about the project by reading files on disk. This lets the
// editor say what it sees *right now*: which scene is open, how many objects it holds, how
// many are observable, whether it is playing or compiling. Facts, not files.
//
// It is a narrow publisher on purpose: one world, a bounded list of validated facts, one
// endpoint. It cannot read anything back and it cannot touch the project.
//
// Batch:
//   set AICORE_BRAIN_URL=http://127.0.0.1:8765
//   set AICORE_TOKEN=<the brain's token>
//   set AICORE_WORLD=<world id>
//   Unity.exe -batchmode -nographics -quit -projectPath <project> ^
//     -logFile <log> -executeMethod AliTerra.AICore.Editor.AICoreLiveFacts.PublishBatch
//
// The URL must be loopback: this never talks to anything but the local brain.

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net;
using System.Text;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace AliTerra.AICore.Editor
{
    public static class AICoreLiveFacts
    {
        public const string DefaultUrl = "http://127.0.0.1:8765";
        public const string DefaultWorld = "sandbox";

        private sealed class Fact
        {
            public string key;
            public string value;
            public bool numeric;
            public bool boolean;
        }

        [MenuItem("AICore/Publish Live Facts")]
        public static void PublishMenu()
        {
            string url = Environment.GetEnvironmentVariable("AICORE_BRAIN_URL");
            if (string.IsNullOrEmpty(url))
            {
                url = DefaultUrl;
            }
            string token = Environment.GetEnvironmentVariable("AICORE_TOKEN");
            string world = Environment.GetEnvironmentVariable("AICORE_WORLD");
            if (string.IsNullOrEmpty(world))
            {
                world = DefaultWorld;
            }
            string error = Publish(url, token, world);
            if (error == null)
            {
                Debug.Log("[AICoreLiveFacts] facts published to " + url);
            }
            else
            {
                Debug.LogError("[AICoreLiveFacts] " + error);
            }
        }

        public static void PublishBatch()
        {
            try
            {
                string url = Environment.GetEnvironmentVariable("AICORE_BRAIN_URL");
                if (string.IsNullOrEmpty(url))
                {
                    url = DefaultUrl;
                }
                string token = Environment.GetEnvironmentVariable("AICORE_TOKEN");
                string world = Environment.GetEnvironmentVariable("AICORE_WORLD");
                if (string.IsNullOrEmpty(world))
                {
                    world = DefaultWorld;
                }
                string error = Publish(url, token, world);
                if (error != null)
                {
                    Debug.LogError("[AICoreLiveFacts] " + error);
                    if (Application.isBatchMode)
                    {
                        EditorApplication.Exit(1);
                    }
                    return;
                }
                Debug.Log("[AICoreLiveFacts] facts published to " + url);
                if (Application.isBatchMode)
                {
                    EditorApplication.Exit(0);
                }
            }
            catch (Exception error)
            {
                Debug.LogError("[AICoreLiveFacts] " + error.GetType().Name + ": " + error.Message);
                if (Application.isBatchMode)
                {
                    EditorApplication.Exit(1);
                }
            }
        }

        /// <summary>Sends the facts. Returns null on success, or a failure message.</summary>
        public static string Publish(string url, string token, string world)
        {
            if (string.IsNullOrEmpty(url))
            {
                return "no brain URL was given";
            }
            Uri parsed;
            if (!Uri.TryCreate(url, UriKind.Absolute, out parsed))
            {
                return "the brain URL is not a valid absolute URL: " + url;
            }
            if (parsed.Host != "127.0.0.1" && parsed.Host != "localhost" && parsed.Host != "::1")
            {
                return "refusing to publish to a non-loopback host: " + parsed.Host;
            }
            if (string.IsNullOrEmpty(token))
            {
                return "AICORE_TOKEN is not set, so the brain would refuse the facts";
            }
            string payload = BuildPayload(world);
            try
            {
                string answer = Post(parsed.GetLeftPart(UriPartial.Authority) + "/v1/knowledge",
                                     token, payload);
                Debug.Log("[AICoreLiveFacts] brain answered: " + answer);
                return null;
            }
            catch (WebException error)
            {
                string detail = "";
                if (error.Response != null)
                {
                    using (var reader = new StreamReader(error.Response.GetResponseStream()))
                    {
                        detail = reader.ReadToEnd();
                    }
                }
                return "the brain refused the facts: " + error.Message + " " + detail;
            }
        }

        /// <summary>The live facts, as the JSON body the brain expects.</summary>
        public static string BuildPayload(string world)
        {
            OpenConfiguredScene();
            var facts = new List<Fact>();
            Scene scene = SceneManager.GetActiveScene();
            Add(facts, "scene.name", scene.IsValid() ? scene.name : "untitled");
            Add(facts, "scene.objects", CountObjects(scene), true);
            Add(facts, "scene.observed", CountObserved(scene), true);
            Add(facts, "scene.cameras", CountOfType(scene, "Camera"), true);
            Add(facts, "scene.missing_scripts", CountMissingScripts(scene), true);
            Add(facts, "editor.unity_version", Application.unityVersion);
            Add(facts, "editor.playing", Application.isPlaying, false, true);
            Add(facts, "editor.compiling", EditorApplication.isCompiling, false, true);
            Add(facts, "editor.batch", Application.isBatchMode, false, true);
            return Serialise(world, facts);
        }

        /// <summary>In batch mode nothing is open, so the scene must be named.</summary>
        private static void OpenConfiguredScene()
        {
            string path = Environment.GetEnvironmentVariable("AICORE_SCENE");
            if (string.IsNullOrEmpty(path))
            {
                return;
            }
            for (int index = 0; index < SceneManager.sceneCount; index++)
            {
                Scene loaded = SceneManager.GetSceneAt(index);
                if (loaded.isLoaded && loaded.path == path)
                {
                    return;
                }
            }
            EditorSceneManager.OpenScene(path, OpenSceneMode.Single);
        }

        private static void Add(List<Fact> facts, string key, string value)

        {
            facts.Add(new Fact { key = key, value = value });
        }

        private static void Add(List<Fact> facts, string key, int value, bool numeric)
        {
            facts.Add(new Fact { key = key, value = value.ToString(CultureInfo.InvariantCulture), numeric = numeric });
        }

        private static void Add(List<Fact> facts, string key, bool value, bool numeric, bool boolean)
        {
            facts.Add(new Fact { key = key, value = value ? "true" : "false", boolean = boolean });
        }

        private static string Serialise(string world, List<Fact> facts)
        {
            var builder = new StringBuilder();
            builder.Append("{\"world_id\": ").Append(Quote(world)).Append(", \"facts\": [");
            for (int index = 0; index < facts.Count; index++)
            {
                Fact fact = facts[index];
                if (index > 0)
                {
                    builder.Append(", ");
                }
                builder.Append("{\"key\": ").Append(Quote(fact.key)).Append(", \"value\": ");
                if (fact.boolean)
                {
                    builder.Append(fact.value);
                }
                else if (fact.numeric)
                {
                    builder.Append(fact.value);
                }
                else
                {
                    builder.Append(Quote(fact.value));
                }
                builder.Append(", \"category\": \"system\", \"confidence\": 0.9}");
            }
            builder.Append("]}");
            return builder.ToString();
        }

        private static IEnumerable<GameObject> Objects(Scene scene)
        {
            if (!scene.IsValid() || !scene.isLoaded)
            {
                yield break;
            }
            foreach (GameObject root in scene.GetRootGameObjects())
            {
                foreach (Transform item in root.GetComponentsInChildren<Transform>(true))
                {
                    yield return item.gameObject;
                }
            }
        }

        private static int CountObjects(Scene scene)
        {
            int total = 0;
            foreach (GameObject _item in Objects(scene))
            {
                total++;
            }
            return total;
        }

        private static int CountObserved(Scene scene)
        {
            int total = 0;
            foreach (GameObject item in Objects(scene))
            {
                if (item.GetComponent<WorldEntity>() != null)
                {
                    total++;
                }
            }
            return total;
        }

        private static int CountOfType(Scene scene, string typeName)
        {
            int total = 0;
            foreach (GameObject item in Objects(scene))
            {
                foreach (Component component in item.GetComponents<Component>())
                {
                    if (component != null && component.GetType().Name == typeName)
                    {
                        total++;
                    }
                }
            }
            return total;
        }

        private static int CountMissingScripts(Scene scene)
        {
            int total = 0;
            foreach (GameObject item in Objects(scene))
            {
                foreach (Component component in item.GetComponents<Component>())
                {
                    if (component == null)
                    {
                        total++;
                    }
                }
            }
            return total;
        }

        private static string Post(string url, string token, string payload)
        {
            var request = (HttpWebRequest)WebRequest.Create(url);
            request.Method = "POST";
            request.ContentType = "application/json";
            request.Headers.Add("Authorization", "Bearer " + token);
            request.Timeout = 5000;
            byte[] body = Encoding.UTF8.GetBytes(payload);
            request.ContentLength = body.Length;
            using (Stream stream = request.GetRequestStream())
            {
                stream.Write(body, 0, body.Length);
            }
            using (var response = (HttpWebResponse)request.GetResponse())
            using (var reader = new StreamReader(response.GetResponseStream(), Encoding.UTF8))
            {
                return reader.ReadToEnd();
            }
        }

        private static string Quote(string value)
        {
            if (value == null)
            {
                return "null";
            }
            var builder = new StringBuilder(value.Length + 2);
            builder.Append('"');
            foreach (char character in value)
            {
                switch (character)
                {
                    case '"': builder.Append("\\\""); break;
                    case '\\': builder.Append("\\\\"); break;
                    case '\n': builder.Append("\\n"); break;
                    case '\r': builder.Append("\\r"); break;
                    case '\t': builder.Append("\\t"); break;
                    default:
                        if (character < ' ')
                        {
                            builder.Append("\\u").Append(((int)character).ToString("x4", CultureInfo.InvariantCulture));
                        }
                        else
                        {
                            builder.Append(character);
                        }
                        break;
                }
            }
            builder.Append('"');
            return builder.ToString();
        }
    }
}
