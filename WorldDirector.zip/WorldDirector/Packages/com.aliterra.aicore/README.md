# AliTerra AI World Director

## Execution model

AICore executes approved catalog prefab actions on Unity's main thread. The executor is intentionally **best effort**, not transactional: existing-root actions (`move`, `activate`, `deactivate`) can invoke trusted Unity callbacks and are not rolled back.

## Catalog callback contract

Every catalog entry declares two safeguards:

- **Callback safety** — `Autonomous safe` means `Awake`, `OnEnable`, and `OnDisable` do not modify the hierarchy, director ownership, protected scene objects, networking, economy, or gameplay state. `Manual approval only` blocks autonomous execution but remains available in Approval mode.
- **Execution guarantee** — only `Best effort` is supported. `Transaction required` rejects every mutation, preventing gameplay, economy, or other transactional prefab actions from being mistaken for atomic operations.

AICore revalidates ownership, hierarchy, bounds, and active state after callbacks. Failed spawns remove the new root and release its owned-root capacity reservation. Callback side effects outside that root cannot be automatically reversed.

## Operational guidance

- Use **Autonomous** only with entries explicitly marked `Autonomous safe` and `Best effort`.
- Use **Approval** for assets with complex lifecycle logic after reviewing the proposed action.
- Keep economic, inventory, quest, multiplayer, and irreversible gameplay behavior outside AICore prefab callbacks.
- Validate new catalog assets against hostile lifecycle callback fixtures before enabling them in production.
