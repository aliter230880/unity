"""The NPC world has to stay a world: scene, catalog and prefabs checked without Unity.

A regression in NpcWorldBuilder (a lost marker, a token written into the scene, a goal that
points at a catalog id that no longer exists) fails here in milliseconds instead of in a live
Play Mode run. Everything is parsed out of the generated files.
"""

from __future__ import annotations

import re
import unittest
from pathlib import Path

WORLD_DIR = Path(__file__).resolve().parent.parent      # AICore/WorldDirector
UNITY_PROJECT = __import__("projectroot").optional_root()
# The real project root when available; the layout guess only keeps the module
# importable in a mirror copy (the class is skipped there anyway).
REPO = UNITY_PROJECT if UNITY_PROJECT is not None else WORLD_DIR.parent.parent
WORLD = REPO / "Assets" / "AICoreWorld"
SCENE = WORLD / "NpcWorldScene.unity"
CATALOG = WORLD / "NpcWorldCatalog.asset"
PREFABS = WORLD / "Prefabs"
# The runtime exists twice: the package copy and the mirror under Assets/AICore/Runtime,
# and the two copies carry different GUIDs. Scenes and prefabs bind to the PACKAGE copy,
# so the package is the source of truth here.
PACKAGE_RUNTIME = REPO / "AICore" / "WorldDirector" / "Packages" / "com.aliterra.aicore" / "Runtime"
MIRROR_RUNTIME = REPO / "Assets" / "AICore" / "Runtime"

GUID = re.compile(r"guid:\s*([0-9a-f]{32})")


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def asset_guid(meta: Path) -> str:
    match = GUID.search(read(meta))
    if match is None:
        raise AssertionError("no guid in %s" % meta)
    return match.group(1)


def script_guid(name: str) -> str:
    for folder in (PACKAGE_RUNTIME, MIRROR_RUNTIME):
        meta = folder / (name + ".cs.meta")
        if meta.is_file():
            return asset_guid(meta)
    raise AssertionError("no script meta for %s" % name)


def catalog_entries(text: str) -> list[tuple[str, str, str]]:
    """(id, kind, prefab guid) for every catalog entry."""
    entries: list[tuple[str, str, str]] = []
    current: dict[str, str] = {}
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("- id:"):
            if current:
                entries.append((current.get("id", ""), current.get("kind", ""),
                                current.get("prefab", "")))
            current = {"id": stripped.split(":", 1)[1].strip()}
        elif stripped.startswith("kind:") and current:
            current["kind"] = stripped.split(":", 1)[1].strip()
        elif stripped.startswith("prefab:") and current:
            match = GUID.search(stripped)
            current["prefab"] = match.group(1) if match else ""
    if current:
        entries.append((current.get("id", ""), current.get("kind", ""),
                        current.get("prefab", "")))
    return entries


def prefab_by_guid() -> dict[str, Path]:
    found: dict[str, Path] = {}
    for prefab in sorted(PREFABS.glob("*.prefab")):
        meta = prefab.with_suffix(prefab.suffix + ".meta")
        if meta.is_file():
            found[asset_guid(meta)] = prefab
    return found


def field(text: str, name: str) -> str | None:
    # [ \t] rather than \s: a trailing \s* would swallow the newline and read the next field.
    match = re.search(r"^[ \t]*%s:[ \t]*(.*)$" % re.escape(name), text, re.MULTILINE)
    return match.group(1).strip() if match else None


@unittest.skipUnless(UNITY_PROJECT is not None, __import__("projectroot").REASON)
class NpcWorldAssetTests(unittest.TestCase):
    def test_assets_exist(self) -> None:
        self.assertTrue(SCENE.is_file(), "the world scene is missing: %s" % SCENE)
        self.assertTrue(CATALOG.is_file(), "the world catalog is missing: %s" % CATALOG)
        prefabs = sorted(PREFABS.glob("*.prefab"))
        self.assertGreaterEqual(len(prefabs), 3, "expected at least three npc prefabs")

    def test_scene_never_stores_a_token(self) -> None:
        self.assertIn("token:", read(SCENE), "the scene has no token field at all")
        self.assertEqual("", field(read(SCENE), "token"),
                         "a secret must never be serialised into the scene")

    def test_endpoint_is_loopback(self) -> None:
        endpoint = field(read(SCENE), "endpoint") or ""
        self.assertTrue(endpoint.startswith("http://127.0.0.1") or endpoint.startswith("http://localhost"),
                        "the brain endpoint must be loopback; found %r" % endpoint)

    def test_director_is_armed_for_the_world(self) -> None:
        text = read(SCENE)
        self.assertEqual("2", field(text, "configuredMode"), "the test bed runs in Autonomous mode")
        self.assertEqual("1", field(text, "configuredAuthority"), "the test bed has world authority")
        self.assertEqual("2", field(text, "protocolVersion"), "the world speaks protocol v2")

    def test_catalog_entries_are_unique_npc_kinds(self) -> None:
        entries = catalog_entries(read(CATALOG))
        self.assertGreaterEqual(len(entries), 3, "expected at least three catalog entries")
        ids = [entry[0] for entry in entries]
        self.assertEqual(len(ids), len(set(ids)), "catalog ids must be unique: %s" % ids)
        for identifier, kind, prefab in entries:
            self.assertTrue(identifier, "a catalog entry has no id")
            self.assertTrue(prefab, "entry %s has no prefab" % identifier)
            self.assertNotEqual("player", kind.lower(), "entry %s must not be a player" % identifier)

    def test_goal_points_at_a_catalog_entry(self) -> None:
        text = read(SCENE)
        target = field(text, "targetCatalogId") or ""
        count = field(text, "targetCount") or "0"
        self.assertTrue(target, "the director has no population target")
        self.assertTrue(count.isdigit() and int(count) > 0, "targetCount must be positive")
        ids = [entry[0] for entry in catalog_entries(read(CATALOG))]
        self.assertIn(target, ids, "targetCatalogId %r is not in the catalog %s" % (target, ids))

    def test_every_catalog_prefab_has_exactly_one_marker(self) -> None:
        marker = script_guid("WorldEntity")
        prefabs = prefab_by_guid()
        for identifier, _kind, guid in catalog_entries(read(CATALOG)):
            self.assertIn(guid, prefabs, "entry %s points at no prefab asset" % identifier)
            body = read(prefabs[guid])
            found = body.count(marker)
            self.assertEqual(1, found,
                             "prefab for %s must carry exactly one WorldEntity, found %d"
                             % (identifier, found))

    def test_scene_references_one_catalog_and_one_director(self) -> None:
        text = read(SCENE)
        self.assertEqual(1, text.count(asset_guid(CATALOG.with_suffix(CATALOG.suffix + ".meta"))),
                         "the scene must reference the catalog exactly once")
        self.assertEqual(1, text.count(script_guid("WorldDirector")),
                         "the scene must contain exactly one WorldDirector")


if __name__ == "__main__":
    unittest.main()
