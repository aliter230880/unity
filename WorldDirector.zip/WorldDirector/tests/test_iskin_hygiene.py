"""Hygiene helpers for a single living brain process. No real processes are killed."""
from __future__ import annotations

import importlib.util
import sys
import unittest
from pathlib import Path

PC = Path(__file__).resolve().parents[2] / "pc" / "iskin.py"
spec = importlib.util.spec_from_file_location("iskin_hygiene", PC)
iskin = importlib.util.module_from_spec(spec)
sys.modules["iskin_hygiene"] = iskin
spec.loader.exec_module(iskin)


BRAIN = Path(r"E:\AI\AI_folder\unity\AICore\WorldDirector\brain")


class HygieneTests(unittest.TestCase):
    def test_iskin_launch_line_is_ours(self):
        command = r"C:\Python\python.exe -u server.py --port 8765"
        self.assertTrue(iskin.command_is_our_brain(command, BRAIN, 8765))

    def test_full_path_to_our_server_is_ours(self):
        command = r'python.exe "E:\AI\AI_folder\unity\AICore\WorldDirector\brain\server.py"'
        self.assertTrue(iskin.command_is_our_brain(command, BRAIN, 8765))

    def test_foreign_server_on_another_port_is_not_ours(self):
        command = r"python.exe D:\other\brain\server.py --port 9000"
        self.assertFalse(iskin.command_is_our_brain(command, BRAIN, 8765))

    def test_unrelated_python_is_not_ours(self):
        self.assertFalse(iskin.command_is_our_brain("python.exe -m http.server 8765", BRAIN, 8765))

    def test_parse_process_payload_accepts_object_list_and_empty(self):
        self.assertEqual(iskin.parse_process_payload(""), [])
        self.assertEqual(iskin.parse_process_payload('{"pid": 4, "command": "x"}'),
                         [(4, "x")])
        self.assertEqual(iskin.parse_process_payload(
            '[{"pid": 1, "command": "a"}, {"pid": 2, "command": "b"}]'),
            [(1, "a"), (2, "b")])

    def test_extra_pids_drop_the_current_process(self):
        rows = [(11, "python -u server.py --port 8765"),
                (22, "python -m http.server")]
        found = iskin.brain_pids_from_rows(rows, BRAIN, 8765, current_pid=11)
        self.assertEqual(found, [])
        found = iskin.brain_pids_from_rows(rows, BRAIN, 8765, current_pid=99)
        self.assertEqual(found, [11])


if __name__ == "__main__":
    unittest.main()
