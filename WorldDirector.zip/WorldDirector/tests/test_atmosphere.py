"""Stage B atmosphere: day/night, lights, occupancy. No Unity, no HTTP."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "brain"))

import atmosphere  # noqa: E402


def lamp(entity_id="lamp-1", active=True, reactivatable=True, catalog="street-lamp"):
    return {"id": entity_id, "catalog_id": catalog, "kind": "light", "owned": True,
            "active": active, "reactivatable": reactivatable,
            "position": {"x": 0.0, "y": 0.0, "z": 0.0}}


LIMITS = {"min": {"x": -10.0, "y": -10.0, "z": -10.0},
          "max": {"x": 10.0, "y": 10.0, "z": 10.0}, "action_budget": 8}
CAPS = ("spawn", "move", "activate", "deactivate")


class AtmosphereUnitTests(unittest.TestCase):
    def test_phase_wraps_around_midnight(self):
        self.assertTrue(atmosphere.is_night(22.0))
        self.assertTrue(atmosphere.is_night(3.0))
        self.assertFalse(atmosphere.is_night(12.0))
        self.assertEqual(atmosphere.wrap_hour(25.5), 1.5)
        self.assertEqual(atmosphere.phase_name(20.0), "night")
        self.assertEqual(atmosphere.phase_name(6.0), "day")

    def test_light_detection_from_kind_and_catalog_id(self):
        self.assertTrue(atmosphere.looks_like_light({"kind": "light", "catalog_id": "x"}))
        self.assertTrue(atmosphere.looks_like_light({"kind": "prop", "catalog_id": "street-lamp"}))
        self.assertFalse(atmosphere.looks_like_light({"kind": "prop", "catalog_id": "crate"}))

    def test_event_hour_takes_the_last_finite_world_hour(self):
        events = [{"kind": "population.changed", "value": 1},
                  {"kind": "world.hour", "value": 21.0},
                  {"kind": "world.hour", "value": 22.5}]
        self.assertEqual(atmosphere.event_hour(events), 22.5)
        self.assertIsNone(atmosphere.event_hour([{"kind": "world.hour", "value": float("nan")}]))

    def test_night_activates_owned_inactive_lights(self):
        data = {"entities": [lamp(active=False), {"id": "crate-1", "catalog_id": "crate",
                                                  "kind": "prop", "owned": True, "active": True,
                                                  "position": {"x": 0.0, "y": 0.0, "z": 0.0}}],
                "catalog": [{"id": "street-lamp", "kind": "light"}], "limits": LIMITS}
        actions, notes, facts = atmosphere.plan(data, 22.0, CAPS, 4)
        self.assertEqual([a["type"] for a in actions], ["activate"])
        self.assertEqual(actions[0]["target_id"], "lamp-1")
        self.assertEqual(facts["atmosphere.phase"], "night")
        self.assertEqual(notes, [])

    def test_day_deactivates_owned_active_lights_and_does_not_spam(self):
        data = {"entities": [lamp(active=True), lamp("lamp-2", active=False, reactivatable=True)],
                "catalog": [{"id": "street-lamp", "kind": "light"}], "limits": LIMITS}
        actions, _, facts = atmosphere.plan(data, 12.0, CAPS, 4)
        self.assertEqual([a["target_id"] for a in actions], ["lamp-1"])
        self.assertEqual(actions[0]["type"], "deactivate")
        self.assertEqual(facts["atmosphere.phase"], "day")

    def test_no_spawn_when_catalog_has_a_lamp_but_none_are_owned(self):
        data = {"entities": [], "catalog": [{"id": "street-lamp", "kind": "light"}], "limits": LIMITS}
        actions, notes, _ = atmosphere.plan(data, 22.0, CAPS, 4)
        self.assertEqual(actions, [])
        self.assertTrue(any("owner" in note for note in notes))

    def test_missing_capability_records_facts_but_does_not_act(self):
        data = {"entities": [lamp(active=False)], "catalog": [], "limits": LIMITS}
        actions, notes, facts = atmosphere.plan(data, 22.0, ("spawn", "move"), 4)
        self.assertEqual(actions, [])
        self.assertTrue(notes)
        self.assertEqual(facts["atmosphere.phase"], "night")


if __name__ == "__main__":
    unittest.main()
