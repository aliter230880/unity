"""Tests for approval permits: operator directory, scope, expiry, single use."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

TESTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(TESTS_DIR.parent / "brain"))

import approval  # noqa: E402

SECRET = "test-secret-0123456789"
SUBJECT = "operator-test"
DIRECTORY = approval.OperatorDirectory.single(SECRET)
TOOL = "outputs.write_text"
TARGET = "D:/project/AICore/outputs/notes.txt"

ALICE_SECRET = "alice-secret-0123456789"
BOB_SECRET = "bobby-secret-0123456789"


def two_operators():
    directory = approval.OperatorDirectory()
    directory.add("alice", ALICE_SECRET)
    directory.add("bob", BOB_SECRET)
    return directory


def issue(tool=TOOL, target=TARGET, operator=SUBJECT, secret=SECRET, directory=DIRECTORY, **kwargs):
    """Issue through the module, so each test stays about one thing."""
    return approval.issue(directory, operator, secret, tool, target, **kwargs)


class IssueTests(unittest.TestCase):
    def test_issue_and_verify_roundtrip(self):
        permit = issue()
        payload = approval.verify(DIRECTORY, permit["token"], TOOL, TARGET)
        self.assertEqual(payload["tool"], TOOL)
        self.assertEqual(payload["target"], approval.target_digest(TARGET))

    def test_default_ttl_is_applied(self):
        self.assertEqual(issue()["ttl_seconds"], approval.DEFAULT_TTL_SECONDS)

    def test_ttl_is_bounded(self):
        for bad in (0, -1, approval.MAX_TTL_SECONDS + 1):
            with self.assertRaises(approval.ApprovalError):
                issue(ttl_seconds=bad)
        self.assertTrue(issue(ttl_seconds=approval.MAX_TTL_SECONDS)["token"])

    def test_ttl_must_be_an_integer(self):
        with self.assertRaises(approval.ApprovalError):
            issue(ttl_seconds=True)

    def test_a_wrong_secret_cannot_issue(self):
        with self.assertRaises(approval.ApprovalError) as caught:
            issue(secret="not-the-secret-0123456789")
        self.assertIn("operator secret", str(caught.exception))

    def test_a_brain_with_no_secret_cannot_issue(self):
        empty = approval.OperatorDirectory.single("")
        with self.assertRaises(approval.ApprovalError):
            issue(directory=empty)
        with self.assertRaises(approval.ApprovalError):
            issue(directory=None)


class SubjectTests(unittest.TestCase):
    def test_a_permit_must_say_who_asked(self):
        with self.assertRaises(approval.ApprovalError) as caught:
            approval.issue(DIRECTORY, "", SECRET, TOOL, TARGET)
        self.assertIn("operator", str(caught.exception))

    def test_an_overlong_operator_is_refused(self):
        with self.assertRaises(approval.ApprovalError):
            approval.issue(DIRECTORY, "x" * (approval.MAX_SUBJECT_LENGTH + 1), SECRET, TOOL, TARGET)

    def test_the_operator_travels_in_the_permit(self):
        permit = issue(operator="operator-7")
        self.assertEqual(permit["subject"], "operator-7")
        self.assertEqual(approval.verify(DIRECTORY, permit["token"], TOOL, TARGET)["sub"], "operator-7")

    def test_the_operator_is_trimmed(self):
        self.assertEqual(issue(operator="  operator-9  ")["subject"], "operator-9")


class OperatorDirectoryTests(unittest.TestCase):
    def test_each_operator_signs_with_its_own_secret(self):
        directory = two_operators()
        permit = approval.issue(directory, "alice", ALICE_SECRET, TOOL, TARGET)
        self.assertEqual(approval.verify(directory, permit["token"], TOOL, TARGET)["sub"], "alice")

    def test_an_operator_cannot_sign_with_someone_elses_secret(self):
        directory = two_operators()
        with self.assertRaises(approval.ApprovalError) as caught:
            approval.issue(directory, "bob", ALICE_SECRET, TOOL, TARGET)
        self.assertIn("operator secret", str(caught.exception))

    def test_an_unknown_operator_cannot_issue(self):
        directory = two_operators()
        with self.assertRaises(approval.ApprovalError):
            approval.issue(directory, "carol", "carol-secret-0123456789", TOOL, TARGET)

    def test_a_permit_from_an_unknown_operator_is_refused(self):
        directory = two_operators()
        foreign = approval.issue(DIRECTORY, SUBJECT, SECRET, TOOL, TARGET)
        with self.assertRaises(approval.ApprovalError) as caught:
            approval.verify(directory, foreign["token"], TOOL, TARGET)
        self.assertIn("does not know", str(caught.exception))

    def test_two_operators_do_not_interchange_their_permits(self):
        directory = two_operators()
        permit = approval.issue(directory, "alice", ALICE_SECRET, TOOL, TARGET)
        wrong = approval.OperatorDirectory()
        wrong.add("alice", BOB_SECRET)
        with self.assertRaises(approval.ApprovalError) as caught:
            approval.verify(wrong, permit["token"], TOOL, TARGET)
        self.assertIn("signature", str(caught.exception))

    def test_parse_reads_a_configuration_string(self):
        directory = approval.OperatorDirectory.parse("alice:%s, bob:%s" % (ALICE_SECRET, BOB_SECRET))
        self.assertEqual(directory.names(), ["alice", "bob"])
        self.assertTrue(directory.authorises("bob", BOB_SECRET))

    def test_parse_returns_none_for_an_empty_value(self):
        self.assertIsNone(approval.OperatorDirectory.parse(""))
        self.assertIsNone(approval.OperatorDirectory.parse(None))

    def test_add_validates_the_secret(self):
        directory = approval.OperatorDirectory()
        for bad in ("short", "", "x" * 4097, "with space 0123456789"):
            with self.assertRaises(approval.ApprovalError):
                directory.add("someone", bad)

    def test_add_rejects_a_duplicate_name(self):
        directory = two_operators()
        with self.assertRaises(approval.ApprovalError):
            directory.add("alice", "another-secret-0123456789")


class VerifyTests(unittest.TestCase):
    def setUp(self):
        self.permit = issue()["token"]

    def test_a_permit_for_another_tool_is_refused(self):
        with self.assertRaises(approval.ApprovalError) as caught:
            approval.verify(DIRECTORY, self.permit, "outputs.revert", TARGET)
        self.assertIn("was issued for", str(caught.exception))

    def test_a_permit_for_another_target_is_refused(self):
        with self.assertRaises(approval.ApprovalError) as caught:
            approval.verify(DIRECTORY, self.permit, TOOL, "D:/project/AICore/outputs/other.txt")
        self.assertIn("different target", str(caught.exception))

    def test_an_expired_permit_is_refused(self):
        token = issue(ttl_seconds=1, now=1000)["token"]
        approval.verify(DIRECTORY, token, TOOL, TARGET, now=1000)
        with self.assertRaises(approval.ApprovalError) as caught:
            approval.verify(DIRECTORY, token, TOOL, TARGET, now=1000 + 2 + approval.CLOCK_SKEW_SECONDS + 1)
        self.assertIn("expired", str(caught.exception))

    def test_clock_skew_is_tolerated(self):
        token = issue(ttl_seconds=10, now=1000)["token"]
        approval.verify(DIRECTORY, token, TOOL, TARGET, now=1000 + 10 + approval.CLOCK_SKEW_SECONDS)

    def test_a_tampered_payload_is_refused(self):
        _head, _dot, signature = self.permit.partition(".")
        forged = approval._b64e(b'{"v":1,"tool":"x","target":"y","nonce":"n","sub":"s","iat":1,"exp":9999999999}')
        with self.assertRaises(approval.ApprovalError) as caught:
            approval.verify(DIRECTORY, forged + "." + signature, TOOL, TARGET)
        self.assertIn("signature", str(caught.exception))

    def test_a_tampered_signature_is_refused(self):
        with self.assertRaises(approval.ApprovalError) as caught:
            approval.verify(DIRECTORY, self.permit[:-4] + "0000", TOOL, TARGET)
        self.assertIn("signature", str(caught.exception))

    def test_another_secret_cannot_verify(self):
        other = approval.OperatorDirectory.single("another-secret-0123456789")
        with self.assertRaises(approval.ApprovalError):
            approval.verify(other, self.permit, TOOL, TARGET)

    def test_malformed_tokens_are_refused(self):
        for bad in ("", "   ", "no-dot", "a.b.c", "!!!.???"):
            with self.assertRaises(approval.ApprovalError):
                approval.verify(DIRECTORY, bad, TOOL, TARGET)

    def test_a_missing_configuration_is_refused(self):
        with self.assertRaises(approval.ApprovalError) as caught:
            approval.verify(None, self.permit, TOOL, TARGET)
        self.assertIn("not configured", str(caught.exception))

    def test_the_token_is_not_the_secret(self):
        self.assertNotIn(SECRET, self.permit)


if __name__ == "__main__":
    unittest.main()
