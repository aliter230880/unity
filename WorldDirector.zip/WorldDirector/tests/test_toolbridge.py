"""Tests for the HTTP tool bridge (brain/server.py + brain/tools.py).

Run: python tests/test_toolbridge.py
"""
from __future__ import annotations

import json
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from pathlib import Path

TESTS_DIR = Path(__file__).resolve().parent
BRAIN_DIR = TESTS_DIR.parent / "brain"
sys.path.insert(0, str(BRAIN_DIR))

import server  # noqa: E402
import tools  # noqa: E402

TOKEN = "test-token-0123456789"


class BridgeTestCase(unittest.TestCase):
    """Runs a real brain on an ephemeral loopback port and talks to it over HTTP."""

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.root = Path(self._tmp.name)
        self.project = self.root / "Project"
        (self.project / "Assets").mkdir(parents=True)
        (self.project / "AICore" / "outputs" / "scene").mkdir(parents=True)
        self.db = self.root / "brain.sqlite3"
        self.brain = server.Brain(self.db)
        self.addCleanup(self.brain.close)
        self.server = server.make_server(self.brain, TOKEN, 0,
                                         project_root=self.project, scope_db=self.db)
        self.addCleanup(self.server.server_close)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.addCleanup(self.server.shutdown)
        self.base = "http://127.0.0.1:%d" % self.server.server_address[1]

    def get(self, path, token=TOKEN, origin=None):
        request = urllib.request.Request(self.base + path)
        if token is not None:
            request.add_header("Authorization", "Bearer " + token)
        if origin:
            request.add_header("Origin", origin)
        return self._send(request)

    def post(self, path, payload, token=TOKEN, content_type="application/json"):
        body = payload if isinstance(payload, bytes) else json.dumps(payload).encode("utf-8")
        request = urllib.request.Request(self.base + path, data=body, method="POST")
        request.add_header("Content-Type", content_type)
        if token is not None:
            request.add_header("Authorization", "Bearer " + token)
        return self._send(request)

    @staticmethod
    def _send(request):
        try:
            with urllib.request.urlopen(request, timeout=5) as response:
                return response.status, json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as error:
            return error.code, json.loads(error.read().decode("utf-8"))


class CatalogueTests(BridgeTestCase):
    def test_catalogue_requires_a_token(self):
        status, _ = self.get("/v1/tools", token=None)
        self.assertEqual(status, 401)

    def test_browser_origin_is_refused(self):
        status, _ = self.get("/v1/tools", origin="http://evil.example")
        self.assertEqual(status, 403)

    def test_catalogue_lists_the_tools_with_their_categories(self):
        status, body = self.get("/v1/tools")
        self.assertEqual(status, 200)
        self.assertTrue(body["read_only"])
        names = [item["name"] for item in body["tools"]]
        self.assertIn("unity.scene.report", names)
        for item in body["tools"]:
            self.assertIn(item["category"], ("read", "write"), item["name"])

    def test_unknown_endpoint_is_404(self):
        self.assertEqual(self.get("/v1/nope")[0], 404)

    def test_existing_endpoints_still_work(self):
        status, body = self.get("/health")
        self.assertEqual(status, 200)
        self.assertEqual(body["status"], "ok")


class ToolCallTests(BridgeTestCase):
    def test_unknown_tool_is_reported_not_thrown(self):
        status, body = self.post("/v1/tools/call", {"tool": "no.such.tool"})
        self.assertEqual(status, 200)
        self.assertFalse(body["ok"])
        self.assertIn("unknown tool", body["error"])

    def test_reading_the_brain_database_works(self):
        status, body = self.post("/v1/tools/call", {"tool": "brain.knowledge.facts", "params": {}})
        self.assertEqual(status, 200)
        self.assertTrue(body["ok"], body)
        self.assertTrue(body["read_only"])
        self.assertEqual(Path(body["data"]["database"]).resolve(), self.db.resolve())

    def test_caller_cannot_escape_the_configured_root(self):
        outside = self.root / "elsewhere.json"
        outside.write_text("{}", encoding="utf-8")
        status, body = self.post("/v1/tools/call",
                                 {"tool": "unity.scene.report", "params": {"report": str(outside)}})
        self.assertEqual(status, 200)
        self.assertFalse(body["ok"])
        self.assertIn("configured project root", body["error"])

    def test_paths_inside_the_root_are_accepted(self):
        report = self.project / "AICore" / "outputs" / "scene" / "scene-report.json"
        report.write_text(json.dumps({"findings": [], "summary": {}}), encoding="utf-8")
        status, body = self.post("/v1/tools/call",
                                 {"tool": "unity.scene.report",
                                  "params": {"report": "AICore/outputs/scene/scene-report.json"}})
        self.assertEqual(status, 200)
        self.assertTrue(body["ok"], body)
        self.assertEqual(body["data"]["count"], 0)

    def test_project_root_is_forced_to_the_configured_value(self):
        other = self.root / "Other"
        (other / "Assets").mkdir(parents=True)
        status, body = self.post("/v1/tools/call",
                                 {"tool": "unity.project.inventory",
                                  "params": {"project_root": str(other)}})
        self.assertEqual(status, 200)
        self.assertTrue(body["ok"], body)
        self.assertEqual(Path(body["data"]["project_root"]).resolve(), self.project.resolve())

    def test_database_path_is_forced_to_the_configured_value(self):
        other = self.root / "other.sqlite3"
        status, body = self.post("/v1/tools/call",
                                 {"tool": "brain.knowledge.facts", "params": {"db": str(other)}})
        self.assertEqual(status, 200)
        self.assertTrue(body["ok"], body)
        self.assertEqual(Path(body["data"]["database"]).resolve(), self.db.resolve())

    def test_unknown_parameters_are_rejected(self):
        status, body = self.post("/v1/tools/call",
                                 {"tool": "brain.knowledge.facts", "params": {"nope": 1}})
        self.assertEqual(status, 200)
        self.assertFalse(body["ok"])
        self.assertIn("unknown parameter", body["error"])

    def test_unknown_call_fields_are_rejected(self):
        status, _ = self.post("/v1/tools/call",
                              {"tool": "brain.knowledge.facts", "extra": 1})
        self.assertEqual(status, 400)

    def test_missing_tool_name_is_rejected(self):
        self.assertEqual(self.post("/v1/tools/call", {"params": {}})[0], 400)

    def test_broken_json_is_a_400(self):
        self.assertEqual(self.post("/v1/tools/call", b"{not json")[0], 400)

    def test_wrong_content_type_is_415(self):
        status, _ = self.post("/v1/tools/call", {"tool": "brain.knowledge.facts"},
                              content_type="text/plain")
        self.assertEqual(status, 415)

    def test_console_tail_is_callable_without_a_project_root(self):
        status, body = self.post("/v1/tools/call",
                                 {"tool": "unity.console.tail", "params": {"lines": 1}})
        self.assertIn(status, (200,))
        # The machine may have no editor console at all; either answer is fine as long as
        # the bridge does not refuse the tool for lacking a project root.
        if not body["ok"]:
            self.assertIn("console", body["error"].lower())


class ConfinementTests(unittest.TestCase):
    def test_tools_needing_a_project_path_are_refused_without_a_configured_root(self):
        result = tools.execute_scoped("unity.project.inventory", {"project_root": "."}, confine=True)
        self.assertFalse(result.ok)
        self.assertIn("--project", result.error)

    def test_database_only_tools_are_not_refused_for_lacking_a_root(self):
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp) / "brain.sqlite3"
            db.touch()
            result = tools.execute_scoped("brain.knowledge.facts", {}, db_path=db, confine=True)
        self.assertTrue(result.ok, result.error)

    def test_cli_execution_is_not_confined(self):
        with tempfile.TemporaryDirectory() as tmp:
            project = Path(tmp)
            (project / "Assets").mkdir()
            result = tools.execute("unity.project.inventory", {"project_root": str(project)})
        self.assertTrue(result.ok, result.error)

    def test_relative_report_path_resolves_inside_the_root(self):
        with tempfile.TemporaryDirectory() as tmp:
            project = Path(tmp)
            target = project / "AICore" / "outputs" / "scene"
            target.mkdir(parents=True)
            (target / "scene-report.json").write_text(json.dumps({"findings": [], "summary": {}}),
                                                      encoding="utf-8")
            result = tools.execute_scoped("unity.scene.report",
                                          {"report": "AICore/outputs/scene/scene-report.json"},
                                          project_root=project, confine=True)
        self.assertTrue(result.ok, result.error)
        self.assertEqual(result.data["count"], 0)


if __name__ == "__main__":
    unittest.main()
