"""Tests for the auto-approval policy: when may the brain act without a person?"""
from __future__ import annotations

import sys
import tempfile
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "brain"))

import policy  # noqa: E402

PLAN = {"plan_id": "fix_1", "fixes": [{"id": "fix.a", "risk": "low"}]}
MEDIUM = {"plan_id": "fix_2", "fixes": [{"id": "fix.b", "risk": "medium"}]}
OBSERVED = {"objects": 3, "observed": 1}
UNOBSERVED = {"objects": 3, "observed": 0}


class PolicyTests(unittest.TestCase):
    def test_nothing_is_automatic_unless_it_is_switched_on(self):
        verdict = policy.AutoApprovalPolicy().evaluate(PLAN)
        self.assertFalse(verdict["allowed"])
        self.assertIn("switched off", " ".join(verdict["reasons"]))

    def test_a_low_risk_plan_is_allowed_when_enabled(self):
        verdict = policy.AutoApprovalPolicy(enabled=True).evaluate(PLAN, map_context=OBSERVED)
        self.assertTrue(verdict["allowed"], verdict)
        self.assertEqual(verdict["reasons"], [])

    def test_a_riskier_plan_is_refused_with_a_reason(self):
        verdict = policy.AutoApprovalPolicy(enabled=True).evaluate(MEDIUM, map_context=OBSERVED)
        self.assertFalse(verdict["allowed"])
        self.assertIn("medium", " ".join(verdict["reasons"]))

    def test_a_higher_limit_admits_more(self):
        verdict = policy.AutoApprovalPolicy(enabled=True, max_risk="medium").evaluate(
            MEDIUM, map_context=OBSERVED)
        self.assertTrue(verdict["allowed"], verdict)

    def test_an_unknown_risk_is_treated_as_the_worst(self):
        plan = {"fixes": [{"id": "fix.c"}]}
        verdict = policy.AutoApprovalPolicy(enabled=True, max_risk="high").evaluate(
            plan, map_context=OBSERVED)
        self.assertFalse(verdict["allowed"])

    def test_the_hourly_budget_stops_the_third_application(self):
        rule = policy.AutoApprovalPolicy(enabled=True, max_per_hour=2)
        self.assertTrue(rule.evaluate(PLAN, applied_recently=1, map_context=OBSERVED)["allowed"])
        self.assertFalse(rule.evaluate(PLAN, applied_recently=2, map_context=OBSERVED)["allowed"])

    def test_an_empty_plan_is_refused(self):
        verdict = policy.AutoApprovalPolicy(enabled=True).evaluate({"fixes": []},
                                                                   map_context=OBSERVED)
        self.assertFalse(verdict["allowed"])
        self.assertIn("nothing to apply", " ".join(verdict["reasons"]))

    def test_a_scene_with_nothing_observed_is_refused(self):
        verdict = policy.AutoApprovalPolicy(enabled=True).evaluate(PLAN, map_context=UNOBSERVED)
        self.assertFalse(verdict["allowed"])
        self.assertIn("observable", " ".join(verdict["reasons"]))

    def test_the_observed_rule_can_be_switched_off(self):
        rule = policy.AutoApprovalPolicy(enabled=True, require_observed=False)
        self.assertTrue(rule.evaluate(PLAN, map_context=UNOBSERVED)["allowed"])

    def test_without_a_map_the_observed_rule_stays_quiet(self):
        self.assertTrue(policy.AutoApprovalPolicy(enabled=True).evaluate(PLAN)["allowed"])

    def test_a_broken_context_or_count_is_tolerated(self):
        rule = policy.AutoApprovalPolicy(enabled=True)
        self.assertTrue(rule.evaluate(PLAN, applied_recently="many", map_context={"objects": "x"})["allowed"])

    def test_the_verdict_carries_its_policy(self):
        verdict = policy.AutoApprovalPolicy(enabled=True, max_risk="low").evaluate(
            PLAN, map_context=OBSERVED)
        self.assertEqual(verdict["policy"]["max_risk"], "low")
        self.assertTrue(verdict["policy"]["enabled"])


class EnvironmentTests(unittest.TestCase):
    def test_the_default_is_off(self):
        rule = policy.AutoApprovalPolicy.from_environment({})
        self.assertFalse(rule.enabled)

    def test_it_can_be_switched_on_with_a_risk(self):
        rule = policy.AutoApprovalPolicy.from_environment(
            {"AICORE_AUTO_APPROVE": "true", "AICORE_AUTO_RISK": "medium",
             "AICORE_AUTO_PER_HOUR": "5"})
        self.assertTrue(rule.enabled)
        self.assertEqual(rule.max_risk, "medium")
        self.assertEqual(rule.max_per_hour, 5)

    def test_a_nonsense_budget_falls_back(self):
        rule = policy.AutoApprovalPolicy.from_environment(
            {"AICORE_AUTO_APPROVE": "1", "AICORE_AUTO_PER_HOUR": "many"})
        self.assertEqual(rule.max_per_hour, policy.DEFAULT_MAX_PER_HOUR)

    def test_the_observed_rule_can_be_switched_off_by_configuration(self):
        rule = policy.AutoApprovalPolicy.from_environment(
            {"AICORE_AUTO_APPROVE": "1", "AICORE_AUTO_REQUIRE_OBSERVED": "0"})
        self.assertFalse(rule.require_observed)


class AuditCountingTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.log = Path(self._tmp.name) / "aicore-writes.log"

    def _entry(self, action, seconds_ago):
        stamp = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - seconds_ago))
        return '{"action": "%s", "utc": "%s"}' % (action, stamp)

    def test_applications_within_the_hour_are_counted(self):
        self.log.write_text("\n".join([self._entry("apply-fix-plan", 60),
                                       self._entry("apply-fix-plan", 600),
                                       self._entry("apply-fix-plan", 7200),
                                       self._entry("write_text", 30)]), encoding="utf-8")
        self.assertEqual(policy.count_recent_applies(self.log), 2)

    def test_a_missing_log_counts_zero(self):
        self.assertEqual(policy.count_recent_applies(self.log), 0)

    def test_broken_lines_are_skipped(self):
        self.log.write_text("not json\n" + self._entry("apply-fix-plan", 10), encoding="utf-8")
        self.assertEqual(policy.count_recent_applies(self.log), 1)


if __name__ == "__main__":
    unittest.main()
