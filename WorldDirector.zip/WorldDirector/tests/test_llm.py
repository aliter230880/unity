"""Tests for the optional LLM planning core (brain/llm.py).

No network is ever touched: the HTTP transport is replaced by fakes, and the
integration tests attach stub planners to a real Brain over a throwaway
database. The default configuration must stay "off" so existing behaviour is
unchanged unless AICORE_LLM is explicitly set.
"""

from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

TESTS_DIR = Path(__file__).resolve().parent
BRAIN = TESTS_DIR.parent / "brain"
sys.path.insert(0, str(BRAIN))

import llm as llm_core  # noqa: E402
import server  # noqa: E402


def v2(**changes):
    value = {
        "protocol_version": 2, "world_id": "world-1", "session_id": "session-1",
        "observation_id": "observation-1", "goal": "Maintain the crate population.",
        "target_catalog_id": "crate", "target_count": 3,
        "anchor": {"x": 0.0, "y": 0.0, "z": 0.0},
        "allow_mutations": True, "entities_truncated": False,
        "limits": {"min": {"x": -100.0, "y": -100.0, "z": -100.0},
                   "max": {"x": 100.0, "y": 100.0, "z": 100.0},
                   "max_owned_entities": 100, "owned_entity_count": 1, "action_budget": 8},
        "entities": [{"id": "11111111-1111-1111-1111-111111111111", "catalog_id": "crate",
                      "kind": "prop", "position": {"x": 1.0, "y": 0.0, "z": 1.0},
                      "owned": True, "active": True, "reactivatable": False}],
        "catalog": [{"id": "crate", "kind": "prop"}, {"id": "barrel", "kind": "prop"}],
        "results": [], "events": [], "feedback": [],
        "goals": [], "knowledge_updates": [], "relations": [],
        "capabilities": {"action_types": ["spawn", "move", "activate", "deactivate"]},
        "allow_reactivation": True,
    }
    value.update(changes)
    return value


GOALS = [{"goal_id": "g1", "catalog_id": "crate", "target_count": 3,
          "priority": 1, "status": "active"}]


class LLMEnvMixin(unittest.TestCase):
    def setUp(self):
        self._saved = {key: value for key, value in os.environ.items() if key.startswith("AICORE_LLM")}
        for key in self._saved:
            del os.environ[key]

    def tearDown(self):
        os.environ.update(self._saved)
        for key in [k for k in os.environ if k.startswith("AICORE_LLM") and k not in self._saved]:
            del os.environ[key]


class ConfigTests(LLMEnvMixin):
    def test_disabled_by_default(self):
        self.assertEqual(llm_core.LLMConfig.from_env().backend, "off")

    def test_ollama_defaults(self):
        os.environ["AICORE_LLM"] = "ollama"
        os.environ["AICORE_LLM_MODEL"] = "qwen2.5:14b"
        config = llm_core.LLMConfig.from_env()
        self.assertEqual((config.backend, config.model), ("ollama", "qwen2.5:14b"))
        self.assertEqual(config.url, "http://127.0.0.1:11434")

    def test_openai_requires_url_and_key(self):
        os.environ["AICORE_LLM"] = "openai"
        os.environ["AICORE_LLM_MODEL"] = "deepseek-chat"
        with self.assertRaises(ValueError):
            llm_core.LLMConfig.from_env()
        os.environ["AICORE_LLM_URL"] = "https://api.deepseek.com/v1"
        with self.assertRaises(ValueError):
            llm_core.LLMConfig.from_env()
        os.environ["AICORE_LLM_API_KEY"] = "sk-test"
        self.assertEqual(llm_core.LLMConfig.from_env().backend, "openai")

    def test_unknown_backend_is_rejected(self):
        os.environ["AICORE_LLM"] = "skynet"
        with self.assertRaises(ValueError):
            llm_core.LLMConfig.from_env()


class PayloadTests(unittest.TestCase):
    def make(self, backend):
        return llm_core.LLMPlanner(llm_core.LLMConfig(
            backend, "http://unit", "model-x", "key-x", 5, 321, False))

    def test_ollama_payload_is_bounded(self):
        payload = self.make("ollama")._payload([{"role": "user", "content": "hi"}])
        self.assertIs(payload["stream"], False)
        self.assertEqual(payload["options"]["num_predict"], 321)
        self.assertEqual(payload["model"], "model-x")

    def test_openai_payload_is_bounded(self):
        payload = self.make("openai")._payload([{"role": "user", "content": "hi"}])
        self.assertEqual(payload["max_tokens"], 321)
        self.assertNotIn("stream", payload)

    def test_content_extraction_both_backends(self):
        planner = self.make("ollama")
        self.assertEqual(planner._content({"message": {"content": "[]"}}), "[]")
        planner = self.make("openai")
        self.assertEqual(planner._content({"choices": [{"message": {"content": "[]"}}]}), "[]")
        self.assertIsNone(planner._content({"choices": []}))

    def test_world_summary_is_compact_and_bounded(self):
        planner = self.make("ollama")
        summary = planner.summarize_world(v2(), GOALS)
        self.assertEqual(summary["goals"][0]["current_count"], 1)
        self.assertLessEqual(len(summary["owned_entities"]), llm_core.MAX_ENTITIES_IN_PROMPT)
        self.assertEqual(summary["max_actions"], 8)


class ParseTests(unittest.TestCase):
    def test_plain_array(self):
        self.assertEqual(llm_core.parse_json_array('[{"type":"spawn"}]'), [{"type": "spawn"}])

    def test_markdown_fence(self):
        text = "```json\n[{\"type\": \"spawn\"}]\n```"
        self.assertEqual(llm_core.parse_json_array(text), [{"type": "spawn"}])

    def test_prose_around_array(self):
        text = 'Here is my plan: [{"type": "move"}] hope it helps'
        self.assertEqual(llm_core.parse_json_array(text), [{"type": "move"}])

    def test_object_and_garbage_are_rejected(self):
        self.assertIsNone(llm_core.parse_json_array('{"type": "spawn"}'))
        self.assertIsNone(llm_core.parse_json_array("no plan today"))
        self.assertIsNone(llm_core.parse_json_array(None))


class ValidationTests(unittest.TestCase):
    CAPS = ["spawn", "move", "activate", "deactivate"]

    def validate(self, actions, data=None):
        return llm_core.validate_actions(actions, data or v2(), GOALS, self.CAPS)

    def test_valid_spawn_gets_the_llm_strategy(self):
        actions, warnings = self.validate(
            [{"type": "spawn", "catalog_id": "crate", "target_id": "",
              "position": {"x": 5.0, "y": 0.0, "z": 5.0}, "reason": "grow", "goal_id": "g1"}])
        self.assertEqual(len(actions), 1)
        self.assertEqual(actions[0]["_strategy"], "llm")
        self.assertEqual(actions[0]["goal_id"], "g1")
        self.assertEqual(warnings, [])

    def test_out_of_bounds_and_unknown_catalog_are_dropped(self):
        actions, warnings = self.validate([
            {"type": "spawn", "catalog_id": "crate", "position": {"x": 500.0, "y": 0.0, "z": 0.0}},
            {"type": "spawn", "catalog_id": "nuke", "position": {"x": 0.0, "y": 0.0, "z": 0.0}},
        ])
        self.assertEqual(actions, [])
        self.assertEqual(len(warnings), 2)

    def test_spawn_with_target_is_dropped(self):
        actions, _ = self.validate(
            [{"type": "spawn", "catalog_id": "crate", "target_id": "11111111-1111-1111-1111-111111111111",
              "position": {"x": 0.0, "y": 0.0, "z": 0.0}}])
        self.assertEqual(actions, [])

    def test_move_requires_an_owned_target_inside_bounds(self):
        entity = "11111111-1111-1111-1111-111111111111"
        actions, warnings = self.validate([
            {"type": "move", "target_id": entity, "position": {"x": 2.0, "y": 0.0, "z": 2.0}},
            {"type": "move", "target_id": "not-owned", "position": {"x": 2.0, "y": 0.0, "z": 2.0}},
            {"type": "move", "target_id": entity, "position": {"x": 999.0, "y": 0.0, "z": 0.0}},
        ])
        self.assertEqual(len(actions), 1)
        self.assertEqual(len(warnings), 2)

    def test_activate_and_deactivate_state_rules(self):
        entity = "11111111-1111-1111-1111-111111111111"
        data = v2(allow_reactivation=False)
        actions, _ = self.validate(
            [{"type": "activate", "target_id": entity}], data)
        self.assertEqual(actions, [])  # permission missing
        data = v2()
        data["entities"][0]["active"] = False
        data["entities"][0]["reactivatable"] = True
        actions, _ = self.validate([{"type": "activate", "target_id": entity}], data)
        self.assertEqual(len(actions), 1)
        actions, _ = self.validate([{"type": "deactivate", "target_id": entity}], data)
        self.assertEqual(actions, [])  # already inactive

    def test_more_than_eight_actions_rejects_the_whole_plan(self):
        actions, _ = self.validate(
            [{"type": "spawn", "catalog_id": "crate", "position": {"x": 1.0, "y": 0.0, "z": 1.0}}] * 9)
        self.assertEqual(actions, [])

    def test_plan_is_cut_to_the_advertised_budget(self):
        data = v2()
        data["limits"]["action_budget"] = 2
        actions, warnings = self.validate(
            [{"type": "spawn", "catalog_id": "crate", "position": {"x": 1.0, "y": 0.0, "z": 1.0}}] * 4,
            data)
        self.assertEqual(len(actions), 2)
        self.assertTrue(any("budget" in w for w in warnings))

    def test_unknown_goal_id_is_sanitised_not_trusted(self):
        actions, _ = self.validate(
            [{"type": "spawn", "catalog_id": "crate", "goal_id": "evil",
              "position": {"x": 1.0, "y": 0.0, "z": 1.0}}])
        self.assertEqual(actions[0]["goal_id"], "")

    def test_ownership_cap_blocks_spawns(self):
        data = v2()
        data["limits"]["owned_entity_count"] = 100
        actions, _ = self.validate(
            [{"type": "spawn", "catalog_id": "crate", "position": {"x": 1.0, "y": 0.0, "z": 1.0}}],
            data)
        self.assertEqual(actions, [])


class PlannerTests(unittest.TestCase):
    def make(self, reply, allow_empty=False, backend="ollama"):
        config = llm_core.LLMConfig(backend, "http://unit", "model-x", "key-x", 5, 256, allow_empty)
        captured = []

        def transport(payload):
            captured.append(payload)
            if isinstance(reply, Exception):
                raise reply
            return ({"message": {"content": reply}} if backend == "ollama"
                    else {"choices": [{"message": {"content": reply}}]})

        return llm_core.LLMPlanner(config, transport), captured

    def test_valid_reply_becomes_a_validated_plan(self):
        reply = json.dumps([{"type": "spawn", "catalog_id": "crate",
                             "position": {"x": 3.0, "y": 0.0, "z": 3.0}, "reason": "grow"}])
        planner, captured = self.make(reply)
        actions, summary, warnings = planner.plan(v2(), GOALS, list(llm_core.CORE_ACTIONS))
        self.assertEqual(len(actions), 1)
        self.assertIn("1 action", summary)
        self.assertEqual(warnings, [])
        self.assertEqual(captured[0]["model"], "model-x")

    def test_unreachable_transport_falls_back(self):
        planner, _ = self.make(Exception("connection refused"))
        actions, summary, warnings = planner.plan(v2(), GOALS, list(llm_core.CORE_ACTIONS))
        self.assertIsNone(actions)
        self.assertTrue(any("unreachable" in w for w in warnings))

    def test_garbage_reply_falls_back(self):
        planner, _ = self.make("I am afraid I cannot do that.")
        actions, _, warnings = planner.plan(v2(), GOALS, list(llm_core.CORE_ACTIONS))
        self.assertIsNone(actions)
        self.assertTrue(any("JSON array" in w for w in warnings))

    def test_empty_plan_falls_back_unless_allowed(self):
        planner, _ = self.make("[]")
        actions, _, _ = planner.plan(v2(), GOALS, list(llm_core.CORE_ACTIONS))
        self.assertIsNone(actions)
        planner, _ = self.make("[]", allow_empty=True)
        actions, summary, _ = planner.plan(v2(), GOALS, list(llm_core.CORE_ACTIONS))
        self.assertEqual(actions, [])
        self.assertIn("no action", summary)


class StubPlanner:
    """Quacks like LLMPlanner; used to wire the planner into a real Brain."""

    def __init__(self, result):
        self.result = result
        self.calls = 0

    def describe(self):
        return "stub"

    def plan(self, data, goals, capabilities, knowledge=None):
        self.calls += 1
        return self.result


class BrainIntegrationTests(LLMEnvMixin):
    def setUp(self):
        super().setUp()
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.brain = server.Brain(Path(self._tmp.name) / "brain.sqlite3")
        self.addCleanup(self.brain.close)

    def test_llm_is_absent_by_default(self):
        self.assertIsNone(self.brain.llm)

    def test_heuristic_planner_still_works(self):
        response = self.brain.tick_v2(v2(goals=[dict(g, status="active") for g in GOALS]))
        self.assertEqual(len(response["actions"]), 2)  # target 3, one already active
        self.assertEqual(response["source"], "multi_objective_v2")

    def test_stub_planner_replaces_the_plan_when_valid(self):
        stub = StubPlanner(([{"type": "spawn", "catalog_id": "crate", "target_id": "",
                              "position": {"x": 7.0, "y": 0.0, "z": 7.0},
                              "reason": "stub", "goal_id": "g1", "_strategy": "llm"}],
                            "stub planned one spawn.", []))
        self.brain.llm = stub
        response = self.brain.tick_v2(v2(goals=[dict(g, status="active") for g in GOALS]))
        self.assertEqual(len(response["actions"]), 1)
        self.assertIn("[stub]", response["summary"])
        row = self.brain.db.execute(
            "SELECT strategy FROM actions WHERE type='spawn'").fetchone()
        self.assertEqual(row["strategy"], "llm")

    def test_stub_failure_falls_back_to_the_heuristic(self):
        self.brain.llm = StubPlanner((None, "", ["stub is down."]))
        response = self.brain.tick_v2(v2(goals=[dict(g, status="active") for g in GOALS]))
        self.assertEqual(len(response["actions"]), 2)
        self.assertTrue(any("deterministic planner used" in w for w in response["warnings"]))

    def test_bad_llm_environment_fails_startup_loudly(self):
        os.environ["AICORE_LLM"] = "wat"
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(SystemExit):
                server.Brain(Path(tmp) / "b.sqlite3")


if __name__ == "__main__":
    unittest.main()
