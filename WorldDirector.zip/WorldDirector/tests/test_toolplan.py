"""Tests for deterministic planner tool selection (brain/toolplan.py)."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

TESTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(TESTS_DIR.parent / "brain"))

import toolplan  # noqa: E402

ALL = {"project.diagnostics", "unity.scene.report", "unity.console.tail",
       "unity.project.inventory", "brain.knowledge.facts", "outputs.write_text"}


def names(result):
    return [item["tool"] for item in result["recommended"]]


class SelectionTests(unittest.TestCase):
    def test_an_empty_state_still_recommends_something_safe(self):
        result = toolplan.recommend({}, ALL)
        self.assertIn("brain.knowledge.facts", names(result))
        for item in result["recommended"]:
            self.assertTrue(item["reason"])

    def test_errors_promote_diagnostics_to_the_top(self):
        result = toolplan.recommend({"findings": [{"severity": "critical"}], "scene_report_age": 1}, ALL)
        self.assertEqual(names(result)[0], "project.diagnostics")
        self.assertIn("critical", result["recommended"][0]["reason"])

    def test_a_missing_scene_report_is_recommended(self):
        result = toolplan.recommend({"scene_report_age": None}, ALL)
        self.assertIn("unity.scene.report", names(result))

    def test_a_stale_scene_report_is_recommended(self):
        result = toolplan.recommend({"scene_report_age": 900}, ALL)
        entry = next(item for item in result["recommended"] if item["tool"] == "unity.scene.report")
        self.assertIn("900", entry["reason"])

    def test_a_fresh_scene_report_is_not_recommended(self):
        result = toolplan.recommend({"scene_report_age": 10}, ALL)
        self.assertNotIn("unity.scene.report", names(result))

    def test_console_errors_pull_in_the_console_tool(self):
        result = toolplan.recommend({"console_errors": 4}, ALL)
        entry = next(item for item in result["recommended"] if item["tool"] == "unity.console.tail")
        self.assertEqual(entry["params"], {"level": "error"})

    def test_no_console_errors_means_no_console_tool(self):
        self.assertNotIn("unity.console.tail", names(toolplan.recommend({"console_errors": 0}, ALL)))

    def test_budget_is_respected(self):
        result = toolplan.recommend({"findings": [{"severity": "error"}], "console_errors": 3}, ALL, budget=2)
        self.assertEqual(len(result["recommended"]), 2)
        self.assertEqual(result["budget"], 2)

    def test_budget_is_bounded(self):
        for bad in (0, -3, toolplan.MAX_BUDGET + 1):
            with self.assertRaises(ValueError):
                toolplan.recommend({}, ALL, budget=bad)

    def test_only_tools_that_exist_are_proposed(self):
        result = toolplan.recommend({"findings": [{"severity": "error"}], "scene_report_age": 900},
                                    {"brain.knowledge.facts"})
        self.assertEqual(names(result), ["brain.knowledge.facts"])

    def test_nothing_is_proposed_twice(self):
        result = toolplan.recommend({"findings": [{"severity": "critical"}], "console_errors": 2}, ALL)
        self.assertEqual(len(names(result)), len(set(names(result))))

    def test_the_decision_is_reproducible(self):
        state = {"findings": [{"severity": "error"}], "console_errors": 2, "scene_report_age": 900}
        self.assertEqual(toolplan.recommend(state, ALL), toolplan.recommend(state, ALL))

    def test_the_basis_is_reported(self):
        result = toolplan.recommend({"findings": [{"severity": "warning"}], "console_errors": 1}, ALL)
        self.assertEqual(result["based_on"]["findings"], 1)
        self.assertEqual(result["based_on"]["severities"], ["warning"])

    def test_write_tools_are_never_selected(self):
        result = toolplan.recommend({"findings": [{"severity": "critical"}], "console_errors": 9},
                                    ALL, budget=toolplan.MAX_BUDGET)
        self.assertNotIn("outputs.write_text", names(result))


if __name__ == "__main__":
    unittest.main()
