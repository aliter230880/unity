"""Tests for the phase 2 read-only toolbox (brain/tools.py and brain/toolbox.py).

Run: python tests/test_tools.py
"""
from __future__ import annotations

import json
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

TESTS_DIR = Path(__file__).resolve().parent
BRAIN_DIR = TESTS_DIR.parent / "brain"
sys.path.insert(0, str(BRAIN_DIR))

import diagnostics  # noqa: E402
import tools  # noqa: E402

CLI = BRAIN_DIR / "toolbox.py"


class ToolContractTests(unittest.TestCase):
    def test_every_spec_is_well_formed(self):
        names = [spec.name for spec in tools.specs()]
        self.assertEqual(len(names), len(set(names)), "tool names must be unique")
        for spec in tools.specs():
            self.assertIn(spec.category, tools.CATEGORIES)
            self.assertTrue(spec.summary, spec.name)
            self.assertTrue(spec.returns, spec.name)
            seen = set()
            for parameter in spec.parameters:
                self.assertIn(parameter.kind, tools.KINDS, parameter.name)
                self.assertNotIn(parameter.name, seen, parameter.name)
                seen.add(parameter.name)
                if parameter.required:
                    self.assertIsNone(parameter.default, parameter.name)

    def test_schema_is_json_serialisable(self):
        payload = json.dumps(tools.schema())
        self.assertIn("unity.console.tail", payload)

    def test_every_tool_declares_a_known_category(self):
        for spec in tools.specs():
            self.assertIn(spec.category, tools.CATEGORIES, spec.name)

    def test_write_tools_declare_their_requirement(self):
        write_tools = [spec for spec in tools.specs() if spec.category == tools.WRITE]
        self.assertTrue(write_tools, "phase 3 registers at least one write tool")
        for spec in write_tools:
            self.assertTrue(spec.requires, spec.name)

    def test_file_write_tools_are_reversible(self):
        for name in ("outputs.write_text", "outputs.revert"):
            self.assertTrue(tools.get(name).reversible, name)

    def test_revocation_is_declared_irreversible(self):
        self.assertFalse(tools.get("brain.approval.revoke").reversible)

    def test_expected_tools_are_present(self):
        names = {spec.name for spec in tools.specs()}
        for expected in ("unity.console.tail", "unity.project.inventory",
                         "project.diagnostics", "brain.knowledge.facts",
                         "brain.observations.recent", "unity.scene.report"):
            self.assertIn(expected, names)

    def test_get_rejects_unknown_tool(self):
        with self.assertRaises(tools.ToolError):
            tools.get("no.such.tool")


class ParameterValidationTests(unittest.TestCase):
    def _spec(self):
        return tools.ToolSpec(
            name="test.spec", category=tools.READ, summary="s", returns="r",
            parameters=(
                tools.Parameter("text", tools.STRING),
                tools.Parameter("count", tools.INTEGER, required=False, default=3),
                tools.Parameter("flag", tools.BOOLEAN, required=False, default=False),
                tools.Parameter("items", tools.STRING_LIST, required=False, default=None),
            ))

    def test_unknown_parameter_is_rejected(self):
        with self.assertRaises(tools.ToolError):
            tools.validate_parameters(self._spec(), {"text": "a", "nope": "1"})

    def test_missing_required_parameter_is_rejected(self):
        with self.assertRaises(tools.ToolError):
            tools.validate_parameters(self._spec(), {})

    def test_defaults_are_applied(self):
        cleaned = tools.validate_parameters(self._spec(), {"text": "a"})
        self.assertEqual(cleaned["count"], 3)
        self.assertFalse(cleaned["flag"])
        self.assertIsNone(cleaned["items"])

    def test_integers_and_booleans_are_coerced(self):
        cleaned = tools.validate_parameters(self._spec(), {"text": "a", "count": "7", "flag": "yes"})
        self.assertEqual(cleaned["count"], 7)
        self.assertIs(cleaned["flag"], True)

    def test_string_lists_split_on_commas(self):
        cleaned = tools.validate_parameters(self._spec(), {"text": "a", "items": "x, y ,z"})
        self.assertEqual(cleaned["items"], ["x", "y", "z"])

    def test_bad_boolean_is_rejected(self):
        with self.assertRaises(tools.ToolError):
            tools.validate_parameters(self._spec(), {"text": "a", "flag": "maybe"})


class DispatchTests(unittest.TestCase):
    def test_unknown_tool_returns_a_failed_result_not_an_exception(self):
        result = tools.execute("no.such.tool")
        self.assertFalse(result.ok)
        self.assertIn("unknown tool", result.error)

    def test_write_tools_are_refused_in_phase_two(self):
        fake = tools.ToolSpec(name="fake.write", category=tools.WRITE, summary="fake", returns="x")
        with mock.patch.object(tools, "get", return_value=fake):
            result = tools.execute("fake.write")
        self.assertFalse(result.ok)
        self.assertFalse(result.read_only)
        self.assertIn("read-only tools", result.error)

    def test_bad_parameters_produce_a_failed_result(self):
        result = tools.execute("unity.console.tail", {"lines": 999999})
        self.assertFalse(result.ok)
        self.assertIn("lines", result.error)

    def test_results_carry_the_ok_flag_and_timing(self):
        with tempfile.TemporaryDirectory() as tmp:
            project = Path(tmp)
            (project / "Assets").mkdir()
            result = tools.execute("unity.project.inventory", {"project_root": str(project)})
        self.assertTrue(result.ok, result.error)
        self.assertGreaterEqual(result.duration_ms, 0)
        self.assertTrue(result.read_only)


class ReadToolBehaviourTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.root = Path(self._tmp.name)
        self.user = self.root / "user"
        self.editor = self.user / "Unity" / "Editor"
        self.editor.mkdir(parents=True)
        self._patch = mock.patch.object(diagnostics, "editor_log_dir", return_value=self.editor)
        self._patch.start()
        self.addCleanup(self._patch.stop)

    def _project(self):
        project = self.root / "Project"
        (project / "Assets").mkdir(parents=True, exist_ok=True)
        (project / "Assets" / "Readme.txt").write_text("asset\n", encoding="utf-8")
        settings = project / "ProjectSettings"
        settings.mkdir(parents=True, exist_ok=True)
        (settings / "EditorBuildSettings.asset").write_text(
            "%YAML 1.1\nEditorBuildSettings:\n  m_Scenes: []\n", encoding="utf-8")
        packages = project / "Packages"
        packages.mkdir(parents=True, exist_ok=True)
        (packages / "manifest.json").write_text('{"dependencies": {}}', encoding="utf-8")
        (project / "Logs").mkdir(parents=True, exist_ok=True)
        return project

    def test_console_tail_reads_only_the_tail(self):
        lines = ["line %d" % index for index in range(1, 11)]
        (self.editor / "Editor.log").write_text("\n".join(lines), encoding="utf-8")
        result = tools.execute("unity.console.tail", {"lines": 3})
        self.assertTrue(result.ok, result.error)
        self.assertEqual(result.data["lines_returned"], 3)
        self.assertEqual(result.data["lines"][-1], "line 10")

    def test_console_tail_rejects_a_foreign_file_name(self):
        result = tools.execute("unity.console.tail", {"file": "../../etc/passwd"})
        self.assertFalse(result.ok)
        self.assertIn("file must be one of", result.error)

    def test_console_tail_rejects_a_missing_file(self):
        result = tools.execute("unity.console.tail", {})
        self.assertFalse(result.ok)
        self.assertIn("not found", result.error)

    def test_console_tail_filters_by_level(self):
        (self.editor / "Editor.log").write_text(
            "all good\nError: boom\nwarning: hmm\nException: crash\n", encoding="utf-8")
        result = tools.execute("unity.console.tail", {"level": "error"})
        self.assertTrue(result.ok, result.error)
        self.assertEqual(result.data["lines_returned"], 2)

    def test_diagnostics_tool_writes_no_files(self):
        project = self._project()
        (project / "Logs" / "AssetImportWorker0.log").write_text(
            "Unhandled exception: boom\n", encoding="utf-8")
        before = sorted(str(item.relative_to(project)) for item in project.rglob("*"))
        result = tools.execute("project.diagnostics", {"project_root": str(project)})
        after = sorted(str(item.relative_to(project)) for item in project.rglob("*"))
        self.assertTrue(result.ok, result.error)
        self.assertEqual(before, after, "the diagnostics tool must not write into the project")
        self.assertGreaterEqual(result.data["summary"]["findings"], 1)

    def test_inventory_reports_a_project_without_scenes(self):
        project = self._project()
        result = tools.execute("unity.project.inventory", {"project_root": str(project)})
        self.assertTrue(result.ok, result.error)
        titles = [finding["title"] for finding in result.data["findings"]]
        self.assertTrue(any("no scene" in title.lower() for title in titles), titles)

    def test_inventory_rejects_a_missing_root(self):
        result = tools.execute("unity.project.inventory", {"project_root": str(self.root / "nope")})
        self.assertFalse(result.ok)
        self.assertIn("not a directory", result.error)


class BrainReadToolTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.db = Path(self._tmp.name) / "brain.sqlite3"

    def _make_facts_db(self):
        connection = sqlite3.connect(str(self.db))
        connection.execute(
            "CREATE TABLE facts (world TEXT, key TEXT, value TEXT, category TEXT, "
            "confidence REAL, updated REAL, access_count INTEGER, PRIMARY KEY (world, key))")
        connection.execute("INSERT INTO facts VALUES ('sandbox','weather.current','rain','weather',0.9,1.0,2)")
        connection.execute("INSERT INTO facts VALUES ('sandbox','build.state','ok','system',1.0,2.0,0)")
        connection.commit()
        connection.close()

    def test_facts_are_read_from_the_database(self):
        self._make_facts_db()
        result = tools.execute("brain.knowledge.facts", {"db": str(self.db)})
        self.assertTrue(result.ok, result.error)
        self.assertEqual(result.data["count"], 2)

    def test_facts_can_be_filtered_by_category(self):
        self._make_facts_db()
        result = tools.execute("brain.knowledge.facts", {"db": str(self.db), "category": "system"})
        self.assertTrue(result.ok, result.error)
        self.assertEqual(result.data["count"], 1)

    def test_missing_table_is_reported_not_thrown(self):
        sqlite3.connect(str(self.db)).close()
        result = tools.execute("brain.knowledge.facts", {"db": str(self.db)})
        self.assertTrue(result.ok, result.error)
        self.assertEqual(result.data["facts"], [])

    def test_missing_database_is_a_clean_error(self):
        result = tools.execute("brain.knowledge.facts", {"db": str(self.db)})
        self.assertFalse(result.ok)
        self.assertIn("not found", result.error)

    def test_read_connection_cannot_write(self):
        self._make_facts_db()
        connection = tools._readonly_connection(self.db)
        try:
            with self.assertRaises(sqlite3.OperationalError):
                connection.execute("INSERT INTO facts VALUES ('x','y','z','c',1.0,1.0,0)")
        finally:
            connection.close()

    def test_observations_are_read_from_the_database(self):
        connection = sqlite3.connect(str(self.db))
        connection.execute(
            "CREATE TABLE observations (world TEXT, session TEXT, observation TEXT, digest TEXT, "
            "response TEXT, events TEXT, created REAL, PRIMARY KEY (world, session, observation))")
        connection.execute("INSERT INTO observations VALUES ('sandbox','s1','o1','d1','{}','[]',5.0)")
        connection.commit()
        connection.close()
        result = tools.execute("brain.observations.recent", {"db": str(self.db)})
        self.assertTrue(result.ok, result.error)
        self.assertEqual(result.data["count"], 1)


class SceneReportToolTests(unittest.TestCase):
    """unity.scene.report reads what the editor probe wrote; it never probes itself."""

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.root = Path(self._tmp.name)
        self.report = self.root / "scene-report.json"

    def _write_report(self, findings=None):
        payload = {
            "report_version": "1",
            "probe": "AICoreSceneProbe",
            "unity_version": "6000.3.9f1",
            "read_only": True,
            "generated_utc": "2026-09-18T09:53:05.8259802Z",
            "summary": {"scenes_loaded": 1, "game_objects": 7, "findings": len(findings or [])},
            "findings": findings if findings is not None else [
                {"id": "scene.multiple-AudioListener", "category": "ui_conflict",
                 "severity": "error", "title": "More than one AudioListener",
                 "detail": "2 instances", "evidence": "path", "suggested_action": "keep one"},
                {"id": "scene.lodgroup-present", "category": "rig_conflict",
                 "severity": "info", "title": "LODGroup present",
                 "detail": "1 found", "evidence": "path", "suggested_action": "review"},
            ],
        }
        self.report.write_text(json.dumps(payload), encoding="utf-8")
        return self.report

    def test_reads_the_summary_and_findings(self):
        self._write_report()
        result = tools.execute("unity.scene.report", {"report": str(self.report)})
        self.assertTrue(result.ok, result.error)
        self.assertEqual(result.data["count"], 2)
        self.assertEqual(result.data["summary"]["game_objects"], 7)
        self.assertIn("report_age_seconds", result.data)

    def test_filters_by_severity(self):
        self._write_report()
        result = tools.execute("unity.scene.report", {"report": str(self.report), "severity": "error"})
        self.assertTrue(result.ok, result.error)
        self.assertEqual(result.data["count"], 1)

    def test_rejects_an_unknown_severity(self):
        self._write_report()
        result = tools.execute("unity.scene.report", {"report": str(self.report), "severity": "fatal"})
        self.assertFalse(result.ok)
        self.assertIn("severity", result.error)

    def test_limit_caps_the_returned_findings(self):
        self._write_report()
        result = tools.execute("unity.scene.report", {"report": str(self.report), "limit": 1})
        self.assertTrue(result.ok, result.error)
        self.assertEqual(result.data["count"], 2)
        self.assertEqual(len(result.data["findings"]), 1)

    def test_missing_report_explains_how_to_produce_it(self):
        result = tools.execute("unity.scene.report", {"report": str(self.root / "nope.json")})
        self.assertFalse(result.ok)
        self.assertIn("AICoreSceneProbe.RunBatch", result.error)

    def test_requires_a_report_path_or_a_project_root(self):
        result = tools.execute("unity.scene.report", {})
        self.assertFalse(result.ok)
        self.assertIn("project_root", result.error)

    def test_project_root_locates_the_default_report_path(self):
        default = self.root / "AICore" / "outputs" / "scene"
        default.mkdir(parents=True)
        (default / "scene-report.json").write_text(json.dumps({"findings": [], "summary": {}}),
                                                   encoding="utf-8")
        result = tools.execute("unity.scene.report", {"project_root": str(self.root)})
        self.assertTrue(result.ok, result.error)
        self.assertEqual(result.data["count"], 0)

    def test_broken_json_is_a_clean_error(self):
        self.report.write_text("not json at all", encoding="utf-8")
        result = tools.execute("unity.scene.report", {"report": str(self.report)})
        self.assertFalse(result.ok)
        self.assertIn("unreadable", result.error)

    def test_report_without_findings_is_rejected(self):
        self.report.write_text(json.dumps({"summary": {}}), encoding="utf-8")
        result = tools.execute("unity.scene.report", {"report": str(self.report)})
        self.assertFalse(result.ok)
        self.assertIn("unexpected shape", result.error)


class CliTests(unittest.TestCase):
    def _run(self, *args):
        return subprocess.run([sys.executable, str(CLI), *args],
                              capture_output=True, text=True, encoding="utf-8")

    def test_list_returns_valid_json(self):
        completed = self._run("list", "--json")
        self.assertEqual(completed.returncode, 0, completed.stderr)
        payload = json.loads(completed.stdout)
        self.assertTrue(payload["read_only"])
        self.assertTrue(payload["tools"])

    def test_describe_prints_the_contract(self):
        completed = self._run("describe", "unity.console.tail")
        self.assertEqual(completed.returncode, 0, completed.stderr)
        self.assertIn("reversible: yes", completed.stdout)

    def test_unknown_tool_fails_cleanly_without_a_traceback(self):
        completed = self._run("run", "no.such.tool")
        self.assertEqual(completed.returncode, 1)
        self.assertNotIn("Traceback", completed.stderr)
        self.assertIn("unknown tool", completed.stderr)

    def test_write_tool_needs_allow_write(self):
        completed = self._run("run", "outputs.write_text", "--arg", "path=x.txt", "--arg", "content=y")
        self.assertEqual(completed.returncode, 1)
        self.assertIn("read-only tools", completed.stderr)

    def test_allow_write_is_no_longer_a_blanket_refusal(self):
        completed = self._run("run", "unity.console.tail", "--allow-write", "--arg", "lines=1")
        self.assertIn(completed.returncode, (0, 1))
        self.assertNotIn("reserved for phase 3", completed.stderr)


if __name__ == "__main__":
    unittest.main()
