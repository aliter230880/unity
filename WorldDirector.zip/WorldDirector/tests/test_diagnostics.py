"""Tests for the read-only diagnostics observer (Phase 1).

Standard library only, in the same shape as ``test_brain.py``. Every test works on
throwaway files under the system temp directory: the real Unity project is never
read or written by the suite.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import sqlite3
import sys
import tempfile
import unittest


TEST_ROOT = Path(__file__).resolve().parent
BRAIN_DIR = TEST_ROOT.parent / "brain"
UNITY_PROJECT = __import__("projectroot").optional_root()
sys.path.insert(0, str(BRAIN_DIR))

import diagnostics  # noqa: E402 - imported after sys.path setup
from knowledge import KnowledgeBase  # noqa: E402


def write(path: Path, text: str, newline: str = "\n") -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.replace("\n", newline), encoding="utf-8")
    return path


def make_complete_project(root: Path, dependencies=None) -> Path:
    """A minimal but *complete* project: one scene, build settings, manifest, version."""
    (root / "Assets").mkdir(parents=True)
    (root / "ProjectSettings").mkdir()
    (root / "Packages").mkdir()
    write(root / "Assets" / "Main.unity", "%YAML 1.1\n")
    write(root / "Assets" / "Main.unity.meta",
          "fileFormatVersion: 2\nguid: 66666666666666666666666666666666\n")
    write(root / "ProjectSettings" / "ProjectVersion.txt",
          "m_EditorVersion: 6000.3.9f1\nm_EditorVersionWithRevision: 6000.3.9f1 (7a9955a4f2fa)\n")
    write(root / "ProjectSettings" / "EditorBuildSettings.asset",
          "EditorBuildSettings:\n  m_Scenes:\n  - enabled: 1\n"
          "    path: Assets/Main.unity\n    guid: 66666666666666666666666666666666\n"
          "  m_configObjects: {}\n")
    write(root / "Packages" / "manifest.json",
          json.dumps({"dependencies": dependencies or {"com.unity.modules.ui": "1.0.0"}}, indent=2))
    return root


def finding_for(findings: list, rule_id: str):
    for finding in findings:
        if finding.rule_id == rule_id:
            return finding
    return None


class TempCase(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = Path(tempfile.mkdtemp(prefix="aicore-diag-"))
        self.addCleanup(shutil.rmtree, self.tmp, ignore_errors=True)

    @property
    def work(self) -> Path:
        return self.tmp


# --------------------------------------------------------------------------------------
# Rule coverage: one synthetic line per rule
# --------------------------------------------------------------------------------------

class RuleCoverageTests(TempCase):
    def scan_lines(self, *lines: str) -> list:
        log = write(self.work / "sample.log", "\n".join(lines) + "\n")
        return diagnostics.parse_log(log)

    def assert_rule(self, rule_id, text, category, severity, expect_occurrences=1):
        findings = self.scan_lines(text)
        matching = [finding for finding in findings if finding.rule_id == rule_id]
        self.assertEqual(len(matching), 1, f"{rule_id}: {[f.rule_id for f in findings]}")
        finding = matching[0]
        self.assertEqual(finding.category, category)
        self.assertEqual(finding.severity, severity)
        self.assertEqual(finding.occurrences, expect_occurrences)
        self.assertEqual(finding.evidence[0]["line"], 1)
        self.assertTrue(finding.evidence[0]["snippet"])
        self.assertTrue(finding.finding_id.startswith(rule_id + ":"))
        self.assertGreaterEqual(finding.confidence, 0.0)
        self.assertLessEqual(finding.confidence, 1.0)
        return finding

    def test_compiler_error(self):
        finding = self.assert_rule(
            "compile.cs-error",
            "Assets/Scripts/Foo.cs(12,5): error CS0246: The type or namespace name 'Bar' "
            "could not be found (are you missing a using directive?)",
            "compile", "error")
        self.assertIn("CS0246", finding.title)
        self.assertIn("CS0246", finding.detail)

    def test_compiler_error_codes_stay_separate(self):
        findings = self.scan_lines(
            "error CS0246: The type or namespace name 'Bar' could not be found",
            "error CS1002: ; expected")
        codes = sorted(finding.title for finding in findings)
        self.assertEqual(len(findings), 2, codes)
        self.assertTrue(any("CS0246" in code for code in codes))
        self.assertTrue(any("CS1002" in code for code in codes))

    def test_compiler_warning(self):
        self.assert_rule("compile.cs-warning",
                         "Assets/Scripts/Foo.cs(3,9): warning CS0414: The field 'Foo.bar' "
                         "is assigned but its value is never used",
                         "compile", "warning")

    def test_shader_error(self):
        finding = self.assert_rule("compile.shader-error",
                                   "Shader error in 'AliTerra/World': 'vert': syntax error "
                                   "at line 42 (on d3d11)", "compile", "error")
        self.assertIn("AliTerra/World", finding.title)

    def test_shader_compilation_failed(self):
        self.assert_rule("compile.shader-compilation-failed", "Shader compilation failed.",
                         "compile", "error")

    def test_null_reference(self):
        self.assert_rule("runtime.null-reference",
                         "NullReferenceException: Object reference not set to an instance "
                         "of an object", "runtime_exception", "error")

    def test_missing_reference(self):
        self.assert_rule("runtime.missing-reference",
                         "MissingReferenceException: The object of type 'WorldEntity' has "
                         "been destroyed but you are still trying to access it.",
                         "runtime_exception", "error")

    def test_object_disposed_standalone(self):
        self.assert_rule("runtime.object-disposed",
                         "ObjectDisposedException: Cannot access a disposed object.",
                         "runtime_exception", "error")

    def test_curl_tls_error(self):
        finding = self.assert_rule("environment.curl-tls",
                                   "Curl error 35: Cert verify failed. Certificate could not "
                                   "be verified (either omitted or unsupported). UnityTls "
                                   "error code: 7", "environment", "error")
        self.assertIn("35", finding.title)

    def test_curl_aborted_is_info(self):
        self.assert_rule("environment.curl-aborted", "Curl error 42: Callback aborted",
                         "environment", "info")

    def test_curl_generic(self):
        finding = self.assert_rule("environment.curl",
                                   "Curl error 7: Failed to connect to 127.0.0.1 port 8765",
                                   "environment", "warning")
        self.assertIn("7", finding.title)

    def test_licensing_error(self):
        self.assert_rule("environment.licensing-error",
                         "[Licensing::Module] Error: Access token is unavailable; failed to update",
                         "environment", "error")

    def test_licensing_client_unavailable(self):
        self.assert_rule("environment.licensing-client-unavailable",
                         "[Licensing::Module] LicensingClient has failed validation; ignoring",
                         "environment", "warning")

    def test_licensing_token_message_without_error_prefix(self):
        self.assert_rule("environment.licensing-token",
                         "[Licensing::Client] Access token is unavailable", "environment", "warning")

    def test_benign_licensing_lines_are_ignored(self):
        findings = self.scan_lines(
            "[Licensing::Module] Trying to connect to existing licensing client channel...",
            "[Licensing::Client] Successfully updated license, isAsync: True, time: 0.01",
            "[Licensing::Module] Licensing Background thread has ended after 1.11s")
        self.assertEqual(findings, [])

    def test_d3d12_info_queue(self):
        self.assert_rule("environment.d3d12-info-queue",
                         "d3d12: failed to query info queue interface (0x80004002).",
                         "environment", "info")

    def test_package_upm_ipc(self):
        self.assert_rule("package.upm-ipc",
                         '[Package Manager] Could not connect to IPC stream "Upm-36656" '
                         "after 30.0 seconds.", "package", "critical")

    def test_package_upm_start_failed(self):
        self.assert_rule("package.upm-start-failed",
                         "[Package Manager] Failed to start the Unity Package Manager local "
                         "server process. Make sure the process is not blocked by antivirus.",
                         "package", "critical")

    def test_package_upm_error(self):
        self.assert_rule("package.upm-error",
                         "[Package Manager] Failed to resolve packages: registry unreachable",
                         "package", "error")

    def test_import_worker_failed(self):
        self.assert_rule("import.worker-failed",
                         "[Worker3] Import of Assets/Rig/Man.fbx failed: mesh has no bones",
                         "import", "error")

    def test_import_failed(self):
        self.assert_rule("import.asset-import-failed",
                         "Failed to import Assets/Rig/Man.fbx", "import", "error")

    def test_missing_script(self):
        self.assert_rule("missing_asset.missing-script",
                         "The referenced script on this Behaviour (Game Object 'Player') is "
                         "missing!", "missing_asset", "error")

    def test_missing_asset_reference(self):
        self.assert_rule("missing_asset.asset-not-found",
                         "Could not find asset at path Assets/Props/Crate.prefab",
                         "missing_asset", "warning")

    def test_ui_event_system_conflict_by_message(self):
        self.assert_rule("ui.event-system-conflict",
                         "There are 2 event systems in the scene. Please ensure there is "
                         "always exactly one event system in the scene",
                         "ui_conflict", "warning")

    def test_ui_event_system_conflict_by_multiple_wording(self):
        self.assert_rule("ui.event-system-conflict", "Multiple EventSystem components found",
                         "ui_conflict", "warning")

    def test_ui_event_system_alone_is_not_a_finding(self):
        findings = self.scan_lines("EventSystem created for the new scene",
                                  "Adding EventSystem to the canvas hierarchy")
        self.assertEqual(findings, [], "EventSystem without conflict evidence must not fire")

    def test_rig_duplicate(self):
        self.assert_rule("rig.duplicate-rig", "duplicate rig found under Player/Model",
                         "rig_conflict", "warning")

    def test_rig_lod_group_conflict(self):
        self.assert_rule("rig.lod-group-conflict",
                         "LODGroup on Player/Model is missing renderers",
                         "rig_conflict", "warning")

    def test_lod_group_alone_is_not_a_finding(self):
        findings = self.scan_lines("LODGroup LOD0 renderer cached for Player",
                                  "LODGroup has 3 levels")
        self.assertEqual(findings, [], "LODGroup alone must not be reported")


# --------------------------------------------------------------------------------------
# Unhandled exception blocks
# --------------------------------------------------------------------------------------

class UnhandledExceptionTests(TempCase):
    CRASH = (
        "[Package Manager] Could not connect to IPC stream \"Upm-1\" after 30.0 seconds.\n"
        "Unhandled exception. System.ObjectDisposedException: Cannot access a disposed object.\n"
        "Object name: 'IServiceProvider'.\n"
        "   at Microsoft.Extensions.DependencyInjection.ServiceLookup.ThrowHelper.ThrowObjectDisposedException()\n"
        "   at Microsoft.Extensions.DependencyInjection.ServiceProvider.GetService(Type serviceType)\n"
        "   at Unity.Licensing.Client.CommandExecutors.Startup.ProgramInitializer.InitializeImpl()\n"
        "Exiting without the bug reporter.\n")

    def test_crash_is_one_critical_finding_with_real_line_numbers(self):
        log = write(self.work / "crash.log", self.CRASH)
        findings = diagnostics.parse_log(log)
        crashes = [finding for finding in findings if finding.rule_id == "runtime.unhandled-exception"]
        self.assertEqual(len(crashes), 1)
        crash = crashes[0]
        self.assertEqual(crash.category, "runtime_exception")
        self.assertEqual(crash.severity, "critical")
        self.assertIn("ObjectDisposedException", crash.title)
        self.assertIn("Cannot access a disposed object", crash.detail)
        lines = [item["line"] for item in crash.evidence]
        self.assertEqual(lines[0], 2)
        self.assertTrue(all(line >= 2 for line in lines))
        self.assertIn(4, lines)  # first stack frame
        self.assertEqual(len(lines), len(set(lines)))

    def test_crash_signature_line_is_not_reported_twice(self):
        log = write(self.work / "crash.log", self.CRASH)
        findings = diagnostics.parse_log(log)
        rule_ids = [finding.rule_id for finding in findings]
        self.assertNotIn("runtime.object-disposed", rule_ids)
        self.assertEqual(rule_ids.count("runtime.unhandled-exception"), 1)

    def test_crash_terminated_by_unindented_line(self):
        log = write(self.work / "crash.log",
                    "Unhandled exception. System.NullReferenceException: boom\n"
                    "   at Foo.Bar()\n"
                    "[Licensing::Module] Error: Access token is unavailable\n")
        findings = diagnostics.parse_log(log)
        crash = finding_for(findings, "runtime.unhandled-exception")
        self.assertIsNotNone(crash)
        self.assertEqual(crash.evidence[0]["line"], 1)
        self.assertIn(2, [item["line"] for item in crash.evidence])
        self.assertIsNotNone(finding_for(findings, "environment.licensing-error"),
                             "the line after the crash block must still be scanned")

    def test_trailing_crash_without_trailing_newline(self):
        log = self.work / "crash.log"
        write(log, "Unhandled exception. System.ObjectDisposedException: bye\n   at Foo.Bar()")
        findings = diagnostics.parse_log(log)
        crash = finding_for(findings, "runtime.unhandled-exception")
        self.assertIsNotNone(crash, "an unterminated crash block at EOF must still be reported")

    def test_crash_types_do_not_merge(self):
        log = write(self.work / "crash.log",
                    "Unhandled exception. System.ObjectDisposedException: a\n"
                    "Unhandled exception. System.NullReferenceException: b\n")
        findings = [finding for finding in diagnostics.parse_log(log)
                    if finding.rule_id == "runtime.unhandled-exception"]
        self.assertEqual(len(findings), 2)


# --------------------------------------------------------------------------------------
# Evidence line numbers and aggregation
# --------------------------------------------------------------------------------------

class EvidenceAndAggregationTests(TempCase):
    def test_line_numbers_survive_crlf_and_leading_nul(self):
        log = self.work / "crlf.log"
        log.write_bytes(b"# header\r\n\x00Unhandled exception. System.ObjectDisposedException: x\r\n"
                        b"   at Foo.Bar()\r\n"
                        b"Assets/A.cs(1,1): error CS1002: ; expected\r\n")
        findings = diagnostics.parse_log(log)
        crash = finding_for(findings, "runtime.unhandled-exception")
        self.assertEqual(crash.evidence[0]["line"], 2)
        compile_error = finding_for(findings, "compile.cs-error")
        self.assertEqual(compile_error.evidence[0]["line"], 4)
        self.assertTrue(compile_error.evidence[0]["snippet"].startswith("Assets/A.cs"))

    def test_repeated_messages_aggregate(self):
        log = write(self.work / "repeat.log", "\n".join(
            ["Curl error 35: Cert verify failed. Certificate could not be verified"] * 5) + "\n")
        findings = diagnostics.parse_log(log)
        self.assertEqual(len(findings), 1)
        finding = findings[0]
        self.assertEqual(finding.occurrences, 5)
        self.assertEqual(len(finding.evidence), 5)
        self.assertEqual(sorted(item["line"] for item in finding.evidence), [1, 2, 3, 4, 5])

    def test_evidence_is_capped_but_occurrences_are_not(self):
        log = write(self.work / "many.log", "\n".join(
            ["Curl error 35: Cert verify failed. Certificate could not be verified"] * 12) + "\n")
        finding = diagnostics.parse_log(log)[0]
        self.assertEqual(finding.occurrences, 12)
        self.assertEqual(len(finding.evidence), diagnostics.MAX_EVIDENCE_PER_FINDING)
        self.assertEqual(sorted(item["line"] for item in finding.evidence)[0], 1,
                         "the retained examples are still real locations")
        report = diagnostics.build_report(None, [log])
        markdown = diagnostics.render_markdown(report)
        self.assertIn("(×12, файлов: 1)", markdown, "the report must show the true count")

    def test_volatile_numbers_do_not_split_aggregation(self):
        log = write(self.work / "volatile.log",
                    '[Package Manager] Could not connect to IPC stream "Upm-36656" after 30.0 seconds.\n'
                    '[Package Manager] Could not connect to IPC stream "Upm-4242" after 30.1 seconds.\n')
        findings = diagnostics.parse_log(log)
        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0].occurrences, 2)
        self.assertEqual(sorted(item["line"] for item in findings[0].evidence), [1, 2])

    def test_aggregation_bumps_confidence_but_stays_bounded(self):
        one = write(self.work / "one.log", "Curl error 35: Cert verify failed\n")
        many = write(self.work / "many.log", "Curl error 35: Cert verify failed\n" * 40)
        single = diagnostics.parse_log(one)[0]
        repeated = diagnostics.parse_log(many)[0]
        self.assertGreater(repeated.confidence, single.confidence)
        self.assertLessEqual(repeated.confidence, 0.97)

    def test_same_message_in_two_logs_merges_with_both_locations(self):
        first = write(self.work / "a.log", "NullReferenceException: boom\n")
        second = write(self.work / "b.log", "NullReferenceException: boom\n")
        report = diagnostics.build_report(None, [first, second])
        self.assertEqual(report["summary"]["findings"], 1)
        finding = report["findings"][0]
        self.assertEqual(finding["occurrences"], 2)
        self.assertEqual(len(finding["sources"]), 2)
        self.assertEqual(len(finding["evidence"]), 2)

    def test_aggregation_preserves_severity_and_category(self):
        log = write(self.work / "mixed.log",
                    "Curl error 35: Cert verify failed\n"
                    "Curl error 35: Cert verify failed\n")
        finding = diagnostics.parse_log(log)[0]
        self.assertEqual(finding.severity, "error")
        self.assertEqual(finding.category, "environment")
        self.assertEqual(finding.rule_id, "environment.curl-tls")


# --------------------------------------------------------------------------------------
# Robustness
# --------------------------------------------------------------------------------------

class RobustnessTests(TempCase):
    def test_empty_file_produces_no_findings(self):
        log = write(self.work / "empty.log", "")
        self.assertEqual(diagnostics.parse_log(log), [])

    def test_only_blank_lines(self):
        log = write(self.work / "blank.log", "\n\n   \n\t\n")
        self.assertEqual(diagnostics.parse_log(log), [])

    def test_garbage_lines_do_not_crash(self):
        log = self.work / "garbage.log"
        log.write_bytes(b"\xff\xfe\x00garbage \xc3\x28 \x00\x01\x02\n" * 3 +
                        "日本語のログ行\n".encode("utf-8") +
                        b"~!@#$%^&*()_+-=[]{}|;':\",./<>?\n")
        findings = diagnostics.parse_log(log)
        self.assertEqual(findings, [])

    def test_very_long_line_is_clipped_in_evidence(self):
        long_line = "error CS0246: " + "x" * 5000
        log = write(self.work / "long.log", long_line + "\n")
        finding = diagnostics.parse_log(log)[0]
        self.assertLessEqual(len(finding.evidence[0]["snippet"]), diagnostics.MAX_SNIPPET)

    def test_missing_log_file_raises(self):
        with self.assertRaises(diagnostics.DiagnosticsError):
            diagnostics.parse_log(self.work / "nope.log")

    def test_finding_rejects_bad_schema(self):
        with self.assertRaises(diagnostics.DiagnosticsError):
            diagnostics.Finding("id", "not-a-category", "error", "t", "d")
        with self.assertRaises(diagnostics.DiagnosticsError):
            diagnostics.Finding("id", "compile", "catastrophic", "t", "d")
        with self.assertRaises(diagnostics.DiagnosticsError):
            diagnostics.Finding("id", "compile", "error", "t", "d", confidence=2.0)

    def test_ignored_lines_are_counted_not_reported(self):
        log = write(self.work / "ignored.log",
                    "abort_threads: Failed aborting id: 0000000000007078, mono_thread_manage "
                    "will ignore it\n"
                    "~StackAllocator(ALLOC_TEMP_MAIN) m_LastAlloc not NULL. Did you forget to "
                    "call FreeAllStackAllocations()?\n")
        scan = diagnostics.scan_log(log)
        self.assertEqual(scan["findings"], [])
        reasons = {entry["reason"]: entry["count"] for entry in scan["ignored"]}
        self.assertEqual(len(reasons), 2)
        self.assertEqual(sum(reasons.values()), 2)

    def test_binary_nul_padding_is_reported_in_notes(self):
        log = self.work / "nul.log"
        log.write_bytes(b"\x00Unhandled exception. System.ObjectDisposedException: x\n")
        report = diagnostics.build_report(None, [log])
        self.assertTrue(any("NUL" in note for note in report["notes"]))
        self.assertEqual(report["logs"][0]["nul_bytes"], 1)


# --------------------------------------------------------------------------------------
# Project inventory on a synthetic fixture
# --------------------------------------------------------------------------------------

class InventoryTests(TempCase):
    def make_project(self, with_scene: bool = False) -> Path:
        root = self.work / "Project"
        (root / "Assets").mkdir(parents=True)
        (root / "ProjectSettings").mkdir()
        (root / "Packages").mkdir()
        write(root / "Assets" / "Keep.cs", "class Keep {}\n")
        write(root / "Assets" / "Keep.cs.meta",
              "fileFormatVersion: 2\nguid: 11111111111111111111111111111111\n")
        if with_scene:
            write(root / "Assets" / "Main.unity", "%YAML 1.1\n")
            write(root / "Assets" / "Main.unity.meta",
                  "fileFormatVersion: 2\nguid: 22222222222222222222222222222222\n")
        write(root / "ProjectSettings" / "ProjectVersion.txt",
              "m_EditorVersion: 6000.3.9f1\nm_EditorVersionWithRevision: 6000.3.9f1 (7a9955a4f2fa)\n")
        write(root / "ProjectSettings" / "EditorBuildSettings.asset",
              "EditorBuildSettings:\n  m_Scenes: []\n  m_configObjects: {}\n")
        write(root / "Packages" / "manifest.json",
              json.dumps({"dependencies": {"com.unity.modules.ui": "1.0.0"}}, indent=2))
        return root

    def find(self, findings, rule_id):
        return finding_for(findings, rule_id)

    def test_empty_assets_is_reported(self):
        root = self.work / "Empty"
        (root / "Assets").mkdir(parents=True)
        (root / "ProjectSettings").mkdir()
        findings = diagnostics.inventory_project(root)[1]
        self.assertIsNotNone(self.find(findings, "project_layout.assets-empty"))
        self.assertIsNone(self.find(findings, "project_layout.assets-without-scenes"),
                          "an empty Assets folder is reported once, not twice")

    def test_assets_without_scenes_is_reported(self):
        root = self.work / "NoScenes"
        (root / "Assets").mkdir(parents=True)
        (root / "ProjectSettings").mkdir()
        write(root / "Assets" / "Only.cs", "class Only {}\n")
        write(root / "Assets" / "Only.cs.meta", "fileFormatVersion: 2\nguid: 7777\n")
        findings = diagnostics.inventory_project(root)[1]
        self.assertIsNotNone(self.find(findings, "project_layout.assets-without-scenes"))
        self.assertIsNone(self.find(findings, "project_layout.assets-empty"))

    def test_missing_assets_is_reported(self):
        root = self.work / "NoAssets"
        root.mkdir()
        findings = diagnostics.inventory_project(root)[1]
        self.assertIsNotNone(self.find(findings, "project_layout.assets-missing"))

    def test_missing_project_root(self):
        metadata, findings = diagnostics.inventory_project(self.work / "absent")
        self.assertFalse(metadata["exists"])
        self.assertEqual(findings[0].rule_id, "project_layout.root-missing")

    def test_orphan_meta_reported_with_guid_line(self):
        root = self.make_project()
        write(root / "Assets" / "Ghost.cs.meta",
              "fileFormatVersion: 2\nguid: 33333333333333333333333333333333\n")
        findings = diagnostics.inventory_project(root)[1]
        finding = self.find(findings, "missing_asset.orphan-meta")
        self.assertIsNotNone(finding)
        self.assertEqual(finding.category, "missing_asset")
        self.assertEqual(finding.severity, "warning")
        self.assertEqual(finding.occurrences, 1)
        self.assertEqual(finding.evidence[0]["line"], 2, "evidence points at the guid line")
        self.assertIn("33333333333333333333333333333333", finding.evidence[0]["snippet"])

    def test_meta_for_directory_is_not_an_orphan(self):
        root = self.make_project()
        (root / "Assets" / "Folder").mkdir()
        write(root / "Assets" / "Folder.meta",
              "fileFormatVersion: 2\nguid: 44444444444444444444444444444444\n")
        findings = diagnostics.inventory_project(root)[1]
        self.assertIsNone(self.find(findings, "missing_asset.orphan-meta"))

    def test_asset_without_meta_is_reported(self):
        root = self.make_project()
        write(root / "Assets" / "NoMeta.cs", "class NoMeta {}\n")
        finding = self.find(diagnostics.inventory_project(root)[1], "missing_asset.missing-meta")
        self.assertIsNotNone(finding)
        self.assertIn("NoMeta.cs", finding.evidence[0]["file"])
        self.assertEqual(finding.evidence[0]["line"], 1)

    def test_duplicate_guids_are_reported_as_error(self):
        root = self.make_project()
        write(root / "Assets" / "Twin.cs", "class Twin {}\n")
        write(root / "Assets" / "Twin.cs.meta",
              "fileFormatVersion: 2\nguid: 11111111111111111111111111111111\n")
        finding = self.find(diagnostics.inventory_project(root)[1], "missing_asset.duplicate-guid")
        self.assertIsNotNone(finding)
        self.assertEqual(finding.severity, "error")
        self.assertGreaterEqual(finding.occurrences, 2)
        self.assertTrue(all(item["line"] == 2 for item in finding.evidence))

    def test_empty_build_settings_reported(self):
        root = self.make_project(with_scene=True)
        finding = self.find(diagnostics.inventory_project(root)[1],
                            "project_layout.build-settings-empty")
        self.assertIsNotNone(finding)
        self.assertEqual(finding.evidence[0]["file"].endswith("EditorBuildSettings.asset"), True)
        self.assertEqual(finding.evidence[0]["line"], 2)

    def test_listed_scene_that_does_not_exist_is_an_error(self):
        root = self.make_project(with_scene=True)
        write(root / "ProjectSettings" / "EditorBuildSettings.asset",
              "EditorBuildSettings:\n  m_Scenes:\n  - enabled: 1\n"
              "    path: Assets/Scenes/Missing.unity\n  m_configObjects: {}\n")
        finding = self.find(diagnostics.inventory_project(root)[1],
                            "missing_asset.build-scene-missing")
        self.assertIsNotNone(finding)
        self.assertEqual(finding.severity, "error")
        self.assertEqual(finding.evidence[0]["line"], 4)

    def test_existing_listed_scene_is_clean(self):
        root = self.make_project(with_scene=True)
        write(root / "ProjectSettings" / "EditorBuildSettings.asset",
              "EditorBuildSettings:\n  m_Scenes:\n  - enabled: 1\n"
              "    path: Assets/Main.unity\n  m_configObjects: {}\n")
        findings = diagnostics.inventory_project(root)[1]
        self.assertIsNone(self.find(findings, "missing_asset.build-scene-missing"))
        self.assertIsNone(self.find(findings, "project_layout.build-settings-empty"))
        self.assertIsNone(self.find(findings, "project_layout.assets-without-scenes"))

    def test_manifest_problems(self):
        root = self.make_project()
        write(root / "Packages" / "manifest.json", "{ not json")
        self.assertIsNotNone(self.find(diagnostics.inventory_project(root)[1],
                                       "package.manifest-invalid"))
        write(root / "Packages" / "manifest.json", json.dumps({"dependencies": {}}))
        self.assertIsNotNone(self.find(diagnostics.inventory_project(root)[1],
                                       "package.manifest-empty"))
        write(root / "Packages" / "manifest.json",
              json.dumps({"dependencies": {"BadName": "1.0.0"}}))
        self.assertIsNotNone(self.find(diagnostics.inventory_project(root)[1],
                                       "package.malformed-dependency-name"))
        write(root / "Packages" / "manifest.json",
              json.dumps({"dependencies": {"com.example.local": "file:../local"}}, indent=2))
        finding = self.find(diagnostics.inventory_project(root)[1],
                            "package.non-registry-dependency")
        self.assertIsNotNone(finding)
        self.assertIn("com.example.local", finding.evidence[0]["snippet"])
        self.assertEqual(finding.evidence[0]["line"], 3, "manifest line numbers must be real")
        lines = (root / "Packages" / "manifest.json").read_text(encoding="utf-8").splitlines()
        self.assertIn("com.example.local", lines[finding.evidence[0]["line"] - 1])

    def test_missing_manifest(self):
        root = self.make_project()
        (root / "Packages" / "manifest.json").unlink()
        self.assertIsNotNone(self.find(diagnostics.inventory_project(root)[1],
                                       "package.manifest-missing"))

    def test_project_version_are_read_into_metadata(self):
        root = self.make_project()
        metadata, findings = diagnostics.inventory_project(root)
        self.assertEqual(metadata["editor_version"], "6000.3.9f1")
        self.assertEqual(metadata["editor_revision"], "7a9955a4f2fa")
        self.assertIsNone(self.find(findings, "environment.project-version-missing"))
        (root / "ProjectSettings" / "ProjectVersion.txt").unlink()
        metadata, findings = diagnostics.inventory_project(root)
        self.assertIsNotNone(self.find(findings, "environment.project-version-missing"))
        self.assertIsNone(metadata.get("editor_version"))

    def test_service_directories_are_skipped(self):
        root = self.make_project()
        write(root / "Assets" / "Library" / "junk.cs", "class Junk {}\n")
        metadata = diagnostics.inventory_project(root)[0]
        self.assertEqual(metadata["assets"]["files"], 1)
        self.assertIsNone(self.find(diagnostics.inventory_project(root)[1],
                                    "missing_asset.missing-meta"))

    def test_real_project_is_clean_of_orphans_and_duplicate_guids(self):
        """Guard for the real tree: no orphan meta, no duplicate GUID, no missing meta.

        It deliberately does *not* assert which layout findings appear: those depend on
        the project's actual state, and the state changes as the project is worked on.
        What must always hold is that the tree is internally consistent and was inspected.
        """
        if UNITY_PROJECT is None:
            self.skipTest(__import__("projectroot").REASON)
        real = UNITY_PROJECT
        metadata, findings = diagnostics.inventory_project(real)
        self.assertTrue(metadata["exists"])
        rule_ids = [finding.rule_id for finding in findings]
        self.assertNotIn("missing_asset.orphan-meta", rule_ids)
        self.assertNotIn("missing_asset.duplicate-guid", rule_ids)
        self.assertNotIn("missing_asset.missing-meta", rule_ids)
        self.assertGreaterEqual(metadata["assets"]["files"], 1)
        self.assertEqual(metadata["editor_version"], "6000.3.9f1")


# --------------------------------------------------------------------------------------
# run(): side effects and report artifacts
# --------------------------------------------------------------------------------------

class RunBoundaryTests(TempCase):
    def make_inputs(self):
        project = make_complete_project(self.work / "Project")
        log = write(self.work / "logs" / "editor.log",
                    "error CS0246: The type or namespace name 'Bar' could not be found\n")
        return project, log

    def snapshot(self, root: Path) -> set:
        return {path.relative_to(root).as_posix() for path in root.rglob("*")}

    def test_run_without_out_dir_writes_nothing(self):
        project, log = self.make_inputs()
        before = self.snapshot(self.work)
        report = diagnostics.run(project, [log])
        self.assertEqual(self.snapshot(self.work), before)
        rule_ids = [item["rule_id"] for item in report["findings"]]
        self.assertIn("compile.cs-error", rule_ids)
        self.assertEqual(report["summary"]["findings"], 1,
                         "the complete fixture project contributes no structural findings")
        self.assertNotIn("artifacts", report)

    def test_run_does_not_create_or_touch_a_database_when_persist_is_false(self):
        project, log = self.make_inputs()
        db = self.work / "brain.sqlite3"
        report = diagnostics.run(project, [log], db_path=db, world="world-1", persist=False)
        self.assertFalse(db.exists(), "persist=False must not create a database")
        self.assertFalse(report["persist"]["enabled"])

    def test_existing_database_is_untouched_when_persist_is_false(self):
        project, log = self.make_inputs()
        db = self.work / "brain.sqlite3"
        connection = sqlite3.connect(db)
        connection.execute("CREATE TABLE marker(value TEXT)")
        connection.execute("INSERT INTO marker VALUES('before')")
        connection.commit()
        connection.close()
        before = db.read_bytes()
        diagnostics.run(project, [log], db_path=db, world="world-1", persist=False)
        self.assertEqual(db.read_bytes(), before)

    def test_persist_requires_db_and_world(self):
        project, log = self.make_inputs()
        with self.assertRaises(diagnostics.DiagnosticsError):
            diagnostics.run(project, [log], persist=True, world="world-1")
        with self.assertRaises(diagnostics.DiagnosticsError):
            diagnostics.run(project, [log], persist=True, db_path=self.work / "b.sqlite3")
        self.assertFalse((self.work / "b.sqlite3").exists())

    def test_persist_writes_facts_through_the_knowledge_api(self):
        project, log = self.make_inputs()
        db = self.work / "brain.sqlite3"
        report = diagnostics.run(project, [log], db_path=db, world="world-1", persist=True)
        persist = report["persist"]
        self.assertTrue(persist["enabled"])
        self.assertEqual(persist["facts_rejected"], 0)
        self.assertGreaterEqual(persist["facts_written"], report["summary"]["findings"] + 2)
        connection = sqlite3.connect(db)
        connection.row_factory = sqlite3.Row
        rows = connection.execute("SELECT * FROM facts WHERE world='world-1'").fetchall()
        connection.close()
        keys = {row["key"] for row in rows}
        self.assertIn("diagnostics.summary", keys)
        self.assertIn("diagnostics.last_run", keys)
        for row in rows:
            self.assertEqual(row["category"], "system")
            self.assertLessEqual(len(row["value"]), 2000)
            self.assertLessEqual(len(row["key"]), 256)
            self.assertIsInstance(json.loads(row["value"]), (dict, str))
        detail_row = next(row for row in rows
                          if row["key"].startswith("diagnostics.compile.cs-error"))
        payload = json.loads(detail_row["value"])
        self.assertEqual(payload["severity"], "error")
        self.assertIn("evidence", payload)

    def test_oversized_finding_is_still_stored_as_valid_json(self):
        finding = diagnostics.Finding(
            finding_id="x:1", category="compile", severity="error", title="t" * 400,
            detail="d" * 5000, evidence=[{"file": "f" * 300, "line": index, "snippet": "s" * 300}
                                         for index in range(6)],
            suggested_action="a" * 900, confidence=0.9, rule_id="x")
        value = diagnostics.fact_value(finding)
        self.assertLessEqual(len(value), 2000)
        self.assertIsInstance(json.loads(value), dict)

    def test_persist_uses_knowledge_base_readable_by_the_brain(self):
        project, log = self.make_inputs()
        db = self.work / "brain.sqlite3"
        diagnostics.run(project, [log], db_path=db, world="world-1", persist=True)
        connection = sqlite3.connect(db)
        connection.row_factory = sqlite3.Row
        knowledge = KnowledgeBase(connection)
        facts = knowledge.query_facts("world-1", "diagnostics.", limit=50)
        connection.close()
        self.assertGreaterEqual(len(facts), 2)
        self.assertTrue(all(fact["category"] == "system" for fact in facts))


class ReportArtifactTests(TempCase):
    def test_report_files_are_written_only_to_out_dir(self):
        project = make_complete_project(self.work / "Project")
        log = write(self.work / "logs" / "editor.log", "Curl error 42: Callback aborted\n")
        out = self.work / "reports"
        before = {path.as_posix() for path in project.rglob("*")}
        report = diagnostics.run(project, [log], out_dir=out)
        self.assertEqual({path.as_posix() for path in project.rglob("*")}, before,
                         "the project directory must not be modified by a run")
        json_path = Path(report["artifacts"]["json"])
        md_path = Path(report["artifacts"]["markdown"])
        self.assertTrue(json_path.is_file())
        self.assertTrue(md_path.is_file())
        self.assertTrue(json_path.name.startswith("diagnose-"))
        self.assertTrue(json_path.name.endswith(".json"))
        self.assertTrue(md_path.name.endswith(".md"))
        self.assertEqual(json_path.parent, out)
        payload = json.loads(json_path.read_text(encoding="utf-8"))
        self.assertEqual(payload["report_version"], diagnostics.REPORT_VERSION)
        self.assertTrue(payload["read_only"])
        self.assertEqual(len(payload["findings"]), report["summary"]["findings"])
        for key in ("finding_id", "category", "severity", "title", "detail", "evidence",
                    "suggested_action", "confidence"):
            self.assertIn(key, payload["findings"][0])

    def test_reports_are_utf8_without_bom(self):
        project = make_complete_project(self.work / "Project")
        log = write(self.work / "logs" / "editor.log", "MissingReferenceException: gone\n")
        report = diagnostics.run(project, [log], out_dir=self.work / "reports")
        for path in (report["artifacts"]["json"], report["artifacts"]["markdown"]):
            raw = Path(path).read_bytes()
            self.assertFalse(raw.startswith(b"\xef\xbb\xbf"), f"{path} must not start with a BOM")
            raw.decode("utf-8")

    def test_markdown_report_has_russian_table_and_evidence(self):
        project = make_complete_project(self.work / "Project")
        log = write(self.work / "logs" / "editor.log",
                    "Assets/A.cs(1,1): error CS0246: missing type\n")
        report = diagnostics.run(project, [log], out_dir=self.work / "reports")
        markdown = Path(report["artifacts"]["markdown"]).read_text(encoding="utf-8")
        self.assertIn("| серьёзность | категория | что не так | доказательство файл:строка | что делать |",
                      markdown)
        self.assertIn("только чтение", markdown)
        self.assertIn("error CS0246", markdown)
        self.assertIn(":1", markdown)
        self.assertIn("editor.log", markdown)

    def test_markdown_reports_absence_of_findings(self):
        log = write(self.work / "clean.log", "[Licensing::Module] Successfully updated license\n")
        report = diagnostics.run(None, [log])
        markdown = diagnostics.render_markdown(report)
        self.assertIn("Находок нет", markdown)
        self.assertIn("— (инвентарь не запускался)", markdown)

    def test_report_inventory_metadata_is_present(self):
        project = make_complete_project(self.work / "Project")
        report = diagnostics.run(project, [])
        self.assertEqual(report["project"]["editor_version"], "6000.3.9f1")
        self.assertEqual(report["project"]["editor_revision"], "7a9955a4f2fa")
        self.assertEqual(report["project"]["assets"]["scenes"], ["Main.unity"])
        self.assertEqual(report["project"]["manifest"]["dependency_count"], 1)
        self.assertEqual(report["project"]["build_settings"]["scenes"], ["Assets/Main.unity"])
        self.assertEqual(report["summary"]["findings"], 0)
        self.assertEqual(report["logs"], [])


class DeterminismTests(TempCase):
    def test_repeated_runs_produce_identical_finding_ids(self):
        log = write(self.work / "log.log",
                    "Curl error 35: Cert verify failed\n"
                    "error CS0246: missing type\n"
                    "NullReferenceException: boom\n")
        first = diagnostics.build_report(None, [log])
        second = diagnostics.build_report(None, [log])
        self.assertEqual([item["finding_id"] for item in first["findings"]],
                         [item["finding_id"] for item in second["findings"]])
        self.assertEqual([item["confidence"] for item in first["findings"]],
                         [item["confidence"] for item in second["findings"]])

    def test_severity_ordering_is_critical_first(self):
        log = write(self.work / "log.log",
                    "Curl error 42: Callback aborted\n"
                    "Unhandled exception. System.ObjectDisposedException: late\n"
                    "NullReferenceException: boom\n")
        report = diagnostics.build_report(None, [log])
        severities = [item["severity"] for item in report["findings"]]
        self.assertEqual(severities[0], "critical")
        self.assertEqual(severities, sorted(severities,
                                            key=lambda value: diagnostics.SEVERITY_RANK[value]))


class CliTests(TempCase):
    def run_cli(self, argv: list) -> tuple:
        """Run ``diagnose.main`` with stdout and stderr captured."""
        import contextlib
        import diagnose
        import io

        out, err = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            code = diagnose.main(argv)
        return code, out.getvalue(), err.getvalue()

    def test_cli_writes_reports_and_returns_zero(self):
        project = make_complete_project(self.work / "Project")
        first = write(self.work / "logs" / "a.log", "error CS1002: ; expected\n")
        second = write(self.work / "logs" / "b.log", "Curl error 42: Callback aborted\n")
        out = self.work / "out"
        code, stdout, _ = self.run_cli(["--project", str(project),
                                        "--logs", f"{first},{second}",
                                        "--out", str(out)])
        self.assertEqual(code, 0)
        self.assertIn("Диагностика AICore", stdout)
        self.assertIn("находки: 2", stdout)
        self.assertEqual(len(list(out.glob("diagnose-*.json"))), 1)
        self.assertEqual(len(list(out.glob("diagnose-*.md"))), 1)
        payload = json.loads(next(out.glob("diagnose-*.json")).read_text(encoding="utf-8"))
        self.assertEqual(payload["summary"]["error"], 1)
        self.assertEqual(payload["summary"]["info"], 1)
        self.assertEqual(len(payload["logs"]), 2)

    def test_cli_requires_persist_dependencies(self):
        with self.assertRaises(SystemExit):
            self.run_cli(["--project", str(self.work), "--logs", "x.log",
                          "--out", str(self.work / "out"), "--persist"])
        self.assertFalse((self.work / "out").exists())

    def test_cli_rejects_missing_log(self):
        code, _, stderr = self.run_cli(["--project", str(self.work), "--logs", "missing.log",
                                        "--out", str(self.work / "out")])
        self.assertEqual(code, 1)
        self.assertIn("not found", stderr)

    def test_cli_refuses_persist_without_database(self):
        log = write(self.work / "editor.log", "error CS1002: ; expected\n")
        with self.assertRaises(SystemExit) as exit_info:
            self.run_cli(["--project", str(self.work), "--logs", str(log),
                          "--out", str(self.work / "out"), "--persist", "--world", "w1"])
        self.assertEqual(exit_info.exception.code, 2, "a usage error must not look like a run")
        self.assertFalse((self.work / "out").exists(), "nothing may be written on a usage error")

    def test_cli_persist_writes_into_the_database(self):
        project = make_complete_project(self.work / "Project")
        log = write(self.work / "logs" / "editor.log", "error CS1002: ; expected\n")
        db = self.work / "brain.sqlite3"
        code, stdout, _ = self.run_cli(["--project", str(project), "--logs", str(log),
                                        "--out", str(self.work / "out"), "--persist",
                                        "--db", str(db), "--world", "world-1"])
        self.assertEqual(code, 0)
        self.assertIn("память:", stdout)
        self.assertTrue(db.is_file())
        connection = sqlite3.connect(db)
        count = connection.execute(
            "SELECT COUNT(*) FROM facts WHERE world='world-1'").fetchone()[0]
        connection.close()
        self.assertGreaterEqual(count, 3)

    def test_cli_json_mode_prints_the_report(self):
        project = make_complete_project(self.work / "Project")
        log = write(self.work / "logs" / "editor.log", "error CS1002: ; expected\n")
        code, stdout, _ = self.run_cli(["--project", str(project), "--logs", str(log),
                                        "--out", str(self.work / "out"), "--json"])
        self.assertEqual(code, 0)
        payload = json.loads(stdout)
        self.assertEqual(payload["summary"]["error"], 1)
        self.assertEqual(payload["summary"]["findings"], 1)

    def test_cli_accepts_repeated_logs_flags(self):
        project = make_complete_project(self.work / "Project")
        first = write(self.work / "logs" / "a.log", "error CS1002: ; expected\n")
        second = write(self.work / "logs" / "b.log", "NullReferenceException: boom\n")
        code, _, _ = self.run_cli(["--project", str(project), "--logs", str(first),
                                   "--logs", str(second), "--out", str(self.work / "out")])
        self.assertEqual(code, 0)
        payload = json.loads(next((self.work / "out").glob("diagnose-*.json"))
                             .read_text(encoding="utf-8"))
        self.assertEqual(len(payload["logs"]), 2)
        self.assertEqual(payload["summary"]["findings"], 2)


class DocumentationTests(unittest.TestCase):
    def test_every_rule_is_documented(self):
        """DIAGNOSTICS.md must list every rule, so the docs cannot drift."""
        doc = (TEST_ROOT.parent.parent / "DIAGNOSTICS.md").read_text(encoding="utf-8")
        rule_ids = {rule.rule_id for rule in diagnostics.RULES}
        rule_ids.add("runtime.unhandled-exception")
        for rule_id in sorted(rule_ids):
            self.assertIn(f"`{rule_id}`", doc, f"{rule_id} is missing from DIAGNOSTICS.md")
    def test_the_real_project_is_still_inspected(self):
        """The inventory must keep working on the real tree, whatever it finds."""
        if UNITY_PROJECT is None:
            self.skipTest(__import__("projectroot").REASON)
        metadata, _findings = diagnostics.inventory_project(UNITY_PROJECT)
        self.assertTrue(metadata["exists"])
        self.assertGreaterEqual(metadata["assets"]["files"], 1)

    def test_inventory_rule_ids_are_documented(self):
        doc = (TEST_ROOT.parent.parent / "DIAGNOSTICS.md").read_text(encoding="utf-8")
        source = (BRAIN_DIR / "diagnostics.py").read_text(encoding="utf-8")
        import re as _re
        for rule_id in sorted(set(_re.findall(r'"((?:project_layout|package|missing_asset|environment)\.[a-z0-9-]+)"',
                                              source))):
            self.assertIn(f"`{rule_id}`", doc, f"{rule_id} is missing from DIAGNOSTICS.md")

    def test_documented_categories_match_the_code(self):
        doc = (TEST_ROOT.parent.parent / "DIAGNOSTICS.md").read_text(encoding="utf-8")
        for category in diagnostics.CATEGORIES:
            self.assertIn(f"`{category}`", doc, f"category {category} is not documented")

    def test_documented_ignore_reasons_match_the_code(self):
        doc = (TEST_ROOT.parent.parent / "DIAGNOSTICS.md").read_text(encoding="utf-8")
        for _pattern, reason in diagnostics.IGNORED_PATTERNS:
            self.assertIn(reason, doc, f"ignore reason not documented: {reason}")


class DefaultConsoleLogDiscoveryTests(unittest.TestCase):
    """The observer must find the editor console and project logs on its own."""

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.root = Path(self._tmp.name)
        self._saved = os.environ.get(diagnostics.EDITOR_LOG_ENV)
        os.environ[diagnostics.EDITOR_LOG_ENV] = str(self.root / 'user')
        self.addCleanup(self._restore)

    def _restore(self):
        if self._saved is None:
            os.environ.pop(diagnostics.EDITOR_LOG_ENV, None)
        else:
            os.environ[diagnostics.EDITOR_LOG_ENV] = self._saved

    def _write(self, relative, text='a line' + chr(10)):
        path = self.root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding='utf-8')
        return path

    def _project(self):
        project = self.root / 'Project'
        (project / 'Assets').mkdir(parents=True, exist_ok=True)
        return project

    def test_editor_log_dir_follows_the_environment_variable(self):
        self.assertEqual(diagnostics.editor_log_dir(), self.root / 'user' / 'Unity' / 'Editor')

    def test_missing_everything_yields_an_empty_list(self):
        self.assertEqual(diagnostics.default_console_logs(self._project()), [])

    def test_discovers_editor_log_and_previous_log(self):
        self._write('user/Unity/Editor/Editor.log')
        self._write('user/Unity/Editor/Editor-prev.log')
        found = diagnostics.default_console_logs(self._project())
        self.assertEqual(len(found), 2)
        self.assertTrue(found[0].endswith('Editor.log'))
        self.assertTrue(found[1].endswith('Editor-prev.log'))

    def test_discovers_project_logs_directory(self):
        project = self._project()
        self._write('Project/Logs/AssetImportWorker0.log')
        self._write('Project/Logs/Packages-Update.log')
        self._write('Project/Logs/notes.txt')
        found = diagnostics.default_console_logs(project)
        self.assertEqual(len(found), 2)
        self.assertTrue(all(item.endswith('.log') for item in found))

    def test_returns_only_existing_files_and_never_duplicates(self):
        self._write('user/Unity/Editor/Editor.log')
        self._write('Project/Logs/AssetImportWorker0.log')
        found = diagnostics.default_console_logs(self._project())
        self.assertEqual(len(found), len(set(item.casefold() for item in found)))
        self.assertTrue(all(os.path.isfile(item) for item in found))

    def test_a_directory_named_like_a_log_is_not_returned(self):
        (self.root / 'user' / 'Unity' / 'Editor' / 'Editor.log').mkdir(parents=True)
        self.assertEqual(diagnostics.default_console_logs(self._project()), [])


if __name__ == "__main__":
    unittest.main()
