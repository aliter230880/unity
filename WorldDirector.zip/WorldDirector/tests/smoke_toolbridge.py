"""Live smoke test: start the real brain over HTTP and call tools through the bridge."""
import json
import os
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
from pathlib import Path

PROJECT = Path(r"D:\Work\Unity\Projects\AICore_0.5")
WORLD_DIR = PROJECT / "AICore" / "WorldDirector"
PORT = 8791
TOKEN = "smoke-token-0123456789"


def call(method, path, payload=None, timeout=15):
    url = "http://127.0.0.1:%d%s" % (PORT, path)
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(url, data=data, method=method)
    request.add_header("Authorization", "Bearer " + TOKEN)
    if data is not None:
        request.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return response.status, json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as error:
        return error.code, json.loads(error.read().decode("utf-8"))


def main():
    tmp = tempfile.TemporaryDirectory()
    db = Path(tmp.name) / "brain.sqlite3"
    env = dict(os.environ, AICORE_TOKEN=TOKEN, PYTHONIOENCODING="utf-8")
    process = subprocess.Popen(
        [sys.executable, "brain/server.py", "--port", str(PORT), "--db", str(db),
         "--project", str(PROJECT)],
        cwd=str(WORLD_DIR), env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    try:
        ready = False
        for _ in range(40):
            try:
                status, _ = call("GET", "/health", timeout=2)
                if status == 200:
                    ready = True
                    break
            except Exception:
                time.sleep(0.25)
        print("server ready:", ready)
        if not ready:
            print(process.stdout.read())
            return 1

        status, catalogue = call("GET", "/v1/tools")
        print("GET /v1/tools ->", status, "tools:", len(catalogue["tools"]))

        for tool, params in (("unity.console.tail", {"lines": 2}),
                             ("unity.project.inventory", {}),
                             ("unity.scene.report", {}),
                             ("brain.knowledge.facts", {"limit": 5}),
                             ("no.such.tool", {})):
            status, body = call("POST", "/v1/tools/call", {"tool": tool, "params": params})
            state = "ok" if body.get("ok") else "refused"
            print("  %-26s %s %s  %s" % (tool, status, state, (body.get("error") or "")[:80]))

        status, body = call("POST", "/v1/tools/call",
                            {"tool": "unity.scene.report", "params": {"report": "C:/Windows/win.ini"}})
        print("  escape attempt             %s %s  %s" % (status, body.get("ok"), (body.get("error") or "")[:80]))
        return 0
    finally:
        process.terminate()
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            process.kill()
        tmp.cleanup()


if __name__ == "__main__":
    raise SystemExit(main())
