"""The run lock: one cycle at a time, and it is always given back."""
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

WORLD_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(WORLD_DIR / "tools"))

import run_autonomous_cycle as cycle  # noqa: E402


class RunLock(unittest.TestCase):
    def setUp(self):
        self._temp = tempfile.TemporaryDirectory()
        self.path = Path(self._temp.name) / cycle.LOCK_NAME

    def tearDown(self):
        self._temp.cleanup()

    def test_one_holder_at_a_time(self):
        first = cycle.acquire_lock(self.path)
        self.assertTrue(first["held"])
        second = cycle.acquire_lock(self.path)
        self.assertFalse(second["held"])
        self.assertEqual(second["holder"]["pid"], os.getpid())
        self.assertIn("started", second["holder"])

    def test_release_lets_the_next_run_in(self):
        cycle.acquire_lock(self.path)
        cycle.release_lock(self.path)
        self.assertFalse(self.path.exists())
        self.assertTrue(cycle.acquire_lock(self.path)["held"])

    def test_release_is_forgiving(self):
        cycle.release_lock(self.path)  # never held
        cycle.release_lock(self.path)  # twice
        self.assertFalse(self.path.exists())

    def test_an_unreadable_lock_still_locks(self):
        self.path.write_text("not json at all", encoding="utf-8")
        second = cycle.acquire_lock(self.path)
        self.assertFalse(second["held"])
        self.assertTrue(second["holder"].get("unreadable"))

    def test_the_lock_names_its_subject(self):
        cycle.acquire_lock(self.path)
        payload = json.loads(self.path.read_text(encoding="utf-8"))
        self.assertEqual(payload["subject"], cycle.SUBJECT)

    def test_the_lock_lives_inside_the_project(self):
        # Not a style point: a lock outside the project it guards cannot be found by the
        # next run, and the two runs would still race.
        self.assertEqual(cycle.LOCK_NAME, "autonomous-cycle.lock")
        self.assertTrue(str(cycle.OUT).startswith(str(cycle.PROJECT)))




class AggregateOutcome(unittest.TestCase):
    """A busy wake must not be reported to a scheduler as a quiet one."""

    def test_converging_without_changes_is_quiet(self):
        self.assertEqual(cycle.aggregate_outcome("converged", False), "converged")

    def test_applying_then_converging_is_not_quiet(self):
        word = cycle.aggregate_outcome("converged", True)
        self.assertEqual(word, "converged-after-applying")
        sys.path.insert(0, str(WORLD_DIR / "brain"))
        import schedule as brain_schedule
        self.assertNotIn(word, brain_schedule.QUIET_OUTCOMES)

    def test_a_change_is_never_rewritten(self):
        for word in cycle.CHANGING_OUTCOMES:
            self.assertEqual(cycle.aggregate_outcome(word, True), word)

    def test_an_unfinished_run_that_changed_is_not_quiet(self):
        word = cycle.aggregate_outcome("incomplete", True)
        self.assertEqual(word, "incomplete-after-applying")
        sys.path.insert(0, str(WORLD_DIR / "brain"))
        import schedule as brain_schedule
        self.assertNotIn(word, brain_schedule.QUIET_OUTCOMES)




class DriverReportsThroughLastOutcome(unittest.TestCase):
    """A scheduler reads LAST_OUTCOME; a refusal that only exists as a local variable is a lie."""

    def test_a_second_run_reports_the_refusal(self):
        with tempfile.TemporaryDirectory() as folder:
            project = Path(folder)
            scene_dir = project / "AICore" / "outputs" / "scene"
            scene_dir.mkdir(parents=True)
            (scene_dir / cycle.LOCK_NAME).write_text('{"pid": 1}', encoding="utf-8")
            cycle.LAST_OUTCOME = ""
            saved_out, saved_ledger = cycle.OUT, cycle.LEDGER
            try:
                code = cycle.main(["--project", str(project), "--auto"])
            finally:
                # main() moves the module-wide output paths; leave them where they were,
                # or the next test inherits a temporary directory.
                cycle.OUT, cycle.LEDGER = saved_out, saved_ledger
            self.assertEqual(code, 1)
            self.assertEqual(cycle.LAST_OUTCOME, "refused-by-lock")


if __name__ == "__main__":
    unittest.main(verbosity=2)
