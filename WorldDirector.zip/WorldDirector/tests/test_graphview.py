"""Tests for reading a scene's shape out of the relation graph.

The identifier cases are copied from a real map built by the editor: if the two schemes
ever drift apart, the graph stops joining and these tests fail first.
"""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "brain"))

import graphview  # noqa: E402

SCENE = "Assets/AICoreSandbox/SandboxScene.unity"
SCENE_ID = "scene.Assets_AICoreSandbox_SandboxScene.unity"
REAL_IDS = [
    ("scene", "Assets/AICoreSandbox/SandboxScene.unity",
     "scene.Assets_AICoreSandbox_SandboxScene.unity"),
    ("object", "Assets/AICoreSandbox/SandboxScene.unity#Main Camera",
     "object.Assets_AICoreSandbox_SandboxScene.unity_Main_Camera"),
    ("asset", "Assets/AICoreSandbox/SandboxScene.unity",
     "asset.Assets_AICoreSandbox_SandboxScene.unity"),
    ("prefab", "Assets/Prefabs/Crate.prefab", "prefab.Assets_Prefabs_Crate.prefab"),
]

RELATIONS = [
    {"source": SCENE_ID, "target": "object.A", "type": "contains"},
    {"source": SCENE_ID, "target": "object.B", "type": "contains"},
    {"source": "object.A", "target": "Camera", "type": "has_component"},
    {"source": "object.A", "target": "true", "type": "observed"},
    {"source": "object.B", "target": "true", "type": "has_missing_script"},
    {"source": "scene.Other", "target": SCENE_ID, "type": "depends_on"},
]


class IdentifierTests(unittest.TestCase):
    def test_the_scheme_matches_the_editor(self):
        for kind, path, expected in REAL_IDS:
            self.assertEqual(graphview.identifier(kind, path), expected,
                             "%s %s" % (kind, path))

    def test_awkward_characters_become_underscores(self):
        self.assertEqual(graphview.identifier("object", "Assets/A/B C#Root"),
                         "object.Assets_A_B_C_Root")

    def test_a_very_long_path_is_shortened(self):
        long_id = graphview.identifier("asset", "Assets/" + "x" * 300)
        self.assertLessEqual(len(long_id), graphview.MAX_IDENTIFIER)

    def test_missing_pieces_do_not_crash(self):
        self.assertEqual(graphview.identifier("", ""), ".")


class SummariseTests(unittest.TestCase):
    def test_the_scene_is_described(self):
        context = graphview.summarise(SCENE_ID, RELATIONS)
        self.assertEqual(context["objects"], 2)
        self.assertEqual(context["observed"], 1)
        self.assertEqual(context["missing_scripts"], 1)
        self.assertEqual(context["dependents"], 1)

    def test_a_scene_with_nothing_observed_says_so(self):
        relations = [{"source": SCENE_ID, "target": "object.A", "type": "contains"}]
        self.assertEqual(graphview.summarise(SCENE_ID, relations)["observed"], 0)

    def test_another_scenes_objects_are_not_counted(self):
        relations = [{"source": "scene.Elsewhere", "target": "object.Z", "type": "contains"}]
        self.assertEqual(graphview.summarise(SCENE_ID, relations)["objects"], 0)

    def test_relations_that_only_depend_are_not_objects(self):
        relations = [{"source": "scene.Other", "target": SCENE_ID, "type": "depends_on"}]
        context = graphview.summarise(SCENE_ID, relations)
        self.assertEqual(context["objects"], 0)
        self.assertEqual(context["dependents"], 1)

    def test_missing_pieces_do_not_crash(self):
        self.assertEqual(graphview.summarise(SCENE_ID, None)["objects"], 0)
        self.assertEqual(graphview.summarise(SCENE_ID, [{}, "junk", None])["objects"], 0)

    def test_is_populated_tells_an_empty_graph_from_a_real_one(self):
        self.assertFalse(graphview.is_populated(None))
        self.assertFalse(graphview.is_populated({"objects": 0}))
        self.assertTrue(graphview.is_populated({"objects": 5}))


if __name__ == "__main__":
    unittest.main()
