"""Tests for the guarded write tools (phase 3/4): dry-run, backup, permits, confinement.

Run: python tests/test_writetools.py
"""
from __future__ import annotations

import json
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from pathlib import Path

TESTS_DIR = Path(__file__).resolve().parent
BRAIN_DIR = TESTS_DIR.parent / "brain"
sys.path.insert(0, str(BRAIN_DIR))

import approval  # noqa: E402
import server  # noqa: E402
import tools  # noqa: E402

MASTER = "approval-token-0123456789"
BRIDGE_TOKEN = "bridge-token-0123456789"


class WriteToolCase(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.project = Path(self._tmp.name) / "Project"
        self.outputs = self.project / "AICore" / "outputs"
        self.outputs.mkdir(parents=True)
        self.db = self.project / "brain.sqlite3"

    def issue_full(self, tool, path, ttl=300):
        result = tools.execute_scoped("brain.approval.issue",
                                      {"tool": tool, "path": path, "ttl_seconds": ttl,
                                       "subject": "operator-test", "master": MASTER},
                                      project_root=self.project, approval=MASTER, db_path=self.db,
                                      allow_write=True, confine=False)
        self.assertTrue(result.ok, result.error)
        return result.data

    def issue(self, tool, path, ttl=300):
        return self.issue_full(tool, path, ttl)["token"]

    def run_tool(self, name, params):
        return tools.execute_scoped(name, params, project_root=self.project,
                                    approval=MASTER, allow_write=True, confine=False,
                                    db_path=self.db)

    def write(self, path, content, **extra):
        params = {"path": path, "content": content, "dry_run": False,
                  "approval": self.issue("outputs.write_text", path)}
        params.update(extra)
        return self.run_tool("outputs.write_text", params)


class DryRunTests(WriteToolCase):
    def test_dry_run_is_the_default_and_writes_nothing(self):
        result = self.run_tool("outputs.write_text", {"path": "notes.txt", "content": "hello"})
        self.assertTrue(result.ok, result.error)
        self.assertTrue(result.data["dry_run"])
        self.assertFalse((self.outputs / "notes.txt").exists())

    def test_dry_run_does_not_need_a_permit(self):
        result = self.run_tool("outputs.write_text", {"path": "notes.txt", "content": "hello"})
        self.assertTrue(result.ok, result.error)

    def test_dry_run_reports_the_planned_target(self):
        result = self.run_tool("outputs.write_text", {"path": "deep/notes.txt", "content": "abc"})
        self.assertEqual(result.data["would_write"]["bytes"], 3)


class PermitTests(WriteToolCase):
    def test_the_master_secret_alone_is_not_a_licence_to_write(self):
        result = self.run_tool("outputs.write_text",
                               {"path": "notes.txt", "content": "x", "dry_run": False,
                                "approval": MASTER})
        self.assertFalse(result.ok)
        self.assertIn("permit", result.error)
        self.assertFalse((self.outputs / "notes.txt").exists())

    def test_a_write_without_any_permit_is_refused(self):
        result = self.run_tool("outputs.write_text",
                               {"path": "notes.txt", "content": "x", "dry_run": False})
        self.assertFalse(result.ok)

    def test_a_permit_cannot_be_reused_for_another_path(self):
        permit = self.issue("outputs.write_text", "notes.txt")
        result = self.run_tool("outputs.write_text",
                               {"path": "other.txt", "content": "x", "dry_run": False,
                                "approval": permit})
        self.assertFalse(result.ok)
        self.assertIn("different target", result.error)

    def test_a_permit_for_another_tool_is_refused(self):
        permit = self.issue("outputs.write_text", "notes.txt")
        result = self.run_tool("outputs.revert",
                               {"backup": permit, "dry_run": False, "approval": permit})
        self.assertFalse(result.ok)

    def test_an_expired_permit_is_refused(self):
        permit = self.issue("outputs.write_text", "notes.txt", ttl=1)
        import time
        time.sleep(1 + approval.CLOCK_SKEW_SECONDS + 1)
        result = self.run_tool("outputs.write_text",
                               {"path": "notes.txt", "content": "x", "dry_run": False,
                                "approval": permit})
        self.assertFalse(result.ok)
        self.assertIn("expired", result.error)

    def test_issuing_needs_the_operator_secret(self):
        result = self.run_tool("brain.approval.issue",
                               {"tool": "outputs.write_text", "path": "notes.txt",
                                "subject": "operator-test", "master": "wrong-secret-0123456789"})
        self.assertFalse(result.ok)
        self.assertIn("operator secret", result.error)

    def test_permits_are_only_issued_for_write_tools(self):
        result = self.run_tool("brain.approval.issue",
                               {"tool": "unity.console.tail", "path": "x", "subject": "operator-test", "master": MASTER})
        self.assertFalse(result.ok)
        self.assertIn("write tools", result.error)

    def test_a_permit_can_only_be_spent_once(self):
        permit = self.issue("outputs.write_text", "notes.txt")
        first = self.run_tool("outputs.write_text",
                              {"path": "notes.txt", "content": "a", "dry_run": False,
                               "approval": permit})
        self.assertTrue(first.ok, first.error)
        second = self.run_tool("outputs.write_text",
                               {"path": "notes.txt", "content": "b", "overwrite": True,
                                "dry_run": False, "approval": permit})
        self.assertFalse(second.ok)
        self.assertIn("already been used", second.error)
        self.assertEqual((self.outputs / "notes.txt").read_text(encoding="utf-8"), "a")

    def test_a_revoked_permit_is_refused(self):
        issued = self.issue_full("outputs.write_text", "notes.txt")
        revoked = self.run_tool("brain.approval.revoke",
                                {"nonce": issued["nonce"], "subject": "operator-test", "master": MASTER})
        self.assertTrue(revoked.ok, revoked.error)
        write = self.run_tool("outputs.write_text",
                              {"path": "notes.txt", "content": "x", "dry_run": False,
                               "approval": issued["token"]})
        self.assertFalse(write.ok)
        self.assertIn("revoked", write.error)

    def test_revoking_everything_before_now_blocks_earlier_permits(self):
        issued = self.issue_full("outputs.write_text", "notes.txt")
        self.run_tool("brain.approval.revoke", {"before_now": True, "subject": "operator-test", "master": MASTER})
        write = self.run_tool("outputs.write_text",
                              {"path": "notes.txt", "content": "x", "dry_run": False,
                               "approval": issued["token"]})
        self.assertFalse(write.ok)
        self.assertIn("revoked", write.error)

    def test_a_permit_issued_after_a_blanket_revocation_still_works(self):
        self.run_tool("brain.approval.revoke", {"before_now": True, "subject": "operator-test", "master": MASTER})
        result = self.write("notes.txt", "after")
        self.assertTrue(result.ok, result.error)

    def test_revocation_is_recorded_in_the_write_log(self):
        issued = self.issue_full("outputs.write_text", "notes.txt")
        self.run_tool("brain.approval.revoke", {"nonce": issued["nonce"], "subject": "operator-test", "master": MASTER})
        raw = (self.project / "AI" / "aicore-writes.log").read_text(encoding="utf-8")
        self.assertIn("revoke_permit", raw)
        self.assertNotIn(issued["token"], raw)

    def test_a_write_permit_must_have_a_subject(self):
        result = self.run_tool("brain.approval.issue",
                               {"tool": "outputs.write_text", "path": "notes.txt",
                                "master": MASTER})
        self.assertFalse(result.ok)
        self.assertIn("subject", result.error)

    def test_the_write_log_records_the_subject(self):
        self.write("notes.txt", "hello")
        entry = json.loads((self.project / "AI" / "aicore-writes.log")
                           .read_text(encoding="utf-8").strip().splitlines()[-1])
        self.assertEqual(entry["subject"], "operator-test")

    def test_the_write_log_records_who_revoked(self):
        issued = self.issue_full("outputs.write_text", "notes.txt")
        self.run_tool("brain.approval.revoke",
                      {"nonce": issued["nonce"], "subject": "operator-2", "master": MASTER})
        entry = json.loads((self.project / "AI" / "aicore-writes.log")
                           .read_text(encoding="utf-8").strip().splitlines()[-1])
        self.assertEqual(entry["subject"], "operator-2")
        self.assertEqual(entry["action"], "revoke_permit")

    def test_write_tools_are_refused_without_allow_write(self):
        permit = self.issue("outputs.write_text", "notes.txt")
        result = tools.execute_scoped("outputs.write_text",
                                      {"path": "notes.txt", "content": "x", "dry_run": False,
                                       "approval": permit},
                                      project_root=self.project, approval=MASTER, allow_write=False)
        self.assertFalse(result.ok)
        self.assertIn("read-only tools", result.error)


class WriteTests(WriteToolCase):
    def test_real_write_creates_the_file(self):
        result = self.write("notes.txt", "hello")
        self.assertTrue(result.ok, result.error)
        self.assertFalse(result.data["dry_run"])
        self.assertIsNone(result.data["backup"])
        self.assertEqual((self.outputs / "notes.txt").read_text(encoding="utf-8"), "hello")

    def test_overwrite_needs_an_explicit_flag(self):
        self.write("notes.txt", "old")
        result = self.write("notes.txt", "new")
        self.assertFalse(result.ok)
        self.assertIn("already exists", result.error)
        self.assertEqual((self.outputs / "notes.txt").read_text(encoding="utf-8"), "old")

    def test_overwrite_creates_a_backup_first(self):
        self.write("notes.txt", "old")
        result = self.write("notes.txt", "new", overwrite=True)
        self.assertTrue(result.ok, result.error)
        backup = Path(result.data["backup"])
        self.assertEqual(backup.read_text(encoding="utf-8"), "old")
        self.assertEqual((self.outputs / "notes.txt").read_text(encoding="utf-8"), "new")

    def test_two_backups_of_one_file_do_not_collide(self):
        self.write("notes.txt", "first")
        first = self.write("notes.txt", "second", overwrite=True).data["backup"]
        second = self.write("notes.txt", "third", overwrite=True).data["backup"]
        self.assertNotEqual(first, second)
        self.assertEqual(Path(first).read_text(encoding="utf-8"), "first")
        self.assertEqual(Path(second).read_text(encoding="utf-8"), "second")

    def test_write_log_records_the_change(self):
        self.write("notes.txt", "hello")
        log_path = self.project / "AI" / "aicore-writes.log"
        entry = json.loads(log_path.read_text(encoding="utf-8").strip().splitlines()[-1])
        self.assertEqual(entry["action"], "write_text")
        self.assertEqual(entry["bytes"], 5)

    def test_the_permit_never_reaches_the_log(self):
        permit = self.issue("outputs.write_text", "notes.txt")
        self.run_tool("outputs.write_text",
                      {"path": "notes.txt", "content": "x", "dry_run": False, "approval": permit})
        raw = (self.project / "AI" / "aicore-writes.log").read_text(encoding="utf-8")
        self.assertNotIn(permit, raw)
        self.assertNotIn(MASTER, raw)


class ConfinementTests(WriteToolCase):
    def test_relative_escape_is_refused(self):
        result = self.run_tool("outputs.write_text",
                               {"path": "../../outside.txt", "content": "x", "dry_run": False})
        self.assertFalse(result.ok)
        self.assertIn("must stay inside AICore/outputs", result.error)

    def test_absolute_path_outside_is_refused(self):
        outside = Path(self._tmp.name) / "outside.txt"
        result = self.run_tool("outputs.write_text",
                               {"path": str(outside), "content": "x", "dry_run": False})
        self.assertFalse(result.ok)
        self.assertFalse(outside.exists())

    def test_a_permit_cannot_authorise_an_escape(self):
        result = self.run_tool("brain.approval.issue",
                               {"tool": "outputs.write_text", "path": "../../escape.txt",
                                "subject": "operator-test", "master": MASTER})
        self.assertFalse(result.ok)
        self.assertIn("must stay inside AICore/outputs", result.error)

    def test_oversized_content_is_refused(self):
        result = self.run_tool("outputs.write_text",
                               {"path": "big.txt", "content": "x" * (tools.MAX_WRITE_BYTES + 1),
                                "dry_run": False})
        self.assertFalse(result.ok)
        self.assertIn("exceeds", result.error)


class RevertTests(WriteToolCase):
    def _backup_of(self):
        self.write("notes.txt", "first")
        return self.write("notes.txt", "second", overwrite=True).data["backup"]

    def revert(self, backup, **extra):
        params = {"backup": backup, "dry_run": False,
                  "approval": self.issue("outputs.revert", backup)}
        params.update(extra)
        return self.run_tool("outputs.revert", params)

    def test_revert_dry_run_reports_without_restoring(self):
        backup = self._backup_of()
        result = self.run_tool("outputs.revert", {"backup": backup})
        self.assertTrue(result.data["dry_run"])
        self.assertEqual((self.outputs / "notes.txt").read_text(encoding="utf-8"), "second")

    def test_revert_restores_the_previous_content(self):
        backup = self._backup_of()
        result = self.revert(backup)
        self.assertTrue(result.ok, result.error)
        self.assertEqual((self.outputs / "notes.txt").read_text(encoding="utf-8"), "first")

    def test_revert_needs_a_permit(self):
        backup = self._backup_of()
        result = self.run_tool("outputs.revert", {"backup": backup, "dry_run": False})
        self.assertFalse(result.ok)
        self.assertIn("permit", result.error)

    def test_revert_outside_the_backup_area_is_refused(self):
        outsider = Path(self._tmp.name) / "loose.txt"
        outsider.write_text("x", encoding="utf-8")
        result = self.run_tool("outputs.revert",
                               {"backup": str(outsider), "dry_run": False, "approval": MASTER})
        self.assertFalse(result.ok)
        self.assertIn("must stay inside AI/backups", result.error)


class BridgeWriteTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.root = Path(self._tmp.name)
        self.project = self.root / "Project"
        (self.project / "AICore" / "outputs").mkdir(parents=True)
        self.db = self.root / "brain.sqlite3"
        self.brain = server.Brain(self.db)
        self.addCleanup(self.brain.close)
        self.server = server.make_server(self.brain, BRIDGE_TOKEN, 0, project_root=self.project,
                                         scope_db=self.db, approval_token=MASTER)
        self.addCleanup(self.server.server_close)
        threading.Thread(target=self.server.serve_forever, daemon=True).start()
        self.addCleanup(self.server.shutdown)
        self.base = "http://127.0.0.1:%d" % self.server.server_address[1]

    def call(self, payload):
        request = urllib.request.Request(self.base + "/v1/tools/call",
                                         data=json.dumps(payload).encode("utf-8"), method="POST")
        request.add_header("Content-Type", "application/json")
        request.add_header("Authorization", "Bearer " + BRIDGE_TOKEN)
        try:
            with urllib.request.urlopen(request, timeout=5) as response:
                return response.status, json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as error:
            return error.code, json.loads(error.read().decode("utf-8"))

    def test_write_over_the_bridge_without_a_permit_is_refused(self):
        status, body = self.call({"tool": "outputs.write_text",
                                  "params": {"path": "x.txt", "content": "y", "dry_run": False}})
        self.assertEqual(status, 200)
        self.assertFalse(body["ok"])
        self.assertIn("permit", body["error"])
        self.assertFalse((self.project / "AICore" / "outputs" / "x.txt").exists())

    def test_issue_then_write_over_the_bridge(self):
        status, issued = self.call({"tool": "brain.approval.issue",
                                    "params": {"tool": "outputs.write_text", "path": "x.txt",
                                               "subject": "operator-test", "master": MASTER}})
        self.assertEqual(status, 200)
        self.assertTrue(issued["ok"], issued)
        status, body = self.call({"tool": "outputs.write_text",
                                  "params": {"path": "x.txt", "content": "y", "dry_run": False,
                                             "approval": issued["data"]["token"]}})
        self.assertEqual(status, 200)
        self.assertTrue(body["ok"], body)
        self.assertEqual((self.project / "AICore" / "outputs" / "x.txt").read_text(encoding="utf-8"), "y")

    def test_escape_attempt_is_refused_even_when_issuing(self):
        status, body = self.call({"tool": "brain.approval.issue",
                                  "params": {"tool": "outputs.write_text", "path": "../../e.txt",
                                             "subject": "operator-test", "master": MASTER}})
        self.assertEqual(status, 200)
        self.assertFalse(body["ok"])
        self.assertIn("must stay inside AICore/outputs", body["error"])


if __name__ == "__main__":
    unittest.main()
