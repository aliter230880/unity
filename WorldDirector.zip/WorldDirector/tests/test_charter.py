"""Owner charter: verbs, catalogs and kinds the director may not grant itself."""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "brain"))

import charter  # noqa: E402


SPAWN = {"type": "spawn", "catalog_id": "crate"}
MOVE = {"type": "move", "catalog_id": "crate", "target_id": "npc-1"}
TRADE = {"type": "trade", "catalog_id": "crate"}


class CharterTests(unittest.TestCase):
    def test_default_admits_known_verbs_and_refuses_unknown(self):
        gate = charter.Charter()
        kept, reasons = gate.filter_actions([SPAWN, MOVE, TRADE])
        self.assertEqual(kept, [SPAWN, MOVE])
        self.assertTrue(any("trade" in item for item in reasons))

    def test_player_kind_is_forbidden_even_for_an_allowed_verb(self):
        gate = charter.Charter()
        kept, reasons = gate.filter_actions(
            [SPAWN], catalog=[{"id": "crate", "kind": "Player"}])
        self.assertEqual(kept, [])
        self.assertTrue(any("player" in item for item in reasons))

    def test_empty_allowed_catalogs_means_all_except_forbidden(self):
        gate = charter.Charter(forbidden_catalogs=("barrel",))
        kept, reasons = gate.filter_actions(
            [SPAWN, {"type": "spawn", "catalog_id": "barrel"}])
        self.assertEqual(kept, [SPAWN])
        self.assertTrue(any("barrel" in item for item in reasons))

    def test_whitelist_rejects_unlisted_catalogs(self):
        gate = charter.Charter(allowed_catalogs=("crate",))
        kept, _ = gate.filter_actions([SPAWN, {"type": "spawn", "catalog_id": "lamp"}])
        self.assertEqual(kept, [SPAWN])

    def test_cannot_grant_an_unknown_verb_in_the_charter_itself(self):
        with self.assertRaises(ValueError):
            charter.Charter(allowed_actions=("spawn", "trade"))

    def test_load_from_file_and_missing_env_path_fail_closed(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "charter.json"
            path.write_text(json.dumps({
                "allowed_actions": ["move"],
                "forbidden_kinds": ["player"],
                "can_self_expand": False,
            }), encoding="utf-8")
            loaded = charter.Charter.load(path)
            self.assertEqual(loaded.allowed_actions, ("move",))
            with self.assertRaises(ValueError):
                charter.Charter.load(env={"AICORE_CHARTER": str(Path(folder) / "missing.json")})

    def test_builtin_city111_charter_does_not_self_expand(self):
        loaded = charter.Charter.load()
        self.assertFalse(loaded.can_self_expand)
        self.assertEqual(set(loaded.allowed_actions), set(charter.KNOWN_ACTIONS))
        self.assertIn("player", loaded.forbidden_kinds)


if __name__ == "__main__":
    unittest.main()
