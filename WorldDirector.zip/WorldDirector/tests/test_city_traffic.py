"""Unity-free checks for the city traffic layer.

Run:  python AICore/WorldDirector/tests/test_city_traffic.py
Exit code 0 = all checks passed.

Everything here is derived from the scene probe dump (`AICore/outputs/city/city_geometry.json`)
and, when present, from the Unity self-test receipt (`AICore/outputs/city/city_traffic_receipt.json`).
No Unity, no Editor, no asset pack mutation.
"""
from __future__ import print_function

import io
import json
import math
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..'))
GEOM = os.path.join(ROOT, 'AICore', 'outputs', 'city', 'city_geometry.json')
RECEIPT = os.path.join(ROOT, 'AICore', 'outputs', 'city', 'city_traffic_receipt.json')

STREET_FAMILY = ('Lane', 'Intersection', 'Corner')
LANE_OFFSET = 3.3
LANE_TOLERANCE = 1.0
PAVEMENT_SHARE_MIN = 0.9

_results = []


def check(name, ok, detail=''):
    _results.append((name, bool(ok), detail))
    print('  [%s] %-58s %s' % ('ok  ' if ok else 'FAIL', name, detail))
    return bool(ok)


def load_records(path):
    with io.open(path, encoding='utf-8') as fh:
        data = json.load(fh)
    if isinstance(data, dict):
        for key in ('objects', 'items', 'records', 'dump', 'instances', 'roots'):
            if key in data and isinstance(data[key], list):
                return data[key]
        raise SystemExit('unexpected geometry dump: dict without a record list')
    return data


def rasterise(tiles):
    minx = min(t[1][0] - t[2][0] / 2.0 for t in tiles)
    maxx = max(t[1][0] + t[2][0] / 2.0 for t in tiles)
    minz = min(t[1][2] - t[2][2] / 2.0 for t in tiles)
    maxz = max(t[1][2] + t[2][2] / 2.0 for t in tiles)
    x0, z0 = int(math.floor(minx)) - 2, int(math.floor(minz)) - 2
    w = int(math.ceil(maxx) + 2 - x0) + 1
    h = int(math.ceil(maxz) + 2 - z0) + 1
    occ = bytearray(w * h)
    for _name, centre, size in tiles:
        for z in range(int(round(centre[2] - size[2] / 2.0)), int(round(centre[2] + size[2] / 2.0)) + 1):
            iz = z - z0
            if not 0 <= iz < h:
                continue
            row = iz * w
            for x in range(int(round(centre[0] - size[0] / 2.0)), int(round(centre[0] + size[0] / 2.0)) + 1):
                ix = x - x0
                if 0 <= ix < w:
                    occ[row + ix] = 1
    return occ, x0, z0, w, h


def paved(occ, x0, z0, w, h, x, z):
    ix, iz = int(round(x)) - x0, int(round(z)) - z0
    return 0 <= ix < w and 0 <= iz < h and bool(occ[iz * w + ix])


def longest_run(occ, x0, z0, w, h, horizontal, at):
    best = cur = 0
    n = w if horizontal else h
    for i in range(n):
        x, z = (x0 + i, at) if horizontal else (at, z0 + i)
        if paved(occ, x0, z0, w, h, x, z):
            cur += 1
            best = max(best, cur)
        else:
            cur = 0
    return best


def clusters(hits, gap=4):
    if not hits:
        return []
    out, start, prev = [], hits[0], hits[0]
    for h in hits[1:]:
        if h - prev <= gap:
            prev = h
            continue
        out.append((start + prev) // 2)
        start = prev = h
    out.append((start + prev) // 2)
    return out


def footprint_share(box, centre, size, yaw_deg):
    occ, x0, z0, w, h = box
    yaw = math.radians(yaw_deg)
    fwd = (math.sin(yaw), math.cos(yaw))
    side = (fwd[1], -fwd[0])
    half_l, half_w = size[2] / 2.0, size[0] / 2.0
    on = total = 0
    for i in range(-2, 3):
        for j in range(-2, 3):
            x = centre[0] + fwd[0] * (i * 0.5 * half_l) + side[0] * (j * 0.5 * half_w)
            z = centre[2] + fwd[1] * (i * 0.5 * half_l) + side[1] * (j * 0.5 * half_w)
            total += 1
            if paved(occ, x0, z0, w, h, x, z):
                on += 1
    return on / float(total)


def main():
    print('== geometry dump ==')
    if not os.path.isfile(GEOM):
        print('missing %s - run CityTrafficBuilder.Probe() in the Editor first' % GEOM)
        return 2
    records = load_records(GEOM)

    roads = []
    for rec in records:
        prefab = str(rec.get('prefab') or '')
        if not prefab.startswith('Road ') or prefab.startswith('Road Split'):
            continue
        size = rec.get('wsize') or [0, 0, 0]
        if size[0] < 4 or size[2] < 4:
            continue
        roads.append((prefab.replace('.prefab', ''), rec.get('wcenter'), size))

    street = [t for t in roads if any(k in t[0] for k in STREET_FAMILY)]
    plaza = [t for t in roads if not any(k in t[0] for k in STREET_FAMILY)]
    vehicles = [r for r in records if str(r.get('prefab') or '').startswith('Vehicle')]

    print('  road tiles %d (street family %d, plaza %d), vehicles %d' % (len(roads), len(street), len(plaza), len(vehicles)))
    check('the pack ships 97 road tiles', len(roads) == 97, str(len(roads)))
    check('86 of them belong to the street family', len(street) == 86, str(len(street)))
    check('the scene carries 104 vehicles', len(vehicles) == 104, str(len(vehicles)))

    print('== streets: the graph must come from street tiles only ==')
    box = rasterise(street)
    occ, x0, z0, w, h = box
    rows = [z for z in range(z0, z0 + h) if longest_run(occ, x0, z0, w, h, True, z) >= 60]
    cols = [x for x in range(x0, x0 + w) if longest_run(occ, x0, z0, w, h, False, x) >= 60]
    hz, vx = clusters(rows), clusters(cols)
    check('4 horizontal streets at z = 0, 60, 120, 160', hz == [0, 60, 120, 160], str(hz))
    check('5 vertical streets at x = 0, 60, 120, 180, 240', vx == [0, 60, 120, 180, 240], str(vx))

    nodes = [(x, z) for x in vx for z in hz if paved(occ, x0, z0, w, h, x, z)]
    check('20 crossings of the two street sets', len(nodes) == 20, str(len(nodes)))

    print('== driving side and lane offsets (as shipped by the pack) ==')
    def nearest_street(value, centres):
        return min(centres, key=lambda c: abs(c - value))

    offsets = []
    for rec in vehicles:
        yaw = rec['euler'][1] % 360.0
        x, z = rec['wcenter'][0], rec['wcenter'][2]
        if abs(yaw - 90.0) < 1.0:                      # heading +X: the offset is measured across z
            offsets.append(('+X', round(z - nearest_street(z, hz), 2)))
        elif abs(yaw - 270.0) < 1.0:                    # heading -X
            offsets.append(('-X', round(z - nearest_street(z, hz), 2)))
        elif abs(yaw) < 1.0:                            # heading +Z: the offset is measured across x
            offsets.append(('+Z', round(x - nearest_street(x, vx), 2)))
        elif abs(yaw - 180.0) < 1.0:                    # heading -Z
            offsets.append(('-Z', round(x - nearest_street(x, vx), 2)))
    plus = [o for d, o in offsets if d == '+X']
    minus = [o for d, o in offsets if d == '-X']
    upz = [o for d, o in offsets if d == '+Z']
    downz = [o for d, o in offsets if d == '-Z']
    check('vehicles heading +X exist for the side test', len(plus) > 0, str(len(plus)))
    check('right-hand: +X traffic keeps to negative z',
          len(plus) > 0 and sum(1 for o in plus if o < 0) * 3 > len(plus) * 2, str(sorted(plus)[:8]))
    check('right-hand: -X traffic keeps to positive z',
          len(minus) > 0 and sum(1 for o in minus if o > 0) * 3 > len(minus) * 2, str(sorted(minus)[:8]))
    check('right-hand: +Z traffic keeps to positive x',
          len(upz) > 0 and sum(1 for o in upz if o > 0) * 3 > len(upz) * 2, str(sorted(upz)[:8]))
    check('right-hand: -Z traffic keeps to negative x',
          len(downz) > 0 and sum(1 for o in downz if o < 0) * 3 > len(downz) * 2, str(sorted(downz)[:8]))
    lane_offsets = [abs(o) for d, o in offsets if abs(o) > 0.2]
    tight = [o for o in lane_offsets if 2.6 <= o <= 4.0]
    check('measured lane offsets cluster at about 3.3 m',
          len(lane_offsets) > 0 and len(tight) * 2 > len(lane_offsets),
          '%d of %d inside 2.6..4.0 m' % (len(tight), len(lane_offsets)))

    print('== as shipped: vehicles whose footprint is not on the carriageway ==')
    off = 0
    worst = []
    for rec in vehicles:
        share = footprint_share(box, rec.get('wcenter'), rec.get('wsize'), rec['euler'][1])
        if share < PAVEMENT_SHARE_MIN:
            off += 1
            worst.append((round(share, 2), str(rec['prefab']).replace('.prefab', ''),
                          round(rec['wcenter'][0], 1), round(rec['wcenter'][2], 1)))
    check('the shipped placement has 33 vehicles off the carriageway', off == 33, 'measured %d' % off)
    for row in sorted(worst)[:6]:
        print('      share=%.2f %-32s (%.1f, %.1f)' % row)

    print('== the Unity self-test receipt ==')
    if not os.path.isfile(RECEIPT):
        print('  (no receipt yet: run CityTrafficBuilder.SelfTest() in the Editor)')
    else:
        with io.open(RECEIPT, encoding='utf-8') as fh:
            rec = json.load(fh)
        g = rec.get('graph', {})
        pl = rec.get('placement', {})
        m = rec.get('metrics', {})
        check('graph: 20 nodes, 58 lanes, offset 3.3', g.get('nodes') == 20 and g.get('lanes') == 58
              and abs(g.get('lane_offset', 0) - LANE_OFFSET) < 0.01, str(g))
        check('after placement every vehicle is on the carriageway',
              pl.get('after_placement', {}).get('off_pavement') == 0, str(pl.get('after_placement')))
        check('the placarded state has no overlapping bodies',
              pl.get('placement_state', {}).get('overlaps') == 0, str(pl.get('placement_state')))
        check('minimum gap between followers stays positive (rule 3.2)',
              m.get('min_gap', -1) > 0, 'min_gap=%s' % m.get('min_gap'))
        check('no speed violation (rule 2.3)', m.get('speed_violations') == 0, str(m.get('speed_violations')))
        check('vehicles stop at a stop line (rule 4.3)', m.get('stops_at_stop_line', 0) > 0, str(m.get('stops_at_stop_line')))
        check('budget <= 0.5 ms per step (rule 9.1)', m.get('ms_per_step', 99) <= 0.5, str(m.get('ms_per_step')))
        print('  verdict from the Editor: %s (failed checks %s)' % (rec.get('verdict'), rec.get('failed_checks')))
        for entry in rec.get('checks', []):
            if not entry.get('ok'):
                print('      still failing: %s - %s' % (entry.get('check'), entry.get('detail')))

    failed = [n for n, ok, _ in _results if not ok]
    print('\n%d checks, %d failed' % (len(_results), len(failed)))
    for name in failed:
        print('  FAILED: %s' % name)
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
