"""Tests for the approve-and-apply operation.

The editor calls are replaced, so these tests check the guarantees, not Unity:
a dry run always precedes an apply, an apply without a backup is refused, and a revert
restores the file and re-reads the scene.
"""
from __future__ import annotations

import json
import os
import sqlite3
import sys
import tempfile
import time
import unittest
from pathlib import Path

TOOLS = Path(__file__).resolve().parent.parent / "tools"
sys.path.insert(0, str(TOOLS))

import apply_fix_plan as ops  # noqa: E402
import policy as policy_module  # noqa: E402

PLAN = {"plan_id": "fix_1", "scene": "Assets/Scenes/Main.unity",
        "fixes": [{"id": "fix.scene.no-camera", "action": "add-camera", "risk": "low"}]}


class PlanLoadingTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.root = Path(self._tmp.name)
        self.db = self.root / "brain.sqlite3"

    def _store(self, plan):
        connection = sqlite3.connect(str(self.db))
        connection.execute("CREATE TABLE IF NOT EXISTS fix_plans "
                           "(world TEXT, session TEXT, plan_id TEXT, plan TEXT, prepared REAL)")
        connection.execute("INSERT INTO fix_plans VALUES (?,?,?,?,?)",
                           ("world", "session", plan["plan_id"], json.dumps(plan), 1.0))
        connection.commit()
        connection.close()

    def test_a_stored_plan_can_be_loaded(self):
        self._store(PLAN)
        self.assertEqual(ops.load_plan("fix_1", None, str(self.db))["plan_id"], "fix_1")

    def test_an_unknown_plan_id_is_refused(self):
        self._store(PLAN)
        with self.assertRaises(ops.ApplyError):
            ops.load_plan("fix_nope", None, str(self.db))

    def test_a_database_without_plans_is_refused(self):
        sqlite3.connect(str(self.db)).close()
        with self.assertRaises(ops.ApplyError) as caught:
            ops.load_plan("fix_1", None, str(self.db))
        self.assertIn("has not prepared", str(caught.exception))

    def test_a_missing_database_is_refused(self):
        with self.assertRaises(ops.ApplyError):
            ops.load_plan("fix_1", None, str(self.root / "nope.sqlite3"))

    def test_a_plan_file_works_too(self):
        path = self.root / "plan.json"
        path.write_text(json.dumps(PLAN), encoding="utf-8")
        self.assertEqual(ops.load_plan(None, str(path), None)["plan_id"], "fix_1")

    def test_neither_id_nor_file_is_refused(self):
        with self.assertRaises(ops.ApplyError) as caught:
            ops.load_plan(None, None, None)
        self.assertIn("--plan-id or --plan-file", str(caught.exception))


class ApplyTests(unittest.TestCase):
    """run_unity is replaced: the tests drive the decisions, not the editor."""

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.project = Path(self._tmp.name) / "Project"
        (self.project / "Assets").mkdir(parents=True)
        self.calls = []
        self.dry_run_fixes = [{"id": "fix.scene.no-camera"}]
        self.backup = self.project / "AI" / "backups" / "fix-x" / "Assets" / "Scenes" / "Main.unity"
        self.backup.parent.mkdir(parents=True)
        self.backup.write_text("scene", encoding="utf-8")
        self.backup_reported = str(self.backup)
        self.original = ops.run_unity
        ops.run_unity = self._fake_unity
        self.addCleanup(setattr, ops, "run_unity", self.original)

    def _fake_unity(self, project, method, env_extra, log_path):
        self.calls.append((method, dict(env_extra)))
        out = env_extra.get("AICORE_FIX_OUT")
        if out:
            dry = env_extra.get("AICORE_FIX_DRY_RUN") == "1"
            payload = {"dry_run": dry, "applied": self.dry_run_fixes,
                       "backup": None if dry else self.backup_reported}
            Path(out).write_text(json.dumps(payload), encoding="utf-8")
        probe = env_extra.get("AICORE_PROBE_OUT")
        if probe:
            Path(probe).parent.mkdir(parents=True, exist_ok=True)
            Path(probe).write_text(json.dumps(
                {"summary": {}, "findings": [{"id": "scene.no-camera"}]}), encoding="utf-8")

    def test_a_dry_run_changes_nothing(self):
        outcome = ops.apply_plan(self.project, "Assets/Scenes/Main.unity", PLAN, True, "alice")
        self.assertTrue(outcome["dry_run"])
        self.assertFalse(outcome["applied"])
        self.assertEqual(outcome["planned"], 1)
        methods = [method for method, _env in self.calls]
        self.assertIn(ops.FIXER, methods)
        applies = [env for method, env in self.calls
                   if method == ops.FIXER and env.get("AICORE_FIX_DRY_RUN") == "0"]
        self.assertEqual(applies, [], "a dry run must not ask for an apply")

    def test_an_apply_runs_a_dry_run_first(self):
        ops.apply_plan(self.project, "Assets/Scenes/Main.unity", PLAN, False, "alice")
        fixer_calls = [env for method, env in self.calls if method == ops.FIXER]
        self.assertEqual(len(fixer_calls), 2)
        self.assertEqual(fixer_calls[0].get("AICORE_FIX_DRY_RUN"), "1")
        self.assertEqual(fixer_calls[1].get("AICORE_FIX_DRY_RUN"), "0")

    def test_an_apply_reports_before_and_after(self):
        outcome = ops.apply_plan(self.project, "Assets/Scenes/Main.unity", PLAN, False, "alice")
        self.assertTrue(outcome["applied"])
        self.assertEqual(outcome["before"], ["scene.no-camera"])
        self.assertEqual(outcome["backup"], self.backup_reported)

    def test_an_empty_dry_run_is_refused(self):
        self.dry_run_fixes = []
        with self.assertRaises(ops.ApplyError) as caught:
            ops.apply_plan(self.project, "Assets/Scenes/Main.unity", PLAN, False, "alice")
        self.assertIn("nothing to do", str(caught.exception))

    def test_an_apply_without_a_backup_is_refused(self):
        self.backup_reported = None
        with self.assertRaises(ops.ApplyError) as caught:
            ops.apply_plan(self.project, "Assets/Scenes/Main.unity", PLAN, False, "alice")
        self.assertIn("backup", str(caught.exception))

    def test_a_missing_backup_file_is_refused(self):
        self.backup_reported = str(self.backup.parent / "gone.unity")
        with self.assertRaises(ops.ApplyError):
            ops.apply_plan(self.project, "Assets/Scenes/Main.unity", PLAN, False, "alice")

    def test_the_change_is_written_to_the_audit_log(self):
        ops.apply_plan(self.project, "Assets/Scenes/Main.unity", PLAN, False, "alice")
        entries = [json.loads(line) for line in
                   (self.project / "AI" / "aicore-writes.log").read_text(encoding="utf-8").splitlines()]
        self.assertEqual(entries[-1]["action"], "apply-fix-plan")
        self.assertEqual(entries[-1]["subject"], "alice")
        self.assertEqual(entries[-1]["plan_id"], "fix_1")

    def test_a_dry_run_writes_no_audit_entry(self):
        ops.apply_plan(self.project, "Assets/Scenes/Main.unity", PLAN, True, "alice")
        self.assertFalse((self.project / "AI" / "aicore-writes.log").exists())

    def test_a_revert_restores_the_file(self):
        scene = self.project / "Assets" / "Scenes" / "Main.unity"
        scene.parent.mkdir(parents=True)
        scene.write_text("changed", encoding="utf-8")
        outcome = ops.revert(self.project, "Assets/Scenes/Main.unity", self.backup_reported, "alice")
        self.assertTrue(outcome["reverted"])
        self.assertEqual(scene.read_text(encoding="utf-8"), "scene")

    def test_a_revert_without_a_backup_is_refused(self):
        with self.assertRaises(ops.ApplyError):
            ops.revert(self.project, "Assets/Scenes/Main.unity",
                       str(self.project / "nope.unity"), "alice")



    def test_auto_approval_is_refused_when_the_policy_is_off(self):
        plan_file = self.project / "plan.json"
        plan_file.write_text(json.dumps(PLAN), encoding="utf-8")
        original = os.environ.pop("AICORE_AUTO_APPROVE", None)
        self.addCleanup(self._restore_auto, original)
        code = ops.main(["--project", str(self.project), "--scene", "Assets/Scenes/Main.unity",
                         "--plan-file", str(plan_file), "--auto"])
        self.assertEqual(code, 1)
        fixer_calls = [env for method, env in self.calls if method == ops.FIXER]
        self.assertEqual(fixer_calls, [], "nothing may reach the editor when the policy refuses")

    def _restore_auto(self, value):
        if value is None:
            os.environ.pop("AICORE_AUTO_APPROVE", None)
        else:
            os.environ["AICORE_AUTO_APPROVE"] = value

    def test_auto_approval_applies_when_the_policy_allows_it(self):
        plan_file = self.project / "plan.json"
        plan_file.write_text(json.dumps(PLAN), encoding="utf-8")
        previous = os.environ.get("AICORE_AUTO_APPROVE")
        os.environ["AICORE_AUTO_APPROVE"] = "1"
        os.environ["AICORE_AUTO_REQUIRE_OBSERVED"] = "0"
        self.addCleanup(self._restore_env, previous)
        code = ops.main(["--project", str(self.project), "--scene", "Assets/Scenes/Main.unity",
                         "--plan-file", str(plan_file), "--auto"])
        self.assertEqual(code, 0)
        entries = [json.loads(line) for line in
                   (self.project / "AI" / "aicore-writes.log").read_text(encoding="utf-8").splitlines()]
        self.assertEqual(entries[-1]["subject"], "auto")

    def _restore_env(self, previous):
        if previous is None:
            os.environ.pop("AICORE_AUTO_APPROVE", None)
        else:
            os.environ["AICORE_AUTO_APPROVE"] = previous
        os.environ.pop("AICORE_AUTO_REQUIRE_OBSERVED", None)

    def test_the_audit_log_stops_auto_approval_after_the_budget(self):
        audit = self.project / "AI" / "aicore-writes.log"
        audit.parent.mkdir(parents=True, exist_ok=True)
        stamp = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        audit.write_text("\n".join(['{"action": "apply-fix-plan", "utc": "%s"}' % stamp] * 2),
                         encoding="utf-8")
        plan = {"plan_id": "fix_1", "fixes": [{"id": "fix.a", "risk": "low"}]}
        rule = policy_module.AutoApprovalPolicy(enabled=True, require_observed=False, max_per_hour=2)
        verdict = ops.auto_decision(self.project, "Assets/Scenes/Main.unity", plan, rule)
        self.assertFalse(verdict["allowed"])
        self.assertIn("budget", " ".join(verdict["reasons"]))


class CommandLineTests(unittest.TestCase):
    def test_the_parser_requires_a_project_and_a_scene(self):
        with self.assertRaises(SystemExit):
            ops.build_parser().parse_args([])

    def test_a_non_project_directory_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            self.assertEqual(ops.main(["--project", tmp, "--scene", "Assets/A.unity"]), 1)


if __name__ == "__main__":
    unittest.main()
