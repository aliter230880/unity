"""Unity-free checks for the sandbox cast: sources, frozen formats, driver parser."""

from __future__ import annotations

import importlib.util
import sys
import unittest
from pathlib import Path

TESTS = Path(__file__).resolve().parent
WORLD = TESTS.parent
UNITY_PROJECT = __import__("projectroot").optional_root()
# The real project root when available; the layout guess only keeps the module
# importable in a mirror copy (SourceContractTests is skipped there anyway).
REPO = UNITY_PROJECT if UNITY_PROJECT is not None else WORLD.parents[1]
DRIVER_PATH = WORLD / "tools" / "run_sandbox_alive_check.py"
SCRIPTS = REPO / "Assets" / "AICoreSandbox" / "Scripts"

SAMPLE_LOG = "\n".join([
    "Initialize engine",
    "[SandboxAliveSelftest] phase=build actors=5 moved=5 travelled=84.12 meets=7 exchanges=4 parts=4",
    "[SandboxAliveSelftest] last: NPC_Villager pos=(1.00,0.90,-2.00) state=roam travelled=16.50",
    "[SandboxAliveSelftest] phase=scene actors=5 moved=5 travelled=22.40 meets=2 exchanges=1 parts=1",
    "[SandboxAliveSelftest] verdict=PASSED build=ok scene=ok",
])

SAMPLE_ACTOR_LOG = "\n".join([
    "[SandboxAlive] t=0.50 actor=NPC_Villager pos=(1.00,0.90,-2.00) state=roam partner=-",
    "[SandboxAlive] event=meet actor=NPC_Villager partner=NPC_Merchant",
    "[SandboxAlive] event=exchange actor=NPC_Villager partner=NPC_Merchant",
    "[SandboxAlive] event=part actor=NPC_Villager partner=NPC_Merchant",
    "[SandboxAlive] t=1.00 actor=NPC_Guard pos=(3.00,0.90,1.00) state=roam partner=-",
])


def load_driver():
    spec = importlib.util.spec_from_file_location("run_sandbox_alive_check", DRIVER_PATH)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


class DriverParserTests(unittest.TestCase):
    def setUp(self):
        self.driver = load_driver()

    def test_paths_point_at_the_repository_and_the_twin(self):
        self.assertEqual(self.driver.REPO, REPO)
        self.assertEqual(self.driver.TWIN.name, "ValidationProject")
        self.assertTrue(self.driver.TWIN.parent.name == "WorldDirector")

    def test_parses_phases_and_verdict(self):
        parsed = self.driver.parse_selftest(SAMPLE_LOG)
        self.assertEqual(parsed["verdict"], "PASSED")
        self.assertEqual(parsed["phases"]["build"]["actors"], "5")
        self.assertEqual(int(parsed["phases"]["build"]["meets"]), 7)
        self.assertEqual(parsed["phases"]["scene"]["exchanges"], "1")
        self.assertEqual(len(parsed["last"]), 1)
        self.assertIn("NPC_Villager", parsed["last"][0])

    def test_failed_verdict_is_not_mistaken_for_success(self):
        parsed = self.driver.parse_selftest(
            "[SandboxAliveSelftest] verdict=FAILED build=failed scene=ok")
        self.assertEqual(parsed["verdict"], "FAILED")

    def test_counts_actor_events(self):
        counts = self.driver.count_events(SAMPLE_ACTOR_LOG)
        self.assertEqual(counts["meet"], 1)
        self.assertEqual(counts["exchange"], 1)
        self.assertEqual(counts["part"], 1)
        self.assertEqual(counts["snapshots"], 2)

    def test_number_helper_survives_missing_values(self):
        self.assertEqual(self.driver.number({"moved": "4"}, "moved"), 4.0)
        self.assertEqual(self.driver.number({}, "moved"), 0.0)


@unittest.skipUnless(UNITY_PROJECT is not None, __import__("projectroot").REASON)
class SourceContractTests(unittest.TestCase):
    def read(self, relative: str) -> str:
        path = SCRIPTS / relative
        self.assertTrue(path.exists(), "missing source: %s" % path)
        return path.read_text(encoding="utf-8")

    def test_actor_is_steppable_from_outside(self):
        source = self.read("SandboxActor.cs")
        self.assertIn("public void Step(float dt)", source)
        self.assertIn("public float Travelled", source)

    def test_cast_owns_the_clock_and_the_scene_hook(self):
        source = self.read("SandboxCast.cs")
        self.assertIn("ExternallyDriven", source)
        self.assertIn("RuntimeInitializeOnLoadMethod", source)
        self.assertIn("SandboxScene", source)

    def test_cast_adopts_every_character_in_the_scene(self):
        source = self.read("SandboxCast.cs")
        for name in ("NPC_Villager", "NPC_QuestGiver", "NPC_Merchant", "NPC_Guard",
                     "Character_Human"):
            self.assertIn(name, source)

    def test_empty_characters_get_a_visible_body(self):
        source = self.read("SandboxCast.cs")
        self.assertIn("DressIfEmpty", source)
        self.assertIn("PrimitiveType.Capsule", source)

    def test_log_format_is_frozen(self):
        source = self.read("SandboxAliveLog.cs")
        self.assertIn("[SandboxAlive] event={0} actor={1} partner={2}", source)
        self.assertIn("state={5} partner={6}", source)

    def test_interaction_states_all_exist(self):
        source = self.read("SandboxActor.cs")
        for state in ("Roam", "Approach", "Face", "Exchange", "Part", "Rest"):
            self.assertIn(state, source)

    def test_selftest_has_the_batch_entry_point(self):
        source = self.read("Editor/SandboxAliveSelfTest.cs")
        self.assertIn("public static void RunBatch()", source)
        self.assertIn("[SandboxAliveSelftest] ", source)
        self.assertIn("EditorApplication.Exit", source)


if __name__ == "__main__":
    unittest.main()
