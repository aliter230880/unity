"""Tests for POST /v1/observe: the brain running the readings its planner asked for."""
from __future__ import annotations

import json
import sys
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
from pathlib import Path

TESTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(TESTS_DIR.parent / "brain"))

import server  # noqa: E402
import tools  # noqa: E402

TOKEN = "observe-token-0123456789"
WRITE_TOOLS = {"outputs.write_text", "outputs.revert", "brain.approval.revoke"}


class ObserveCase(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.root = Path(self._tmp.name)
        self.project = self.root / "Project"
        (self.project / "Assets").mkdir(parents=True)
        (self.project / "AICore" / "outputs" / "scene").mkdir(parents=True)
        (self.project / "Logs").mkdir(parents=True)
        (self.project / "Logs" / "broken.log").write_text(
            "some noise\nUnhandled exception: boom\n", encoding="utf-8")
        (self.project / "Logs" / "clean.log").write_text("all fine\n", encoding="utf-8")
        self.db = self.root / "brain.sqlite3"
        self.brain = server.Brain(self.db)
        self.addCleanup(self.brain.close)
        self.server = server.make_server(self.brain, TOKEN, 0, project_root=self.project,
                                         scope_db=self.db)
        self.addCleanup(self.server.server_close)
        threading.Thread(target=self.server.serve_forever, daemon=True).start()
        self.addCleanup(self.server.shutdown)
        self.base = "http://127.0.0.1:%d" % self.server.server_address[1]

    def observe(self, body, token=TOKEN):
        request = urllib.request.Request(self.base + "/v1/observe",
                                         data=json.dumps(body).encode("utf-8"), method="POST")
        request.add_header("Content-Type", "application/json")
        if token is not None:
            request.add_header("Authorization", "Bearer " + token)
        # The servers under test are short-lived; on Windows a socket can still be in
        # TIME_WAIT when the next server binds the same port, which surfaces here as a
        # connection abort. Retrying is the honest fix for a harness whose subject really
        # is a dying socket.
        last = None
        for _attempt in range(3):
            try:
                with urllib.request.urlopen(request, timeout=30) as response:
                    return response.status, json.loads(response.read().decode("utf-8"))
            except urllib.error.HTTPError as error:
                return error.code, json.loads(error.read().decode("utf-8"))
            except (ConnectionError, OSError) as error:
                last = error
                time.sleep(0.25)
        raise AssertionError("the request never completed: %s" % last)

    def facts(self, world="world-1"):
        return {row["key"]: row["value"]
                for row in self.brain.knowledge.query_facts(world, "", "", 200)}


class ObserveTests(ObserveCase):
    def test_observe_runs_tools_and_records_facts(self):
        status, body = self.observe({"world_id": "world-1", "session_id": "session-1",
                                     "logs": ["Logs/broken.log"]})
        self.assertEqual(status, 200, body)
        self.assertTrue(body["tools"], "no tool ran at all")
        self.assertGreaterEqual(body["facts_written"], 1)
        facts = self.facts()
        self.assertIn("diagnostics.last_run", facts)
        self.assertGreaterEqual(int(facts["diagnostics.critical"]) + int(facts["diagnostics.error"]), 1)

    def test_observe_reports_per_tool_outcomes(self):
        _, body = self.observe({"world_id": "world-1", "session_id": "session-1",
                                "logs": ["Logs/broken.log"]})
        for entry in body["tools"]:
            self.assertIn("tool", entry)
            self.assertIn("ok", entry)
            self.assertTrue(entry["reason"])

    def test_observe_closes_the_loop(self):
        before = self.brain._recommend_tools({"results": []}, ("world-1", "session-1"))
        self.assertIn("project.diagnostics", [call["tool"] for call in before])
        self.observe({"world_id": "world-1", "session_id": "session-1",
                      "logs": ["Logs/broken.log"]})
        after = self.brain._recommend_tools({"results": []}, ("world-1", "session-1"))
        self.assertNotIn("project.diagnostics", [call["tool"] for call in after])

    def test_observe_never_runs_a_write_tool(self):
        _, body = self.observe({"world_id": "world-1", "session_id": "session-1",
                                "logs": ["Logs/broken.log"], "budget": 8})
        names = {entry["tool"] for entry in body["tools"]}
        self.assertFalse(names & WRITE_TOOLS, names)

    def test_observe_does_not_touch_the_project(self):
        before = sorted(str(item.relative_to(self.project)) for item in self.project.rglob("*"))
        self.observe({"world_id": "world-1", "session_id": "session-1",
                      "logs": ["Logs/broken.log"]})
        after = sorted(str(item.relative_to(self.project)) for item in self.project.rglob("*"))
        self.assertEqual(before, after)

    def test_a_broken_log_produces_more_findings_than_a_clean_one(self):
        # A bare project always has layout findings, so compare two worlds instead of
        # asserting an absolute number.
        self.observe({'world_id': 'w-clean', 'session_id': 's', 'logs': ['Logs/clean.log']})
        self.observe({'world_id': 'w-broken', 'session_id': 's', 'logs': ['Logs/broken.log']})
        clean = int(self.facts('w-clean')['diagnostics.findings'])
        broken = int(self.facts('w-broken')['diagnostics.findings'])
        self.assertGreater(broken, clean, 'the crash in the log was not noticed')
        self.assertGreater(int(self.facts('w-broken')['diagnostics.critical']), 0)
        self.assertEqual(int(self.facts('w-clean')['diagnostics.critical']), 0)



    def test_act_decides_to_fix_and_records_it(self):
        report = self.project / "AICore" / "outputs" / "scene" / "scene-report.json"
        report.write_text(json.dumps({"findings": [{"id": "scene.no-camera",
                                                    "severity": "warning",
                                                    "evidence": "-"}]}), encoding="utf-8")
        status, body = self.observe({"world_id": "world-1", "session_id": "session-1",
                                     "logs": ["Logs/broken.log"], "act": True})
        self.assertEqual(status, 200, body)
        self.assertEqual(body["decision"]["action"], "fix")
        self.assertTrue(body["decision"]["plan_ready"], body["decision"])
        self.assertIn("fix.pending", self.facts())

    def test_without_act_there_is_no_decision(self):
        _, body = self.observe({"world_id": "world-1", "session_id": "session-1",
                                "logs": ["Logs/broken.log"]})
        self.assertNotIn("decision", body)

    def test_act_with_nothing_fixable_keeps_reading(self):
        status, body = self.observe({"world_id": "world-1", "session_id": "session-1",
                                     "logs": ["Logs/broken.log"], "act": True})
        self.assertEqual(status, 200, body)
        self.assertIn(body["decision"]["action"], ("observe", "fix"))

    def test_an_unknown_observe_field_is_still_rejected(self):
        status, _ = self.observe({"world_id": "world-1", "session_id": "session-1",
                                  "act": True, "what": 1})
        self.assertEqual(status, 400)


    def test_a_prepared_plan_is_kept(self):
        report = self.project / "AICore" / "outputs" / "scene" / "scene-report.json"
        report.write_text(json.dumps({"findings": [{"id": "scene.no-camera",
                                                    "severity": "warning",
                                                    "evidence": "-"}]}), encoding="utf-8")
        status, body = self.observe({"world_id": "world-1", "session_id": "session-1",
                                     "logs": ["Logs/broken.log"], "act": True})
        self.assertEqual(status, 200, body)
        decision = body["decision"]
        self.assertEqual(decision["action"], "fix", decision)
        self.assertTrue(decision["prepared"], decision)
        plan_id = decision["prepared_plan_id"]
        self.assertTrue(plan_id)
        stored = [item["plan_id"] for item in self.brain.pending_fix_plans("world-1")]
        self.assertIn(plan_id, stored)

    def test_observe_requires_a_token(self):
        status, _ = self.observe({"world_id": "world-1", "session_id": "session-1"}, token=None)
        self.assertEqual(status, 401)

    def test_unknown_fields_are_rejected(self):
        status, _ = self.observe({"world_id": "world-1", "session_id": "session-1", "extra": 1})
        self.assertEqual(status, 400)

    def test_a_bad_budget_is_rejected(self):
        for bad in (0, 99, "three"):
            status, _ = self.observe({"world_id": "world-1", "session_id": "session-1",
                                      "budget": bad})
            self.assertEqual(status, 400, "budget %r was accepted" % (bad,))

    def test_log_paths_outside_the_project_are_refused(self):
        status, body = self.observe({"world_id": "world-1", "session_id": "session-1",
                                     "logs": ["../../secret.log"]})
        self.assertEqual(status, 400)
        self.assertIn("project root", body["error"])

    def test_an_absolute_log_path_outside_is_refused(self):
        outside = self.root / "outside.log"
        outside.write_text("Unhandled exception: nope\n", encoding="utf-8")
        status, _ = self.observe({"world_id": "world-1", "session_id": "session-1",
                                  "logs": [str(outside)]})
        self.assertEqual(status, 400)


def _rejected(body):
    return len(body.get("facts_rejected") or [])


class ObserveFactsTests(unittest.TestCase):
    def test_tools_needing_a_project_path_are_refused_without_a_root(self):
        result = tools.execute_scoped("project.diagnostics", {"project_root": "."}, confine=True)
        self.assertFalse(result.ok)
        self.assertIn("--project", result.error)


class FixPlanStorageTests(unittest.TestCase):
    """The brain keeps prepared plans in its own database, so a decision survives the pass."""

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.brain = server.Brain(Path(self._tmp.name) / "brain.sqlite3")
        self.addCleanup(self.brain.close)

    def test_a_plan_round_trips(self):
        plan = {"plan_id": "fix_1", "fixes": [{"id": "fix.a"}]}
        self.assertEqual(self.brain.store_fix_plan("world", "session", plan), "fix_1")
        stored = self.brain.pending_fix_plans("world")
        self.assertEqual(len(stored), 1)
        self.assertEqual(stored[0]["plan"], plan)

    def test_a_plan_without_an_id_is_not_stored(self):
        self.assertEqual(self.brain.store_fix_plan("world", "session", {"fixes": []}), "")
        self.assertEqual(self.brain.pending_fix_plans("world"), [])

    def test_storing_the_same_plan_twice_keeps_one_row(self):
        plan = {"plan_id": "fix_1"}
        self.brain.store_fix_plan("world", "session", plan)
        self.brain.store_fix_plan("world", "session", plan)
        self.assertEqual(len(self.brain.pending_fix_plans("world")), 1)

    def test_plans_are_separated_by_world(self):
        self.brain.store_fix_plan("world-a", "session", {"plan_id": "fix_a"})
        self.brain.store_fix_plan("world-b", "session", {"plan_id": "fix_b"})
        self.assertEqual([item["plan_id"] for item in self.brain.pending_fix_plans("world-a")], ["fix_a"])

    def test_an_empty_brain_reports_no_plans(self):
        self.assertEqual(self.brain.pending_fix_plans("world"), [])


if __name__ == "__main__":
    unittest.main()
