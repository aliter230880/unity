"""Tests for the project map: reading the report, and recording it as knowledge."""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

TESTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(TESTS_DIR.parent / "brain"))

import server  # noqa: E402
import tools  # noqa: E402

MAP = {
    "report_version": "1",
    "read_only": True,
    "generated_utc": "2026-09-18T11:00:00Z",
    "summary": {"scenes": 1, "entities": 3, "relations": 3, "truncated": False},
    "entities": [
        {"id": "scene.Assets_Scenes_Main_unity", "path": "Assets/Scenes/Main.unity",
         "kind": "scene", "name": "Main"},
        {"id": "object.scene_Main_Root", "path": "Assets/Scenes/Main.unity#Root",
         "kind": "object", "name": "Root"},
        {"id": "prefab.Assets_Prefabs_Crate_prefab", "path": "Assets/Prefabs/Crate.prefab",
         "kind": "prefab", "name": "Crate"},
    ],
    "relations": [
        {"source": "scene.Assets_Scenes_Main_unity", "target": "object.scene_Main_Root",
         "type": "contains"},
        {"source": "object.scene_Main_Root", "target": "WorldEntity", "type": "has_component"},
        {"source": "prefab.Assets_Prefabs_Crate_prefab", "target": "asset.X", "type": "depends_on"},
    ],
}


class MapToolTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.project = Path(self._tmp.name) / "Project"
        (self.project / "AICore" / "outputs" / "scene").mkdir(parents=True)
        self.report = self.project / "AICore" / "outputs" / "scene" / "project-map.json"
        self.report.write_text(json.dumps(MAP), encoding="utf-8")

    def _map(self, **extra):
        params = {"project_root": str(self.project)}
        params.update(extra)
        return tools.execute_scoped("project.map", params, project_root=self.project, confine=True)

    def test_the_map_is_read(self):
        result = self._map()
        self.assertTrue(result.ok, result.error)
        self.assertEqual(result.data["entity_count"], 3)
        self.assertEqual(result.data["relation_count"], 3)

    def test_entities_can_be_filtered_by_kind(self):
        result = self._map(kind="prefab")
        self.assertEqual([item["id"] for item in result.data["entities"]],
                         ["prefab.Assets_Prefabs_Crate_prefab"])

    def test_relations_can_be_filtered_by_type(self):
        result = self._map(relation="contains")
        self.assertEqual(result.data["relation_count"], 1)

    def test_the_limit_caps_both_lists(self):
        result = self._map(limit=1)
        self.assertEqual(len(result.data["entities"]), 1)
        self.assertEqual(len(result.data["relations"]), 1)
        self.assertEqual(result.data["entity_count"], 3)

    def test_a_bad_limit_is_refused(self):
        self.assertFalse(self._map(limit=0).ok)
        self.assertFalse(self._map(limit=999).ok)

    def test_a_missing_map_is_a_clean_error(self):
        self.report.unlink()
        result = self._map()
        self.assertFalse(result.ok)
        self.assertIn("project map not found", result.error)

    def test_a_map_outside_the_root_is_refused(self):
        outside = Path(self._tmp.name) / "elsewhere.json"
        outside.write_text(json.dumps(MAP), encoding="utf-8")
        result = self._map(report=str(outside))
        self.assertFalse(result.ok)
        self.assertIn("configured project root", result.error)

    def test_an_unreadable_map_is_a_clean_error(self):
        self.report.write_text("not json", encoding="utf-8")
        self.assertIn("unreadable", self._map().error)


class MapIngestTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.project = Path(self._tmp.name) / "Project"
        (self.project / "AICore" / "outputs" / "scene").mkdir(parents=True)
        self.brain = server.Brain(Path(self._tmp.name) / "brain.sqlite3")
        self.addCleanup(self.brain.close)

    def _write_map(self, payload=MAP):
        (self.project / "AICore" / "outputs" / "scene" / "project-map.json").write_text(
            json.dumps(payload), encoding="utf-8")

    def test_the_map_becomes_knowledge_relations(self):
        self._write_map()
        outcome = server.ingest_project_map(self.brain, self.project, "world")
        self.assertTrue(outcome["mapped"], outcome)
        self.assertEqual(outcome["stored"], 3)
        self.assertEqual(outcome["rejected"], 0)
        self.assertGreaterEqual(self.brain.knowledge.world_summary("world")["relation_count"], 3)

    def test_a_missing_map_is_reported_not_fatal(self):
        outcome = server.ingest_project_map(self.brain, self.project, "world")
        self.assertFalse(outcome["mapped"])
        self.assertIn("has been built", outcome["reason"])

    def test_a_project_without_a_root_is_reported(self):
        outcome = server.ingest_project_map(self.brain, None, "world")
        self.assertFalse(outcome["mapped"])

    def test_a_malformed_map_is_reported(self):
        (self.project / "AICore" / "outputs" / "scene" / "project-map.json").write_text(
            "{not json", encoding="utf-8")
        outcome = server.ingest_project_map(self.brain, self.project, "world")
        self.assertFalse(outcome["mapped"])
        self.assertIn("unreadable", outcome["reason"])

    def test_invalid_relations_are_counted_not_stored(self):
        self._write_map({"summary": {}, "entities": [], "relations": [
            {"source": "bad id with spaces", "target": "x", "type": "contains"},
            {"source": "good.id", "target": "other.id", "type": "contains"},
        ]})
        outcome = server.ingest_project_map(self.brain, self.project, "world")
        self.assertEqual(outcome["stored"], 1)
        self.assertEqual(outcome["rejected"], 1)

    def test_the_ingest_is_bounded(self):
        many = {"summary": {}, "entities": [],
                "relations": [{"source": "a.%d" % index, "target": "b.%d" % index,
                               "type": "contains"} for index in range(50)]}
        self._write_map(many)
        outcome = server.ingest_project_map(self.brain, self.project, "world", limit=10)
        self.assertEqual(outcome["stored"], 10)
        self.assertEqual(outcome["relations"], 50)


if __name__ == "__main__":
    unittest.main()
