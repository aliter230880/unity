"""Fixture contract test: the polygon scene must keep producing its expected findings.

This test is skipped when the fixture scan has not been produced yet (it needs a
Unity batch run). Run the fixture with:

    Unity.exe -batchmode -nographics -quit ^
      -projectPath ValidationProject -logFile <log> ^
      -executeMethod AliTerra.AICore.Fixture.AICoreFixtureBuilder.BuildAndProbeBatch
"""
from __future__ import annotations

import json
import unittest
from pathlib import Path

TESTS_DIR = Path(__file__).resolve().parent
WORLD_DIR = TESTS_DIR.parent
MANIFEST = WORLD_DIR / "ValidationProject" / "Assets" / "AICoreFixture" / "expected-findings.json"
SCAN = WORLD_DIR.parent / "outputs" / "scene" / "fixture-scan.json"


@unittest.skipUnless(SCAN.is_file(), "fixture scan not produced yet: run AICoreFixtureBuilder.BuildAndProbeBatch")
class FixtureContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
        cls.scan = json.loads(SCAN.read_text(encoding="utf-8"))
        cls.ids = [finding.get("id") for finding in cls.scan.get("findings", [])]

    def test_every_expected_finding_is_reported(self):
        for expected in self.manifest["expected_findings"]:
            self.assertIn(expected, self.ids, "%s is no longer detected" % expected)

    def test_expected_counters_match(self):
        for key, expected in self.manifest["expected_summary"].items():
            self.assertEqual(self.scan["summary"].get(key), expected,
                             "%s changed: %r" % (key, self.scan["summary"].get(key)))

    def test_the_scan_is_read_only(self):
        self.assertTrue(self.scan.get("read_only"))

    def test_the_fixture_scene_still_exists(self):
        self.assertTrue((WORLD_DIR / "ValidationProject" / self.manifest["scene"]).is_file())


if __name__ == "__main__":
    unittest.main()
