"""Tests for asking the map questions: entities, relations, and the tool over them."""
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

TESTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(TESTS_DIR.parent / "brain"))

import server  # noqa: E402
import tools  # noqa: E402

ENTITIES = [
    {"id": "scene.Assets_Scenes_Main_unity", "path": "Assets/Scenes/Main.unity",
     "kind": "scene", "name": "Main"},
    {"id": "object.Main_Root", "path": "Assets/Scenes/Main.unity#Root",
     "kind": "object", "name": "Root"},
    {"id": "object.Main_Camera", "path": "Assets/Scenes/Main.unity#Main Camera",
     "kind": "object", "name": "Main Camera"},
]
RELATIONS = [
    {"source_id": "scene.Assets_Scenes_Main_unity", "target_id": "object.Main_Root",
     "type": "contains", "strength": 1.0},
    {"source_id": "scene.Assets_Scenes_Main_unity", "target_id": "object.Main_Camera",
     "type": "contains", "strength": 1.0},
    {"source_id": "object.Main_Root", "target_id": "WorldEntity", "type": "has_component",
     "strength": 1.0},
    {"source_id": "object.Main_Root", "target_id": "true", "type": "missing_script",
     "strength": 1.0},
]


class MapStorageTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.brain = server.Brain(Path(self._tmp.name) / "brain.sqlite3")
        self.addCleanup(self.brain.close)
        self.brain.store_map_entities("world", ENTITIES)
        for relation in RELATIONS:
            self.brain.knowledge.upsert_relation("world", relation, commit=False)
        self.brain.db.commit()

    def test_entities_are_stored(self):
        found = self.brain.find_map_entities("world")
        self.assertEqual(len(found), 3)

    def test_entities_can_be_found_by_name(self):
        found = self.brain.find_map_entities("world", text="Camera")
        self.assertEqual([item["id"] for item in found], ["object.Main_Camera"])

    def test_entities_can_be_filtered_by_kind(self):
        self.assertEqual(len(self.brain.find_map_entities("world", kind="object")), 2)

    def test_relations_are_found_in_both_directions(self):
        links = self.brain.related("world", "scene.Assets_Scenes_Main_unity")
        self.assertEqual(len(links), 2)
        self.assertTrue(all(link["direction"] == "out" for link in links))
        incoming = self.brain.related("world", "object.Main_Root")
        directions = {link["direction"] for link in incoming}
        self.assertEqual(directions, {"in", "out"})

    def test_a_relation_limit_is_respected(self):
        self.assertEqual(len(self.brain.related("world", "object.Main_Root", limit=1)), 1)

    def test_the_summary_counts_kinds_and_types(self):
        summary = self.brain.map_summary("world")
        self.assertEqual(summary["entities"]["object"], 2)
        self.assertEqual(summary["relations"]["contains"], 2)

    def test_an_unknown_world_is_empty(self):
        self.assertEqual(self.brain.find_map_entities("nowhere"), [])
        self.assertEqual(self.brain.related("nowhere", "x"), {}.get("x", []))


class QueryToolTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.db = Path(self._tmp.name) / "brain.sqlite3"
        brain = server.Brain(self.db)
        try:
            brain.store_map_entities("world", ENTITIES)
            for relation in RELATIONS:
                brain.knowledge.upsert_relation("world", relation, commit=False)
            brain.db.commit()
        finally:
            brain.close()

    def query(self, **extra):
        params = {"db": str(self.db)}
        params.update(extra)
        return tools.execute_scoped("project.query", params, confine=False)

    def test_a_summary_answers_what_the_map_holds(self):
        result = self.query()
        self.assertTrue(result.ok, result.error)
        self.assertEqual(result.data["summary"]["entities"]["object"], 2)
        self.assertEqual(result.data["summary"]["relations"]["has_component"], 1)

    def test_an_entity_can_be_found_by_name(self):
        result = self.query(text="Camera")
        self.assertEqual(result.data["count"], 1)
        entity = result.data["entities"][0]
        self.assertEqual(entity["entity"]["kind"], "object")
        self.assertTrue(entity["relations"])

    def test_relations_of_one_type_can_be_listed(self):
        result = self.query(relation="missing_script")
        self.assertEqual(result.data["count"], 1)
        self.assertEqual(result.data["relations"][0]["source"], "object.Main_Root")

    def test_kind_and_text_can_be_combined(self):
        result = self.query(kind="scene", text="Main")
        self.assertEqual([item["entity"]["kind"] for item in result.data["entities"]], ["scene"])

    def test_a_limit_is_respected(self):
        self.assertEqual(self.query(limit=1, kind="object").data["count"], 1)

    def test_a_bad_limit_is_refused(self):
        self.assertFalse(self.query(limit=0).ok)
        self.assertFalse(self.query(limit=500).ok)

    def test_an_empty_database_is_reported_cleanly(self):
        empty = Path(self._tmp.name) / "empty.sqlite3"
        server.Brain(empty).close()
        result = tools.execute_scoped("project.query", {"db": str(empty)}, confine=False)
        self.assertTrue(result.ok, result.error)
        self.assertEqual(result.data["note"], "no project map has been recorded yet")

    def test_an_unknown_name_returns_nothing(self):
        result = self.query(text="definitely-absent")
        self.assertTrue(result.ok, result.error)
        self.assertEqual(result.data["count"], 0)

    def test_the_query_does_not_write(self):
        before = self.db.stat().st_mtime_ns
        self.query(text="Main")
        self.assertEqual(self.db.stat().st_mtime_ns, before)


if __name__ == "__main__":
    unittest.main()
