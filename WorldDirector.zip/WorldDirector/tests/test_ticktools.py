"""Tests for tool calls inside the tick response, revocation, and the fix plan."""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from copy import deepcopy
from pathlib import Path

TESTS_DIR = Path(__file__).resolve().parent
BRAIN = TESTS_DIR.parent / "brain"
sys.path.insert(0, str(BRAIN))

import server  # noqa: E402
import tools  # noqa: E402

MASTER = "approval-token-0123456789"
KNOWN_READ_TOOLS = {"project.diagnostics", "unity.scene.report", "unity.console.tail",
                    "unity.project.inventory", "brain.knowledge.facts"}


def request(**changes):
    value = {
        "protocol_version": 1, "world_id": "world-1", "session_id": "session-1",
        "observation_id": "observation-1", "goal": "Maintain the explicit crate population.",
        "target_catalog_id": "crate", "target_count": 3,
        "anchor": {"x": 0.0, "y": 0.0, "z": 0.0},
        "allow_mutations": True, "entities_truncated": False,
        "limits": {"min": {"x": -100.0, "y": -100.0, "z": -100.0},
                   "max": {"x": 100.0, "y": 100.0, "z": 100.0},
                   "max_owned_entities": 100, "owned_entity_count": 0, "action_budget": 8},
        "entities": [], "catalog": [{"id": "crate", "kind": "prop"}],
        "results": [], "events": [], "feedback": [],
    }
    value.update(changes)
    return value


def v2(**changes):
    data = request()
    data.update({"protocol_version": 2, "goals": [], "knowledge_updates": [], "relations": [],
                 "capabilities": {"action_types": ["spawn", "activate", "deactivate"]}})
    data.update(changes)
    return data


class TickToolCallTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.brain = server.Brain(Path(self._tmp.name) / "brain.sqlite3")
        self.addCleanup(self.brain.close)
        self.scope = ("world-1", "session-1")

    def test_the_v2_response_carries_tool_calls(self):
        response = self.brain.tick_v2(v2())
        self.assertIn("tool_calls", response)
        self.assertIsInstance(response["tool_calls"], list)
        self.assertTrue(response["tool_calls"])
        for call in response["tool_calls"]:
            self.assertIn(call["tool"], KNOWN_READ_TOOLS)
            self.assertTrue(call["reason"])

    def test_no_write_tool_is_ever_suggested(self):
        names = [call["tool"] for call in self.brain.tick_v2(v2())["tool_calls"]]
        self.assertNotIn("outputs.write_text", names)
        self.assertNotIn("outputs.revert", names)

    def test_failed_results_pull_in_the_diagnostics(self):
        data = v2(results=[{"action_id": "a1", "status": "failed", "message": "boom"}])
        calls = self.brain._recommend_tools(data, self.scope)
        self.assertEqual(calls[0]["tool"], "project.diagnostics")

    def test_published_console_errors_pull_in_the_console_tool(self):
        self.brain.knowledge.upsert_facts("world-1", [
            {"key": "console.errors", "value": 5, "category": "system", "confidence": 1.0}])
        calls = self.brain._recommend_tools(v2(), self.scope)
        self.assertIn("unity.console.tail", [call["tool"] for call in calls])

    def test_a_fresh_published_scene_age_suppresses_the_scene_tool(self):
        self.brain.knowledge.upsert_facts("world-1", [
            {"key": "scene.report.age_seconds", "value": 10, "category": "system", "confidence": 1.0}])
        calls = self.brain._recommend_tools(v2(), self.scope)
        self.assertNotIn("unity.scene.report", [call["tool"] for call in calls])

    def test_a_stale_published_scene_age_requests_the_scene_tool(self):
        self.brain.knowledge.upsert_facts("world-1", [
            {"key": "scene.report.age_seconds", "value": 9000, "category": "system", "confidence": 1.0}])
        calls = self.brain._recommend_tools(v2(), self.scope)
        self.assertIn("unity.scene.report", [call["tool"] for call in calls])

    def test_replay_returns_the_same_tool_calls(self):
        data = v2()
        first = self.brain.tick_v2(data)
        self.assertEqual(self.brain.tick_v2(deepcopy(data))["tool_calls"], first["tool_calls"])

    def test_the_v1_response_has_no_tool_calls(self):
        response = self.brain.tick(request())
        self.assertNotIn("tool_calls", response)


class FixPlanTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.project = Path(self._tmp.name) / "Project"
        (self.project / "AICore" / "outputs" / "scene").mkdir(parents=True)
        self.report = self.project / "AICore" / "outputs" / "scene" / "scene-report.json"

    def _write_report(self, findings):
        self.report.write_text(json.dumps({"summary": {"findings": len(findings)},
                                           "findings": findings}), encoding="utf-8")

    def _plan(self, **extra):
        params = {"project_root": str(self.project)}
        params.update(extra)
        return tools.execute_scoped("scene.fixplan", params, project_root=self.project,
                                    confine=True, db_path=self.project / "brain.sqlite3")

    def test_a_plan_is_produced_from_a_report(self):
        self._write_report([
            {"id": "scene.no-camera", "severity": "warning", "evidence": "-"},
            {"id": "scene.multiple-AudioListener", "severity": "error", "evidence": "p"},
        ])
        result = self._plan()
        self.assertTrue(result.ok, result.error)
        actions = [fix["action"] for fix in result.data["fixes"]]
        self.assertIn("add-camera", actions)
        self.assertIn("remove-extra-singletons", actions)
        self.assertEqual(result.data["fixes"][0]["severity"], "error")

    def test_every_fix_names_the_finding_it_resolves(self):
        self._write_report([{"id": "scene.lodgroup-present", "severity": "info", "evidence": "p"}])
        fix = self._plan().data["fixes"][0]
        self.assertEqual(fix["finding"], "scene.lodgroup-present")
        self.assertEqual(fix["id"], "fix.scene.lodgroup-present")
        self.assertTrue(fix["reversible"])

    def test_unknown_findings_are_reported_not_guessed(self):
        self._write_report([{"id": "scene.something-new", "severity": "warning", "evidence": "p"}])
        result = self._plan()
        self.assertTrue(result.ok, result.error)
        self.assertEqual(result.data["fixes"], [])
        self.assertEqual(result.data["unresolved_findings"], ["scene.something-new"])

    def test_a_missing_report_is_a_clean_error(self):
        result = self._plan()
        self.assertFalse(result.ok)
        self.assertIn("scene report not found", result.error)

    def test_a_report_outside_the_root_is_refused(self):
        outside = Path(self._tmp.name) / "elsewhere.json"
        outside.write_text(json.dumps({"findings": []}), encoding="utf-8")
        result = self._plan(report=str(outside))
        self.assertFalse(result.ok)
        self.assertIn("configured project root", result.error)

    def test_the_plan_is_reproducible(self):
        self._write_report([{"id": "scene.no-camera", "severity": "warning", "evidence": "-"}])
        self.assertEqual(self._plan().data, self._plan().data)


class RevokeToolTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.project = Path(self._tmp.name) / "Project"
        (self.project / "AICore" / "outputs").mkdir(parents=True)

    def _run(self, name, params):
        return tools.execute_scoped(name, params, project_root=self.project,
                                    approval=MASTER, allow_write=True, confine=False,
                                    db_path=self.project / "brain.sqlite3")

    def test_revocation_needs_a_valid_operator_secret(self):
        result = self._run("brain.approval.revoke",
                           {"before_now": True, "master": "wrong-secret-0123456789"})
        self.assertFalse(result.ok)
        self.assertIn("approval secret", result.error)

    def test_revocation_needs_something_to_revoke(self):
        result = self._run("brain.approval.revoke", {"master": MASTER})
        self.assertFalse(result.ok)
        self.assertIn("nonce", result.error)

    def test_revoking_a_single_permit_is_recorded(self):
        issued = self._run("brain.approval.issue",
                           {"tool": "outputs.write_text", "path": "a.txt",
                            "subject": "operator-test", "master": MASTER})
        result = self._run("brain.approval.revoke",
                           {"nonce": issued.data["nonce"], "master": MASTER})
        self.assertTrue(result.ok, result.error)
        self.assertEqual(result.data["nonce"], issued.data["nonce"])


if __name__ == "__main__":
    unittest.main()
