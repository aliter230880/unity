"""Tests for the decision layer: fix, keep reading, or stop."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "brain"))

import decide  # noqa: E402

FINDINGS = [{"id": "scene.no-camera", "severity": "warning"},
            {"id": "scene.multiple-AudioListener", "severity": "error"}]
PLAN = {"plan_id": "fix_abc",
        "fixes": [{"id": "fix.scene.no-camera", "risk": "low"},
                  {"id": "fix.scene.multiple-AudioListener", "risk": "low"}],
        "unresolved_findings": []}


class DecisionTests(unittest.TestCase):
    def test_fixable_findings_lead_to_a_fix_decision(self):
        result = decide.decide(FINDINGS, PLAN, subject="operator-1")
        self.assertEqual(result["action"], decide.DECISION_FIX)
        self.assertEqual(result["count"], 2)
        self.assertEqual(result["plan_id"], "fix_abc")
        self.assertTrue(result["needs_backup"])

    def test_a_fix_decision_names_what_it_needs(self):
        result = decide.decide(FINDINGS, PLAN, subject="operator-1")
        self.assertEqual(result["requires"]["tool"], "outputs.write_text")
        self.assertEqual(result["requires"]["subject"], "operator-1")
        self.assertIn("dry run", result["note"])

    def test_risks_are_deduplicated_and_sorted(self):
        plan = {"fixes": [{"id": "a", "risk": "medium"}, {"id": "b", "risk": "low"},
                          {"id": "c", "risk": "medium"}]}
        self.assertEqual(decide.decide(FINDINGS, plan)["risks"], ["low", "medium"])

    def test_findings_without_a_plan_keep_the_brain_reading(self):
        result = decide.decide(FINDINGS, {"plan_id": "p", "unresolved_findings": ["scene.odd"]})
        self.assertEqual(result["action"], decide.DECISION_OBSERVE)
        self.assertEqual(result["unresolved"], ["scene.odd"])
        self.assertEqual(result["requires"], {})

    def test_nothing_broken_leads_to_idle(self):
        result = decide.decide([], PLAN)
        self.assertEqual(result["action"], decide.DECISION_IDLE)
        self.assertEqual(result["count"], 0)

    def test_unresolved_findings_are_still_reported_when_fixing(self):
        plan = dict(PLAN, unresolved_findings=["scene.something-new"])
        result = decide.decide(FINDINGS, plan)
        self.assertEqual(result["action"], decide.DECISION_FIX)
        self.assertEqual(result["unresolved"], ["scene.something-new"])

    def test_a_malformed_plan_is_ignored_not_trusted(self):
        for bad in (None, [], "nope", {"fixes": "no"}, {"fixes": [None, 5]}):
            result = decide.decide(FINDINGS, bad)
            self.assertEqual(result["action"], decide.DECISION_OBSERVE, bad)

    def test_no_findings_and_no_plan_is_idle(self):
        self.assertEqual(decide.decide(None, None)["action"], decide.DECISION_IDLE)


    def test_what_the_brain_already_knows_still_counts(self):
        # A pass that only refreshed the scene report must not conclude "all clear".
        result = decide.decide([], None, known_findings=4)
        self.assertEqual(result["action"], decide.DECISION_OBSERVE)
        self.assertIn("4", result["reason"])

    def test_known_findings_are_ignored_when_a_pass_saw_none_and_knows_none(self):
        self.assertEqual(decide.decide([], None, known_findings=0)["action"], decide.DECISION_IDLE)

    def test_a_bad_known_count_is_treated_as_zero(self):
        for bad in (None, "many", -3, True):
            self.assertEqual(decide.decide([], None, known_findings=bad)["action"],
                             decide.DECISION_IDLE, bad)

    def test_a_fix_decision_counts_what_is_known_too(self):
        result = decide.decide([], PLAN, known_findings=3)
        self.assertEqual(result["action"], decide.DECISION_FIX)
        self.assertIn("3", result["reason"])


    def test_a_stale_report_blocks_a_fix(self):
        result = decide.decide(FINDINGS, PLAN, report_age_seconds=decide.STALE_REPORT_SECONDS + 1)
        self.assertEqual(result["action"], decide.DECISION_OBSERVE)
        self.assertEqual(result["blocked_by"], "stale-report")
        self.assertIn("refresh", result["reason"])

    def test_a_fresh_report_allows_a_fix(self):
        result = decide.decide(FINDINGS, PLAN, report_age_seconds=10)
        self.assertEqual(result["action"], decide.DECISION_FIX)
        self.assertEqual(result["blocked_by"], "")

    def test_an_unknown_report_age_does_not_block(self):
        self.assertEqual(decide.decide(FINDINGS, PLAN, report_age_seconds=None)["action"],
                         decide.DECISION_FIX)

    def test_a_boolean_age_is_not_an_age(self):
        self.assertEqual(decide.decide([], None, known_findings=2, report_age_seconds=True)["action"],
                         decide.DECISION_OBSERVE)


    def test_a_scene_where_nothing_is_observed_is_flagged(self):
        plan = dict(PLAN, scene="Assets/Scenes/Main.unity")
        result = decide.decide(FINDINGS, plan, map_context={"objects": 5, "observed": 0})
        self.assertEqual(result["action"], decide.DECISION_FIX)
        self.assertTrue(any("observable" in warning for warning in result["warnings"]),
                        result["warnings"])

    def test_an_observed_scene_is_not_flagged(self):
        plan = dict(PLAN, scene="Assets/Scenes/Main.unity")
        result = decide.decide(FINDINGS, plan, map_context={"objects": 5, "observed": 2})
        self.assertEqual(result["warnings"], [])
        self.assertEqual(result["impact"]["observed"], 2)

    def test_dependents_are_reported_as_impact(self):
        result = decide.decide(FINDINGS, PLAN, map_context={"objects": 3, "observed": 1,
                                                            "dependents": 4})
        self.assertEqual(result["impact"]["dependents"], 4)
        self.assertTrue(any("depend" in warning for warning in result["warnings"]))

    def test_without_a_map_there_is_nothing_to_flag(self):
        result = decide.decide(FINDINGS, PLAN)
        self.assertEqual(result["warnings"], [])
        self.assertEqual(result["impact"], {})

    def test_a_broken_map_context_is_ignored(self):
        for bad in ({"objects": "many"}, {"observed": None}, "nope", 5):
            result = decide.decide(FINDINGS, PLAN, map_context=bad)
            self.assertEqual(result["action"], decide.DECISION_FIX, bad)

    def test_the_decision_is_reproducible(self):
        self.assertEqual(decide.decide(FINDINGS, PLAN), decide.decide(FINDINGS, PLAN))

    def test_the_decision_carries_its_reason(self):
        for findings, plan in ((FINDINGS, PLAN), (FINDINGS, None), ([], None)):
            self.assertTrue(decide.decide(findings, plan)["reason"])


if __name__ == "__main__":
    unittest.main()
