"""Tests for the observation scheduler and the run_observation entry point."""
from __future__ import annotations

import json
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path

TESTS_DIR = Path(__file__).resolve().parent
BRAIN = TESTS_DIR.parent / "brain"
sys.path.insert(0, str(BRAIN))

import schedule  # noqa: E402
import server  # noqa: E402


class SchedulerUnitTests(unittest.TestCase):
    def test_an_interval_must_be_positive(self):
        for bad in (0, -1, -0.5):
            with self.assertRaises(ValueError):
                schedule.ObservationScheduler(lambda: None, bad)

    def test_the_tick_must_be_callable(self):
        with self.assertRaises(ValueError):
            schedule.ObservationScheduler("nope", 1)

    def test_run_once_records_the_result(self):
        scheduler = schedule.ObservationScheduler(lambda: {"ok": True}, 60)
        self.assertEqual(scheduler.run_once(), {"ok": True})
        self.assertEqual(scheduler.runs, 1)
        self.assertEqual(scheduler.failures, 0)
        self.assertEqual(scheduler.last_result, {"ok": True})

    def test_a_failing_tick_is_recorded_and_not_raised(self):
        def boom():
            raise RuntimeError("nope")
        scheduler = schedule.ObservationScheduler(boom, 60)
        self.assertIsNone(scheduler.run_once())
        scheduler.run_once()
        self.assertEqual(scheduler.runs, 0)
        self.assertEqual(scheduler.failures, 2)
        self.assertIn("RuntimeError", scheduler.last_error)

    def test_a_failure_does_not_stop_the_loop(self):
        state = {"calls": 0}

        def flaky():
            state["calls"] += 1
            if state["calls"] == 1:
                raise RuntimeError("first one fails")
            return "recovered"
        scheduler = schedule.ObservationScheduler(flaky, 0.05)
        scheduler.start()
        deadline = time.monotonic() + 5
        while scheduler.runs < 1 and time.monotonic() < deadline:
            time.sleep(0.05)
        scheduler.stop()
        self.assertGreaterEqual(scheduler.runs, 1, scheduler.stats())
        self.assertEqual(scheduler.failures, 1)

    def test_stop_is_safe_before_start(self):
        scheduler = schedule.ObservationScheduler(lambda: None, 1)
        scheduler.stop()
        self.assertFalse(scheduler.running)

    def test_start_is_idempotent(self):
        scheduler = schedule.ObservationScheduler(lambda: None, 0.05)
        scheduler.start()
        scheduler.start()
        self.assertTrue(scheduler.running)
        scheduler.stop()
        self.assertFalse(scheduler.running)

    def test_stats_describe_the_loop(self):
        scheduler = schedule.ObservationScheduler(lambda: 1, 2.5)
        stats = scheduler.stats()
        self.assertEqual(stats["interval_seconds"], 2.5)
        self.assertFalse(stats["running"])


class RunObservationTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.root = Path(self._tmp.name)
        self.project = self.root / "Project"
        (self.project / "Assets").mkdir(parents=True)
        (self.project / "Logs").mkdir(parents=True)
        (self.project / "Logs" / "broken.log").write_text(
            "Unhandled exception: boom\n", encoding="utf-8")
        self.db = self.root / "brain.sqlite3"
        self.brain = server.Brain(self.db)
        self.addCleanup(self.brain.close)

    def observe(self, world="world-1"):
        return server.run_observation(self.brain, self.project, self.db, world, "session-1",
                                      budget=3, logs_override=[str(self.project / "Logs" / "broken.log")])

    def test_it_runs_tools_and_writes_facts(self):
        result = self.observe()
        self.assertTrue(result["tools"])
        self.assertGreaterEqual(result["facts_written"], 1)
        facts = {row["key"] for row in self.brain.knowledge.query_facts("world-1", "", "", 50)}
        self.assertIn("diagnostics.last_run", facts)

    def test_a_second_run_asks_for_less(self):
        # The loop closing, observed from outside: once the diagnostics have been read,
        # the planner stops asking for them, so the second run executes fewer tools.
        first = self.observe()
        second = self.observe()
        self.assertLess(len(second["tools"]), len(first["tools"]),
                        "the brain asked for the same reading twice")
        self.assertNotIn("project.diagnostics", second["recommended"])


    def test_the_scheduler_can_drive_it(self):
        scheduler = schedule.ObservationScheduler(lambda: self.observe(), 0.05)
        scheduler.start()
        deadline = time.monotonic() + 5
        while scheduler.runs < 2 and time.monotonic() < deadline:
            time.sleep(0.05)
        scheduler.stop()
        self.assertGreaterEqual(scheduler.runs, 2, scheduler.stats())
        self.assertEqual(scheduler.failures, 0, scheduler.last_error)

    def test_a_missing_project_root_does_not_crash_the_tick(self):
        result = server.run_observation(self.brain, None, self.db, "world-1", "session-1")
        self.assertIn("tools", result)



class BackoffTests(unittest.TestCase):
    def test_bad_configuration_is_refused(self):
        for bad in (0, -1, True):
            with self.assertRaises(ValueError):
                schedule.BackoffSchedule(bad)
        with self.assertRaises(ValueError):
            schedule.BackoffSchedule(60, factor=0.5)

    def test_quiet_outcomes_wait_longer(self):
        backoff = schedule.BackoffSchedule(60)
        self.assertEqual(backoff.next_interval("converged"), 120)
        self.assertEqual(backoff.next_interval("converged"), 240)
        self.assertEqual(backoff.quiet_streak, 2)

    def test_the_wait_is_capped(self):
        backoff = schedule.BackoffSchedule(60, factor=10, maximum_seconds=200)
        self.assertEqual(backoff.next_interval("converged"), 200)
        self.assertEqual(backoff.next_interval("converged"), 200)

    def test_a_change_snaps_back_to_the_base_interval(self):
        backoff = schedule.BackoffSchedule(60)
        backoff.next_interval("converged")
        backoff.next_interval("converged")
        self.assertEqual(backoff.next_interval("applied-and-verified"), 60)
        self.assertEqual(backoff.quiet_streak, 0)

    def test_a_refusal_is_not_treated_as_quiet(self):
        # Work is waiting or a person is needed: do not slow down for that.
        backoff = schedule.BackoffSchedule(60)
        self.assertEqual(backoff.next_interval("refused-by-policy"), 60)
        self.assertEqual(backoff.next_interval("rolled-back"), 60)
        self.assertEqual(backoff.quiet_streak, 0)

    def test_the_ceiling_cannot_sit_below_the_base(self):
        with self.assertRaises(ValueError):
            schedule.BackoffSchedule(60, maximum_seconds=10)

    def test_describe_reports_the_current_state(self):
        backoff = schedule.BackoffSchedule(30, factor=2)
        backoff.next_interval("converged")
        report = backoff.describe()
        self.assertEqual(report["interval"], 60)
        self.assertEqual(report["quiet_streak"], 1)

if __name__ == "__main__":
    unittest.main()
