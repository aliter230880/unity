"""The player proof stays runnable: harness, build entry and receipt parsing checked without Unity.

The player harness is the only way to prove the running game obeys the brain on machines where
the editor never advances Play Mode frames, so it must not rot silently. These checks are
static: they read the harness sources and exercise the receipt parser.
"""

from __future__ import annotations

import importlib.util
import re
import unittest
from pathlib import Path

WORLD_DIR = Path(__file__).resolve().parent.parent      # AICore/WorldDirector
TOOLS = WORLD_DIR / "tools"
PLAYER_SOURCES = TOOLS / "player"
UNITY_PROJECT = __import__("projectroot").optional_root()


def load_driver():
    spec = importlib.util.spec_from_file_location(
        "run_npc_world_playercheck", TOOLS / "run_npc_world_playercheck.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class PlayerHarnessTests(unittest.TestCase):
    def test_harness_sources_are_present(self) -> None:
        for name in ("AICorePlayerCheck.cs", "AICorePlayerBuild.cs"):
            self.assertTrue((PLAYER_SOURCES / name).is_file(),
                            "the player harness source is missing: %s" % name)

    def test_runtime_harness_is_guarded_and_quits(self) -> None:
        text = (PLAYER_SOURCES / "AICorePlayerCheck.cs").read_text(encoding="utf-8")
        self.assertIn('Environment.GetEnvironmentVariable("AICORE_PLAY_CHECK")', text,
                      "the harness must only act when the check is requested")
        self.assertIn('Environment.GetEnvironmentVariable("AICORE_TOKEN")', text,
                      "the bearer token must come from the environment, never the scene")
        self.assertIn("Application.Quit(", text, "a check that can hang is worse than one that fails")
        self.assertIn("[AICorePlay] after ", text, "the receipt format is the contract")
        self.assertNotIn("EditorApplication", text, "the player harness must not depend on the editor")

    def test_build_entry_targets_windows_player(self) -> None:
        text = (PLAYER_SOURCES / "AICorePlayerBuild.cs").read_text(encoding="utf-8")
        self.assertIn("BuildTarget.StandaloneWindows64", text)
        self.assertIn("BuildPipeline.BuildPlayer", text)
        self.assertIn('Environment.GetEnvironmentVariable("AICORE_SCENE")', text)
        self.assertIn('Environment.GetEnvironmentVariable("AICORE_PLAYER_BUILD")', text)

    def test_receipt_parser_accepts_a_real_line(self) -> None:
        driver = load_driver()
        sample = ('[AICorePlay] after 16s: status="answered"; session=abc123; pendingPlan=True; '
                  'bufferedResults=0; lastAction=none; entitiesOwnedByThisDirector=5; verdict=answered')
        match = driver.RECEIPT_LINE.search(sample)
        self.assertIsNotNone(match, "the driver must recognise the receipt line the harness prints")
        fields = dict(part.split("=", 1) for part in match.group(1).split("; ") if "=" in part)
        self.assertEqual("5", fields["entitiesOwnedByThisDirector"].strip('"'))
        self.assertEqual("answered", fields["verdict"])

    def test_driver_reads_the_scene_out_of_the_repository(self) -> None:
        if UNITY_PROJECT is None:
            self.skipTest(__import__("projectroot").REASON)
        driver = load_driver()
        self.assertTrue(driver.SCENE_IN_TWIN.endswith("AICoreWorld/NpcWorldScene.unity"))
        self.assertTrue((UNITY_PROJECT / "Assets" / "AICoreWorld" / "NpcWorldScene.unity").is_file())
        self.assertNotIn("AICore/outputs", str(driver.PLAYER_DIR),
                         "a player build must not land inside the repository")


if __name__ == "__main__":
    unittest.main()
