"""Tests for POST /v1/knowledge: the narrow way a client publishes what it sees."""
from __future__ import annotations

import json
import sys
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
from pathlib import Path

TESTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(TESTS_DIR.parent / "brain"))

import server  # noqa: E402

TOKEN = "publish-token-0123456789"


class PublishCase(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.root = Path(self._tmp.name)
        self.db = self.root / "brain.sqlite3"
        self.brain = server.Brain(self.db)
        self.addCleanup(self.brain.close)
        self.server = server.make_server(self.brain, TOKEN, 0)
        self.addCleanup(self.server.server_close)
        threading.Thread(target=self.server.serve_forever, daemon=True).start()
        self.addCleanup(self.server.shutdown)
        self.base = "http://127.0.0.1:%d" % self.server.server_address[1]

    def _send(self, request):
        last = None
        for _attempt in range(3):
            try:
                with urllib.request.urlopen(request, timeout=30) as response:
                    return response.status, json.loads(response.read().decode("utf-8"))
            except urllib.error.HTTPError as error:
                return error.code, json.loads(error.read().decode("utf-8"))
            except (ConnectionError, OSError) as error:
                last = error
                time.sleep(0.25)
        raise AssertionError("the request never completed: %s" % last)

    def publish(self, body, token=TOKEN):
        request = urllib.request.Request(self.base + "/v1/knowledge",
                                         data=json.dumps(body).encode("utf-8"), method="POST")
        request.add_header("Content-Type", "application/json")
        if token is not None:
            request.add_header("Authorization", "Bearer " + token)
        return self._send(request)

    def get(self, path, token=TOKEN):
        request = urllib.request.Request(self.base + path)
        if token is not None:
            request.add_header("Authorization", "Bearer " + token)
        return self._send(request)


class PublishTests(PublishCase):
    def test_facts_are_stored_and_readable(self):
        status, body = self.publish({"world_id": "sandbox", "facts": [
            {"key": "scene.name", "value": "SandboxScene", "category": "system", "confidence": 0.9},
            {"key": "scene.objects", "value": 5, "category": "system", "confidence": 0.9},
        ]})
        self.assertEqual(status, 200, body)
        self.assertEqual(body["accepted"], 2)
        self.assertEqual(body["rejected"], [])
        status, knowledge = self.get("/v1/knowledge?world=sandbox&limit=10")
        keys = {fact["key"] for fact in knowledge["facts"]}
        self.assertIn("scene.name", keys)
        self.assertIn("scene.objects", keys)

    def test_a_bad_fact_is_reported_without_losing_the_good_ones(self):
        status, body = self.publish({"world_id": "sandbox", "facts": [
            {"key": "good.key", "value": 1, "category": "system", "confidence": 0.5},
            {"key": "bad key with spaces", "value": 1, "category": "system", "confidence": 0.5},
        ]})
        self.assertEqual(status, 200, body)
        self.assertEqual(body["accepted"], 1)
        self.assertEqual(len(body["rejected"]), 1)
        self.assertEqual(body["rejected"][0]["index"], 1)

    def test_the_fact_count_comes_back(self):
        self.publish({"world_id": "sandbox", "facts": [
            {"key": "a.b", "value": "x", "category": "system", "confidence": 1.0}]})
        status, body = self.publish({"world_id": "sandbox", "facts": [
            {"key": "c.d", "value": "y", "category": "system", "confidence": 1.0}]})
        self.assertEqual(body["fact_count"], 2)

    def test_an_empty_list_is_refused(self):
        self.assertEqual(self.publish({"world_id": "sandbox", "facts": []})[0], 400)

    def test_a_missing_world_is_refused(self):
        self.assertEqual(self.publish({"facts": [
            {"key": "a.b", "value": 1, "category": "system", "confidence": 1.0}]})[0], 400)

    def test_too_many_facts_are_refused(self):
        facts = [{"key": "a.%d" % index, "value": index, "category": "system", "confidence": 1.0}
                 for index in range(server.MAX_PUBLISHED_FACTS + 1)]
        self.assertEqual(self.publish({"world_id": "w", "facts": facts})[0], 400)

    def test_relations_cannot_be_published(self):
        status, _ = self.publish({"world_id": "w", "facts": [
            {"key": "a.b", "value": 1, "category": "system", "confidence": 1.0}],
            "relations": []})
        self.assertEqual(status, 400)

    def test_a_token_is_required(self):
        self.assertEqual(self.publish({"world_id": "w", "facts": [
            {"key": "a.b", "value": 1, "category": "system", "confidence": 1.0}]},
            token=None)[0], 401)

    def test_broken_json_is_a_400(self):
        request = urllib.request.Request(self.base + "/v1/knowledge", data=b"{not json",
                                         method="POST")
        request.add_header("Content-Type", "application/json")
        request.add_header("Authorization", "Bearer " + TOKEN)
        self.assertEqual(self._send(request)[0], 400)

    def test_publishing_does_not_touch_a_project(self):
        with tempfile.TemporaryDirectory() as tmp:
            project = Path(tmp)
            (project / "Assets").mkdir()
            before = sorted(str(item) for item in project.rglob("*"))
            self.publish({"world_id": "w", "facts": [
                {"key": "a.b", "value": 1, "category": "system", "confidence": 1.0}]})
            after = sorted(str(item) for item in project.rglob("*"))
        self.assertEqual(before, after)


if __name__ == "__main__":
    unittest.main()
