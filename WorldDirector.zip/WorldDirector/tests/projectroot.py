"""Locate the Unity project that this WorldDirector tree belongs to.

The suites that inspect Unity-side assets (the NPC world scene and catalog, the
sandbox sources, the project inventory) need the root of the real Unity project.
Inside that project this tree sits at ``<project>/AICore/WorldDirector``, so
walking two levels up is correct. In a mirror or hub copy there is no ``Assets/``
two levels up, and guessing produces false failures - the root must be either
discoverable or explicitly provided.

Resolution order:

1. ``AICORE_PROJECT_ROOT`` - absolute path of a Unity project root (must contain
   ``Assets/`` and ``ProjectSettings/``).
2. Two levels up from this file, when that directory really is a Unity project.

Callers that can live without the real tree use :func:`optional_root` and skip
with :data:`REASON`; callers that cannot work at all without it use
:func:`project_root` and let the error name the fix.
"""

from __future__ import annotations

import os
from pathlib import Path

WORLD_DIR = Path(__file__).resolve().parent.parent  # AICore/WorldDirector

REASON = ("no Unity project around this copy and AICORE_PROJECT_ROOT is not set; "
          "asset tests need the real project (for example "
          "AICORE_PROJECT_ROOT=D:\\Work\\Unity\\Projects\\AICore_0.5)")


class TestRootUnavailable(RuntimeError):
    """Raised when neither the environment nor the layout names a Unity project."""


def _is_unity_project(root: Path) -> bool:
    return (root / "Assets").is_dir() and (root / "ProjectSettings").is_dir()


def project_root() -> Path:
    """Return the Unity project root, raising TestRootUnavailable when unknown."""
    override = os.environ.get("AICORE_PROJECT_ROOT", "").strip()
    if override:
        root = Path(override).expanduser().resolve()
        if _is_unity_project(root):
            return root
        raise TestRootUnavailable(
            "AICORE_PROJECT_ROOT=%s is not a Unity project root "
            "(expected Assets/ and ProjectSettings/ inside)" % root)
    candidate = WORLD_DIR.parent.parent
    if _is_unity_project(candidate):
        return candidate
    raise TestRootUnavailable(REASON)


def optional_root() -> Path | None:
    """Return the project root, or None when this tree is only a mirror copy."""
    try:
        return project_root()
    except TestRootUnavailable:
        return None
