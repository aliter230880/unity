"""Prove the NPC world works with the live brain.

The main project is usually open in the Unity editor, and Unity refuses to open the same
project twice, so the proof mirrors the world assets into the validation twin
(AICore/WorldDirector/ValidationProject - a second project in this repository that uses the
same package), starts the brain on loopback with a fresh database, runs the Play Mode check
there, and reads the verdict out of the log. The twin copies are removed in a finally block.

    python tools\\run_npc_world_playcheck.py [--expect-count 5] [--timeout 300] [--keep-twin-assets]

Success means the receipt reports verdict=answered AND
entitiesOwnedByThisDirector == --expect-count: those NPCs exist in the running game because
the brain decided to create them, not because a human placed them.

The bearer token is generated here and only ever lives in the child processes' environment.
It is redacted from every line this script prints or writes.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import secrets
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

TOOLS_DIR = Path(__file__).resolve().parent
WORLD_DIR = TOOLS_DIR.parent                 # AICore/WorldDirector
REPO = WORLD_DIR.parent.parent               # the Unity project
TWIN = WORLD_DIR / "ValidationProject"       # batch-capable twin, same package
OUT = REPO / "AICore" / "outputs" / "scene"

WORLD_ASSETS = REPO / "Assets" / "AICoreWorld"
HARNESS_SOURCES = (
    REPO / "Assets" / "AICoreHarness" / "Editor" / "AICorePlayCheck.cs",
    REPO / "Assets" / "AICoreHarness" / "AICorePlayCheckRuntime.cs",
)

SCENE_IN_TWIN = "Assets/AICoreWorld/NpcWorldScene.unity"
SCENE_PATH = WORLD_ASSETS / "NpcWorldScene.unity"
WORLD_ID = "npc_world"

BRAIN_LOG = OUT / "npc-world-brain.log"
UNITY_LOG = OUT / "npc-world-playcheck-unity.log"
RECEIPT = OUT / "npc-world-playcheck.log"
DB = OUT / "npc-world-brain.sqlite3"

HOST = "http://127.0.0.1:8765"
PORT = 8765
RECEIPT_LINE = re.compile(r"\[AICorePlay\] after [0-9.]+s: (.*)")


def step(index: int, text: str) -> None:
    print("[%d] %s" % (index, text), flush=True)


def redact(text: str, token: str) -> str:
    return text.replace(token, "***") if token else text


def mirror_assets() -> list[Path]:
    """Copy the world and the harness into the twin, metadata included."""
    if not SCENE_PATH.is_file():
        raise SystemExit("the world scene is missing: %s" % SCENE_PATH)
    created: list[Path] = []

    target = TWIN / "Assets" / "AICoreWorld"
    if target.exists():
        shutil.rmtree(target)
    shutil.copytree(WORLD_ASSETS, target, copy_function=shutil.copy2)
    created.append(target)

    for source in HARNESS_SOURCES:
        if not source.is_file():
            raise SystemExit("the play harness is missing: %s" % source)
        relative = source.relative_to(REPO / "Assets")
        destination = TWIN / "Assets" / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        if source.with_suffix(source.suffix + ".meta").is_file():
            shutil.copy2(source.with_suffix(source.suffix + ".meta"),
                         destination.with_suffix(destination.suffix + ".meta"))
        harness_folder = TWIN / "Assets" / "AICoreHarness"
        if harness_folder not in created:
            created.append(harness_folder)
    return created


def start_brain(token: str) -> subprocess.Popen:
    env = os.environ.copy()
    env["AICORE_TOKEN"] = token
    env["PYTHONIOENCODING"] = "utf-8"
    if DB.exists():
        DB.unlink()
    handle = open(BRAIN_LOG, "w", encoding="utf-8", errors="replace")
    return subprocess.Popen(
        [sys.executable, "brain\\server.py", "--port", str(PORT), "--project", str(REPO),
         "--db", str(DB)],
        cwd=str(WORLD_DIR), env=env, stdout=handle, stderr=subprocess.STDOUT)


def wait_for_brain(token: str, timeout: float) -> dict | None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            request = urllib.request.Request(HOST + "/health",
                                             headers={"Authorization": "Bearer " + token})
            with urllib.request.urlopen(request, timeout=3) as response:
                return json.loads(response.read().decode("utf-8"))
        except Exception:
            time.sleep(0.5)
    return None


def brain_json(path: str, token: str) -> dict | None:
    try:
        request = urllib.request.Request(HOST + path, headers={"Authorization": "Bearer " + token})
        with urllib.request.urlopen(request, timeout=10) as response:
            return json.loads(response.read().decode("utf-8"))
    except Exception as error:  # a missing receipt must not fail the proof by itself
        return {"error": "%s: %s" % (type(error).__name__, error)}


def kill_tree(pid: int) -> None:
    subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def run_play_check(token: str, timeout: float, windowed: bool = False) -> tuple[int | None, bool]:
    unity = os.environ.get("UNITY_EXE", r"C:\Program Files\Unity\Hub\Editor\6000.3.9f1\Editor\Unity.exe")
    if not Path(unity).is_file():
        raise SystemExit("Unity was not found at %s (set UNITY_EXE)" % unity)
    env = os.environ.copy()
    env["AICORE_PLAY_CHECK"] = "1"
    env["AICORE_SCENE"] = SCENE_IN_TWIN
    env["AICORE_TOKEN"] = token
    env.setdefault("PROGRAMDATA", r"C:\ProgramData")
    env.setdefault("ALLUSERSPROFILE", r"C:\ProgramData")
    command = [unity, "-projectPath", str(TWIN),
               "-logFile", str(UNITY_LOG), "-executeMethod", "AICorePlayCheck.StartBatch"]
    if not windowed:
        # Batch is the default, but on some machines batch Play Mode never advances frames
        # (TOOLBOX.md); --windowed opens a normal editor window instead.
        command[1:1] = ["-batchmode", "-nographics"]
    process = subprocess.Popen(command, env=env, stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL)
    try:
        return process.wait(timeout=timeout), False
    except subprocess.TimeoutExpired:
        kill_tree(process.pid)
        try:
            process.wait(timeout=30)
        except subprocess.TimeoutExpired:
            pass
        return None, True


def parse_receipt(text: str) -> tuple[str | None, dict]:
    match = RECEIPT_LINE.search(text)
    if match is None:
        return None, {}
    fields: dict[str, str] = {}
    for part in match.group(1).split("; "):
        if "=" in part:
            key, value = part.split("=", 1)
            fields[key.strip()] = value.strip()
    return match.group(0), fields


def main() -> int:
    parser = argparse.ArgumentParser(description="Run the NPC world Play Mode proof.")
    parser.add_argument("--expect-count", type=int, default=5)
    parser.add_argument("--timeout", type=float, default=300.0)
    parser.add_argument("--windowed", action="store_true",
                        help="open a normal editor window instead of batch: batch Play Mode "
                             "does not advance frames on some machines (see TOOLBOX.md)")
    parser.add_argument("--keep-twin-assets", action="store_true")
    args = parser.parse_args()

    OUT.mkdir(parents=True, exist_ok=True)
    token = secrets.token_urlsafe(32)
    copied: list[Path] = []
    brain: subprocess.Popen | None = None
    verdict_fields: dict[str, str] = {}
    line: str | None = None
    unity_code: int | None = None
    timed_out = False
    reason = ""
    goals: dict | None = None
    stats: dict | None = None

    try:
        step(1, "mirroring the world and the harness into %s" % TWIN.name)
        copied = mirror_assets()
        step(2, "starting the brain on %s with a fresh database" % HOST)
        brain = start_brain(token)
        health = wait_for_brain(token, 45.0)
        if health is None:
            reason = "the brain did not answer /health"
            return finish(1, token, copied, brain, line, verdict_fields, unity_code, timed_out,
                          reason, goals, stats, args.keep_twin_assets)
        step(3, "brain is up: %s" % json.dumps(health, ensure_ascii=False))
        step(4, "running the Play Mode check in the twin (timeout %.0fs)" % args.timeout)
        unity_code, timed_out = run_play_check(token, args.timeout, args.windowed)
        text = UNITY_LOG.read_text(encoding="utf-8", errors="replace") if UNITY_LOG.is_file() else ""
        line, verdict_fields = parse_receipt(text)
        if line is None:
            reason = "no [AICorePlay] receipt in the log (unity exit=%s, timed out=%s)" % (
                unity_code, timed_out)
            # A batch Play Mode that never advances leaves no receipt: on this machine the editor
            # update pump stops after an internal search-database exception. Record the fingerprint
            # so a failed run says why instead of just timing out.
            if "SearchDatabase" in text and "ArgumentOutOfRangeException" in text:
                reason += "; the Unity editor loop stopped after an internal search-database exception"
            return finish(1, token, copied, brain, line, verdict_fields, unity_code, timed_out,
                          reason, goals, stats, args.keep_twin_assets)
        step(5, redact(line, token))

        session = verdict_fields.get("session", "")
        goals = brain_json("/v1/goals?world=%s&session=%s" % (WORLD_ID, session), token)
        stats = brain_json("/v1/stats", token)

        owned = verdict_fields.get("entitiesOwnedByThisDirector", "")
        verdict = verdict_fields.get("verdict", "")
        if verdict != "answered":
            reason = "the director did not answer (verdict=%s)" % verdict
        elif not owned.isdigit() or int(owned) != args.expect_count:
            reason = "the brain populated %s of %d requested NPCs" % (owned, args.expect_count)
        else:
            reason = ""
        return finish(0 if not reason else 1, token, copied, brain, line, verdict_fields,
                      unity_code, timed_out, reason, goals, stats, args.keep_twin_assets)
    finally:
        pass


def finish(code: int, token: str, copied: list[Path], brain: subprocess.Popen | None,
           line: str | None, fields: dict, unity_code: int | None, timed_out: bool,
           reason: str, goals: dict | None, stats: dict | None, keep_assets: bool) -> int:
    step(6, "stopping the brain and removing the twin copies")
    leftover: list[str] = []
    if brain is not None:
        brain.terminate()
        try:
            brain.wait(timeout=15)
        except subprocess.TimeoutExpired:
            brain.kill()
            leftover.append("the brain had to be killed")
    if not keep_assets:
        for path in copied:
            if path.exists():
                shutil.rmtree(path, ignore_errors=True)
            meta = path.with_suffix(path.suffix + ".meta")
            if meta.exists():
                meta.unlink()
    else:
        leftover.append("twin copies were kept on request")

    lines = [
        "NPC WORLD PLAYCHECK receipt",
        "utc: %s" % time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "project: %s" % REPO,
        "scene: %s (run in the twin %s)" % (SCENE_PATH, TWIN.name),
        "unity exit: %s; timed out: %s" % (unity_code, timed_out),
        "play receipt: %s" % (line if line else "none"),
        "goals: %s" % json.dumps(goals, ensure_ascii=False, sort_keys=True),
        "stats: %s" % json.dumps(stats, ensure_ascii=False, sort_keys=True),
        "cleanup: %s" % ("; ".join(leftover) if leftover else "twin copies removed"),
        "NPC WORLD PLAYCHECK: %s%s" % ("PASSED" if code == 0 else "FAILED",
                                       "" if code == 0 else " - " + reason),
    ]
    RECEIPT.write_text(redact("\n".join(lines) + "\n", token), encoding="utf-8")
    step(7, redact(lines[-1], token))
    step(8, "receipt written to %s" % RECEIPT)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
