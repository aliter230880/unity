// Hub copy of 111 Assets/AICoreMultiplayer/Editor/LibraryImport.cs.
// Apply AFTER client #7 finishes: copy over the 111 file, then RunBatch.
// Change vs live 111: decoration targetCount 5 → DecorationTargetCount (12).
// Five props per type vanish on the AMT City.prefab; twelve is the first
// density that reads as a street, without exploding maxOwnedEntities.
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using AliTerra.AICore;
using Mirror;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace AICoreMultiplayer.Editor
{
    public static class LibraryImport
    {
        private const int DecorationTargetCount = 12;

        [Serializable]
        private class StagedItem
        {
            public string id; public string name; public string source;
            public string license; public string url; public string model;
            public string[] textures;
        }
        [Serializable]
        private class StagedManifest { public StagedItem[] items; }

        private static string Root() { return Directory.GetParent(Application.dataPath).FullName; }
        private static string StagingRoot => Path.Combine(Root(), "AICore", "library", "staging");
        private const string CatalogPath = "Assets/AICoreMultiplayer/NPCatalog.asset";
        private const string ScenePath = "Assets/Advanced Multiplayer Template/Scenes/MainScene.unity";

        public static void RunBatch()
        {
            int code = 0;
            try { code = Run(); }
            catch (Exception error)
            {
                Debug.LogError("[LibraryImport] " + error.GetType().Name + ": " + error.Message);
                code = 1;
            }
            if (Application.isBatchMode) EditorApplication.Exit(code);
        }

        public static void RunViaBridge() { Run(); }

        private static int Run()
        {
            string manifestPath = Path.Combine(StagingRoot, "manifest.json");
            if (!File.Exists(manifestPath))
            {
                Debug.Log("[LibraryImport] result=Failed (no staged manifest)");
                return 1;
            }
            StagedManifest manifest = JsonUtility.FromJson<StagedManifest>(File.ReadAllText(manifestPath, Encoding.UTF8));
            if (manifest == null || manifest.items == null || manifest.items.Length == 0)
            {
                Debug.Log("[LibraryImport] result=NothingStaged");
                return 0;
            }
            PrefabCatalog catalog = AssetDatabase.LoadAssetAtPath<PrefabCatalog>(CatalogPath);
            if (catalog == null)
            {
                Debug.Log("[LibraryImport] result=Failed (catalog not found)");
                return 1;
            }
            var entries = new List<PrefabCatalog.Entry>(catalog.entries);
            var goals = new List<WorldDirector.SecondaryGoal>();
            int imported = 0, skipped = 0, failed = 0;

            foreach (StagedItem item in manifest.items)
            {
                string id = "prop_" + Sanitize(item.id);
                if (entries.Any(entry => entry != null && entry.id == id)) { skipped++; continue; }
                try
                {
                    GameObject prefab = ImportOne(item, id);
                    entries.Add(new PrefabCatalog.Entry { id = id, kind = "prop", prefab = prefab });
                    goals.Add(new WorldDirector.SecondaryGoal
                    {
                        goalId = "decoration." + id,
                        targetCatalogId = id,
                        targetCount = DecorationTargetCount,
                        goalPriority = 30,
                        goal = "Keep " + (string.IsNullOrEmpty(item.name) ? id : item.name) +
                               " placed around the city (" + (item.license ?? "CC0") + ", " + (item.source ?? "library") + ")."
                    });
                    imported++;
                }
                catch (Exception error)
                {
                    Debug.LogWarning("[LibraryImport] " + item.id + " failed: " + error.Message);
                    failed++;
                }
            }
            if (imported > 0)
            {
                catalog.entries = entries.ToArray();
                EditorUtility.SetDirty(catalog);
                AssetDatabase.SaveAssets();
                PatchScene(goals);
            }
            Debug.Log("[LibraryImport] result=Ok imported=" + imported +
                      " skipped=" + skipped + " failed=" + failed);
            return imported == 0 && failed > 0 ? 1 : 0;
        }

        private static string Sanitize(string value)
        {
            var builder = new StringBuilder();
            foreach (char c in (value ?? "").ToLowerInvariant())
                if (char.IsLetterOrDigit(c) || c == '_' || c == '-' || c == '.')
                    builder.Append(c);
            return builder.Length > 0 ? builder.ToString() : "model";
        }

        private static GameObject ImportOne(StagedItem item, string id)
        {
            string sourceDir = Path.Combine(StagingRoot, item.id);
            string modelFile = Path.GetFileName(item.model ?? "");
            if (string.IsNullOrEmpty(modelFile) || !File.Exists(Path.Combine(sourceDir, modelFile)))
                throw new InvalidOperationException("staged model file missing for " + item.id);

            string relativeDir = "Assets/AICoreLibrary/Models/" + item.id;
            string absoluteDir = Path.Combine(Root(), relativeDir);
            Directory.CreateDirectory(absoluteDir);
            Directory.CreateDirectory(Path.Combine(Root(), "Assets/AICoreLibrary/Prefabs"));
            File.Copy(Path.Combine(sourceDir, modelFile), Path.Combine(absoluteDir, modelFile), true);
            foreach (string texture in item.textures ?? new string[0])
                if (File.Exists(Path.Combine(sourceDir, texture)))
                    File.Copy(Path.Combine(sourceDir, texture), Path.Combine(absoluteDir, texture), true);
            AssetDatabase.Refresh(ImportAssetOptions.ForceUpdate);

            string modelAssetPath = relativeDir + "/" + modelFile;
            GameObject model = AssetDatabase.LoadAssetAtPath<GameObject>(modelAssetPath);
            if (model == null) throw new InvalidOperationException("model did not import: " + modelAssetPath);
            LinkTextures(modelAssetPath, absoluteDir, relativeDir);

            GameObject root = UnityEngine.Object.Instantiate(model);
            root.name = id;
            WorldEntity entity = root.AddComponent<WorldEntity>();
            entity.kind = "prop";
            entity.catalogId = id;
            root.AddComponent<NetworkIdentity>();
            MeshFilter mesh = root.GetComponentInChildren<MeshFilter>();
            if (mesh != null && mesh.sharedMesh != null)
            {
                BoxCollider collider = mesh.gameObject.AddComponent<BoxCollider>();
                collider.center = mesh.sharedMesh.bounds.center;
                collider.size = mesh.sharedMesh.bounds.size;
            }
            string prefabPath = "Assets/AICoreLibrary/Prefabs/" + id + ".prefab";
            GameObject prefab = PrefabUtility.SaveAsPrefabAsset(root, prefabPath);
            UnityEngine.Object.DestroyImmediate(root);
            return prefab;
        }

        private static void LinkTextures(string modelAssetPath, string absoluteDir, string relativeDir)
        {
            var textures = new List<Texture2D>();
            foreach (string file in Directory.GetFiles(absoluteDir, "*.jpg"))
                textures.Add(AssetDatabase.LoadAssetAtPath<Texture2D>(
                    relativeDir + "/" + Path.GetFileName(file)));
            textures.RemoveAll(texture => texture == null);
            if (textures.Count == 0) return;
            foreach (Material material in AssetDatabase.LoadAllAssetsAtPath(modelAssetPath).OfType<Material>())
            {
                bool dirty = false;
                if (material.HasProperty("_MainTex"))
                {
                    Texture2D diffuse = textures.FirstOrDefault(t => t.name.ToLowerInvariant().Contains("diff"))
                                        ?? textures.First();
                    material.SetTexture("_MainTex", diffuse);
                    dirty = true;
                }
                if (material.HasProperty("_BumpMap"))
                {
                    Texture2D normal = textures.FirstOrDefault(t => t.name.ToLowerInvariant().Contains("nor"));
                    if (normal != null) { material.SetTexture("_BumpMap", normal); dirty = true; }
                }
                if (dirty) EditorUtility.SetDirty(material);
            }
            AssetDatabase.SaveAssets();
        }

        private static void PatchScene(List<WorldDirector.SecondaryGoal> newGoals)
        {
            Scene scene = EditorSceneManager.OpenScene(ScenePath, OpenSceneMode.Single);
            WorldDirector director = UnityEngine.Object.FindFirstObjectByType<WorldDirector>();
            if (director == null) throw new InvalidOperationException("no WorldDirector in the scene");
            var existing = new List<WorldDirector.SecondaryGoal>(director.secondaryGoals ?? Array.Empty<WorldDirector.SecondaryGoal>());
            foreach (WorldDirector.SecondaryGoal goal in newGoals)
                if (!existing.Any(g => g != null && g.targetCatalogId == goal.targetCatalogId))
                    existing.Add(goal);
            director.secondaryGoals = existing.ToArray();
            // 11 new types × 12 + old 35 + 6 NPC ≈ 173. Default 100 would silently drop spawns.
            if (director.maxOwnedEntities < 200)
                director.maxOwnedEntities = 200;
            EditorUtility.SetDirty(director);

            string backupDir = Path.Combine(Root(), "AI", "backups",
                "library-" + DateTime.UtcNow.ToString("yyyyMMddTHHmmssZ"),
                "Assets", "Advanced Multiplayer Template", "Scenes");
            Directory.CreateDirectory(backupDir);
            File.Copy(Path.Combine(Root(), ScenePath), Path.Combine(backupDir, "MainScene.unity"), true);
            EditorSceneManager.SaveScene(scene);
            Debug.Log("[LibraryImport] scene patched: " + existing.Count + " decoration goal(s), backup in " + backupDir);
        }
    }
}
