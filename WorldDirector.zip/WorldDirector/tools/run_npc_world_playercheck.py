"""Prove the NPC world inside a standalone player build.

The editor is not always able to run the Play Mode proof: on some machines a batch editor
never advances Play Mode past its first frame, and a windowed editor hits the same internal
search-database exception (see TOOLBOX.md). A standalone player has no editor search stack, so
it advances frames everywhere.

    python tools\\run_npc_world_playercheck.py [--expect-count 5] [--run-timeout 120]
                                              [--build-timeout 900] [--keep-twin-assets]

Flow: mirror the world and the player harness into the validation twin, build a Windows player
of the world scene, start the brain on loopback with a fresh database, run the player with
AICORE_PLAY_CHECK=1, read the [AICorePlay] receipt out of the player log, and require
verdict=answered with entitiesOwnedByThisDirector == --expect-count.

The bearer token is generated here, lives only in the child processes' environment and is
redacted from every line this script prints or writes.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import secrets
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

TOOLS_DIR = Path(__file__).resolve().parent
WORLD_DIR = TOOLS_DIR.parent                     # AICore/WorldDirector
# The Unity project: normally two levels up; AICORE_PROJECT_ROOT overrides it for
# mirror copies and CI, where this tree is checked out outside the project.
REPO = (Path(os.environ["AICORE_PROJECT_ROOT"]).resolve()
        if os.environ.get("AICORE_PROJECT_ROOT", "").strip()
        else WORLD_DIR.parent.parent)
TWIN = WORLD_DIR / "ValidationProject"           # batch-capable twin, same package
OUT = REPO / "AICore" / "outputs" / "scene"

WORLD_ASSETS = REPO / "Assets" / "AICoreWorld"
# (source, path inside the twin's harness folder) - the build entry must be an Editor script.
PLAYER_SOURCES = (
    (TOOLS_DIR / "player" / "AICorePlayerCheck.cs", "AICorePlayerCheck.cs"),
    (TOOLS_DIR / "player" / "AICorePlayerBuild.cs", "Editor/AICorePlayerBuild.cs"),
)

SCENE_IN_TWIN = "Assets/AICoreWorld/NpcWorldScene.unity"
WORLD_ID = "npc_world"

# A player build is a large binary: it goes to the temp directory, never into the repository.
PLAYER_DIR = Path(tempfile.gettempdir()) / "aicore_npc_world_player"
PLAYER_EXE = PLAYER_DIR / "NpcWorldPlayer.exe"
PLAYER_LOG = OUT / "npc-world-player.log"
BUILD_LOG = OUT / "npc-world-player-build.log"
BRAIN_LOG = OUT / "npc-world-player-brain.log"
RECEIPT = OUT / "npc-world-playercheck.log"
DB = OUT / "npc-world-player-brain.sqlite3"

HOST = "http://127.0.0.1:8765"
PORT = 8765
RECEIPT_LINE = re.compile(r"\[AICorePlay\] after [0-9.]+s: (.*)")
BUILD_OK = re.compile(r"\[AICorePlayerBuild\] result=Succeeded")


def step(index: int, text: str) -> None:
    print("[%d] %s" % (index, text), flush=True)


def redact(text: str, token: str) -> str:
    return text.replace(token, "***") if token else text


def mirror_assets() -> list[Path]:
    """Copy the world and the player harness into the twin, metadata included."""
    if not (WORLD_ASSETS / "NpcWorldScene.unity").is_file():
        raise SystemExit("the world scene is missing: %s" % (WORLD_ASSETS / "NpcWorldScene.unity"))
    created: list[Path] = []

    target = TWIN / "Assets" / "AICoreWorld"
    if target.exists():
        shutil.rmtree(target)
    shutil.copytree(WORLD_ASSETS, target, copy_function=shutil.copy2)
    created.append(target)

    # Exactly the two player files: the editor harness must not arm a second time inside the
    # player, so the harness folder is replaced, not merged.
    harness = TWIN / "Assets" / "AICoreHarness"
    if harness.exists():
        shutil.rmtree(harness)
    (harness / "Editor").mkdir(parents=True)
    created.append(harness)
    for source, relative in PLAYER_SOURCES:
        if not source.is_file():
            raise SystemExit("the player harness is missing: %s" % source)
        destination = harness / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        meta = source.with_suffix(source.suffix + ".meta")
        if meta.is_file():
            shutil.copy2(meta, destination.with_suffix(destination.suffix + ".meta"))
    return created


def build_player(timeout: float) -> tuple[int | None, bool]:
    unity = os.environ.get("UNITY_EXE", r"C:\Program Files\Unity\Hub\Editor\6000.3.9f1\Editor\Unity.exe")
    if not Path(unity).is_file():
        raise SystemExit("Unity was not found at %s (set UNITY_EXE)" % unity)
    if PLAYER_DIR.exists():
        shutil.rmtree(PLAYER_DIR)
    PLAYER_DIR.mkdir(parents=True)
    env = os.environ.copy()
    env["AICORE_SCENE"] = SCENE_IN_TWIN
    env["AICORE_PLAYER_BUILD"] = str(PLAYER_EXE)
    env.setdefault("PROGRAMDATA", r"C:\ProgramData")
    env.setdefault("ALLUSERSPROFILE", r"C:\ProgramData")
    command = [unity, "-batchmode", "-nographics", "-quit", "-projectPath", str(TWIN),
               "-logFile", str(BUILD_LOG), "-executeMethod", "AICorePlayerBuild.BuildBatch"]
    process = subprocess.Popen(command, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        return process.wait(timeout=timeout), False
    except subprocess.TimeoutExpired:
        kill_tree(process.pid)
        try:
            process.wait(timeout=30)
        except subprocess.TimeoutExpired:
            pass
        return None, True


def _opener() -> urllib.request.OpenerDirector:
    """Loopback brain traffic must never be routed through a machine-wide proxy."""
    return urllib.request.build_opener(urllib.request.ProxyHandler({}))


def start_brain(token: str) -> subprocess.Popen:
    env = os.environ.copy()
    env["AICORE_TOKEN"] = token
    env["PYTHONIOENCODING"] = "utf-8"
    for suffix in ("", "-wal", "-shm"):
        side = Path(str(DB) + suffix)
        if side.exists():
            side.unlink()
    handle = open(BRAIN_LOG, "w", encoding="utf-8", errors="replace")
    return subprocess.Popen(
        [sys.executable, "brain\\server.py", "--port", str(PORT), "--project", str(REPO),
         "--db", str(DB)],
        cwd=str(WORLD_DIR), env=env, stdout=handle, stderr=subprocess.STDOUT)


def wait_for_brain(token: str, timeout: float) -> dict | None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            request = urllib.request.Request(HOST + "/health",
                                             headers={"Authorization": "Bearer " + token})
            with _opener().open(request, timeout=3) as response:
                return json.loads(response.read().decode("utf-8"))
        except Exception:
            time.sleep(0.5)
    return None


def brain_json(path: str, token: str) -> dict | None:
    try:
        request = urllib.request.Request(HOST + path, headers={"Authorization": "Bearer " + token})
        with _opener().open(request, timeout=10) as response:
            return json.loads(response.read().decode("utf-8"))
    except Exception as error:  # a missing reading must not fail the proof by itself
        return {"error": "%s: %s" % (type(error).__name__, error)}


def kill_tree(pid: int) -> None:
    subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def run_player(token: str, timeout: float) -> tuple[int | None, bool]:
    if not PLAYER_EXE.is_file():
        raise SystemExit("the player was not built: %s" % PLAYER_EXE)
    if PLAYER_LOG.exists():
        PLAYER_LOG.unlink()
    env = os.environ.copy()
    env["AICORE_PLAY_CHECK"] = "1"
    env["AICORE_TOKEN"] = token
    process = subprocess.Popen([str(PLAYER_EXE), "-logFile", str(PLAYER_LOG),
                               "-screen-fullscreen", "0", "-screen-width", "480",
                               "-screen-height", "270"],
                               cwd=str(PLAYER_DIR), env=env, stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL)
    try:
        return process.wait(timeout=timeout), False
    except subprocess.TimeoutExpired:
        kill_tree(process.pid)
        try:
            process.wait(timeout=30)
        except subprocess.TimeoutExpired:
            pass
        return None, True


def parse_receipt(text: str) -> tuple[str | None, dict]:
    match = RECEIPT_LINE.search(text)
    if match is None:
        return None, {}
    fields: dict[str, str] = {}
    for part in match.group(1).split("; "):
        if "=" in part:
            key, value = part.split("=", 1)
            fields[key.strip()] = value.strip().strip('"')
    return match.group(0), fields


def finish(code: int, token: str, copied: list[Path], brain: subprocess.Popen | None,
           line: str | None, fields: dict, unity_code: int | None, unity_timed_out: bool,
           run_code: int | None, run_timed_out: bool, reason: str, goals: dict | None,
           stats: dict | None, keep_assets: bool) -> int:
    step(7, "stopping the brain and removing the twin copies")
    leftover: list[str] = []
    if brain is not None:
        brain.terminate()
        try:
            brain.wait(timeout=15)
        except subprocess.TimeoutExpired:
            brain.kill()
            leftover.append("the brain had to be killed")
    if not keep_assets:
        for path in copied:
            if path.exists():
                shutil.rmtree(path, ignore_errors=True)
            meta = path.with_suffix(path.suffix + ".meta")
            if meta.exists():
                meta.unlink()
    else:
        leftover.append("twin copies were kept on request")

    lines = [
        "NPC WORLD PLAYERCHECK receipt",
        "utc: %s" % time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "project: %s" % REPO,
        "scene: %s (built into a standalone player from the twin %s)" % (SCENE_IN_TWIN, TWIN.name),
        "player: %s" % PLAYER_EXE,
        "build exit: %s (timed out: %s)" % (unity_code, unity_timed_out),
        "run exit: %s (timed out: %s)" % (run_code, run_timed_out),
        "play receipt: %s" % (line if line else "none"),
        "goals: %s" % json.dumps(goals, ensure_ascii=False, sort_keys=True),
        "stats: %s" % json.dumps(stats, ensure_ascii=False, sort_keys=True),
        "cleanup: %s" % ("; ".join(leftover) if leftover else "twin copies removed"),
        "NPC WORLD PLAYERCHECK: %s%s" % ("PASSED" if code == 0 else "FAILED",
                                         "" if code == 0 else " - " + reason),
    ]
    RECEIPT.write_text(redact("\n".join(lines) + "\n", token), encoding="utf-8")
    step(8, redact(lines[-1], token))
    step(9, "receipt written to %s" % RECEIPT)
    return code


def main() -> int:
    parser = argparse.ArgumentParser(description="Run the NPC world proof inside a standalone player.")
    parser.add_argument("--expect-count", type=int, default=5)
    parser.add_argument("--build-timeout", type=float, default=900.0)
    parser.add_argument("--run-timeout", type=float, default=120.0)
    parser.add_argument("--keep-twin-assets", action="store_true")
    args = parser.parse_args()

    OUT.mkdir(parents=True, exist_ok=True)
    token = secrets.token_urlsafe(32)
    copied: list[Path] = []
    brain: subprocess.Popen | None = None
    line: str | None = None
    fields: dict = {}
    build_code: int | None = None
    build_timed_out = False
    run_code: int | None = None
    run_timed_out = False
    goals: dict | None = None
    stats: dict | None = None

    try:
        step(1, "mirroring the world and the player harness into %s" % TWIN.name)
        copied = mirror_assets()
        step(2, "building a standalone player (timeout %.0fs)" % args.build_timeout)
        build_code, build_timed_out = build_player(args.build_timeout)
        text = BUILD_LOG.read_text(encoding="utf-8", errors="replace") if BUILD_LOG.is_file() else ""
        if not PLAYER_EXE.is_file() or BUILD_OK.search(text) is None:
            reason = "the player build failed (exit=%s, timed out=%s)" % (build_code, build_timed_out)
            return finish(1, token, copied, brain, line, fields, build_code, build_timed_out,
                          run_code, run_timed_out, reason, goals, stats, args.keep_twin_assets)
        step(3, "player built: %s" % PLAYER_EXE)

        step(4, "starting the brain on %s with a fresh database" % HOST)
        brain = start_brain(token)
        health = wait_for_brain(token, 45.0)
        if health is None:
            reason = "the brain did not answer /health"
            return finish(1, token, copied, brain, line, fields, build_code, build_timed_out,
                          run_code, run_timed_out, reason, goals, stats, args.keep_twin_assets)
        step(5, "brain is up: %s" % json.dumps(health, ensure_ascii=False))

        step(6, "running the player (timeout %.0fs)" % args.run_timeout)
        run_code, run_timed_out = run_player(token, args.run_timeout)
        text = PLAYER_LOG.read_text(encoding="utf-8", errors="replace") if PLAYER_LOG.is_file() else ""
        line, fields = parse_receipt(text)
        if line is None:
            reason = "no [AICorePlay] receipt in the player log (run exit=%s, timed out=%s)" % (
                run_code, run_timed_out)
            return finish(1, token, copied, brain, line, fields, build_code, build_timed_out,
                          run_code, run_timed_out, reason, goals, stats, args.keep_twin_assets)
        step(7, redact(line, token))

        session = fields.get("session", "")
        goals = brain_json("/v1/goals?world=%s&session=%s" % (WORLD_ID, session), token)
        stats = brain_json("/v1/stats", token)

        owned = fields.get("entitiesOwnedByThisDirector", "")
        verdict = fields.get("verdict", "")
        if verdict != "answered":
            reason = "the director did not answer (verdict=%s)" % verdict
        elif not owned.isdigit() or int(owned) != args.expect_count:
            reason = "the brain populated %s of %d requested NPCs" % (owned, args.expect_count)
        else:
            reason = ""
        return finish(0 if not reason else 1, token, copied, brain, line, fields, build_code,
                      build_timed_out, run_code, run_timed_out, reason, goals, stats,
                      args.keep_twin_assets)
    finally:
        pass


if __name__ == "__main__":
    raise SystemExit(main())
