"""Check driver for the city traffic layer.

  python AICore/WorldDirector/tools/run_city_traffic_check.py            # hashes + Unity-free tests
  python AICore/WorldDirector/tools/run_city_traffic_check.py --unity    # also drives the Editor self-test

It prints a single verdict line:

  CITY TRAFFIC CHECK: PASSED|FAILED

Steps
  1. the SimplePoly City asset pack is byte-identical to `AICore/outputs/city/pack-baseline.sha256`
     (the pack is not under version control, so a hash baseline is what proves non-interference);
  2. the Unity-free tests in `AICore/WorldDirector/tests/test_city_traffic.py` pass;
  3. with --unity: the deterministic 60 s self-test runs inside the live Editor through the file bridge
     (`AI/inbox` -> `AI/outbox`), and its receipt is parsed.
"""
from __future__ import print_function

import hashlib
import io
import json
import os
import subprocess
import sys
import time
import uuid

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..'))
BASELINE = os.path.join(ROOT, 'AICore', 'outputs', 'city', 'pack-baseline.sha256')
RECEIPT = os.path.join(ROOT, 'AICore', 'outputs', 'city', 'city_traffic_receipt.json')
TEST = os.path.join(ROOT, 'AICore', 'WorldDirector', 'tests', 'test_city_traffic.py')
INBOX = os.path.join(ROOT, 'AI', 'inbox')
OUTBOX = os.path.join(ROOT, 'AI', 'outbox')
PACK = 'Assets/SimplePoly City - Low Poly Assets'


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def step_pack_hashes():
    print('== 1. asset pack against its hash baseline ==')
    if not os.path.isfile(BASELINE):
        print('   missing baseline %s' % BASELINE)
        return False
    checked = missing = changed = 0
    with io.open(BASELINE, encoding='utf-8') as fh:
        for line in fh:
            parts = line.strip().split('  ', 1)
            if len(parts) != 2:
                continue
            digest, rel = parts
            path = os.path.join(ROOT, rel.replace('/', os.sep))
            if not os.path.isfile(path):
                missing += 1
                print('   missing: %s' % rel)
                continue
            checked += 1
            if sha256(path).lower() != digest.strip().lower():      # the baseline is written by Get-FileHash (upper case)
                changed += 1
                print('   CHANGED: %s' % rel)
    print('   %d files checked, %d changed, %d missing' % (checked, changed, missing))
    ok = changed == 0 and missing == 0
    print('   pack untouched: %s' % ('yes' if ok else 'NO'))
    return ok


def step_pure_tests():
    print('== 2. Unity-free tests ==')
    if not os.path.isfile(TEST):
        print('   missing %s' % TEST)
        return False
    proc = subprocess.Popen([sys.executable, TEST], cwd=ROOT)
    return proc.wait() == 0


def call_bridge(op, args, wait_s=900):
    os.makedirs(INBOX, exist_ok=True)
    os.makedirs(OUTBOX, exist_ok=True)
    ident = 'drv' + uuid.uuid4().hex[:10]
    payload = json.dumps({'id': ident, 'op': op, 'args': list(args)})
    tmp = os.path.join(INBOX, ident + '.json.tmp')
    with io.open(tmp, 'w', encoding='utf-8') as fh:
        fh.write(payload)
    os.replace(tmp, os.path.join(INBOX, ident + '.json'))
    out = os.path.join(OUTBOX, ident + '.txt')
    deadline = time.time() + wait_s
    while time.time() < deadline:
        if os.path.isfile(out):
            with io.open(out, encoding='utf-8') as fh:
                return fh.read()
        time.sleep(0.25)
    return None


def step_editor_selftest(wait_s=900):
    print('== 3. deterministic self-test inside the Editor ==')
    reply = call_bridge('run_method',
                        ['type=AICoreCity.Editor.CityTrafficBuilder', 'method=SelfTest'], wait_s)
    if reply is None:
        print('   the Editor did not answer within %ds (is it running with this project open?)' % wait_s)
        return False
    body = reply.split('\n---\n', 1)[-1].strip()
    print('   %s' % body)
    if not os.path.isfile(RECEIPT):
        print('   no receipt written')
        return False
    with io.open(RECEIPT, encoding='utf-8') as fh:
        rec = json.load(fh)
    print('   verdict %s, failed checks %s, ms/step %s, min_gap %s' % (
        rec.get('verdict'), rec.get('failed_checks'),
        rec.get('metrics', {}).get('ms_per_step'), rec.get('metrics', {}).get('min_gap')))
    for entry in rec.get('checks', []):
        if not entry.get('ok'):
            print('     FAILING: %s - %s' % (entry.get('check'), entry.get('detail')))
    return rec.get('verdict') == 'PASSED'


def main():
    argv = [a for a in sys.argv[1:]]
    with_unity = '--unity' in argv
    wait_s = 900
    if '--wait' in argv:
        wait_s = int(argv[argv.index('--wait') + 1])

    ok = step_pack_hashes()
    ok = step_pure_tests() and ok
    if with_unity:
        ok = step_editor_selftest(wait_s) and ok
    else:
        print('== 3. Editor self-test skipped (pass --unity to run it) ==')

    print('\nCITY TRAFFIC CHECK: %s' % ('PASSED' if ok else 'FAILED'))
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
