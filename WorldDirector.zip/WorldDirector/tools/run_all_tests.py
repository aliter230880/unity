"""Run every test suite in one go and summarise.

    python tools/run_all_tests.py [--quiet]

Exits non-zero if any suite fails, so it can guard a change or an onboarding step.
"""
from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path

WORLD_DIR = Path(__file__).resolve().parent.parent
TESTS = sorted((WORLD_DIR / "tests").glob("test_*.py"))
PATTERN = re.compile(r"Ran (\d+) tests?")


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    quiet = "--quiet" in argv
    if not TESTS:
        print("no test files found in %s" % (WORLD_DIR / "tests"))
        return 1

    total = 0
    failed = []
    for path in TESTS:
        completed = subprocess.run([sys.executable, str(path)], cwd=str(WORLD_DIR),
                                   capture_output=True, text=True, encoding="utf-8",
                                   errors="replace")
        output = (completed.stdout or "") + (completed.stderr or "")
        match = PATTERN.search(output)
        count = int(match.group(1)) if match else 0
        ok = completed.returncode == 0 and "FAILED" not in output and "ERROR:" not in output
        total += count
        print("  %-28s %3d %s" % (path.name, count, "OK" if ok else "FAIL"))
        if not ok:
            failed.append(path.name)
            if not quiet:
                for line in output.splitlines():
                    if line.startswith("FAIL:") or line.startswith("ERROR:"):
                        print("      " + line.strip())

    print("\n%d suite(s), %d test(s), %d failing" % (len(TESTS), total, len(failed)))
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
