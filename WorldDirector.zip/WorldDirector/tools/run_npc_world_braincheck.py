"""Prove the world's population goal against the live brain, without waiting for Unity frames.

Why this exists next to run_npc_world_playcheck.py: on this machine a batch Unity process does
not advance Play Mode past its first frame (one frame, then the editor's update pump stops after
an internal search-database exception - see
outputs/scene/npc-world-playmode-blocker.log), so the Play Mode
receipt cannot be produced here. The decision half of the same world is provable on its own and
deterministically: read the goal, the bounds, the anchor and the catalog straight out of the
generated scene, send the exact protocol v2 observation to a live brain on loopback, and require
that the brain populates the world by itself and then stops.

    python tools\\run_npc_world_braincheck.py

Receipt: AICore/outputs/scene/npc-world-braincheck.log
Exit code 0 only when the brain spawned exactly the requested population for the world's own
catalog and reported the goal satisfied on the next tick.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import secrets
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

TOOLS_DIR = Path(__file__).resolve().parent
WORLD_DIR = TOOLS_DIR.parent                # AICore/WorldDirector
REPO = WORLD_DIR.parent.parent              # the Unity project
OUT = REPO / "AICore" / "outputs" / "scene"
SCENE = REPO / "Assets" / "AICoreWorld" / "NpcWorldScene.unity"
CATALOG = REPO / "Assets" / "AICoreWorld" / "NpcWorldCatalog.asset"
RECEIPT = OUT / "npc-world-braincheck.log"
BRAIN_LOG = OUT / "npc-world-braincheck-brain.log"
DB = OUT / "npc-world-braincheck.sqlite3"

VECTOR = re.compile(r"\{\s*x:\s*(-?[\d.eE+-]+),\s*y:\s*(-?[\d.eE+-]+),\s*z:\s*(-?[\d.eE+-]+)\s*\}")
ACTIONS = ("spawn", "move", "activate", "deactivate")


def step(index: int, text: str) -> None:
    print("[%d] %s" % (index, text), flush=True)


def redact(text: str, token: str) -> str:
    return text.replace(token, "***") if token else text


def field(text: str, name: str) -> str | None:
    match = re.search(r"^[ \t]*%s:[ \t]*(.*)$" % re.escape(name), text, re.MULTILINE)
    return match.group(1).strip() if match else None


def transform_position(text: str, file_id: str) -> dict:
    block = re.search(r"^--- !u!4 &%s\b(.*?)(?=^--- |\Z)" % re.escape(file_id), text,
                      re.MULTILINE | re.DOTALL)
    if block is None:
        raise SystemExit("no transform block for fileID %s in the scene" % file_id)
    match = VECTOR.search(block.group(1))
    if match is None:
        raise SystemExit("no local position in transform %s" % file_id)
    return {"x": float(match.group(1)), "y": float(match.group(2)), "z": float(match.group(3))}


def read_world() -> dict:
    text = SCENE.read_text(encoding="utf-8", errors="replace")
    anchor = re.search(r"^[ \t]*anchor: \{fileID: (\d+)\}", text, re.MULTILINE)
    if anchor is None:
        raise SystemExit("the director has no anchor reference")
    centre_match = re.search(r"^[ \t]*m_Center:[ \t]*(.*)$", text, re.MULTILINE)
    extent_match = re.search(r"^[ \t]*m_Extent:[ \t]*(.*)$", text, re.MULTILINE)
    if centre_match is None or extent_match is None:
        raise SystemExit("the director has no allowed bounds")
    centre = VECTOR.search(centre_match.group(1) + " }")
    extent = VECTOR.search(extent_match.group(1) + " }")
    if centre is None or extent is None:
        raise SystemExit("the bounds cannot be parsed")
    centre = {"x": float(centre.group(1)), "y": float(centre.group(2)), "z": float(centre.group(3))}
    extent = {"x": float(extent.group(1)), "y": float(extent.group(2)), "z": float(extent.group(3))}
    endpoint = field(text, "endpoint") or ""
    port = urllib.parse.urlsplit(endpoint).port or 8765
    return {
        "world_id": field(text, "worldId") or "",
        "endpoint": endpoint,
        "port": port,
        "goal": field(text, "goal") or "Maintain the population.",
        "goal_id": field(text, "goalId") or "population.primary",
        "goal_priority": int(field(text, "goalPriority") or 50),
        "target": field(text, "targetCatalogId") or "",
        "target_count": int(field(text, "targetCount") or 0),
        "max_owned": int(field(text, "maxOwnedEntities") or 100),
        "anchor": transform_position(text, anchor.group(1)),
        "min": {axis: centre[axis] - extent[axis] for axis in "xyz"},
        "max": {axis: centre[axis] + extent[axis] for axis in "xyz"},
    }


def read_catalog() -> list[dict]:
    entries: list[dict] = []
    current: dict | None = None
    for line in CATALOG.read_text(encoding="utf-8", errors="replace").splitlines():
        stripped = line.strip()
        if stripped.startswith("- id:"):
            current = {"id": stripped.split(":", 1)[1].strip(), "kind": ""}
            entries.append(current)
        elif stripped.startswith("kind:") and current is not None:
            current["kind"] = stripped.split(":", 1)[1].strip()
    if not entries:
        raise SystemExit("the catalog has no entries")
    return entries


def observation(world: dict, session: str, observation_id: str, entities: list[dict],
                owned: int, results: list[dict]) -> dict:
    return {
        "protocol_version": 2,
        "world_id": world["world_id"],
        "session_id": session,
        "observation_id": observation_id,
        "goal": world["goal"],
        "target_catalog_id": world["target"],
        "target_count": world["target_count"],
        "anchor": world["anchor"],
        "allow_mutations": True,
        "allow_reactivation": True,
        "entities_truncated": False,
        "limits": {
            "min": world["min"], "max": world["max"],
            "max_owned_entities": world["max_owned"], "owned_entity_count": owned,
            "action_budget": 8,
        },
        "entities": entities,
        "catalog": read_catalog(),
        "results": results,
        "events": [], "feedback": [], "knowledge_updates": [], "relations": [],
        "goals": [{
            "goal_id": world["goal_id"],
            "catalog_id": world["target"],
            "target_count": world["target_count"],
            "priority": world["goal_priority"],
            "status": "active",
            "description": world["goal"],
        }],
        "capabilities": {"action_types": list(ACTIONS)},
    }


def post(endpoint: str, token: str, payload: dict, timeout: float = 20.0) -> dict:
    request = urllib.request.Request(
        endpoint, data=json.dumps(payload).encode("utf-8"), method="POST",
        headers={"Content-Type": "application/json", "Accept": "application/json",
                 "Authorization": "Bearer " + token})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8"))


def start_brain(world: dict, token: str) -> subprocess.Popen:
    env = os.environ.copy()
    env["AICORE_TOKEN"] = token
    env["PYTHONIOENCODING"] = "utf-8"
    if DB.exists():
        DB.unlink()
    handle = open(BRAIN_LOG, "w", encoding="utf-8", errors="replace")
    return subprocess.Popen(
        [sys.executable, "brain\\server.py", "--port", str(world["port"]),
         "--project", str(REPO), "--db", str(DB)],
        cwd=str(WORLD_DIR), env=env, stdout=handle, stderr=subprocess.STDOUT)


def wait_for_brain(port: int, token: str, timeout: float) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            request = urllib.request.Request("http://127.0.0.1:%d/health" % port,
                                             headers={"Authorization": "Bearer " + token})
            with urllib.request.urlopen(request, timeout=3) as response:
                if response.status == 200:
                    return True
        except Exception:
            time.sleep(0.4)
    return False


def main() -> int:
    parser = argparse.ArgumentParser(description="Run the NPC world brain proof.")
    parser.add_argument("--keep-brain-db", action="store_true")
    args = parser.parse_args()

    OUT.mkdir(parents=True, exist_ok=True)
    if not SCENE.is_file():
        raise SystemExit("the world scene is missing: %s" % SCENE)
    if not CATALOG.is_file():
        raise SystemExit("the world catalog is missing: %s" % CATALOG)

    world = read_world()
    catalog = read_catalog()
    token = secrets.token_urlsafe(32)
    session = "braincheck-" + secrets.token_hex(8)
    lines: list[str] = []
    brain: subprocess.Popen | None = None
    failure = ""

    step(1, "world: %s, goal %s x%d, endpoint %s" % (world["world_id"], world["target"],
                                                     world["target_count"], world["endpoint"]))
    step(2, "catalog: %s" % ", ".join("%s(%s)" % (e["id"], e["kind"]) for e in catalog))
    if world["target"] not in [entry["id"] for entry in catalog]:
        raise SystemExit("the world goal names a catalog id that does not exist")

    try:
        brain = start_brain(world, token)
        if not wait_for_brain(world["port"], token, 45.0):
            raise SystemExit("the brain did not answer /health on port %d" % world["port"])
        step(3, "brain is up")

        first = post(world["endpoint"], token,
                     observation(world, session, session + "-1", [], 0, []))
        spawns = [action for action in first.get("actions", []) if action.get("type") == "spawn"]
        lines.append("tick 1: source=%s summary=%s" % (first.get("source"), first.get("summary")))
        lines.append("tick 1: actions=%s" % json.dumps(first.get("actions"), ensure_ascii=False))
        step(4, "tick 1: source=%s, %d action(s), %d spawn(s)"
             % (first.get("source"), len(first.get("actions", [])), len(spawns)))

        inside = all(world["min"][axis] <= action["position"][axis] <= world["max"][axis]
                     for action in spawns for axis in "xyz")
        targets = {action.get("catalog_id") for action in spawns}
        step(5, "tick 1 checks: spawned=%d/%d, inside bounds=%s, catalogs=%s"
             % (len(spawns), world["target_count"], inside, sorted(targets)))

        if first.get("source") != "multi_objective_v2":
            failure = "unexpected plan source %r" % first.get("source")
        elif len(spawns) != world["target_count"]:
            failure = "the brain proposed %d spawn(s) instead of %d" % (len(spawns),
                                                                       world["target_count"])
        elif targets != {world["target"]}:
            failure = "the brain spawned %s instead of %s" % (sorted(targets), world["target"])
        elif not inside:
            failure = "a spawn position fell outside the world bounds"

        population = [
            {"id": action["id"], "catalog_id": action["catalog_id"],
             "kind": next(entry["kind"] for entry in catalog if entry["id"] == action["catalog_id"]),
             "owned": True, "active": True, "reactivatable": False,
             "position": action["position"]}
            for action in spawns
        ]
        results = [{"action_id": action["id"], "status": "executed", "message": "ok"}
                   for action in spawns]

        second = post(world["endpoint"], token,
                      observation(world, session, session + "-2", population, len(population),
                                  results))
        remaining = [action for action in second.get("actions", []) if action.get("type") == "spawn"]
        stats = second.get("goal_stats", {})
        lines.append("tick 2: source=%s summary=%s" % (second.get("source"), second.get("summary")))
        lines.append("tick 2: goal_stats=%s actions=%s"
                     % (json.dumps(stats), json.dumps(second.get("actions"), ensure_ascii=False)))
        step(6, "tick 2: goal_stats=%s, %d further spawn(s)" % (json.dumps(stats), len(remaining)))

        if not failure:
            if remaining:
                failure = "the brain kept spawning after the population was satisfied"
            elif stats.get("satisfied", 0) != 1:
                failure = "the goal was not reported satisfied: %s" % json.dumps(stats)

        code = 0 if not failure else 1
        return finish(code, token, world, catalog, lines, failure)
    except urllib.error.HTTPError as error:
        body = error.read().decode("utf-8", errors="replace")
        return finish(1, token, world, catalog, lines,
                      "the brain refused the observation: HTTP %s %s" % (error.code, body[:400]))
    finally:
        if brain is not None:
            brain.terminate()
            try:
                brain.wait(timeout=15)
            except subprocess.TimeoutExpired:
                brain.kill()
        if not args.keep_brain_db:
            for suffix in ("", "-wal", "-shm"):
                path = Path(str(DB) + suffix)
                if path.exists():
                    path.unlink()


def finish(code: int, token: str, world: dict, catalog: list[dict], lines: list[str],
           failure: str) -> int:
    body = [
        "NPC WORLD BRAINCHECK receipt",
        "utc: %s" % time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "project: %s" % REPO,
        "scene: %s" % SCENE,
        "world: %s, goal %s x%d" % (world["world_id"], world["target"], world["target_count"]),
        "bounds: min=%s max=%s" % (world["min"], world["max"]),
        "catalog: %s" % ", ".join("%s(%s)" % (entry["id"], entry["kind"]) for entry in catalog),
    ] + lines + [
        "NPC WORLD BRAINCHECK: %s%s" % ("PASSED" if code == 0 else "FAILED",
                                        "" if code == 0 else " - " + failure),
    ]
    RECEIPT.write_text(redact("\n".join(body) + "\n", token), encoding="utf-8")
    step(7, redact(body[-1], token))
    step(8, "receipt written to %s" % RECEIPT)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
