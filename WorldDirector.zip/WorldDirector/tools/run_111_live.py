"""Settle IskIn into the multiplayer world of D:\\Work\\Unity\\Projects\\111.

    python tools\\run_111_live.py [--minutes 0] [--every 60] [--build] [--see]

The canonical template flow, with IskIn inside the world server:

  MasterServer (accounts + login) -> City111Server (dedicated game server;
  IskIn armed there by AICoreMirrorBridge) -> clients (login + Quick join).

Default (headless): the driver runs the dedicated server in batchmode and
streams its receipts; the world lives while this window runs, the brain
(pc/iskin.py) keeps its persistent memory forever.

--see: makes sure master+server are up, then opens the game window, which
logs in automatically (test@gmail.com / Passw0rd123!) and quick-joins the
city. Closing the window leaves the world running.
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
PROJECT = Path(os.environ.get("ISKIN_111_PROJECT", r"D:\Work\Unity\Projects\111"))
ISKIN = Path(os.environ.get("ISKIN_PC", r"E:\AI\AI_folder\unity\AICore\pc\iskin.py"))
TOKEN_FILE = ISKIN.parent / "aicore-token.txt"
BRIDGE_IN = PROJECT / "AI" / "inbox"
BRIDGE_OUT = PROJECT / "AI" / "outbox"
BRIDGE_STATUS = PROJECT / "AI" / "state" / "status.txt"
STABLE_BUILD = PROJECT / "Builds" / "City111" / "City111Player.exe"
TEMP_BUILD = Path(os.environ.get("TEMP", r"C:\Temp")) / "aicore_111_player" / "City111Player.exe"
SERVER_EXE = PROJECT / "Builds" / "City111Server" / "Server.exe"
LIVE_LOG = HERE.parent.parent / "outputs" / "scene" / "city111-live.log"
SERVER_LOG = LIVE_LOG.parent / "city111-server.log"
UNITY = os.environ.get("UNITY_EXE", r"C:\Program Files\Unity\Hub\Editor\6000.3.9f1\Editor\Unity.exe")
HOST = "http://127.0.0.1:8765"
CLIENT_EMAIL = "test@gmail.com"
CLIENT_PASSWORD = "Passw0rd123!"


def log(message: str) -> None:
    print(message, flush=True)


def redact(text: str, token: str) -> str:
    return text.replace(token, "***") if token else text


def opener() -> urllib.request.OpenerDirector:
    return urllib.request.build_opener(urllib.request.ProxyHandler({}))


def token() -> str:
    value = os.environ.get("AICORE_TOKEN", "").strip() or (
        TOKEN_FILE.read_text(encoding="utf-8").strip() if TOKEN_FILE.is_file() else "")
    if not value:
        raise SystemExit("no token: start IskIn first (desktop shortcut) or set AICORE_TOKEN")
    return value


def brain_alive(bearer: str) -> bool:
    request = urllib.request.Request(HOST + "/health",
                                     headers={"Authorization": "Bearer " + bearer})
    try:
        with opener().open(request, timeout=2):
            return True
    except Exception:
        return False


def ensure_brain(bearer: str) -> None:
    if brain_alive(bearer):
        log("[1] resident IskIn: already running.")
        return
    if not ISKIN.is_file():
        raise SystemExit("IskIn is not running; launcher not found: %s" % ISKIN)
    subprocess.run([sys.executable, str(ISKIN), "start"], check=False)
    if not brain_alive(bearer):
        raise SystemExit("could not start the resident IskIn")


def task_running(image: str) -> bool:
    listing = subprocess.run(["tasklist", "/FI", "IMAGENAME eq " + image],
                             capture_output=True)
    return image in listing.stdout.decode("cp866", "replace")


def kill_image(image: str) -> bool:
    if not task_running(image):
        return False
    subprocess.run(["taskkill", "/IM", image, "/T", "/F"], capture_output=True)
    time.sleep(2)
    return True


def bridge_alive() -> bool:
    if not BRIDGE_STATUS.is_file():
        return False
    try:
        age = time.time() - BRIDGE_STATUS.stat().st_mtime
    except OSError:
        return False
    if age > 120:
        return False
    return "bridge:" in BRIDGE_STATUS.read_text(encoding="utf-8-sig", errors="replace")[:200]


def bridge_call(command: dict, tag: str, timeout: float) -> str:
    BRIDGE_IN.mkdir(parents=True, exist_ok=True)
    (BRIDGE_IN / (tag + ".json")).write_text(json.dumps(command), encoding="utf-8")
    out = BRIDGE_OUT / (tag + ".txt")
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if out.is_file():
            return out.read_text(encoding="utf-8-sig", errors="replace")
        time.sleep(1)
    return "(bridge: no answer in %.0fs)" % timeout


def player_exe() -> Path:
    override = os.environ.get("AICORE_PLAYER_BUILD")
    if override:
        return Path(override)
    if STABLE_BUILD.is_file():
        return STABLE_BUILD
    return TEMP_BUILD


MASTERSERVER = PROJECT / "Builds" / "WindowsMasterServer" / "MasterServer.exe"


def ensure_masterserver() -> None:
    """The login screen authenticates against the local MasterServer."""
    if task_running("MasterServer.exe"):
        log("[2b] MasterServer: already running (accounts + login available).")
        return
    if not MASTERSERVER.is_file():
        log("[2b] MasterServer build not found (%s); login will be unreachable." % MASTERSERVER)
        return
    subprocess.Popen([str(MASTERSERVER), "-batchmode", "-logFile", str(LIVE_LOG.parent / "masterserver.log")],
                     creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(4)
    if task_running("MasterServer.exe"):
        log("[2b] MasterServer started (accounts + login available).")
    else:
        log("[2b] MasterServer did not come up; check %s" % (LIVE_LOG.parent / "masterserver.log"))


def restart_masterserver() -> None:
    """A hard-killed client leaves a zombie 'online' session in the master's
    memory; that account is then rejected with code 205 on every login. The
    master is local and single-user, so a fresh start clears it."""
    kill_image("MasterServer.exe")
    ensure_masterserver()


def aicore_env(bearer: str, every: int) -> dict:
    environment = os.environ.copy()
    environment.update({
        "AICORE_PLAY_CHECK": "1", "AICORE_PLAY_LIVE": "1",
        "AICORE_LIVE_EVERY": str(every), "AICORE_TOKEN": bearer,
    })
    return environment


def ensure_server_build(force: bool) -> None:
    if SERVER_EXE.is_file() and not force:
        log("[2a] city server build found: %s" % SERVER_EXE)
        return
    env = dict(os.environ)
    env["AICORE_SERVER_BUILD"] = str(SERVER_EXE)
    if bridge_alive():
        log("[2a] editor is open: building the server through the AI bridge (minutes)...", flush=True)
        bridge_call(
            {"id": "serverbuild", "op": "run_method",
             "args": ["type=AICoreMultiplayer.Editor.WorldServerBuild", "method=BuildViaBridge"]},
            "serverbuild", timeout=1800)
    else:
        if not Path(UNITY).is_file():
            raise SystemExit("Unity not found at %s (set UNITY_EXE)" % UNITY)
        log("[2a] building the city server in batch mode (Unity must be closed)...", flush=True)
        subprocess.run([UNITY, "-batchmode", "-nographics", "-quit",
                        "-projectPath", str(PROJECT),
                        "-executeMethod", "AICoreMultiplayer.Editor.WorldServerBuild.BuildBatch"],
                       env=env, timeout=1800, check=False)
    if not SERVER_EXE.is_file():
        raise SystemExit("city server build failed; check the Unity log")
    log("[2a] city server built: %s" % SERVER_EXE)


def ensure_player(force: bool, exe: Path) -> None:
    if exe.is_file() and not force:
        log("[2] player build found: %s" % exe)
        return
    env = dict(os.environ)
    env["AICORE_PLAYER_BUILD"] = str(exe)
    if bridge_alive():
        log("[2] editor is open: building the player through the AI bridge (minutes)...", flush=True)
        reply = bridge_call(
            {"id": "livebuild", "op": "run_method",
             "args": ["type=AICoreMultiplayer.Editor.WorldLiveBuild", "method=BuildViaBridge"]},
            "livebuild", timeout=1800)
        log("    " + reply.splitlines()[4][:120] if "ok: true" in reply else "    " + reply[:200])
    else:
        if not Path(UNITY).is_file():
            raise SystemExit("Unity not found at %s (set UNITY_EXE)" % UNITY)
        log("[2] building the player in batch mode (Unity must be closed)...", flush=True)
        subprocess.run([UNITY, "-batchmode", "-nographics", "-quit",
                        "-projectPath", str(PROJECT),
                        "-executeMethod", "AICoreMultiplayer.Editor.WorldLiveBuild.BuildBatch"],
                       env=env, timeout=1800, check=False)
    if not exe.is_file():
        raise SystemExit("player build failed; check the Unity log")
    log("[2] player built: %s" % exe)


def ensure_server(bearer: str, every: int) -> None:
    """A running stack is left untouched; otherwise start master + server."""
    if task_running("Server.exe"):
        ensure_masterserver()
        log("[3] city server: already running (IskIn's world is live).")
        return
    restart_masterserver()
    subprocess.Popen([str(SERVER_EXE), "-batchmode", "-logFile", str(SERVER_LOG)],
                     creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP,
                     env=aicore_env(bearer, every),
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(5)
    if task_running("Server.exe"):
        log("[3] city server started (IskIn lives there; log: %s)" % SERVER_LOG)
    else:
        raise SystemExit("city server did not start; check %s" % SERVER_LOG)


def run_client(bearer: str, every: int, exe: Path) -> int:
    """Graphical entry: auto-login + quick join, until the window closes."""
    LIVE_LOG.parent.mkdir(parents=True, exist_ok=True)
    log("[4] entering the city: login %s, auto quick-join. Close the GAME "
        "WINDOW to leave - the world server keeps running." % CLIENT_EMAIL)
    stream = open(LIVE_LOG, "a", encoding="utf-8", errors="replace")
    environment = aicore_env(bearer, every)
    player = subprocess.Popen(
        [str(exe), "-logFile", "-", "-force-d3d11",
         "-email", CLIENT_EMAIL, "-password", CLIENT_PASSWORD],
        env=environment, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, encoding="utf-8", errors="replace")
    receipts = 0
    try:
        for line in player.stdout:
            clean = redact(line.rstrip(), bearer)
            log("[%s] %s" % (time.strftime("%d.%m %H:%M:%S"), clean))
            stream.write("[%s] %s\n" % (time.strftime("%d.%m %H:%M:%S"), clean))
            stream.flush()
            if "[AICorePlay]" in line or "[AICoreMirror]" in line or "[MS]" in line:
                receipts += 1
    finally:
        if player.poll() is None:
            kill_image("City111Player.exe")
        stream.close()
    log("[4] game window closed (%d network/receipt lines); the city server "
        "and the brain keep running." % receipts)
    return 0


def run_world(bearer: str, every: int, minutes: float) -> int:
    """Headless mode: the dedicated server IS the world; stream its receipts."""
    LIVE_LOG.parent.mkdir(parents=True, exist_ok=True)
    kill_image("City111Player.exe")
    kill_image("Server.exe")
    restart_masterserver()
    log("[3] the city server is the world (IskIn inside, Mirror + master up); "
        "Ctrl+C to stop the world - the brain keeps running. Server log: %s" % SERVER_LOG)
    stream = open(LIVE_LOG, "a", encoding="utf-8", errors="replace")
    server = subprocess.Popen(
        [str(SERVER_EXE), "-batchmode", "-logFile", "-"],
        env=aicore_env(bearer, every),
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, encoding="utf-8", errors="replace")
    deadline = time.monotonic() + minutes * 60 if minutes > 0 else None
    receipts = 0
    try:
        for line in server.stdout:
            clean = redact(line.rstrip(), bearer)
            log("[%s] %s" % (time.strftime("%d.%m %H:%M:%S"), clean))
            stream.write("[%s] %s\n" % (time.strftime("%d.%m %H:%M:%S"), clean))
            stream.flush()
            if "[AICorePlay]" in line or "[AICoreMirror]" in line:
                receipts += 1
            if deadline and time.monotonic() >= deadline:
                log("[3] time window elapsed (%.0f min)." % minutes)
                break
    except KeyboardInterrupt:
        log("\n[3] stopped by user; the brain keeps running.")
    finally:
        if server.poll() is None:
            kill_image("Server.exe")
        stream.close()
    log("[4] receipts/bridge lines: %d" % receipts)
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="IskIn in the multiplayer city111 world.")
    parser.add_argument("--minutes", type=float, default=0.0)
    parser.add_argument("--every", type=int, default=60)
    parser.add_argument("--build", action="store_true")
    parser.add_argument("--see", action="store_true",
                        help="open the game window, auto-login and quick-join "
                             "the live city; default stays headless")
    args = parser.parse_args()
    if not 10 <= args.every <= 3600:
        raise SystemExit("--every must be 10..3600")
    bearer = token()
    ensure_brain(bearer)
    ensure_server_build(args.build)
    if args.see:
        exe = player_exe()
        ensure_player(args.build, exe)
        kill_image("City111Player.exe")
        ensure_server(bearer, args.every)
        return run_client(bearer, args.every, exe)
    return run_world(bearer, args.every, args.minutes)


if __name__ == "__main__":
    raise SystemExit(main())
