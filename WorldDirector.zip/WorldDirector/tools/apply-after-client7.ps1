# Apply hub visual-density patches AFTER client #7 Unity batchmode exits.
# Does not start a new Unity build. LibraryImport.RunBatch is opt-in (-Import).
#
#   pwsh -File apply-after-client7.ps1            # copy files if Unity is gone
#   pwsh -File apply-after-client7.ps1 -Import    # then RunBatch (opens Unity)
#   pwsh -File apply-after-client7.ps1 -RestartBrain
param(
    [switch]$Import,
    [switch]$RestartBrain
)

$ErrorActionPreference = "Stop"
$hub = Split-Path -Parent $PSScriptRoot
$unity111 = "D:\Work\Unity\Projects\111"
$editor = $env:UNITY_EXE
if (-not $editor) { $editor = "C:\Program Files\Unity\Hub\Editor\6000.3.9f1\Editor\Unity.exe" }

if (Get-Process Unity -ErrorAction SilentlyContinue) {
    Write-Host "Unity is still running. Wait for client #7, then re-run."
    exit 2
}

$importSrc = Join-Path $PSScriptRoot "LibraryImport.cs"
$importDst = Join-Path $unity111 "Assets\AICoreMultiplayer\Editor\LibraryImport.cs"
Copy-Item -LiteralPath $importSrc -Destination $importDst -Force
Write-Host "copied LibraryImport.cs (targetCount=12, maxOwnedEntities>=200)"

$atmoSrc = Join-Path $PSScriptRoot "WorldAtmosphere.cs"
$atmoDst = Join-Path $unity111 "Assets\AICore\Runtime\WorldAtmosphere.cs"
Copy-Item -LiteralPath $atmoSrc -Destination $atmoDst -Force
Write-Host "copied WorldAtmosphere.cs (not yet on a scene object)"

if ($RestartBrain) {
    $iskin = Join-Path (Split-Path -Parent $hub) "pc\iskin.py"
    if (-not (Test-Path $iskin)) { $iskin = "E:\AI\AI_folder\unity\AICore\pc\iskin.py" }
    python $iskin stop
    python $iskin start
}

if ($Import) {
    if (-not (Test-Path $editor)) {
        Write-Host "Unity editor not at $editor"
        exit 1
    }
    $log = "E:\AI\AI_folder\unity\AICore\outputs\scene\library-import.log"
    Write-Host "LibraryImport.RunBatch -> $log"
    & $editor -batchmode -nographics -quit -projectPath $unity111 `
        -executeMethod AICoreMultiplayer.Editor.LibraryImport.RunBatch `
        -logFile $log
    Write-Host "Unity exit $LASTEXITCODE"
    exit $LASTEXITCODE
}

Write-Host "files applied. Pass -Import to run LibraryImport.RunBatch, -RestartBrain for iskin stop/start."
exit 0
