"""Prove the runtime path the user will actually see: a built player, the scene, characters walking.

The deterministic self-test steps the actors by hand. This driver instead builds a standalone
player of SandboxScene and lets the normal frame loop drive the cast — the same path the
Play button uses in the editor. Evidence: positions over time plus meet/exchange/part events.

Run: python tools\\run_sandbox_player_proof.py [--seconds 30] [--build-timeout 1200]
"""

from __future__ import annotations

import argparse
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
WORLD = TOOLS.parent
REPO = WORLD.parents[1]
TWIN = WORLD / "ValidationProject"
UNITY = Path(r"C:\Program Files\Unity\Hub\Editor\6000.3.9f1\Editor\Unity.exe")

SOURCE_SANDBOX = REPO / "Assets" / "AICoreSandbox"
TWIN_SANDBOX = TWIN / "Assets" / "AICoreSandbox"
PLAYER_SOURCES = ((TOOLS / "player" / "AICorePlayerBuild.cs", "Editor/AICorePlayerBuild.cs"),)
SCENE_IN_TWIN = "Assets/AICoreSandbox/SandboxScene.unity"

OUT = REPO / "AICore" / "outputs" / "scene"
RECEIPT = OUT / "sandbox-alive-playercheck.log"
BUILD_LOG = OUT / "sandbox-alive-player-build.log"
PLAYER_LOG = OUT / "sandbox-alive-player.log"
ACTOR_LOG = OUT / "sandbox-alive-player-actor.log"
PLAYER_DIR = Path(tempfile.gettempdir()) / "aicore_sandbox_player"
PLAYER_EXE = PLAYER_DIR / "SandboxPlayer.exe"

SNAPSHOT = re.compile(
    r"\[SandboxAlive\] t=([\d.]+) actor=(\S+) pos=\((-?[\d.]+),(-?[\d.]+),(-?[\d.]+)\) state=(\S+) partner=(\S+)")
BUILD_OK = re.compile(r"\[AICorePlayerBuild\] result=Succeeded")


def step(index: int, text: str) -> None:
    print("[%d] %s" % (index, text), flush=True)


def mirror() -> None:
    if not (SOURCE_SANDBOX / "SandboxScene.unity").is_file():
        raise SystemExit("the sandbox scene is missing: %s" % (SOURCE_SANDBOX / "SandboxScene.unity"))
    if TWIN_SANDBOX.exists():
        shutil.rmtree(TWIN_SANDBOX)
    shutil.copytree(SOURCE_SANDBOX, TWIN_SANDBOX, copy_function=shutil.copy2)
    harness = TWIN / "Assets" / "AICoreHarness"
    if harness.exists():
        shutil.rmtree(harness)
    for source, relative in PLAYER_SOURCES:
        if not source.is_file():
            raise SystemExit("the player harness is missing: %s" % source)
        destination = harness / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
    step(1, "mirrored the scene and the harness into the twin")


def build_player(timeout: int) -> int:
    if PLAYER_DIR.exists():
        shutil.rmtree(PLAYER_DIR)
    PLAYER_DIR.mkdir(parents=True)
    env = os.environ.copy()
    env["PROGRAMDATA"] = env.get("PROGRAMDATA") or r"C:\ProgramData"
    env["ALLUSERSPROFILE"] = env.get("ALLUSERSPROFILE") or r"C:\ProgramData"
    env["AICORE_SCENE"] = SCENE_IN_TWIN
    env["AICORE_PLAYER_BUILD"] = str(PLAYER_EXE)
    command = [str(UNITY), "-batchmode", "-nographics", "-quit", "-projectPath", str(TWIN),
               "-logFile", str(BUILD_LOG), "-executeMethod", "AICorePlayerBuild.BuildBatch"]
    try:
        finished = subprocess.run(command, env=env, timeout=timeout, capture_output=True, text=True)
        return finished.returncode if finished.returncode is not None else -1
    except subprocess.TimeoutExpired:
        step(2, "player build timed out after %ds" % timeout)
        return -9


def run_player(seconds: int) -> None:
    if ACTOR_LOG.exists():
        ACTOR_LOG.unlink()
    env = os.environ.copy()
    env["AICORE_SANDBOX_LOG"] = str(ACTOR_LOG)
    env["AICORE_SANDBOX_PROOF"] = "1"
    process = subprocess.Popen(
        [str(PLAYER_EXE), "-logFile", str(PLAYER_LOG), "-screen-fullscreen", "0",
         "-screen-width", "480", "-screen-height", "270"],
        cwd=str(PLAYER_DIR), env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        process.wait(timeout=seconds)
    except subprocess.TimeoutExpired:
        process.terminate()
        try:
            process.wait(timeout=15)
        except subprocess.TimeoutExpired:
            process.kill()


def analyse() -> tuple:
    text = ACTOR_LOG.read_text(encoding="utf-8", errors="replace") if ACTOR_LOG.exists() else ""
    tracks: dict = {}
    for line in text.splitlines():
        match = SNAPSHOT.search(line)
        if not match:
            continue
        name = match.group(2)
        position = (float(match.group(3)), float(match.group(4)), float(match.group(5)))
        tracks.setdefault(name, []).append((float(match.group(1)), position, match.group(6)))
    events = {
        "meet": len(re.findall(r"event=meet\b", text)),
        "exchange": len(re.findall(r"event=exchange\b", text)),
        "part": len(re.findall(r"event=part\b", text)),
    }
    walked = {}
    for name, samples in tracks.items():
        first = samples[0][1]
        far = max(((sample[1][0] - first[0]) ** 2 + (sample[1][2] - first[2]) ** 2) ** 0.5
                  for sample in samples)
        walked[name] = round(far, 2)
    return tracks, walked, events


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seconds", type=int, default=30)
    parser.add_argument("--build-timeout", type=int, default=1200)
    args = parser.parse_args()

    if not UNITY.is_file():
        print("[driver] Unity not found at %s" % UNITY)
        return 1

    OUT.mkdir(parents=True, exist_ok=True)
    mirror()
    started = time.time()
    exit_code = build_player(args.build_timeout)
    build_text = BUILD_LOG.read_text(encoding="utf-8", errors="replace") if BUILD_LOG.exists() else ""
    if not PLAYER_EXE.is_file() or BUILD_OK.search(build_text) is None:
        tail = "\n".join(build_text.splitlines()[-25:])
        print("SANDBOX PLAYER PROOF: FAILED - the player was not built (exit=%s)" % exit_code)
        print(tail)
        return 1
    step(2, "player built in %.0fs: %s" % (time.time() - started, PLAYER_EXE))

    run_player(args.seconds)
    step(3, "player ran for %ds" % args.seconds)

    tracks, walked, events = analyse()
    problems = []
    if len(walked) < 3:
        problems.append("fewer than 3 characters were tracked: %d" % len(walked))
    movers = [name for name, far in walked.items() if far >= 1.0]
    if len(movers) < 3:
        problems.append("fewer than 3 characters walked a metre: %s" % walked)
    if events["meet"] < 1:
        problems.append("no meeting happened in the player")
    if events["exchange"] < 1:
        problems.append("no exchange happened in the player")

    verdict = "PASSED" if not problems else "FAILED"
    lines = [
        "SANDBOX PLAYER PROOF: %s" % verdict,
        "player: %s  run=%ds build exit=%s" % (PLAYER_EXE, args.seconds, exit_code),
        "characters tracked: %d" % len(tracks),
        "distance from first sample (m): %s" % walked,
        "events: %s" % events,
        "samples per character: %s" % {name: len(samples) for name, samples in tracks.items()},
    ]
    for name, samples in sorted(tracks.items()):
        lines.append("last: %s t=%.2f pos=(%.2f,%.2f,%.2f) state=%s" % (
            name, samples[-1][0], samples[-1][1][0], samples[-1][1][1], samples[-1][1][2], samples[-1][2]))
    if problems:
        lines.append("problems: " + " | ".join(problems))
    receipt = "\n".join(lines) + "\n"
    RECEIPT.write_text(receipt, encoding="utf-8")
    print(receipt)
    print("[driver] receipt: %s" % RECEIPT)
    return 0 if verdict == "PASSED" else 1


if __name__ == "__main__":
    sys.exit(main())
