"""Settle IskIn into the NPC world and let it live-develop the world.

    python tools\\run_npc_world_live.py [--minutes 0] [--every 60] [--build]

Unlike run_npc_world_playercheck (a one-shot proof with a throwaway brain),
this driver connects the world to the RESIDENT IskIn started from the desktop
shortcut (pc/iskin.py): the persistent SQLite memory accumulates across runs,
so every session continues the same world story.

Flow: ensure the resident brain is up (auto-start via pc/iskin.py if not),
build the standalone player once if needed (Unity must be closed for the
build), then run the player in LIVE mode (AICORE_PLAY_LIVE=1): it never quits,
logs an [AICorePlay] receipt every --every seconds, and stops when you close
this window, press Ctrl+C, or --minutes elapses. The brain keeps running:
stopping the world never stops IskIn itself.

The bearer token is redacted from every line printed or written here.
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

TOOLS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS_DIR))

import run_npc_world_playercheck as check  # noqa: E402 - reuse mirror/build/player paths

# The resident-IskIn launcher (home PC). Override with ISKIN_PC for other machines.
ISKIN = Path(os.environ.get(
    "ISKIN_PC", r"E:\AI\AI_folder\unity\AICore\pc\iskin.py"))
TOKEN_FILE = ISKIN.parent / "aicore-token.txt"
LIVE_LOG = check.OUT / "npc-world-live.log"


def resident_token() -> str:
    from_env = os.environ.get("AICORE_TOKEN", "").strip()
    if from_env:
        return from_env
    if TOKEN_FILE.is_file():
        return TOKEN_FILE.read_text(encoding="utf-8").strip()
    raise SystemExit("no token: start IskIn first (desktop shortcut) or set AICORE_TOKEN")


def brain_health(token: str) -> dict | None:
    request = urllib.request.Request(
        check.HOST + "/health", headers={"Authorization": "Bearer " + token})
    try:
        with check._opener().open(request, timeout=2) as response:
            return json.loads(response.read().decode("utf-8"))
    except Exception:
        return None


def ensure_brain(token: str) -> None:
    if brain_health(token) is not None:
        print("[1] resident IskIn: already running on port %d" % check.PORT, flush=True)
        return
    if not ISKIN.is_file():
        raise SystemExit("IskIn is not running and the launcher was not found: %s" % ISKIN)
    print("[1] resident IskIn: starting via %s" % ISKIN, flush=True)
    started = subprocess.run([sys.executable, str(ISKIN), "start"])
    if started.returncode != 0 or brain_health(token) is None:
        raise SystemExit("could not start the resident IskIn; run the desktop start shortcut")


def ensure_player(force: bool) -> None:
    if check.PLAYER_EXE.is_file() and not force:
        print("[2] player build found: %s" % check.PLAYER_EXE, flush=True)
        return
    print("[2] building the standalone player (Unity must be closed; this takes minutes)...",
          flush=True)
    check.mirror_assets()
    code, timed_out = check.build_player(timeout=1800.0)
    if timed_out or code != 0 or not check.PLAYER_EXE.is_file():
        tail = check.BUILD_LOG.read_text(encoding="utf-8", errors="replace").splitlines()[-15:]
        for line in tail:
            print("    " + line, flush=True)
        raise SystemExit("player build failed (code=%s, timed_out=%s); see %s"
                         % (code, timed_out, check.BUILD_LOG))
    print("[2] player built: %s" % check.PLAYER_EXE, flush=True)


def run_world(token: str, every: int, minutes: float) -> int:
    check.OUT.mkdir(parents=True, exist_ok=True)
    environment = os.environ.copy()
    environment["AICORE_PLAY_CHECK"] = "1"
    environment["AICORE_PLAY_LIVE"] = "1"
    environment["AICORE_LIVE_EVERY"] = str(every)
    environment["AICORE_TOKEN"] = token
    print("[3] the world is alive: receipts every %ds; Ctrl+C or close this window to stop "
          "(the brain keeps running). Log: %s" % (every, LIVE_LOG), flush=True)
    log_stream = open(LIVE_LOG, "a", encoding="utf-8", errors="replace")
    # -batchmode: no rendering window; the GPU goes entirely to the LLM, ticks
    # fit the client timeout, and the world evolves without a window at all.
    player = subprocess.Popen(
        [str(check.PLAYER_EXE), "-batchmode", "-logFile", "-"],
        env=environment, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, encoding="utf-8", errors="replace")
    deadline = time.monotonic() + minutes * 60 if minutes > 0 else None
    receipts = 0
    try:
        for line in player.stdout:
            stamp = time.strftime("%H:%M:%S")
            clean = check.redact(line.rstrip(), token)
            print("[%s] %s" % (stamp, clean), flush=True)
            log_stream.write("[%s] %s\n" % (stamp, clean))
            log_stream.flush()
            if "[AICorePlay]" in line:
                receipts += 1
            if deadline and time.monotonic() >= deadline:
                print("[3] time window elapsed (%.0f min); stopping the world." % minutes, flush=True)
                break
    except KeyboardInterrupt:
        print("\n[3] stopped by user; the world closes, the brain keeps running.", flush=True)
    finally:
        if player.poll() is None:
            check.kill_tree(player.pid)
            try:
                player.wait(timeout=30)
            except subprocess.TimeoutExpired:
                pass
        log_stream.close()
    print("[4] session summary: %d receipt line(s); IskIn's memory of this world:" % receipts,
          flush=True)
    request = urllib.request.Request(
        check.HOST + "/v1/knowledge?world=" + check.WORLD_ID,
        headers={"Authorization": "Bearer " + token})
    try:
        with check._opener().open(request, timeout=5) as response:
            knowledge = json.loads(response.read().decode("utf-8"))
        print("    " + json.dumps(knowledge, ensure_ascii=False)[:1000], flush=True)
    except Exception:
        print("    (knowledge endpoint unavailable)", flush=True)
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Settle IskIn into the NPC world (live).")
    parser.add_argument("--minutes", type=float, default=0.0,
                        help="0 (default) = run until stopped")
    parser.add_argument("--every", type=int, default=60,
                        help="seconds between live receipts (10..3600)")
    parser.add_argument("--build", action="store_true",
                        help="force a player rebuild even if one exists")
    args = parser.parse_args()
    if not 10 <= args.every <= 3600:
        raise SystemExit("--every must be 10..3600")
    token = resident_token()
    ensure_brain(token)
    ensure_player(args.build)
    return run_world(token, args.every, args.minutes)


if __name__ == "__main__":
    raise SystemExit(main())
