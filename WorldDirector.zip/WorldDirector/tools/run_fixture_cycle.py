"""One-command fixture cycle: reset, plan, dry run, apply, restore, verify.

This is an operations script, not a tool: it is the only place allowed to spawn
Unity, because the whole point is to drive the editor from outside. The AI tool
layer itself never spawns processes.

    python tools/run_fixture_cycle.py

Exit code 0 means every step held: the polygon started in its known state, the dry
run changed nothing, applying removed every defect, and restoring the automatic
backup brought back exactly the original findings.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

WORLD_DIR = Path(__file__).resolve().parent.parent
PROJECT = WORLD_DIR.parent.parent
VALIDATION = WORLD_DIR / "ValidationProject"
SCENE = "Assets/AICoreFixture/PolygonScene.unity"
OUT = PROJECT / "AICore" / "outputs" / "scene"
UNITY = os.environ.get("UNITY_EXE", r"C:\Program Files\Unity\Hub\Editor\6000.3.9f1\Editor\Unity.exe")
MASTER = os.environ.get("AICORE_APPROVAL_TOKEN") or "cycle-master-0123456789"
SUBJECT = "fixture-cycle"

sys.path.insert(0, str(WORLD_DIR / "brain"))
import tools  # noqa: E402

SCOPE = dict(project_root=PROJECT, approval=MASTER, allow_write=True, confine=True,
             db_path=OUT / "tool-ledger.sqlite3")
step = 0


def say(message):
    global step
    step += 1
    print("[%d] %s" % (step, message), flush=True)


def run_unity(method, env_extra, label):
    env = dict(os.environ)
    env["PYTHONIOENCODING"] = "utf-8"
    env.update(env_extra)
    log = OUT / ("cycle-%s.log" % label)
    OUT.mkdir(parents=True, exist_ok=True)
    started = time.time()
    completed = subprocess.run(
        [UNITY, "-batchmode", "-nographics", "-quit", "-projectPath", str(VALIDATION),
         "-logFile", str(log), "-executeMethod", method],
        env=env, capture_output=True, text=True)
    elapsed = time.time() - started
    say("%s: exit=%d in %.0fs" % (label, completed.returncode, elapsed))
    if completed.returncode != 0:
        text = log.read_text(encoding="utf-8", errors="replace").splitlines()
        for line in text[-8:]:
            print("    " + line)
        raise SystemExit("Unity step failed: %s" % label)
    return log


def scan(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def ids(report):
    return sorted(finding.get("id") for finding in report.get("findings", []))


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    plain = OUT / "cycle-plain.json"
    baseline = OUT / "cycle-baseline.json"
    after_dry = OUT / "cycle-after-dry.json"
    after_apply = OUT / "cycle-after-apply.json"
    after_restore = OUT / "cycle-after-restore.json"

    say("resetting the fixture polygon (rebuilds the scene, so every run starts the same)")
    run_unity("AliTerra.AICore.Fixture.AICoreFixtureBuilder.BuildAndProbeBatch",
              {"AICORE_PROBE_OUT": str(plain)}, "reset")

    say("building the missing-script case: three passes, because the reference can only"
        " dangle after a compile")
    run_unity("AliTerra.AICore.Fixture.AICoreFixtureBuilder.PrepareMissingScriptBatch", {}, "missing-1")
    run_unity("AliTerra.AICore.Fixture.AICoreFixtureBuilder.AttachTempProbeBatch", {}, "missing-2")
    run_unity("AliTerra.AICore.Fixture.AICoreFixtureBuilder.BreakTempProbeBatch", {}, "missing-3")
    # Deleting the script triggers a recompile, so the reading is taken in its own launch:
    # the scene is then read from disk instead of from a stale in-memory copy.
    say("scanning the fixture as it now stands")
    run_unity("AliTerra.AICore.Editor.AICoreSceneProbe.RunBatch",
              {"AICORE_PROBE_SCENE": SCENE, "AICORE_PROBE_OUT": str(baseline)}, "scan")
    plain_report = scan(plain)
    base = scan(baseline)
    say("plain fixture: %d finding(s); with the missing script: %d finding(s), %d object(s)"
        % (plain_report["summary"]["findings"], base["summary"]["findings"],
           base["summary"]["game_objects"]))
    if base["summary"]["missing_scripts"] < 1:
        raise SystemExit("the missing-script case did not materialise")
    if base["summary"]["findings"] <= plain_report["summary"]["findings"]:
        raise SystemExit("the missing script did not add a finding")

    say("planning the fixes from that scan")
    plan = tools.execute_scoped("scene.fixplan",
                                {"project_root": str(PROJECT), "scene": SCENE,
                                 "report": str(baseline)}, **SCOPE)
    if not plan.ok:
        raise SystemExit("scene.fixplan failed: " + plan.error)
    permit = tools.execute_scoped("brain.approval.issue",
                                  {"tool": "outputs.write_text", "path": "scene/cycle-plan.json",
                                   "ttl_seconds": 900, "subject": SUBJECT, "master": MASTER}, **SCOPE)
    if not permit.ok:
        raise SystemExit("issuing a permit failed: " + permit.error)
    saved = tools.execute_scoped("outputs.write_text",
                                 {"path": "scene/cycle-plan.json",
                                  "content": json.dumps(plan.data, indent=2),
                                  "dry_run": False, "overwrite": True,
                                  "approval": permit.data["token"]}, **SCOPE)
    if not saved.ok:
        raise SystemExit("saving the plan failed: " + saved.error)
    say("plan saved by %s with %d fix(es)" % (SUBJECT, len(plan.data["fixes"])))

    plan_path = str(OUT / "cycle-plan.json")
    say("dry run: nothing may change")
    run_unity("AliTerra.AICore.Editor.AICoreSceneFixer.ApplyBatch",
              {"AICORE_FIXPLAN": plan_path, "AICORE_FIX_DRY_RUN": "1",
               "AICORE_FIX_OUT": str(OUT / "cycle-fix-dry.json"),
               "AICORE_PROBE_OUT": str(after_dry)}, "dryrun")
    if ids(scan(after_dry)) != ids(base):
        raise SystemExit("the dry run changed the scene")
    say("dry run left the scene identical")

    say("applying the fixes")
    run_unity("AliTerra.AICore.Editor.AICoreSceneFixer.ApplyBatch",
              {"AICORE_FIXPLAN": plan_path, "AICORE_FIX_DRY_RUN": "0",
               "AICORE_FIX_OUT": str(OUT / "cycle-fix-apply.json"),
               "AICORE_PROBE_OUT": str(after_apply)}, "apply")
    applied = scan(after_apply)
    result = json.loads((OUT / "cycle-fix-apply.json").read_text(encoding="utf-8"))
    backup = result.get("backup")
    say("after apply: %d finding(s); backup=%s" % (applied["summary"]["findings"],
                                                   "yes" if backup and Path(backup).is_file() else "MISSING"))
    if applied["summary"]["findings"] != 0:
        raise SystemExit("the defects were not all fixed")
    if not backup or not Path(backup).is_file():
        raise SystemExit("no backup was taken")

    say("restoring the scene from that backup")
    shutil.copy2(backup, VALIDATION / SCENE)
    run_unity("AliTerra.AICore.Editor.AICoreSceneProbe.RunBatch",
              {"AICORE_PROBE_SCENE": SCENE, "AICORE_PROBE_OUT": str(after_restore)}, "restore")
    if ids(scan(after_restore)) != ids(base):
        raise SystemExit("the restore did not bring back the original findings")
    say("restore brought back exactly the original %d finding(s)" % len(ids(base)))

    print("\nFIXTURE CYCLE PASSED: %d -> 0 -> %d" % (len(ids(base)), len(ids(scan(after_restore)))))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
