"""IskIn's librarian: fetch CC0 3D models from whitelisted free libraries.

    python tools\\iskin_librarian.py --search "bench"            # polyhaven models
    python tools\\iskin_librarian.py --fetch ArmChair_01         # stage one model
    python tools\\iskin_librarian.py --pack <zip-url>            # kenney/quaternius pack
    python tools\\iskin_librarian.py --list                      # staged manifest

Sources and licences (all free for any use, no attribution required):
  - polyhaven.com  : full API, CC0; requires a User-Agent naming the app
  - kenney.nl      : direct zip packs, CC0
  - quaternius.com : direct zip packs, CC0

Safety: only whitelisted domains are ever contacted, downloads land in
AICore/library/staging (outside Assets) and nothing enters the project until
the editor importer (LibraryImport) blesses each file as a catalog prefab.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from run_111_live import PROJECT, log  # noqa: E402

STAGING = PROJECT / "AICore" / "library" / "staging"
MANIFEST = STAGING / "manifest.json"
USER_AGENT = "AliTerra-IskIn/0.6 (local world director)"
WHITELIST = ("api.polyhaven.com", "dl.polyhaven.org", "polyhaven.com",
             "kenney.nl", "www.kenney.nl", "quaternius.com", "www.quaternius.com")
API = "https://api.polyhaven.com"


def opener() -> urllib.request.OpenerDirector:
    # direct connection: the machine proxy must not sit between us and the
    # public libraries, and loopback was never involved here anyway
    return urllib.request.build_opener(urllib.request.ProxyHandler({}))


def request(url: str, timeout: float = 60) -> dict:
    parsed = urllib.parse.urlsplit(url)
    if parsed.hostname not in WHITELIST:
        raise SystemExit("domain not whitelisted: %s" % parsed.hostname)
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with opener().open(req, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8"))


def download(url: str, target: Path, timeout: float = 300) -> None:
    parsed = urllib.parse.urlsplit(url)
    if parsed.hostname not in WHITELIST:
        raise SystemExit("domain not whitelisted: %s" % parsed.hostname)
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with opener().open(req, timeout=timeout) as response, target.open("wb") as out:
        while True:
            chunk = response.read(1 << 16)
            if not chunk:
                break
            out.write(chunk)


def load_manifest() -> dict:
    if MANIFEST.is_file():
        return json.loads(MANIFEST.read_text(encoding="utf-8"))
    return {"items": []}


def save_manifest(manifest: dict) -> None:
    MANIFEST.parent.mkdir(parents=True, exist_ok=True)
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=1), encoding="utf-8")


def search(query: str, limit: int = 15) -> None:
    data = request(API + "/assets?type=models")
    hits = []
    for slug, info in data.items():
        name = info.get("name", "")
        if query.lower() in (slug + " " + name).lower():
            hits.append((slug, name))
    for slug, name in hits[:limit]:
        log("  %-28s %s" % (slug, name))
    log("%d match(es) for %r" % (len(hits), query))


def pick_tier(files: dict, fmt: str) -> tuple:
    """Prefer the smallest tier that still has the format (1k/2k textures)."""
    node = files.get(fmt)
    if not isinstance(node, dict):
        return None, None
    for tier in ("1k", "2k", "4k"):
        entry = node.get(tier, {}).get(fmt)
        if isinstance(entry, dict) and entry.get("url"):
            return tier, entry
    return None, None


def fetch(slug: str) -> None:
    manifest = load_manifest()
    if any(item.get("id") == slug for item in manifest["items"]):
        log("already staged: %s" % slug)
        return
    info = request(API + "/info/" + slug)
    files = request(API + "/files/" + slug)
    tier, entry = pick_tier(files, "fbx")
    if entry is None:
        tier, entry = pick_tier(files, "gltf")
    if entry is None:
        raise SystemExit("no fbx/gltf for %s; stage it by hand" % slug)
    folder = STAGING / slug
    folder.mkdir(parents=True, exist_ok=True)
    ext = ".fbx" if entry["url"].endswith(".fbx") else ".gltf"
    model_file = folder / (slug + ext)
    log("downloading %s (%s, %s tier) ..." % (slug, ext.strip("."), tier))
    download(entry["url"], model_file)
    textures = []
    for rel, item in (entry.get("include") or {}).items():
        url = item.get("url", "")
        if not url.endswith(".jpg"):  # exr/png are heavy; jpg links fine in Unity
            continue
        target = folder / Path(rel).name
        download(url, target)
        textures.append(target.name)
    manifest["items"].append({
        "id": slug, "name": info.get("name", slug),
        "source": "polyhaven.com", "license": "CC0",
        "url": "https://polyhaven.com/a/" + slug,
        "model": str(model_file.name), "textures": textures,
        "staged": time.strftime("%Y-%m-%dT%H:%M:%S"),
    })
    save_manifest(manifest)
    log("staged: %s (%s + %d texture(s)) -> %s" % (slug, model_file.name, len(textures), folder))


def fetch_pack(url: str) -> None:
    name = Path(urllib.parse.urlsplit(url).path).stem or "pack"
    folder = STAGING / name
    folder.mkdir(parents=True, exist_ok=True)
    archive = folder / (name + ".zip")
    log("downloading pack %s ..." % url)
    download(url, archive)
    with zipfile.ZipFile(archive) as zf:
        zf.extractall(folder / "unpacked")
    models = [str(p.relative_to(folder / "unpacked")).replace("\\", "/")
              for p in (folder / "unpacked").rglob("*")
              if p.suffix.lower() in (".fbx", ".glb", ".gltf") and "source" not in p.parts]
    manifest = load_manifest()
    manifest["items"].append({
        "id": name, "name": name, "source": urllib.parse.urlsplit(url).hostname,
        "license": "CC0", "url": url, "model": models[0] if models else "",
        "models": models[:200], "staged": time.strftime("%Y-%m-%dT%H:%M:%S"),
    })
    save_manifest(manifest)
    log("staged pack: %s (%d model file(s))" % (name, len(models)))


def main() -> int:
    parser = argparse.ArgumentParser(description="Fetch CC0 models for IskIn's world.")
    parser.add_argument("--search", default="")
    parser.add_argument("--fetch", default="")
    parser.add_argument("--pack", default="")
    parser.add_argument("--list", action="store_true")
    args = parser.parse_args()
    if args.list:
        for item in load_manifest()["items"]:
            log("  %-24s %-18s %s" % (item["id"], item.get("license"), item.get("model")))
    if args.search:
        search(args.search)
    if args.fetch:
        fetch(args.fetch)
    if args.pack:
        fetch_pack(args.pack)
    if not (args.list or args.search or args.fetch or args.pack):
        parser.print_help()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
