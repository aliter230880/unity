"""Approve and apply one prepared fix plan, in a single explicit operation.

This is the human step in the loop. The brain decides and prepares a plan; this script
is what actually changes a scene, and it only does so when it is told to.

    # look at what would happen (no change, always safe)
    python tools/apply_fix_plan.py --project "D:\\Project" --plan-id fix_abc ^
        --scene Assets/AICoreSandbox/SandboxScene.unity

    # approve it: dry run, apply, verify, and print the revert command
    python tools/apply_fix_plan.py --project "D:\\Project" --plan-id fix_abc ^
        --scene Assets/AICoreSandbox/SandboxScene.unity --apply --subject alice

    # undo it from the backup the fixer took
    python tools/apply_fix_plan.py --project "D:\\Project" --scene Assets/... ^
        --revert "D:\\Project\\AI\\backups\\fix-...\\Assets\\...\\Scene.unity"

Guarantees:

* a dry run always happens before an apply, and an apply is refused if the dry run
  reported nothing to do;
* an apply is refused if the fixer does not report a backup;
* every applied change is written to the same audit log the brain uses;
* a revert restores the file byte for byte and re-reads the scene afterwards.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import time
from pathlib import Path

WORLD_DIR = Path(__file__).resolve().parent.parent
_BRAIN = WORLD_DIR / "brain"
if str(_BRAIN) not in sys.path:
    sys.path.insert(0, str(_BRAIN))
import graphview  # noqa: E402
import policy as policy_module  # noqa: E402
UNITY = os.environ.get("UNITY_EXE", r"C:\Program Files\Unity\Hub\Editor\6000.3.9f1\Editor\Unity.exe")
FIXER = "AliTerra.AICore.Editor.AICoreSceneFixer.ApplyBatch"
PROBE = "AliTerra.AICore.Editor.AICoreSceneProbe.RunBatch"
AUDIT = ("AI", "aicore-writes.log")
DEFAULT_DB = WORLD_DIR / "brain" / "state" / "brain.sqlite3"


class ApplyError(RuntimeError):
    pass


# ---------------------------------------------------------------------------------------
# reading the plan
# ---------------------------------------------------------------------------------------

def load_plan(plan_id: str | None, plan_file: str | None, db_path: str | None) -> dict:
    """A prepared plan, either from a file or from the brain's database."""
    if plan_file:
        path = Path(plan_file).expanduser()
        if not path.is_file():
            raise ApplyError("plan file not found: %s" % path)
        return json.loads(path.read_text(encoding="utf-8"))
    if not plan_id:
        raise ApplyError("pass --plan-id or --plan-file")
    path = Path(db_path).expanduser() if db_path else DEFAULT_DB
    if not path.is_file():
        raise ApplyError("brain database not found: %s" % path)
    connection = sqlite3.connect("file:%s?mode=ro" % path.as_posix(), uri=True)
    connection.row_factory = sqlite3.Row
    try:
        tables = {row["name"] for row in connection.execute(
            "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
        if "fix_plans" not in tables:
            raise ApplyError("the brain has not prepared any plan yet")
        row = connection.execute(
            "SELECT plan FROM fix_plans WHERE plan_id = ? ORDER BY prepared DESC LIMIT 1",
            (plan_id,)).fetchone()
    finally:
        connection.close()
    if row is None:
        raise ApplyError("no prepared plan with id %r" % plan_id)
    return json.loads(row["plan"])


def write_plan_file(plan: dict, out_path: Path) -> Path:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(plan, indent=2), encoding="utf-8")
    return out_path


def audit(project: Path, entry: dict) -> None:
    """Append to the same log the brain writes to, so there is one trail."""
    path = project.joinpath(*AUDIT)
    path.parent.mkdir(parents=True, exist_ok=True)
    entry = dict(entry)
    entry.setdefault("utc", time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))
    with open(path, "a", encoding="utf-8") as handle:
        handle.write(json.dumps(entry, ensure_ascii=False, sort_keys=True) + "\n")


# ---------------------------------------------------------------------------------------
# running the editor
# ---------------------------------------------------------------------------------------

def run_unity(project: Path, method: str, env_extra: dict, log_path: Path) -> None:
    env = dict(os.environ)
    env["PYTHONIOENCODING"] = "utf-8"
    env.update(env_extra)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    completed = subprocess.run(
        [UNITY, "-batchmode", "-nographics", "-quit", "-projectPath", str(project),
         "-logFile", str(log_path), "-executeMethod", method],
        env=env, capture_output=True, text=True)
    if completed.returncode != 0:
        tail = log_path.read_text(encoding="utf-8", errors="replace").splitlines()[-6:]
        raise ApplyError("the editor step failed (%s, exit %d):\n  %s"
                         % (method, completed.returncode, "\n  ".join(tail)))


def scan(project: Path, scene: str, out_path: Path, log_path: Path) -> dict:
    run_unity(project, PROBE, {"AICORE_PROBE_SCENE": scene, "AICORE_PROBE_OUT": str(out_path)},
              log_path)
    return json.loads(out_path.read_text(encoding="utf-8"))


def finding_ids(report: dict) -> list:
    return sorted(str(item.get("id")) for item in report.get("findings", []))


# ---------------------------------------------------------------------------------------
# the operation itself
# ---------------------------------------------------------------------------------------

def apply_plan(project: Path, scene: str, plan: dict, dry_run: bool, subject: str) -> dict:
    """Dry run first, then apply. Returns the outcome, or raises ApplyError."""
    out = project / "AICore" / "outputs" / "scene"
    plan_path = write_plan_file(plan, out / "approved-plan.json")
    before_path, after_path = out / "approve-before.json", out / "approve-after.json"

    before = scan(project, scene, before_path, out / "approve-scan.log")
    dry_path = out / "approve-dry.json"
    run_unity(project, FIXER,
              {"AICORE_FIXPLAN": str(plan_path), "AICORE_FIX_DRY_RUN": "1",
               "AICORE_FIX_OUT": str(dry_path)}, out / "approve-dry.log")
    dry = json.loads(dry_path.read_text(encoding="utf-8"))
    planned = len(dry.get("applied") or [])
    if planned == 0:
        raise ApplyError("the dry run reported nothing to do; refusing to apply")
    if dry_run:
        return {"applied": False, "dry_run": True, "planned": planned,
                "fixes": dry.get("applied") or [], "before": finding_ids(before),
                "backup": None, "plan_id": plan.get("plan_id")}

    apply_path = out / "approve-apply.json"
    run_unity(project, FIXER,
              {"AICORE_FIXPLAN": str(plan_path), "AICORE_FIX_DRY_RUN": "0",
               "AICORE_FIX_OUT": str(apply_path)}, out / "approve-apply.log")
    applied = json.loads(apply_path.read_text(encoding="utf-8"))
    backup = applied.get("backup")
    if not backup or not Path(backup).is_file():
        raise ApplyError("the fixer did not report a usable backup; the change is unverified")

    after = scan(project, scene, after_path, out / "approve-after.log")
    audit(project, {"action": "apply-fix-plan", "plan_id": plan.get("plan_id"),
                    "scene": scene, "backup": backup, "subject": subject,
                    "before": finding_ids(before), "after": finding_ids(after)})
    return {"applied": True, "dry_run": False, "planned": planned,
            "fixes": applied.get("applied") or [], "backup": backup,
            "before": finding_ids(before), "after": finding_ids(after),
            "plan_id": plan.get("plan_id")}


def revert(project: Path, scene: str, backup: str, subject: str) -> dict:
    """Restore a scene from a backup and re-read it."""
    source = Path(backup).expanduser().resolve()
    if not source.is_file():
        raise ApplyError("backup not found: %s" % source)
    target = project / scene
    if not target.is_file():
        raise ApplyError("scene not found: %s" % target)
    shutil.copy2(source, target)
    out = project / "AICore" / "outputs" / "scene"
    report = scan(project, scene, out / "revert-scan.json", out / "revert-scan.log")
    audit(project, {"action": "revert-fix-plan", "scene": scene, "from": str(source),
                    "subject": subject, "after": finding_ids(report)})
    return {"reverted": True, "from": str(source), "findings": finding_ids(report)}


def scene_context_for(project: Path, scene: str) -> dict:
    """The shape of the scene, from the map the editor built."""
    report = project / "AICore" / "outputs" / "scene" / "project-map.json"
    if not report.is_file():
        return {}
    try:
        payload = json.loads(report.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    relations = [{"source": item.get("source"), "target": item.get("target"),
                  "type": item.get("type")}
                 for item in (payload.get("relations") or []) if isinstance(item, dict)]
    return graphview.summarise(graphview.identifier("scene", scene), relations)


def auto_decision(project: Path, scene: str, plan: dict, policy) -> dict:
    """Would the policy let this plan through without a person?"""
    audit_log = project.joinpath(*AUDIT)
    return policy.evaluate(plan,
                           applied_recently=policy_module.count_recent_applies(audit_log),
                           map_context=scene_context_for(project, scene))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="apply_fix_plan.py", description=__doc__)
    parser.add_argument("--project", required=True, help="Unity project root.")
    parser.add_argument("--scene", required=True, help="Scene asset path, e.g. Assets/Scenes/Main.unity")
    parser.add_argument("--plan-id", default=None, help="Prepared plan id in the brain database.")
    parser.add_argument("--plan-file", default=None, help="Plan JSON file, instead of --plan-id.")
    parser.add_argument("--db", default=None, help="Brain database path.")
    parser.add_argument("--apply", action="store_true", help="Actually change the scene.")
    parser.add_argument("--auto", action="store_true",
                        help="Apply without a person, if the auto-approval policy allows it.")
    parser.add_argument("--subject", default="operator", help="Who approved this, for the audit log.")
    parser.add_argument("--revert", default=None, help="Restore the scene from this backup instead.")
    return parser


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    project = Path(args.project).expanduser().resolve()
    if not (project / "Assets").is_dir():
        print("not a Unity project: %s" % project, file=sys.stderr)
        return 1
    try:
        if args.revert:
            outcome = revert(project, args.scene, args.revert, args.subject)
            print("reverted from %s" % outcome["from"])
            print("findings now: %s" % (", ".join(outcome["findings"]) or "none"))
            return 0
        plan = load_plan(args.plan_id, args.plan_file, args.db)
        applying = bool(args.apply)
        subject = args.subject
        if args.auto and not applying:
            policy = policy_module.AutoApprovalPolicy.from_environment(os.environ)
            verdict = auto_decision(project, args.scene, plan, policy)
            if not verdict["allowed"]:
                print("auto-approval refused the plan:", file=sys.stderr)
                for reason in verdict["reasons"]:
                    print("   " + reason, file=sys.stderr)
                print("pass --apply to approve it yourself", file=sys.stderr)
                return 1
            applying = True
            subject = args.subject if args.subject != "operator" else "auto"
            print("auto-approval allowed it: %s" % policy.describe())
        outcome = apply_plan(project, args.scene, plan, dry_run=not applying, subject=subject)
    except ApplyError as error:
        print(str(error), file=sys.stderr)
        return 1

    if outcome["dry_run"]:
        print("dry run only: %d fix(es) planned, nothing changed" % outcome["planned"])
        for fix in outcome["fixes"]:
            print("   " + str(fix))
        print("pass --apply to change the scene")
        return 0

    print("applied %d fix(es) from plan %s" % (outcome["planned"], outcome["plan_id"]))
    print("backup: %s" % outcome["backup"])
    print("findings: %s -> %s" % (", ".join(outcome["before"]) or "none",
                                  ", ".join(outcome["after"]) or "none"))
    print("to undo: python tools\\apply_fix_plan.py --project \"%s\" --scene %s --revert \"%s\""
          % (project, args.scene, outcome["backup"]))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
