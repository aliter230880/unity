// Player-mode play check (phase 23b): same receipt, no editor search stack.
//
// Built into a standalone player, this component replaces the editor harness entry: the scene
// carries the director, this component injects the token and prints the same [AICorePlay]
// receipt, then quits the player. Requires AICORE_PLAY_CHECK=1 in the player's environment.
// Not part of the package; mirrored into the twin only for this check.

using System;
using System.Runtime.InteropServices;
using AliTerra.AICore;
using UnityEngine;

public sealed class AICorePlayerCheck : MonoBehaviour
{
    // A machine-wide proxy must not swallow the loopback request to the brain. Windows apps can
    // override their own proxy configuration without touching the registry; this harness does
    // that for its own process only.
    private const int InternetOptionPerConnectionOption = 75;
    private const int InternetPerConnFlags = 1;
    private const int ProxyTypeDirect = 0x00000001;

    [StructLayout(LayoutKind.Sequential)]
    private struct InternetPerConnOptionList
    {
        public int dwSize;
        public IntPtr pszConnection;
        public int dwOptionCount;
        public int dwOptionError;
        public IntPtr pOptions;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct InternetPerConnOption
    {
        public int dwOption;
        public InternetPerConnOptionValue Value;
    }

    [StructLayout(LayoutKind.Explicit)]
    private struct InternetPerConnOptionValue
    {
        [FieldOffset(0)] public IntPtr pszValue;
        [FieldOffset(0)] public int dwValue;
    }

    [DllImport("wininet.dll", SetLastError = true)]
    private static extern bool InternetSetOption(IntPtr hInternet, int dwOption, IntPtr lpBuffer, int dwBufferLength);

    private static void UseDirectConnection()
    {
        try
        {
            var option = new InternetPerConnOption
            {
                dwOption = InternetPerConnFlags,
                Value = new InternetPerConnOptionValue { dwValue = ProxyTypeDirect }
            };
            int optionSize = Marshal.SizeOf(typeof(InternetPerConnOption));
            int listSize = Marshal.SizeOf(typeof(InternetPerConnOptionList));
            IntPtr optionBlock = Marshal.AllocHGlobal(optionSize);
            IntPtr listBlock = Marshal.AllocHGlobal(listSize);
            try
            {
                Marshal.StructureToPtr(option, optionBlock, false);
                var list = new InternetPerConnOptionList
                {
                    dwSize = listSize,
                    pszConnection = IntPtr.Zero,
                    dwOptionCount = 1,
                    dwOptionError = 0,
                    pOptions = optionBlock
                };
                Marshal.StructureToPtr(list, listBlock, false);
                bool ok = InternetSetOption(IntPtr.Zero, InternetOptionPerConnectionOption, listBlock, listSize);
                Debug.Log("[AICorePlay] loopback proxy override for this process: " + ok);
            }
            finally
            {
                Marshal.FreeHGlobal(optionBlock);
                Marshal.FreeHGlobal(listBlock);
            }
        }
        catch (Exception error)
        {
            Debug.LogWarning("[AICorePlay] proxy override failed: " + error.GetType().Name);
        }
    }
    // Longer than the director's own request timeout, so a slow-but-valid answer is not cut off.
    private const float SettleSeconds = 15f;

    // Nothing may run forever: no answer, no quit - leave anyway.
    private const float HardDeadlineSeconds = 70f;

    // Live mode (AICORE_PLAY_LIVE=1): the world keeps running and a receipt is logged every
    // AICORE_LIVE_EVERY seconds; the player never quits on its own. Settling in, not checking.
    private static bool LiveMode => Environment.GetEnvironmentVariable("AICORE_PLAY_LIVE") == "1";

    private float started;
    private bool reported;
    private string initialStatus;
    private float liveEvery = 60f;
    private float nextLiveReport;

    private static float ParseLiveEvery()
    {
        if (float.TryParse(Environment.GetEnvironmentVariable("AICORE_LIVE_EVERY"),
                           out float value) && value >= 10f && value <= 3600f)
        {
            return value;
        }
        return 60f;
    }

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void Boot()
    {
        if (Environment.GetEnvironmentVariable("AICORE_PLAY_CHECK") != "1")
        {
            return;
        }
        UseDirectConnection();
        WorldDirector director = FindFirstObjectByType<WorldDirector>();
        if (director != null)
        {
            string injected = Environment.GetEnvironmentVariable("AICORE_TOKEN");
            if (!string.IsNullOrEmpty(injected))
            {
                // Never printed and never saved with the scene.
                director.token = injected;
                Debug.Log("[AICorePlay] injected the local brain bearer token from the environment");
            }
        }
        var host = new GameObject("AICorePlayerCheck");
        DontDestroyOnLoad(host);
        host.AddComponent<AICorePlayerCheck>();
        if (Environment.GetEnvironmentVariable("AICORE_PLAY_LIVE") == "1")
        {
            // Live mode publishes world telemetry so the brain (and the LLM planner)
            // reasons about population and relations, not just raw positions.
            host.AddComponent<WorldTelemetry>();
            Debug.Log("[AICorePlay] world telemetry attached");
        }
        Debug.Log("[AICorePlay] player harness armed");
    }

    private void Start()
    {
        started = Time.realtimeSinceStartup;
        liveEvery = ParseLiveEvery();
        nextLiveReport = SettleSeconds;
        WorldDirector current = FindFirstObjectByType<WorldDirector>();
        initialStatus = current == null ? null : current.Status;
        if (LiveMode)
        {
            Debug.Log("[AICorePlay] live mode: receipt every " + Mathf.RoundToInt(liveEvery)
                      + "s; the player keeps running until stopped from outside");
        }
    }

    private void Update()
    {
        if (LiveMode)
        {
            UpdateLive();
            return;
        }
        if (reported)
        {
            return;
        }
        float elapsed = Time.realtimeSinceStartup - started;
        WorldDirector director = FindFirstObjectByType<WorldDirector>();

        // A plan or a stop is a decisive answer; otherwise wait the settling period so that the
        // in-flight status ("waiting for the brain") is never mistaken for an answer.
        bool decisive = director != null && (director.HasPendingPlan || director.IsEmergencyStopped);
        bool timedOut = elapsed >= HardDeadlineSeconds;
        if (!decisive && elapsed < SettleSeconds && !timedOut)
        {
            return;
        }

        reported = true;
        if (director == null)
        {
            Debug.LogError("[AICorePlay] no WorldDirector was found in the scene");
            Finish(1);
            return;
        }

        int owned = 0;
        foreach (WorldEntity entity in FindObjectsByType<WorldEntity>(FindObjectsSortMode.None))
        {
            if (entity.IsOwnedBy(director))
            {
                owned++;
            }
        }

        // "The state moved" is the honest success signal: a status that never left its initial
        // value must not pass.
        bool moved = decisive || director.Status != initialStatus;
        Debug.Log("[AICorePlay] after " + Mathf.RoundToInt(elapsed) + "s: status=\"" + director.Status + "\"; session="
                  + director.SessionId + "; pendingPlan=" + director.HasPendingPlan
                  + "; bufferedResults=" + director.BufferedResultCount
                  + "; lastAction=" + (string.IsNullOrEmpty(director.LastSuccessfulActionId) ? "none" : director.LastSuccessfulActionId)
                  + "; entitiesOwnedByThisDirector=" + owned
                  + "; verdict=" + (moved ? "answered" : timedOut ? "timed out without an answer" : "no answer"));
        if (timedOut && !moved)
        {
            Finish(3);
            return;
        }
        Finish(moved ? 0 : 1);
    }

    private void UpdateLive()
    {
        if (Time.realtimeSinceStartup < nextLiveReport)
        {
            return;
        }
        float elapsed = Time.realtimeSinceStartup - started;
        nextLiveReport = elapsed + liveEvery;
        WorldDirector director = FindFirstObjectByType<WorldDirector>();
        if (director == null)
        {
            Debug.LogError("[AICorePlay] live: no WorldDirector was found in the scene");
            return;
        }
        int owned = 0;
        foreach (WorldEntity entity in FindObjectsByType<WorldEntity>(FindObjectsSortMode.None))
        {
            if (entity.IsOwnedBy(director))
            {
                owned++;
            }
        }
        Debug.Log("[AICorePlay] after " + Mathf.RoundToInt(elapsed) + "s: status=\"" + director.Status
                  + "\"; session=" + director.SessionId
                  + "; bufferedResults=" + director.BufferedResultCount
                  + "; lastAction=" + (string.IsNullOrEmpty(director.LastSuccessfulActionId) ? "none" : director.LastSuccessfulActionId)
                  + "; entitiesOwnedByThisDirector=" + owned
                  + "; verdict=living");
    }

    private void Finish(int code)
    {
        Application.Quit(code);
    }
}
