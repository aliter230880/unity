"""Build the AICore .unitypackage and the staging tree from the package source.

    python tools/build_unitypackage.py [--version 0.6.0]

Reads WorldDirector/Packages/com.aliterra.aicore, writes:
  - UnityPackageStaging/Assets/AICore  (the import mirror, files plus .meta)
  - AICore/AICore_<version>.unitypackage at the AICore root

Every file keeps one stable GUID: the .meta next to the source file is the truth,
and a missing meta is generated once and saved, so a rebuild never re-imports
assets that an earlier package already delivered.
"""

from __future__ import annotations

import argparse
import io
import random
import shutil
import tarfile
import uuid
from pathlib import Path

WORLD_DIR = Path(__file__).resolve().parent.parent
PACKAGE = WORLD_DIR / "Packages" / "com.aliterra.aicore"
AICORE_ROOT = WORLD_DIR.parent
STAGING_ROOT = AICORE_ROOT / "UnityPackageStaging"
STAGING = STAGING_ROOT / "Assets" / "AICore"

# What ships: runtime, editor tooling, examples, and the package README.
SHIPPED_TOP_LEVEL = ("Runtime", "Editor", "Examples", "README.md")

SCRIPT_META = """fileFormatVersion: 2
guid: {guid}
MonoImporter:
  externalObjects: {{}}
  serializedVersion: 2
  defaultReferences: []
  executionOrder: 0
  icon: {{instanceID: 0}}
  userData:
  assetBundleName:
  assetBundleVariant:
"""

DEFAULT_META = """fileFormatVersion: 2
guid: {guid}
DefaultImporter:
  externalObjects: {{}}
  userData:
  assetBundleName:
  assetBundleVariant:
"""


def new_guid() -> str:
    return uuid.UUID(int=random.getrandbits(128)).hex


def ensure_meta(source: Path) -> str:
    meta = source.with_name(source.name + ".meta")
    if meta.is_file():
        for line in meta.read_text(encoding="utf-8").splitlines():
            if line.startswith("guid:"):
                return line.split(":", 1)[1].strip()
    template = SCRIPT_META if source.suffix == ".cs" else DEFAULT_META
    guid = new_guid()
    meta.write_text(template.format(guid=guid), encoding="utf-8", newline="\n")
    return guid


def collect() -> list[tuple[Path, Path, str]]:
    """(absolute source, staging destination, stable guid) for every shipped file."""
    files: list[tuple[Path, Path, str]] = []
    for top in SHIPPED_TOP_LEVEL:
        source_root = PACKAGE / top
        if source_root.is_file():
            files.append((source_root, STAGING / top, ensure_meta(source_root)))
            continue
        for source in sorted(source_root.rglob("*")):
            if source.is_file() and not source.name.endswith(".meta"):
                files.append((source, STAGING / source.relative_to(PACKAGE),
                              ensure_meta(source)))
    return files


def build_staging(files: list[tuple[Path, Path, str]]) -> None:
    if STAGING_ROOT.exists():
        shutil.rmtree(STAGING_ROOT)
    STAGING.mkdir(parents=True, exist_ok=True)
    for source, destination, _guid in files:
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)
        shutil.copyfile(source.with_name(source.name + ".meta"),
                        destination.with_name(destination.name + ".meta"))


def build_unitypackage(files: list[tuple[Path, Path, str]], version: str) -> Path:
    output = AICORE_ROOT / ("AICore_%s.unitypackage" % version)
    with tarfile.open(output, "w:gz") as archive:
        for source, destination, guid in files:
            asset_path = "Assets/AICore/%s" % "/".join(
                part for part in destination.relative_to(STAGING).parts)
            meta = source.with_name(source.name + ".meta")

            def add(name: str, payload: bytes) -> None:
                info = tarfile.TarInfo(name)
                info.size = len(payload)
                archive.addfile(info, io.BytesIO(payload))

            add(guid + "/pathname", asset_path.encode("utf-8"))
            add(guid + "/asset", source.read_bytes())
            add(guid + "/asset.meta", meta.read_bytes())
    return output


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--version", default="0.6.0",
                        help="package version for the file name")
    args = parser.parse_args(argv)

    files = collect()
    if not files:
        print("no files found under %s" % PACKAGE)
        return 1
    build_staging(files)
    output = build_unitypackage(files, args.version)
    print("staged %d files under %s" % (len(files), STAGING))
    print("wrote %s" % output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
