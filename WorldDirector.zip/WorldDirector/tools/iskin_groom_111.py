"""IskIn's grooming loop for project 111: study -> plan -> fix -> report.

    python tools\\iskin_groom_111.py [--apply] [--world city111] [--scene ...]

Every run:
 1. an observe pass (the brain re-reads diagnostics/scene facts),
 2. a fix plan prepared BY the brain (scene.fixplan, stored in its fix_plans),
 3. the plan is saved to AICore/outputs/scene/fixplan.json,
 4. the editor fixer runs DRY and reports what it would change,
 5. with --apply it runs for real (scene backup first, then the fixes),
 6. a fresh scene report is probed and fed back to the brain.

The fixer never invents work: it only executes the plan the brain prepared
from real findings. Runs are serialized (one Unity batch at a time).
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from run_111_live import HOST, PROJECT, UNITY, log, opener, token  # noqa: E402

PLAN_FILE = PROJECT / "AICore" / "outputs" / "scene" / "fixplan.json"
RESULT_FILE = PROJECT / "AICore" / "outputs" / "scene" / "fix-result.json"
SCENE_REPORT = PROJECT / "AICore" / "outputs" / "scene" / "scene-report.json"
DEFAULT_SCENE = "Assets/Advanced Multiplayer Template/Scenes/MainScene.unity"

# Only conservative, local fixes run by default. The broad heuristic actions
# (remove-duplicate-rigs, remove-lod-groups) can mistake normal shared child
# names (UI "Text"/"Image") for duplication and gut a scene: one such run
# took MainScene from 256 objects to 11 before the backup was restored.
SAFE_ACTIONS = {"zero-stretched-size-delta", "strip-missing-scripts",
                "add-camera", "remove-extra-singletons"}


def post(bearer: str, path: str, payload: dict, timeout: float = 300) -> dict:
    request = urllib.request.Request(
        HOST + path,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Authorization": "Bearer " + bearer,
                 "Content-Type": "application/json"},
        method="POST")
    with opener().open(request, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8"))


def find_fixes(node):
    """The plan dict may nest; locate the 'fixes' list wherever it lives."""
    if isinstance(node, dict):
        if isinstance(node.get("fixes"), list):
            return node
        for value in node.values():
            found = find_fixes(value)
            if found is not None:
                return found
    elif isinstance(node, list):
        for value in node:
            found = find_fixes(value)
            if found is not None:
                return found
    return None


def run_unity(args: list, env: dict, log_name: str, timeout: float = 1800) -> int:
    log_file = HERE.parent.parent / "outputs" / "scene" / log_name
    log_file.parent.mkdir(parents=True, exist_ok=True)
    result = subprocess.run(
        [UNITY, "-batchmode", "-nographics", "-quit",
         "-projectPath", str(PROJECT), "-logFile", str(log_file)] + args,
        env=env, timeout=timeout, check=False,
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    tail = ""
    if log_file.is_file():
        lines = log_file.read_text(encoding="utf-8", errors="replace").splitlines()
        tail = "\n".join(lines[-15:])
        log("[fixer] log tail (%s):\n%s" % (log_name, tail))
    return result.returncode


def main() -> int:
    parser = argparse.ArgumentParser(description="IskIn grooms project 111.")
    parser.add_argument("--world", default="city111")
    parser.add_argument("--scene", default=DEFAULT_SCENE)
    parser.add_argument("--apply", action="store_true",
                        help="apply the plan for real (backup first); default is dry")
    parser.add_argument("--unsafe", action="store_true",
                        help="also allow broad heuristic actions (not recommended)")
    args = parser.parse_args()
    bearer = token()

    log("[1] observe pass ...")
    observed = post(bearer, "/v1/observe",
                    {"world_id": args.world, "session_id": "iskin-groom"})
    log("    facts written: %s; recommended: %s"
        % (observed.get("facts_written"), observed.get("recommended")))

    log("[2] asking the brain for a fix plan ...")
    reply = post(bearer, "/v1/tools/call",
                 {"tool": "scene.fixplan", "params": {"scene": args.scene}})
    plan = find_fixes(reply)
    fixes = plan.get("fixes", []) if plan else []
    if not args.unsafe and fixes:
        before = len(fixes)
        fixes = [f for f in fixes if f.get("action") in SAFE_ACTIONS]
        if before - len(fixes):
            log("    dropped %d broad-heuristic fix(es) (scene-gutting risk); "
                "--unsafe to include them." % (before - len(fixes)))
        plan["fixes"] = fixes
    if plan is None or not fixes:
        log("[2] the brain prepared no safe fixes: the scene reads clean.")
        return 0
    plan.setdefault("scene", args.scene)
    plan.setdefault("plan_id", "fix_%d" % int(time.time()))
    PLAN_FILE.parent.mkdir(parents=True, exist_ok=True)
    PLAN_FILE.write_text(json.dumps(plan, ensure_ascii=False, indent=1), encoding="utf-8")
    log("    plan: %d fix(es) for %s -> %s"
        % (len(fixes), plan.get("scene"), PLAN_FILE))
    for fix in fixes:
        log("      - %s: %s" % (fix.get("id"), fix.get("action")))

    env = dict(os.environ)
    env["AICORE_FIXPLAN"] = str(PLAN_FILE)
    env["AICORE_FIX_OUT"] = str(RESULT_FILE)

    log("[3] fixer DRY run ...")
    env["AICORE_FIX_DRY_RUN"] = "1"
    if RESULT_FILE.is_file():
        RESULT_FILE.unlink()
    code = run_unity(["-executeMethod", "AliTerra.AICore.Editor.AICoreSceneFixer.ApplyBatch"],
                     env, "groom-dry.log")
    if code != 0:
        log("[3] dry run failed (exit %d); nothing applied." % code)
        return 1
    if RESULT_FILE.is_file():
        result = json.loads(RESULT_FILE.read_text(encoding="utf-8-sig", errors="replace"))
        log("    dry: would apply %s, skip %s"
            % (len(result.get("applied", [])), len(result.get("skipped", []))))

    if not args.apply:
        log("[4] dry only (pass --apply to execute; a backup is made first).")
        return 0

    log("[4] applying for real (backup first) ...")
    env["AICORE_FIX_DRY_RUN"] = "0"
    if RESULT_FILE.is_file():
        RESULT_FILE.unlink()
    code = run_unity(["-executeMethod", "AliTerra.AICore.Editor.AICoreSceneFixer.ApplyBatch"],
                     env, "groom-apply.log")
    if code != 0:
        log("[4] apply failed (exit %d); the scene backup is kept." % code)
        return 1
    if RESULT_FILE.is_file():
        result = json.loads(RESULT_FILE.read_text(encoding="utf-8-sig", errors="replace"))
        applied_now = len(result.get("applied", []))
        for line in result.get("applied", []):
            log("    applied: %s" % line)
        for line in result.get("skipped", []):
            log("    skipped: %s" % line)
        log("    notes: %s; backup: %s" % (result.get("notes"), result.get("backup")))
        if applied_now:
            try:  # the release cycle triggers on this growing counter
                post(bearer, "/v1/knowledge",
                     {"world_id": args.world, "facts": [{
                         "key": "groom.applied_total", "value": str(applied_now),
                         "category": "system", "confidence": 0.95}]})
            except Exception:
                pass

    log("[5] fresh scene report for the brain ...")
    env2 = dict(os.environ)
    env2["AICORE_PROBE_SCENE"] = args.scene
    if SCENE_REPORT.is_file():
        SCENE_REPORT.unlink()
    run_unity(["-executeMethod", "AliTerra.AICore.Editor.AICoreSceneProbe.RunBatch"],
              env2, "groom-probe.log")
    post(bearer, "/v1/observe", {"world_id": args.world, "session_id": "iskin-groom"})
    log("[5] done: the brain has seen the result. Run iskin_release_111.py "
        "to ship a new build of the city.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
