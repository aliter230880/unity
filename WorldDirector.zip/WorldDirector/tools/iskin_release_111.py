"""Build and deploy a new release of IskIn's city (project 111).

    python tools\\iskin_release_111.py [--force] [--world city111]

The release cycle: when the brain holds more prepared fix plans than were
shipped in the last release (fact release.fixplans_seen), rebuild the
dedicated server and the client player from the current project, restart the
world on the new server build, and record release facts. --force rebuilds
regardless. Runs are serialized (one Unity batch at a time).
"""
from __future__ import annotations

import argparse
import json
import sys
import time
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from run_111_live import (HOST, SERVER_EXE, STABLE_BUILD, UNITY, PROJECT,  # noqa: E402
                          aicore_env, kill_image, log, opener,
                          restart_masterserver, token)

OUT = HERE.parent.parent / "outputs" / "scene"


def post(bearer: str, path: str, payload: dict, timeout: float = 60) -> dict:
    request = urllib.request.Request(
        HOST + path,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Authorization": "Bearer " + bearer,
                 "Content-Type": "application/json"},
        method="POST")
    with opener().open(request, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8"))


def get(bearer: str, path: str, timeout: float = 30) -> dict:
    request = urllib.request.Request(HOST + path,
                                     headers={"Authorization": "Bearer " + bearer})
    with opener().open(request, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8"))


def fact(bearer: str, world: str, key: str, value: str) -> None:
    try:
        post(bearer, "/v1/knowledge",
             {"world_id": world, "facts": [
                 {"key": key, "value": value, "category": "system", "confidence": 0.95}]})
    except Exception as error:
        log("    (fact %s not recorded: %s)" % (key, error))


def knowledge_value(bearer: str, world: str, key: str) -> str:
    try:
        data = get(bearer, "/v1/knowledge?world=" + world)
        for item in data.get("facts", []):
            if item.get("key") == key:
                return str(item.get("value"))
    except Exception:
        pass
    return ""


def plan_count(bearer: str) -> int:
    try:
        reply = post(bearer, "/v1/tools/call",
                     {"tool": "brain.fixplans", "params": {"limit": 50}})
        text = json.dumps(reply)
        return text.count('"plan_id"')
    except Exception:
        return 0


def build(method: str, env_key: str, output: Path, log_name: str, timeout: float = 14400) -> bool:
    import os
    import subprocess
    env = dict(os.environ)
    env[env_key] = str(output)
    log_file = OUT / log_name
    result = subprocess.run(
        [UNITY, "-batchmode", "-nographics", "-quit", "-projectPath", str(PROJECT),
         "-logFile", str(log_file), "-executeMethod", method],
        env=env, timeout=timeout, check=False,
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    code = result.returncode
    tail = ""
    if log_file.is_file():
        lines = log_file.read_text(encoding="utf-8", errors="replace").splitlines()
        tail = "\n".join(lines[-6:])
        log(tail)
    return code == 0 and output.is_file()


def main() -> int:
    parser = argparse.ArgumentParser(description="Release a new build of IskIn's city.")
    parser.add_argument("--world", default="city111")
    parser.add_argument("--force", action="store_true",
                        help="rebuild even when no new fix plans exist")
    parser.add_argument("--skip-build", action="store_true",
                        help="restart the stack on the existing builds only")
    args = parser.parse_args()
    bearer = token()

    plans = plan_count(bearer)
    groomed = knowledge_value(bearer, args.world, "groom.applied_total")
    groomed_n = int(groomed) if groomed.isdigit() else 0
    seen = knowledge_value(bearer, args.world, "release.fixplans_seen")
    seen_n = int(seen) if seen.isdigit() else 0
    log("[1] applied groom fixes: %d; shipped in the last release: %d" % (groomed_n, seen_n))
    if not args.force and not args.skip_build and groomed_n <= seen_n:
        log("[1] nothing new to ship; use --force to rebuild anyway.")
        return 0

    if not args.skip_build:
        log("[2] stopping the world so the build files are not locked ...")
        kill_image("City111Player.exe")
        kill_image("Server.exe")
        log("[2] rebuilding the city server ...")
        if not build("AICoreMultiplayer.Editor.WorldServerBuild.BuildBatch",
                     "AICORE_SERVER_BUILD", SERVER_EXE, "release-server.log"):
            log("[2] server build failed.")
            return 1
        log("[2] rebuilding the client player ...")
        if not build("AICoreMultiplayer.Editor.WorldLiveBuild.BuildBatch",
                     "AICORE_PLAYER_BUILD", STABLE_BUILD, "release-client.log",
                     timeout=7200):
            log("[2] client build failed.")
            return 1

    log("[3] restarting the world on the new build ...")
    kill_image("City111Player.exe")
    kill_image("Server.exe")
    restart_masterserver()
    import os
    import subprocess
    server_log = OUT / "city111-server.log"
    subprocess.Popen([str(SERVER_EXE), "-batchmode", "-logFile", str(server_log)],
                     creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP,
                     env=aicore_env(bearer, 30),
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(6)
    log("[3] world restarted; server log: %s" % server_log)

    count = knowledge_value(bearer, args.world, "release.count")
    count_n = int(count) if count.isdigit() else 0
    fact(bearer, args.world, "release.count", str(count_n + 1))
    fact(bearer, args.world, "release.fixplans_seen", str(max(plans, groomed_n)))
    fact(bearer, args.world, "release.built_at", time.strftime("%Y-%m-%dT%H:%M:%S"))
    log("[4] release #%d recorded in the brain." % (count_n + 1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
