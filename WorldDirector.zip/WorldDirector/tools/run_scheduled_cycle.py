"""Let the cycle wake up on its own, and slow down when the project is quiet.

    python tools/run_scheduled_cycle.py --prepare-first --auto --every-seconds 120 --wakes 4

This is the step between "a command somebody remembers to run" and "something that watches". It
drives the brain's own ``ObservationScheduler``, so a wake that throws is recorded and the
schedule survives it, and it uses ``BackoffSchedule`` for the waiting: quiet wakes get further
apart, and any wake that changed the project snaps the wait back to the base interval.

Each wake runs one full cycle, which takes its own run lock, so a long wake cannot collide with
the next one. The run is bounded - by the number of wakes and by a wall-clock deadline - because
a watcher that cannot be told to stop is not a watcher you can run at night.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

WORLD_DIR = Path(__file__).resolve().parent.parent
if str(WORLD_DIR / "brain") not in sys.path:
    sys.path.insert(0, str(WORLD_DIR / "brain"))
if str(WORLD_DIR / "tools") not in sys.path:
    sys.path.insert(0, str(WORLD_DIR / "tools"))

import run_autonomous_cycle as driver  # noqa: E402
import schedule as brain_schedule  # noqa: E402


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="run_scheduled_cycle.py", description=__doc__)
    parser.add_argument("--every-seconds", type=float, default=120.0,
                        help="the wait after a wake that changed something")
    parser.add_argument("--factor", type=float, default=2.0,
                        help="how much longer to wait after each quiet wake")
    parser.add_argument("--max-seconds", type=float, default=None,
                        help="ceiling for the wait")
    parser.add_argument("--wakes", type=int, default=4, help="how many wakes to run")
    parser.add_argument("--minutes", type=float, default=30.0,
                        help="wall-clock ceiling for the whole run")
    parser.add_argument("--max-cycles", type=int, default=3,
                        help="cycles per wake, passed through to the driver")
    parser.add_argument("--prepare-first", action="store_true",
                        help="let the first wake rebuild the fixture defect case")
    parser.add_argument("--auto", action="store_true",
                        help="let the policy approve without a person")
    args = parser.parse_args(argv)

    backoff = brain_schedule.BackoffSchedule(args.every_seconds, factor=args.factor,
                                             maximum_seconds=args.max_seconds)
    print("schedule: %s" % json.dumps(backoff.describe(), ensure_ascii=False), flush=True)
    state = {"started": 0, "finished": 0}

    def tick():
        state["started"] += 1
        number = state["started"]
        cycle_args = []
        if number == 1 and args.prepare_first:
            cycle_args.append("--prepare")
        if args.auto:
            cycle_args.append("--auto")
        cycle_args += ["--max-cycles", str(args.max_cycles)]
        print("\n[wake %d] %s"
              % (number, time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())), flush=True)
        code = driver.main(cycle_args)
        outcome = driver.LAST_OUTCOME or ("exit-%d" % code)
        wait = backoff.next_interval(outcome)
        print("[wake %d] outcome=%s exit=%d quiet_streak=%d next_wait=%.0fs"
              % (number, outcome, code, backoff.quiet_streak, wait), flush=True)
        # The scheduler reads this after the tick returns, so the wait it uses is the new one.
        scheduler.interval_seconds = wait
        # Counted when the wake is done, not when it starts: a wake that is still running
        # must not let the runner exit and leave a stale lock behind it.
        state["finished"] += 1
        return {"wake": number, "outcome": outcome, "exit": code, "next_wait": wait}

    scheduler = brain_schedule.ObservationScheduler(lambda: None, args.every_seconds)
    scheduler.tick = tick
    scheduler.start()

    deadline = time.monotonic() + max(0.0, args.minutes) * 60.0
    wanted = max(1, args.wakes)
    while state["finished"] < wanted and time.monotonic() < deadline:
        time.sleep(0.5)
    # Stop, and give an in-flight wake time to finish its Unity work before leaving.
    scheduler.stop(timeout=600.0)

    stats = scheduler.stats()
    print("\nSCHEDULED CYCLE: %d/%d wake(s) finished, %d failure(s), interval now %.0fs"
          % (state["finished"], wanted, stats["failures"], scheduler.interval_seconds),
          flush=True)
    if stats["last_error"]:
        print("last error: %s" % stats["last_error"], flush=True)
    reached = state["finished"] >= wanted and state["started"] == state["finished"]
    return 0 if reached and not stats["failures"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
