"""Prove that the SandboxScene cast really moves and really meets.

The main project's batch mode is blocked while the user's editor holds Temp/UnityLockfile,
so the scripts and the scene are mirrored into the validation twin and the deterministic
self-test runs there. The self-test owns the clock: it steps the actors by hand, so the
evidence does not depend on a frame loop (which is exactly what stalls on this machine).

Run: python tools\\run_sandbox_alive_check.py [--keep-twin] [--timeout 1800]
"""

from __future__ import annotations

import argparse
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
WORLD = TOOLS.parent
# The Unity project: normally two levels up; AICORE_PROJECT_ROOT overrides it for
# mirror copies and CI, where this tree is checked out outside the project.
REPO = (Path(os.environ["AICORE_PROJECT_ROOT"]).resolve()
        if os.environ.get("AICORE_PROJECT_ROOT", "").strip()
        else WORLD.parents[1])
TWIN = WORLD / "ValidationProject"
UNITY = Path(r"C:\Program Files\Unity\Hub\Editor\6000.3.9f1\Editor\Unity.exe")

SOURCE_SANDBOX = REPO / "Assets" / "AICoreSandbox"
TWIN_SANDBOX = TWIN / "Assets" / "AICoreSandbox"
SCENE_RELATIVE = Path("Assets") / "AICoreSandbox" / "SandboxScene.unity"
OUT = REPO / "AICore" / "outputs" / "scene"
RECEIPT = OUT / "sandbox-alive-check.log"

EXECUTE_METHOD = "AICoreSandbox.Editor.SandboxAliveSelfTest.RunBatch"
SELFTEST_PREFIX = "[SandboxAliveSelftest]"
ACTOR_PREFIX = "[SandboxAlive]"


def parse_selftest(text: str) -> dict:
    """Pull the numbers the self-test printed out of a Unity log."""
    result: dict = {"verdict": None, "phases": {}, "last": [], "raw": []}
    for line in text.splitlines():
        stripped = line.strip()
        if SELFTEST_PREFIX not in stripped:
            continue
        payload = stripped.split(SELFTEST_PREFIX, 1)[1].strip()
        result["raw"].append(payload)
        if payload.startswith("phase="):
            fields = dict(re.findall(r"([a-z_]+)=([^\s]+)", payload))
            phase = fields.pop("phase", "?")
            result["phases"][phase] = fields
        elif payload.startswith("verdict="):
            result["verdict"] = "PASSED" if "verdict=PASSED" in payload else "FAILED"
            result["verdict_line"] = payload
        elif payload.startswith("last: "):
            result["last"].append(payload[len("last: "):])
    return result


def count_events(text: str) -> dict:
    return {
        "meet": len(re.findall(r"event=meet\b", text)),
        "exchange": len(re.findall(r"event=exchange\b", text)),
        "part": len(re.findall(r"event=part\b", text)),
        "snapshots": len(re.findall(r"\[SandboxAlive\] t=", text)),
    }


def number(phase: dict, key: str) -> float:
    try:
        return float(phase.get(key, "0"))
    except ValueError:
        return 0.0


def mirror() -> list:
    """Copy the sandbox scripts and scene into the twin; drop stale copies first."""
    copied = []
    target_scripts = TWIN_SANDBOX / "Scripts"
    source_scripts = SOURCE_SANDBOX / "Scripts"
    if target_scripts.exists():
        shutil.rmtree(target_scripts)
    shutil.copytree(source_scripts, target_scripts)
    copied.append(str(target_scripts.relative_to(TWIN)))

    for name in ("Prefabs",):
        source = SOURCE_SANDBOX / name
        target = TWIN_SANDBOX / name
        if not source.exists():
            continue
        if target.exists():
            shutil.rmtree(target)
        shutil.copytree(source, target)
        copied.append(str(target.relative_to(TWIN)))

    for name in ("SandboxScene.unity", "SandboxScene.unity.meta", "PropCatalog.asset",
                 "PropCatalog.asset.meta"):
        source = SOURCE_SANDBOX / name
        if not source.exists():
            continue
        target = TWIN_SANDBOX / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        copied.append(str(target.relative_to(TWIN)))
    return copied


def run_unity(timeout: int, log_path: Path, actor_log: Path) -> int:
    env = os.environ.copy()
    env["PROGRAMDATA"] = env.get("PROGRAMDATA") or r"C:\ProgramData"
    env["ALLUSERSPROFILE"] = env.get("ALLUSERSPROFILE") or r"C:\ProgramData"
    env["AICORE_SANDBOX_LOG"] = str(actor_log)
    command = [
        str(UNITY), "-batchmode", "-nographics", "-quit",
        "-projectPath", str(TWIN),
        "-logFile", str(log_path),
        "-executeMethod", EXECUTE_METHOD,
    ]
    print("[driver] unity:", " ".join(command))
    try:
        finished = subprocess.run(command, env=env, timeout=timeout,
                                  capture_output=True, text=True)
        return finished.returncode if finished.returncode is not None else -1
    except subprocess.TimeoutExpired:
        print("[driver] unity timed out after %ds" % timeout)
        return -9


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--timeout", type=int, default=1800)
    parser.add_argument("--keep-twin", action="store_true")
    args = parser.parse_args()

    if not UNITY.exists():
        print("[driver] Unity not found at %s" % UNITY)
        return 1
    if not (SOURCE_SANDBOX / "Scripts").exists():
        print("[driver] no scripts at %s" % (SOURCE_SANDBOX / "Scripts"))
        return 1

    OUT.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    unity_log = OUT / "sandbox-alive-unity.log"
    actor_log = OUT / "sandbox-alive-actor.log"
    for path in (unity_log, actor_log):
        if path.exists():
            path.unlink()

    copied = mirror()
    print("[driver] mirrored into the twin: %d paths" % len(copied))
    for item in copied:
        print("[driver]   " + item)

    started = time.time()
    exit_code = run_unity(args.timeout, unity_log, actor_log)
    elapsed = time.time() - started
    print("[driver] unity exit=%s after %.0fs" % (exit_code, elapsed))

    log_text = unity_log.read_text(encoding="utf-8", errors="replace") if unity_log.exists() else ""
    parsed = parse_selftest(log_text)
    actor_files = [Path(str(actor_log) + suffix) for suffix in (".build", ".scene", "")]
    actor_text = ""
    for path in actor_files:
        if path.exists():
            actor_text += path.read_text(encoding="utf-8", errors="replace")
    events = count_events(actor_text)

    scene_positions = OUT / "sandbox-alive-positions.csv"
    scene_log = Path(str(actor_log) + ".scene")
    if scene_log.exists():
        rows = ["actor,t,pos_x,pos_y,pos_z,state,partner"]
        for line in scene_log.read_text(encoding="utf-8", errors="replace").splitlines():
            match = re.search(
                r"actor=(\S+) pos=\((-?[\d.]+),(-?[\d.]+),(-?[\d.]+)\) state=(\S+) partner=(\S+)", line)
            stamp = re.search(r"t=([\d.]+)", line)
            if not match or not stamp:
                continue
            rows.append(",".join([match.group(1), stamp.group(1), match.group(2), match.group(3),
                                  match.group(4), match.group(5), match.group(6)]))
        scene_positions.write_text("\n".join(rows) + "\n", encoding="utf-8")

    build = parsed["phases"].get("build", {})
    scene = parsed["phases"].get("scene", {})
    problems = []
    if parsed["verdict"] != "PASSED":
        problems.append("self-test verdict=%s" % parsed["verdict"])
    if int(number(build, "actors")) < 3:
        problems.append("built cast too small: %s" % build.get("actors"))
    if int(number(build, "moved")) < 3:
        problems.append("fewer than 3 built actors moved: %s" % build.get("moved"))
    if number(build, "travelled") < 5:
        problems.append("built cast walked too little: %s m" % build.get("travelled"))
    if int(number(build, "meets")) < 2:
        problems.append("too few meetings: %s" % build.get("meets"))
    if int(number(scene, "actors")) < 3:
        problems.append("adopted cast too small: %s" % scene.get("actors"))
    if int(number(scene, "moved")) < 2:
        problems.append("fewer than 2 adopted characters moved: %s" % scene.get("moved"))
    if events["meet"] < 2 or events["exchange"] < 1 or events["part"] < 1:
        problems.append("event log incomplete: %s" % events)

    verdict = "PASSED" if not problems else "FAILED"
    lines = [
        "SANDBOX ALIVE CHECK: %s" % verdict,
        "unity exit=%s elapsed=%.0fs" % (exit_code, elapsed),
        "build phase:   %s" % build,
        "scene phase:   %s" % scene,
        "actor events:  %s" % events,
        "positions dump: %s" % (scene_positions if scene_positions.exists() else "-"),
        "adopted objects: %s" % "; ".join(parsed["last"]),
        "verdict line:  %s" % parsed.get("verdict_line", "-"),
    ]
    if problems:
        lines.append("problems: " + " | ".join(problems))
        tail = "\n".join(log_text.splitlines()[-25:])
        lines.append("unity log tail:\n" + tail)
    receipt = "\n".join(lines) + "\n"
    RECEIPT.write_text(receipt, encoding="utf-8")
    print(receipt)
    print("[driver] receipt: %s" % RECEIPT)

    if not args.keep_twin:
        for path in (unity_log,):
            pass
    return 0 if verdict == "PASSED" else 1


if __name__ == "__main__":
    sys.exit(main())
