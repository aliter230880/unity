"""One unattended cycle, repeated until the project stops asking for attention.

observe -> plan -> decide -> policy -> apply -> verify -> revert when verification fails

This is the operations driver, so it is the thing allowed to spawn Unity: driving the editor
from outside is the whole point of it. The brain layer itself still never spawns a process.

    python tools/run_autonomous_cycle.py --prepare --auto --max-cycles 3

Exit code 0 means the loop ended in a state that can be trusted:

* ``converged``  - a cycle found nothing to fix, so it stopped;
* ``applied-and-verified`` - the change was made and the findings went away;
* ``rolled-back`` - verification failed and the scene was checked to be back to its old self.

A refusal is a result too: the decision layer or the policy says no, with its reasons, and the
a refusal exits non-zero on purpose, so a scheduler can tell
"nothing needed doing" (converged) from "something needed a person" (refused).

One run at a time: the driver takes a lock file in the project it works on, and a second
run refuses with the holder named instead of racing the first over the same scene.

Nothing here bypasses the guards. Planning is a read-only tool call, the apply path takes its
own backup and writes the same audit trail, and the policy - not this script - decides whether
acting without a person is allowed at all.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

WORLD_DIR = Path(__file__).resolve().parent.parent
PROJECT = WORLD_DIR.parent.parent
VALIDATION = WORLD_DIR / "ValidationProject"
# The cycle writes its artifacts inside the project it is working on: the tool layer
# confines every path it is handed to that project root, and it is right to.
OUT = PROJECT / "AICore" / "outputs" / "scene"

if str(WORLD_DIR / "brain") not in sys.path:
    sys.path.insert(0, str(WORLD_DIR / "brain"))
if str(WORLD_DIR / "tools") not in sys.path:
    sys.path.insert(0, str(WORLD_DIR / "tools"))

import apply_fix_plan  # noqa: E402
import decide as brain_decide  # noqa: E402
import policy as brain_policy  # noqa: E402
import tools as brain_tools  # noqa: E402

SUBJECT = "autonomous-cycle"
FIXTURE_SCENE = "Assets/AICoreFixture/PolygonScene.unity"
LEDGER = OUT / "autonomous-cycle.jsonl"

# The last outcome this process produced. A scheduler runs cycles in-process and needs the
# word, not just the exit code, to decide how long to wait next.
LAST_OUTCOME = ""

# A run may apply a fix and still end on a converged cycle. A scheduler must hear that work
# happened, or it will treat a busy wake as a quiet one and back off for no reason.
CHANGING_OUTCOMES = ("applied-and-verified", "rolled-back")


def aggregate_outcome(final_outcome: str, changed: bool) -> str:
    """What to tell a scheduler after a run of several cycles."""
    if changed and str(final_outcome) in ("converged", "incomplete"):
        return "%s-after-applying" % final_outcome
    return str(final_outcome)

# One cycle at a time. Two runs would rewrite the same scene from two backups, and whichever
# finished last would win - which is not a race worth discovering in production.
LOCK_NAME = "autonomous-cycle.lock"


def acquire_lock(path: Path) -> dict:
    """Take the run lock, or report who holds it. Never blocks."""
    payload = json.dumps({"pid": os.getpid(), "subject": SUBJECT,
                          "started": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())})
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        handle = os.open(str(path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError:
        holder = {}
        try:
            holder = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            holder = {"unreadable": True}
        return {"held": False, "holder": holder, "path": str(path)}
    except OSError as error:
        # A lock we cannot write is not a lock: refuse rather than run unprotected.
        return {"held": False, "holder": {"error": str(error)}, "path": str(path)}
    with os.fdopen(handle, "w", encoding="utf-8") as stream:
        stream.write(payload)
    return {"held": True, "holder": json.loads(payload), "path": str(path)}


def release_lock(path: Path) -> None:
    """Releasing twice, or releasing a lock that is gone, is not an error."""
    try:
        path.unlink()
    except OSError:
        pass


def note(message):
    print("  " + message, flush=True)


def prepare_fixture():
    """Rebuild the fixture and plant the missing-script case, so there is something to fix."""
    steps = (
        ("AliTerra.AICore.Fixture.AICoreFixtureBuilder.BuildAndProbeBatch",
         {"AICORE_PROBE_OUT": str(OUT / "autonomous-plain.json")}),
        ("AliTerra.AICore.Fixture.AICoreFixtureBuilder.PrepareMissingScriptBatch", {}),
        ("AliTerra.AICore.Fixture.AICoreFixtureBuilder.AttachTempProbeBatch", {}),
        ("AliTerra.AICore.Fixture.AICoreFixtureBuilder.BreakTempProbeBatch", {}),
    )
    for method, extra in steps:
        name = method.rsplit(".", 1)[-1]
        apply_fix_plan.run_unity(VALIDATION, method, extra,
                                 OUT / ("autonomous-%s.log" % name))
        note("fixture step %s: ok" % name)


def plan_from(project: Path, scene: str, report_path: Path) -> dict:
    """Ask the brain's own read-only planner, so planning stays inside the tool layer."""
    scope = dict(project_root=project, db_path=OUT / "tool-ledger.sqlite3", confine=True)
    result = brain_tools.execute_scoped(
        "scene.fixplan",
        {"project_root": str(project), "scene": scene, "report": str(report_path)},
        **scope)
    if not result.ok:
        raise apply_fix_plan.ApplyError("planning failed: %s" % result.error)
    return result.data


def run_one_cycle(project: Path, scene: str, index: int, policy, fault_inject: bool) -> dict:
    """A single pass: read, decide, act if allowed, and check what actually happened."""
    report = apply_fix_plan.scan(project, scene, OUT / ("autonomous-scan-%d.json" % index),
                                 OUT / ("autonomous-scan-%d.log" % index))
    findings = apply_fix_plan.finding_ids(report)
    note("observed %d finding(s): %s" % (len(findings), ", ".join(findings) or "none"))
    if not findings:
        return {"outcome": "converged", "observed": findings}

    plan = plan_from(project, scene, OUT / ("autonomous-scan-%d.json" % index))
    decision = brain_decide.decide(findings, fix_plan=plan, known_findings=len(findings),
                                   report_age_seconds=0,
                                   map_context=apply_fix_plan.scene_context_for(project, scene))
    note("decision: %s - %s" % (decision["action"], decision["reason"]))
    if decision["action"] != brain_decide.DECISION_FIX:
        return {"outcome": "refused-by-decision", "observed": findings,
                "decision": decision["action"], "reason": decision["reason"]}

    verdict = apply_fix_plan.auto_decision(project, scene, plan, policy)
    note("policy: %s%s" % ("allowed" if verdict["allowed"] else "refused",
                           "" if verdict["allowed"] else " - " + "; ".join(verdict["reasons"])))
    if not verdict["allowed"]:
        return {"outcome": "refused-by-policy", "observed": findings, "policy": verdict}

    applied = apply_fix_plan.apply_plan(project, scene, plan, dry_run=False, subject=SUBJECT)
    note("applied %d fix(es); backup: %s" % (len(applied["fixes"]), applied["backup"]))

    remaining = sorted(str(item) for item in applied["after"])
    verified = not remaining and not fault_inject
    if verified:
        note("verification passed: the findings are gone")
    elif fault_inject and not remaining:
        note("verification FAILED (simulated): the rollback path is what is being tested")
    else:
        note("verification FAILED: %d finding(s) remain" % len(remaining))

    record = {"cycle": index, "observed": findings, "decision": decision["action"],
              "policy_allowed": True, "fixes": applied["fixes"], "backup": applied["backup"],
              "after": remaining, "verified": verified, "simulated_failure": bool(fault_inject)}
    if verified:
        record["outcome"] = "applied-and-verified"
        return record

    reverted = apply_fix_plan.revert(project, scene, applied["backup"], SUBJECT)
    restored = sorted(str(item) for item in reverted["findings"]) == sorted(findings)
    record["reverted_to"] = sorted(str(item) for item in reverted["findings"])
    record["rollback_restored"] = restored
    record["outcome"] = "rolled-back" if restored else "rollback-incomplete"
    note("rolled back: %d finding(s) back%s"
         % (len(reverted["findings"]), "" if restored else " - NOT the original set"))
    return record


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="run_autonomous_cycle.py", description=__doc__)
    parser.add_argument("--project", default=str(VALIDATION))
    parser.add_argument("--scene", default=FIXTURE_SCENE)
    parser.add_argument("--max-cycles", type=int, default=3)
    parser.add_argument("--auto", action="store_true",
                        help="let the policy approve without a person (off by default)")
    parser.add_argument("--fault-inject-verify", action="store_true",
                        help="treat verification as failed, to exercise the rollback path")
    parser.add_argument("--prepare", action="store_true",
                        help="rebuild the fixture defect case before the loop starts")
    parser.add_argument("--break-lock", action="store_true",
                        help="remove a lock left by a run that died, then continue")
    args = parser.parse_args(argv)

    global OUT, LEDGER
    project = Path(args.project).resolve()
    scene = args.scene
    OUT = project / "AICore" / "outputs" / "scene"
    LEDGER = OUT / "autonomous-cycle.jsonl"
    OUT.mkdir(parents=True, exist_ok=True)

    environment = dict(os.environ)
    environment["AICORE_AUTO_APPROVE"] = "1" if args.auto else "0"
    policy = brain_policy.AutoApprovalPolicy.from_environment(environment)
    note("policy: %s" % json.dumps(policy.describe(), ensure_ascii=False))

    global LAST_OUTCOME
    lock_path = OUT / LOCK_NAME
    lock = acquire_lock(lock_path)
    if not lock["held"] and args.break_lock:
        note("--break-lock was given; removing %s" % lock_path)
        release_lock(lock_path)
        lock = acquire_lock(lock_path)
    if not lock["held"]:
        note("another cycle holds the lock: %s"
             % json.dumps(lock.get("holder") or {}, ensure_ascii=False))
        note("if that run is dead, remove the lock file yourself, or pass --break-lock")
        LAST_OUTCOME = "refused-by-lock"
        print("\nAUTONOMOUS CYCLE: refused-by-lock", flush=True)
        return 1
    note("lock taken: %s" % lock_path)

    try:
        return cycle_loop(args, project, scene, policy)
    finally:
        release_lock(lock_path)
        note("lock released")


def cycle_loop(args, project: Path, scene: str, policy) -> int:
    """The loop proper, run under the lock."""
    if args.prepare:
        note("preparing the fixture defect case")
        prepare_fixture()

    global LAST_OUTCOME
    outcome = "incomplete"
    changed = False
    cycles = max(1, int(args.max_cycles))
    for index in range(1, cycles + 1):
        print("[cycle %d of %d]" % (index, cycles), flush=True)
        record = run_one_cycle(project, scene, index, policy, args.fault_inject_verify)
        outcome = record["outcome"]
        if outcome in CHANGING_OUTCOMES:
            changed = True
        try:
            with open(LEDGER, "a", encoding="utf-8") as handle:
                handle.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")
        except OSError as error:
            note("could not append to the ledger: %s" % error)
        if outcome != "applied-and-verified":
            break

    LAST_OUTCOME = aggregate_outcome(outcome, changed)
    print("\nAUTONOMOUS CYCLE: %s%s"
          % (outcome, " (after applying)" if changed and LAST_OUTCOME != outcome else ""),
          flush=True)
    return 0 if outcome in ("converged", "applied-and-verified", "rolled-back") else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except apply_fix_plan.ApplyError as error:
        print("AUTONOMOUS CYCLE: failed - %s" % error, flush=True)
        raise SystemExit(1)
