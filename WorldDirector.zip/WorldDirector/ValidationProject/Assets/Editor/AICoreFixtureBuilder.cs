// AICore fixture scene builder (validation project only).
//
// Builds a scene with known, deliberate defects, saves it, and writes the list of
// findings the scene probe is expected to report. The fixture is the calibration
// target for the probe: if the probe stops reporting one of these, the fixture
// contract fails and we know detection regressed.
//
// Batch: -executeMethod AliTerra.AICore.Fixture.AICoreFixtureBuilder.BuildAndProbeBatch
//        with AICORE_PROBE_OUT=<absolute path> to place the scan report.

using System;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace AliTerra.AICore.Fixture
{
    public static class AICoreFixtureBuilder
    {
        public const string Folder = "Assets/AICoreFixture";
        public const string ScenePath = Folder + "/PolygonScene.unity";
        public const string ManifestPath = Folder + "/expected-findings.json";

        public static void BuildOnlyBatch()
        {
            Run(false);
        }

        public static void BuildAndProbeBatch()
        {
            Run(true);
        }

        private static void Run(bool probe)
        {
            try
            {
                BuildScene();
                WriteManifest();
                if (probe)
                {
                    string outPath = Environment.GetEnvironmentVariable("AICORE_PROBE_OUT");
                    if (string.IsNullOrEmpty(outPath))
                    {
                        throw new InvalidOperationException("AICORE_PROBE_OUT is not set");
                    }
                    string failure = AliTerra.AICore.Editor.AICoreSceneProbe.WriteReport(Path.GetFullPath(outPath));
                    if (failure != null)
                    {
                        throw new InvalidOperationException(failure);
                    }
                    Debug.Log("[AICoreFixture] probe report written to " + outPath);
                }
                Debug.Log("[AICoreFixture] fixture ready: " + ScenePath);
                if (Application.isBatchMode)
                {
                    EditorApplication.Exit(0);
                }
            }
            catch (Exception error)
            {
                Debug.LogError("[AICoreFixture] " + error.GetType().Name + ": " + error.Message);
                if (Application.isBatchMode)
                {
                    EditorApplication.Exit(1);
                }
            }
        }


        /// <summary>Step 1 of 3 for a missing-script case: write a throwaway component.</summary>
        public static void PrepareMissingScriptBatch()
        {
            Wrap(() =>
            {
                Directory.CreateDirectory(Folder);
                File.WriteAllText(Folder + "/TempProbe.cs",
                    "using UnityEngine;\n\nnamespace AliTerra.AICore.Fixture\n{\n"
                    + "    public sealed class TempProbe : MonoBehaviour { }\n}\n",
                    new UTF8Encoding(false));
                AssetDatabase.Refresh();
                Debug.Log("[AICoreFixture] step 1: TempProbe.cs written; run AttachTempProbeBatch next");
            });
        }

        /// <summary>Step 2 of 3: put the throwaway component on an object and save the scene.</summary>
        public static void AttachTempProbeBatch()
        {
            Wrap(() =>
            {
                Scene scene = EditorSceneManager.OpenScene(ScenePath, OpenSceneMode.Single);
                Type probe = null;
                foreach (System.Reflection.Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
                {
                    probe = assembly.GetType("AliTerra.AICore.Fixture.TempProbe");
                    if (probe != null)
                    {
                        break;
                    }
                }
                if (probe == null)
                {
                    throw new InvalidOperationException("TempProbe is not compiled yet; run step 1 first");
                }
                GameObject target = new GameObject("ProbeMissingScript");
                target.AddComponent(probe);
                EditorSceneManager.MarkSceneDirty(scene);
                if (!EditorSceneManager.SaveScene(scene))
                {
                    throw new InvalidOperationException("the fixture scene could not be saved");
                }
                AssetDatabase.Refresh();
                Debug.Log("[AICoreFixture] step 2: probe attached; run BreakTempProbeBatch next");
            });
        }

        /// <summary>Step 3 of 3: delete the component's script, leaving a dangling reference.</summary>
        public static void BreakTempProbeBatch()
        {
            Wrap(() =>
            {
                AssetDatabase.DeleteAsset(Folder + "/TempProbe.cs");
                AssetDatabase.Refresh();
                Debug.Log("[AICoreFixture] step 3: the script is gone, so its component is now missing");
            });
        }

        private static void Wrap(Action action)
        {
            try
            {
                action();
                if (Application.isBatchMode)
                {
                    EditorApplication.Exit(0);
                }
            }
            catch (Exception error)
            {
                Debug.LogError("[AICoreFixture] " + error.GetType().Name + ": " + error.Message);
                if (Application.isBatchMode)
                {
                    EditorApplication.Exit(1);
                }
            }
        }

        private static void BuildScene()
        {
            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            // Defect: two audio listeners, which is never correct.
            new GameObject("ProbeListenerA").AddComponent<AudioListener>();
            new GameObject("ProbeListenerB").AddComponent<AudioListener>();

            // Defect: two hierarchies that both claim to be the same rig.
            GameObject rigLeft = new GameObject("ProbeRigLeft");
            GameObject headLeft = new GameObject("CC_Base_Head");
            headLeft.transform.SetParent(rigLeft.transform);
            GameObject rigRight = new GameObject("ProbeRigRight");
            GameObject headRight = new GameObject("CC_Base_Head");
            headRight.transform.SetParent(rigRight.transform);

            // Defect: an LODGroup, which can cull an instantiated object entirely.
            new GameObject("ProbeLodded").AddComponent<LODGroup>();

            // Defect: stretch anchors with a non-zero sizeDelta - the classic
            // "the click lands outside the drawn control" trap.
            GameObject stretched = new GameObject("ProbeStretchedRect", typeof(RectTransform));
            RectTransform rect = stretched.GetComponent<RectTransform>();
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.sizeDelta = new Vector2(120f, 60f);

            // Defect: deliberately no camera, so the scene renders nothing.

            if (!Directory.Exists(Folder))
            {
                Directory.CreateDirectory(Folder);
            }
            if (!EditorSceneManager.SaveScene(scene, ScenePath))
            {
                throw new InvalidOperationException("the fixture scene could not be saved");
            }
            AssetDatabase.Refresh();
        }

        private static void WriteManifest()
        {
            string json = string.Join("\n", new[]
            {
                "{",
                "  \"fixture\": \"PolygonScene\",",
                "  \"scene\": \"" + ScenePath + "\",",
                "  \"purpose\": \"Calibration target for AICoreSceneProbe: every deliberate defect must be reported.\",",
                "  \"expected_findings\": [",
                "    \"scene.multiple-AudioListener\",",
                "    \"scene.duplicate-transform-names\",",
                "    \"scene.lodgroup-present\",",
                "    \"scene.no-camera\",",
                "    \"scene.rect-stretch-size\"",
                "  ],",
                "  \"expected_summary\": {",
                "    \"cameras\": 0,",
                "    \"lod_groups\": 1,",
                "    \"stretched_rects_with_sizedelta\": 1,",
                "    \"missing_scripts\": 0",
                "  },",
                "  \"known_gaps\": [",
                "    \"the missing-script detector is implemented but is not covered by this fixture: creating a dangling script reference needs a second compile pass.\"",
                "  ]",
                "}",
            });
            File.WriteAllText(ManifestPath, json, new UTF8Encoding(false));
            AssetDatabase.Refresh();
        }
    }
}
