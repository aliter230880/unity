﻿# NPC World Test Scene Setup

Create test scene for AICore LLM reasoning with simple NPC prefabs.

## Scene Structure

- WorldDirector (configured for Approval mode, local LLM)
- Ground plane (100x100)
- 3-5 spawn zones (tavern, market, forest, town square)
- Simple NPC prefabs in catalog (merchant, guard, quest_giver, villager)

## WorldDirector Config

- worldId: npc_test_world
- endpoint: http://127.0.0.1:8765/v2/tick
- mode: Approval
- bounds: (-50, 0, -50) to (50, 20, 50)
- catalog: NPCCatalog.asset (4 prefabs)
- goals: 1 goal - maintain 5 villagers

## Next Steps

Manual work in Unity Editor:
1. Create scene Assets/AICoreSandbox/NPCWorld/NPCTestScene.unity
2. Add WorldDirector GameObject
3. Create 4 simple Cube prefabs with WorldEntity (merchant, guard, quest_giver, villager)
4. Create NPCCatalog ScriptableObject, add 4 prefabs
5. Configure WorldDirector Inspector
6. Test: Start brain server, enter Play mode, click Think

