using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace AICoreSandbox
{
    /// <summary>
    /// Puts the cast on stage. Wired to Unity's scene load, so the scene file itself
    /// never has to change: existing NPC_* / Character_Human objects are adopted,
    /// and if none exist the cast is built from primitives.
    /// </summary>
    public static class SandboxCast
    {
        public const string SceneName = "SandboxScene";

        /// <summary>When a driver owns the clock, Update() must not step the actors.</summary>
        public static bool ExternallyDriven;

        public static readonly List<SandboxActor> Actors = new List<SandboxActor>();

        private static readonly List<GameObject> created = new List<GameObject>();

        public static int Meets;
        public static int Exchanges;
        public static int Parts;

        public static bool HasBounds;
        public static Vector3 BoundsCenter;
        public static float BoundsRadius = 18f;

        private static readonly string[] KnownNames =
        {
            "NPC_Villager", "NPC_QuestGiver", "NPC_Merchant", "NPC_Guard", "Character_Human"
        };

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        private static void Boot()
        {
            if (Environment.GetEnvironmentVariable("AICORE_SANDBOX_OFF") == "1") return;
            Scene scene = SceneManager.GetActiveScene();
            if (scene.name != SceneName) return;
            string logPath = Environment.GetEnvironmentVariable("AICORE_SANDBOX_LOG");
            if (!string.IsNullOrEmpty(logPath)) SandboxAliveLog.Start(logPath);
            Bind(scene, 20260926);
        }

        public static void Reset()
        {
            Actors.Clear();
            Meets = 0;
            Exchanges = 0;
            Parts = 0;
            ExternallyDriven = false;
            for (int index = 0; index < created.Count; index++)
            {
                if (created[index] == null) continue;
                if (Application.isPlaying) UnityEngine.Object.Destroy(created[index]);
                else UnityEngine.Object.DestroyImmediate(created[index]);
            }
            created.Clear();
            SandboxAliveLog.ResetThrottle();
        }

        /// <summary>Adopts the characters already standing in the scene.</summary>
        public static List<SandboxActor> Bind(Scene scene, int seed)
        {
            Actors.Clear();
            ComputeWorldBounds(scene);
            List<GameObject> found = new List<GameObject>();
            GameObject[] roots = scene.GetRootGameObjects();
            for (int index = 0; index < roots.Length; index++) Collect(roots[index].transform, found);
            for (int index = 0; index < found.Count; index++)
            {
                AddActor(found[index], seed + index, found[index].transform.position);
            }
            return Actors;
        }

        private static void Collect(Transform node, List<GameObject> found)
        {
            if (Matches(node.name)) found.Add(node.gameObject);
            for (int index = 0; index < node.childCount; index++) Collect(node.GetChild(index), found);
        }

        private static bool Matches(string name)
        {
            for (int index = 0; index < KnownNames.Length; index++)
            {
                if (name == KnownNames[index]) return true;
            }
            return false;
        }

        /// <summary>Builds a cast from primitives, for a scene that has no characters yet.</summary>
        public static List<SandboxActor> Build(Scene scene, int seed, int count)
        {
            Actors.Clear();
            for (int index = 0; index < count; index++)
            {
                double angle = (Math.PI * 2.0 / count) * index;
                Vector3 position = new Vector3((float)Math.Cos(angle) * 5f, 0.9f, (float)Math.Sin(angle) * 5f);
                string name = index < KnownNames.Length ? KnownNames[index] : "SandboxActor_" + index;
                GameObject root = CreateCharacter(scene, name, position);
                AddActor(root, seed + index, position);
            }
            return Actors;
        }

        private static GameObject CreateCharacter(Scene scene, string name, Vector3 position)
        {
            GameObject root = new GameObject(name);
            SceneManager.MoveGameObjectToScene(root, scene);
            root.transform.position = position;

            GameObject body = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            body.name = "Body";
            SceneManager.MoveGameObjectToScene(body, scene);
            body.transform.SetParent(root.transform, false);
            body.transform.localPosition = new Vector3(0f, 0f, 0f);

            GameObject head = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            head.name = "Head";
            SceneManager.MoveGameObjectToScene(head, scene);
            head.transform.SetParent(root.transform, false);
            head.transform.localPosition = new Vector3(0f, 1.05f, 0f);
            head.transform.localScale = new Vector3(0.6f, 0.6f, 0.6f);

            created.Add(root);
            return root;
        }

        private static readonly Color[] Palette =
        {
            new Color(0.43f, 0.81f, 0.59f),
            new Color(0.35f, 0.66f, 0.90f),
            new Color(0.91f, 0.77f, 0.42f),
            new Color(0.92f, 0.48f, 0.48f),
            new Color(0.78f, 0.57f, 0.92f),
        };

        private static SandboxActor AddActor(GameObject target, int seed, Vector3 home)
        {
            DressIfEmpty(target, seed);
            SandboxActor actor = target.GetComponent<SandboxActor>();
            if (actor == null) actor = target.AddComponent<SandboxActor>();
            actor.Init(seed, home, target.name);
            Actors.Add(actor);
            return actor;
        }

        /// <summary>
        /// The four NPC_ objects in the scene are empty shells: a MeshFilter without a mesh
        /// and a MeshRenderer without a material, so nothing is drawn. Give such a shell a body,
        /// otherwise the cast walks around invisibly.
        /// </summary>
        private static void DressIfEmpty(GameObject target, int seed)
        {
            MeshRenderer[] renderers = target.GetComponentsInChildren<MeshRenderer>();
            for (int index = 0; index < renderers.Length; index++)
            {
                MeshFilter filter = renderers[index].GetComponent<MeshFilter>();
                if (filter != null && filter.sharedMesh != null) return;
            }

            Color colour = Palette[Mathf.Abs(seed) % Palette.Length];
            Material material = MakeMaterial(colour);
            Attach(target, PrimitiveType.Capsule, "SandboxBody", new Vector3(0f, 1.0f, 0f),
                   new Vector3(0.85f, 1.0f, 0.85f), material);
            Attach(target, PrimitiveType.Sphere, "Head", new Vector3(0f, 2.05f, 0f),
                   new Vector3(0.6f, 0.6f, 0.6f), material);
        }

        private static Material MakeMaterial(Color colour)
        {
            Shader shader = Shader.Find("Universal Render Pipeline/Lit");
            if (shader == null) shader = Shader.Find("Standard");
            if (shader == null) shader = Shader.Find("Sprites/Default");
            Material material = new Material(shader);
            material.color = colour;
            return material;
        }

        private static GameObject Attach(GameObject parent, PrimitiveType kind, string name,
                                         Vector3 localPosition, Vector3 localScale, Material material)
        {
            GameObject child = GameObject.CreatePrimitive(kind);
            child.name = name;
            SceneManager.MoveGameObjectToScene(child, SceneManager.GetActiveScene());
            child.transform.SetParent(parent.transform, false);
            child.transform.localPosition = localPosition;
            child.transform.localScale = localScale;
            Renderer renderer = child.GetComponent<Renderer>();
            if (renderer != null && material != null) renderer.sharedMaterial = material;
            created.Add(child);
            return child;
        }

        private static void ComputeWorldBounds(Scene scene)
        {
            HasBounds = false;
            GameObject[] roots = scene.GetRootGameObjects();
            for (int index = 0; index < roots.Length; index++)
            {
                FindGround(roots[index].transform);
                if (HasBounds) break;
            }
            if (!HasBounds) BoundsRadius = 18f;
        }

        private static void FindGround(Transform node)
        {
            if (node.name == "Ground" || node.name == "Floor")
            {
                Renderer renderer = node.GetComponent<Renderer>();
                if (renderer != null)
                {
                    BoundsCenter = renderer.bounds.center;
                    float extent = Mathf.Min(renderer.bounds.extents.x, renderer.bounds.extents.z);
                    BoundsRadius = extent * 0.95f;
                    HasBounds = true;
                    return;
                }
            }
            for (int index = 0; index < node.childCount; index++) FindGround(node.GetChild(index));
        }

        /// <summary>Keeps an actor on the floor area; y is the caller's business.</summary>
        public static Vector3 ClampToWorld(Vector3 position)
        {
            if (!HasBounds || BoundsRadius <= 0f) return position;
            Vector3 delta = new Vector3(position.x - BoundsCenter.x, 0f, position.z - BoundsCenter.z);
            if (delta.magnitude <= BoundsRadius) return position;
            Vector3 clamped = delta.normalized * BoundsRadius;
            return new Vector3(BoundsCenter.x + clamped.x, position.y, BoundsCenter.z + clamped.z);
        }
    }
}
