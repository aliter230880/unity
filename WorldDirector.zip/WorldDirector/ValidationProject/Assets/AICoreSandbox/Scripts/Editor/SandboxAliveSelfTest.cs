using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using AICoreSandbox;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace AICoreSandbox.Editor
{
    /// <summary>
    /// Deterministic proof that the cast walks and meets, without a frame loop:
    /// the driver owns the clock and steps the actors by hand.
    /// Run: -executeMethod AICoreSandbox.Editor.SandboxAliveSelfTest.RunBatch
    /// </summary>
    public static class SandboxAliveSelfTest
    {
        private const int Seed = 20260926;
        private const int Steps = 1800;
        private const int SceneSteps = 900;
        private const float Delta = 1f / 60f;
        private const string ScenePath = "Assets/AICoreSandbox/SandboxScene.unity";
        private const string ReceiptPath = "AICore/outputs/scene/sandbox-alive-selftest.log";

        private static readonly List<string> lines = new List<string>();
        private static string actorLogPath;

        public static void RunBatch()
        {
            int exitCode = 1;
            try
            {
                exitCode = Run();
            }
            catch (Exception error)
            {
                Record("exception=" + error.GetType().Name + ": " + error.Message);
                Debug.LogError("[SandboxAliveSelftest] exception: " + error);
            }
            finally
            {
                SandboxAliveLog.Stop();
                WriteReceipt();
                EditorApplication.Exit(exitCode);
            }
        }

        private static int Run()
        {
            actorLogPath = Environment.GetEnvironmentVariable("AICORE_SANDBOX_LOG");
            StartPhase("build");

            Scene empty = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            SandboxCast.ExternallyDriven = true;
            List<SandboxActor> built = SandboxCast.Build(empty, Seed, 5);
            Step(built, Steps);
            int moved = built.Count(actor => actor != null && actor.Travelled > 1f);
            float travelled = built.Sum(actor => actor == null ? 0f : actor.Travelled);
            Record(string.Format(CultureInfo.InvariantCulture,
                "phase=build actors={0} moved={1} travelled={2} meets={3} exchanges={4} parts={5}",
                built.Count, moved, F(travelled), SandboxCast.Meets, SandboxCast.Exchanges, SandboxCast.Parts));
            ReportLast(built);
            bool phaseBuild = built.Count >= 3 && moved >= 3 && travelled >= 5f
                              && SandboxCast.Meets >= 2 && SandboxCast.Exchanges >= 1 && SandboxCast.Parts >= 1;

            bool phaseScene = false;
            if (File.Exists(ScenePath))
            {
                StartPhase("scene");
                SandboxCast.Reset();
                SandboxCast.ExternallyDriven = true;
                EditorSceneManager.OpenScene(ScenePath, OpenSceneMode.Single);
                List<SandboxActor> bound = SandboxCast.Bind(SceneManager.GetActiveScene(), Seed);
                Step(bound, SceneSteps);
                int movedScene = bound.Count(actor => actor != null && actor.Travelled > 1f);
                float travelledScene = bound.Sum(actor => actor == null ? 0f : actor.Travelled);
                Record(string.Format(CultureInfo.InvariantCulture,
                    "phase=scene actors={0} moved={1} travelled={2} meets={3} exchanges={4} parts={5}",
                    bound.Count, movedScene, F(travelledScene), SandboxCast.Meets, SandboxCast.Exchanges,
                    SandboxCast.Parts));
                ReportLast(bound);
                phaseScene = bound.Count >= 3 && movedScene >= 2 && travelledScene >= 3f;
            }
            else
            {
                Record("phase=scene skipped reason=scene-not-found path=" + ScenePath);
            }

            bool ok = phaseBuild && phaseScene;
            Record(string.Format(CultureInfo.InvariantCulture,
                "verdict={0} build={1} scene={2}",
                ok ? "PASSED" : "FAILED", phaseBuild ? "ok" : "failed", phaseScene ? "ok" : "failed"));
            return ok ? 0 : 1;
        }

        private static void StartPhase(string suffix)
        {
            SandboxAliveLog.ResetThrottle();
            if (string.IsNullOrEmpty(actorLogPath)) return;
            SandboxAliveLog.Start(actorLogPath + "." + suffix);
        }

        private static void Step(List<SandboxActor> actors, int steps)
        {
            for (int index = 0; index < steps; index++)
            {
                for (int actorIndex = 0; actorIndex < actors.Count; actorIndex++)
                {
                    SandboxActor actor = actors[actorIndex];
                    if (actor != null) actor.Step(Delta);
                }
            }
        }

        private static void ReportLast(List<SandboxActor> actors)
        {
            for (int index = 0; index < actors.Count; index++)
            {
                SandboxActor actor = actors[index];
                if (actor == null) continue;
                Vector3 position = actor.transform.position;
                Record(string.Format(CultureInfo.InvariantCulture,
                    "last: {0} pos=({1:0.00},{2:0.00},{3:0.00}) state={4} travelled={5}",
                    actor.DisplayName, position.x, position.y, position.z, actor.StateName, F(actor.Travelled)));
            }
        }

        private static string F(float value)
        {
            return value.ToString("0.00", CultureInfo.InvariantCulture);
        }

        private static void Record(string line)
        {
            string text = "[SandboxAliveSelftest] " + line;
            lines.Add(text);
            Debug.Log(text);
        }

        private static void WriteReceipt()
        {
            try
            {
                string full = Path.Combine(Directory.GetCurrentDirectory(), ReceiptPath);
                string directory = Path.GetDirectoryName(full);
                if (!string.IsNullOrEmpty(directory)) Directory.CreateDirectory(directory);
                File.WriteAllText(full, string.Join("\n", lines) + "\n", new UTF8Encoding(false));
            }
            catch (Exception error)
            {
                Debug.LogWarning("[SandboxAliveSelftest] receipt write failed: " + error.Message);
            }
        }
    }
}
