using System;
using UnityEngine;

namespace AICoreSandbox
{
    public enum ActorState { Roam, Approach, Face, Exchange, Part, Rest }

    /// <summary>
    /// One character: walks its home patch, meets another character, turns to face it,
    /// exchanges a few words (a gesture), parts and cools down.
    /// All logic lives in Step(dt) so a driver can run it without a frame loop.
    /// </summary>
    public class SandboxActor : MonoBehaviour
    {
        public string DisplayName = "actor";
        public float Speed = 1.2f;
        public float RoamRadius = 8f;
        public float MeetRadius = 6f;
        public float RestSeconds = 1.4f;
        public float CooldownSeconds = 10f;
        public Vector3 Home;
        public float Travelled;
        public float SimTime;

        private ActorState state = ActorState.Roam;
        private SandboxActor partner;
        private bool initiator;
        private Vector3 target;
        private Vector3 partTarget;
        private float timer;
        private float cooldown;
        private float lastSnapshotTime = float.NegativeInfinity;
        private System.Random rng;
        private Transform gestureBone;
        private Vector3 gestureBaseEuler;

        public string StateName { get { return state.ToString().ToLowerInvariant(); } }
        public string PartnerName { get { return partner != null ? partner.DisplayName : null; } }
        public bool Busy { get { return state != ActorState.Roam && state != ActorState.Rest; } }

        private void Update()
        {
            if (SandboxCast.ExternallyDriven) return;
            Step(Time.deltaTime);
        }

        public void Init(int seed, Vector3 home, string displayName)
        {
            rng = new System.Random(seed);
            Home = home;
            DisplayName = displayName;
            Speed = 0.8f + (float)rng.NextDouble() * 0.8f;
            RoamRadius = 6f + (float)rng.NextDouble() * 4f;
            MeetRadius = 4f + (float)rng.NextDouble() * 4f;
            CooldownSeconds = 6f + (float)rng.NextDouble() * 9f;
            state = ActorState.Roam;
            timer = 0f;
            cooldown = 0f;
            Travelled = 0f;
            SimTime = 0f;
            target = PickRoamPoint();
            gestureBone = FindChild("Head");
            if (gestureBone == null) gestureBone = FindChild("Body");
            if (gestureBone != null) gestureBaseEuler = gestureBone.localEulerAngles;
        }

        private Transform FindChild(string name)
        {
            foreach (Transform child in transform)
            {
                if (child.name == name) return child;
            }
            return null;
        }

        public void Step(float dt)
        {
            if (dt <= 0f) dt = 1f / 60f;
            SimTime += dt;
            if (cooldown > 0f) cooldown -= dt;

            switch (state)
            {
                case ActorState.Roam: RoamStep(dt); break;
                case ActorState.Approach: ApproachStep(dt); break;
                case ActorState.Face: FaceStep(dt); break;
                case ActorState.Exchange: ExchangeStep(dt); break;
                case ActorState.Part: PartStep(dt); break;
                case ActorState.Rest: RestStep(dt); break;
            }

            ApplySeparation(dt);
            ClampToWorld();
            if (SimTime - lastSnapshotTime >= 0.5f)
            {
                lastSnapshotTime = SimTime;
                SandboxAliveLog.Snapshot(DisplayName, SimTime, transform.position, StateName, PartnerName);
            }
        }

        private Vector3 PickRoamPoint()
        {
            double angle = rng.NextDouble() * Math.PI * 2.0;
            double radius = Math.Sqrt(rng.NextDouble()) * RoamRadius;
            return new Vector3(Home.x + (float)(Math.Cos(angle) * radius), Home.y,
                               Home.z + (float)(Math.Sin(angle) * radius));
        }

        private void Enter(ActorState next)
        {
            state = next;
            timer = 0f;
        }

        private void RoamStep(float dt)
        {
            Vector3 delta = Flat(target) - Flat(transform.position);
            if (delta.magnitude < 0.6f)
            {
                if (rng.NextDouble() < 0.25) { Enter(ActorState.Rest); timer = 0.5f + (float)rng.NextDouble() * RestSeconds; return; }
                target = PickRoamPoint();
            }

            MoveTowards(target, Speed, dt);

            if (cooldown > 0f) return;
            SandboxActor candidate = FindPartner();
            if (candidate == null) return;
            partner = candidate;
            initiator = true;
            Enter(ActorState.Approach);
            partner.Join(this);
            SandboxCast.Meets++;
            SandboxAliveLog.Event("meet", DisplayName, partner.DisplayName);
        }

        private SandboxActor FindPartner()
        {
            SandboxActor best = null;
            float bestDistance = MeetRadius;
            for (int index = 0; index < SandboxCast.Actors.Count; index++)
            {
                SandboxActor other = SandboxCast.Actors[index];
                if (other == null || other == this || other.Busy || other.cooldown > 0f) continue;
                float distance = Flat(other.transform.position - transform.position).magnitude;
                if (distance < bestDistance) { bestDistance = distance; best = other; }
            }
            return best;
        }

        /// <summary>The other side of a meeting: no counters, no events, it just joins in.</summary>
        public void Join(SandboxActor other)
        {
            partner = other;
            initiator = false;
            Enter(ActorState.Approach);
        }

        private void ApproachStep(float dt)
        {
            if (partner == null) { Enter(ActorState.Roam); return; }
            MoveTowards(partner.transform.position, Speed, dt);
            if (Flat(partner.transform.position - transform.position).magnitude <= 1.8f)
            {
                Enter(ActorState.Face);
                timer = 0.5f;
            }
        }

        private void FaceStep(float dt)
        {
            if (partner == null) { Enter(ActorState.Roam); return; }
            LookAt(partner.transform.position, dt);
            timer -= dt;
            if (timer > 0f) return;
            Enter(ActorState.Exchange);
            timer = 2f + (float)rng.NextDouble() * 2f;
            if (initiator)
            {
                SandboxCast.Exchanges++;
                SandboxAliveLog.Event("exchange", DisplayName, partner.DisplayName);
            }
        }

        private void ExchangeStep(float dt)
        {
            if (partner == null) { Enter(ActorState.Roam); return; }
            LookAt(partner.transform.position, dt);
            timer -= dt;
            if (gestureBone != null)
            {
                float swing = Mathf.Sin(SimTime * 6f) * 7f;
                gestureBone.localEulerAngles = gestureBaseEuler + new Vector3(swing, 0f, 0f);
            }
            if (timer > 0f) return;
            if (gestureBone != null) gestureBone.localEulerAngles = gestureBaseEuler;
            Vector3 away = Flat(transform.position - partner.transform.position);
            if (away.magnitude < 0.01f) away = new Vector3(1f, 0f, 0f);
            partTarget = transform.position + away.normalized * (3f + (float)rng.NextDouble() * 2f);
            Enter(ActorState.Part);
            timer = 4f;
            if (initiator)
            {
                SandboxCast.Parts++;
                SandboxAliveLog.Event("part", DisplayName, partner.DisplayName);
            }
        }

        private void PartStep(float dt)
        {
            MoveTowards(partTarget, Speed, dt);
            timer -= dt;
            Vector3 delta = Flat(partTarget) - Flat(transform.position);
            if (delta.magnitude > 0.5f && timer > 0f) return;
            float wait = CooldownSeconds + (float)rng.NextDouble() * 5f;
            cooldown = wait;
            if (partner != null)
            {
                partner.cooldown = wait;
                partner.partner = null;
                partner.Enter(ActorState.Roam);
                partner.target = partner.PickRoamPoint();
            }
            partner = null;
            initiator = false;
            Enter(ActorState.Rest);
            timer = 0.4f;
        }

        private void RestStep(float dt)
        {
            timer -= dt;
            if (timer > 0f) return;
            Enter(ActorState.Roam);
            target = PickRoamPoint();
        }

        private static Vector3 Flat(Vector3 value)
        {
            return new Vector3(value.x, 0f, value.z);
        }

        private void MoveTowards(Vector3 destination, float speed, float dt)
        {
            Vector3 position = transform.position;
            Vector3 flatPosition = Flat(position);
            Vector3 delta = Flat(destination) - flatPosition;
            float distance = delta.magnitude;
            if (distance < 0.0001f) return;
            Vector3 direction = delta / distance;
            float step = Mathf.Min(speed * dt, distance);
            Vector3 next = flatPosition + direction * step;
            next = SandboxCast.ClampToWorld(next);
            transform.position = new Vector3(next.x, position.y, next.z);
            Travelled += step;
            LookAt(transform.position + direction, dt);
        }

        private void LookAt(Vector3 destination, float dt)
        {
            Vector3 delta = Flat(destination) - Flat(transform.position);
            if (delta.sqrMagnitude < 0.0001f) return;
            Quaternion wanted = Quaternion.LookRotation(delta.normalized, Vector3.up);
            transform.rotation = Quaternion.Slerp(transform.rotation, wanted, Mathf.Clamp01(6f * dt));
        }

        private void ApplySeparation(float dt)
        {
            Vector3 push = Vector3.zero;
            for (int index = 0; index < SandboxCast.Actors.Count; index++)
            {
                SandboxActor other = SandboxCast.Actors[index];
                if (other == null || other == this) continue;
                Vector3 delta = Flat(transform.position - other.transform.position);
                float distance = delta.magnitude;
                if (distance > 1.3f || distance < 0.0001f) continue;
                push += delta.normalized * (1.3f - distance);
            }
            if (push.sqrMagnitude < 0.0001f) return;
            Vector3 next = SandboxCast.ClampToWorld(Flat(transform.position) + push * Mathf.Clamp01(dt * 3f));
            transform.position = new Vector3(next.x, transform.position.y, next.z);
        }

        private void ClampToWorld()
        {
            Vector3 next = SandboxCast.ClampToWorld(Flat(transform.position));
            transform.position = new Vector3(next.x, transform.position.y, next.z);
        }
    }
}
