using System;
using System.Globalization;
using System.IO;
using System.Text;
using UnityEngine;

namespace AICoreSandbox
{
    /// <summary>
    /// The evidence sink. The line format is frozen: an outside driver parses it,
    /// so it must stay exactly as written here.
    /// </summary>
    public static class SandboxAliveLog
    {
        private static StreamWriter writer;
        private const float SnapshotInterval = 0.5f;

        public static bool Active { get { return writer != null; } }

        public static void Start(string path)
        {
            Stop();
            try
            {
                if (string.IsNullOrEmpty(path)) return;
                string dir = Path.GetDirectoryName(path);
                if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);
                writer = new StreamWriter(path, false, new UTF8Encoding(false));
                writer.AutoFlush = true;
            }
            catch (Exception error)
            {
                writer = null;
                Debug.LogWarning("[SandboxAlive] log start failed: " + error.Message);
            }
        }

        public static void Stop()
        {
            if (writer == null) return;
            try { writer.Flush(); writer.Dispose(); }
            catch (Exception) { }
            writer = null;
        }

        public static void Line(string text)
        {
            if (writer != null) writer.WriteLine(text);
            else Debug.Log(text);
        }

        public static void Event(string kind, string actor, string partner)
        {
            Line(string.Format(CultureInfo.InvariantCulture,
                "[SandboxAlive] event={0} actor={1} partner={2}", kind, actor, partner));
        }

        public static void Snapshot(string actor, float time, Vector3 position, string state, string partner)
        {
            Line(string.Format(CultureInfo.InvariantCulture,
                "[SandboxAlive] t={0:0.00} actor={1} pos=({2:0.00},{3:0.00},{4:0.00}) state={5} partner={6}",
                time, actor, position.x, position.y, position.z, state, string.IsNullOrEmpty(partner) ? "-" : partner));
        }

        /// <summary>Kept for callers that reset between phases; the throttle now lives per actor.</summary>
        public static void ResetThrottle()
        {
            // no global state to reset: each actor throttles its own snapshots
        }
    }
}
