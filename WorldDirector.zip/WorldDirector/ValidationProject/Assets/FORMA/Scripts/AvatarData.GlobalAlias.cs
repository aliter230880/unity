using UnityEngine;

// Compatibility alias for Magic Avatar Creator scripts that reference
// AvatarData without importing the MagicAvatarCreator namespace.
// The serialized assets continue using MagicAvatarCreator.AvatarData.
public class AvatarData : MagicAvatarCreator.AvatarData
{
}
