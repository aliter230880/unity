using System;
using UnityEngine;

namespace MagicAvatarCreator
{
    // Compatibility container for the supplied MagicAvatarCreator base assets.
    [CreateAssetMenu(fileName = "AvatarData", menuName = "FORMA/Avatar Data")]
    public class AvatarData : ScriptableObject
    {
        public int avatarType;
        public string[] blendShapeNames = Array.Empty<string>();
        public float[] blendShapeValues = Array.Empty<float>();
        public string[] clothGuids = Array.Empty<string>();
        public string clothPlaces;
        public float metallic;
        public float smoothness = 0.45f;
        public Color skinColorCorrector = Color.white;
        public Color lipsColor = Color.white;
        public Color nipplesColor = Color.white;
        public Color frackles = Color.clear;
        public float fracklesIntensity = 0.5f;
        public float fracklesScale = 10f;
        public float fracklesLightness;

        public float GetValue(string name, float fallback = 0f)
        {
            if (blendShapeNames == null || blendShapeValues == null) return fallback;
            for (int i = 0; i < blendShapeNames.Length && i < blendShapeValues.Length; i++)
                if (blendShapeNames[i] == name) return blendShapeValues[i];
            return fallback;
        }
    }
}
