// Player-build entry (phase 23b): build a standalone player of the NPC world scene.
//
// Reads AICORE_SCENE (scene to build) and AICORE_PLAYER_BUILD (absolute output path, .exe).
// Not part of the package; mirrored into the twin only for this check.

using System;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;

public static class AICorePlayerBuild
{
    public static void BuildBatch()
    {
        try
        {
            string scene = Environment.GetEnvironmentVariable("AICORE_SCENE");
            string output = Environment.GetEnvironmentVariable("AICORE_PLAYER_BUILD");
            if (string.IsNullOrEmpty(scene) || string.IsNullOrEmpty(output))
            {
                Debug.LogError("[AICorePlayerBuild] AICORE_SCENE and AICORE_PLAYER_BUILD are required");
                EditorApplication.Exit(1);
                return;
            }
            EditorSceneManager.OpenScene(scene, OpenSceneMode.Single);
            var options = new BuildPlayerOptions
            {
                scenes = new[] { scene },
                locationPathName = output,
                target = BuildTarget.StandaloneWindows64,
                options = BuildOptions.None
            };
            var report = BuildPipeline.BuildPlayer(options);
            Debug.Log("[AICorePlayerBuild] result=" + report.summary.result
                      + " errors=" + report.summary.totalErrors
                      + " output=" + output);
            EditorApplication.Exit(report.summary.result == BuildResult.Succeeded ? 0 : 1);
        }
        catch (Exception error)
        {
            Debug.LogError("[AICorePlayerBuild] " + error.GetType().Name + ": " + error.Message);
            EditorApplication.Exit(1);
        }
    }
}
