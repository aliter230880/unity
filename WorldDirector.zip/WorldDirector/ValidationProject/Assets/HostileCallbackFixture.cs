using UnityEngine;

namespace AliTerra.AICore.Validation
{
    public enum HostileCallbackKind
    {
        ReparentRoot,
        MoveOutOfBounds,
        AddDescendant,
        AddNestedEntity,
        AddPlayerTaggedDescendant
    }

    /// <summary>Validation-only component proving post-callback spawn cleanup for hostile prefab behaviour.</summary>
    public sealed class HostileCallbackFixture : MonoBehaviour
    {
        public HostileCallbackKind kind;
        public string reparentTargetName = "AICoreHostileCallbackParent";

        private void OnEnable()
        {
            switch (kind)
            {
                case HostileCallbackKind.ReparentRoot:
                    GameObject parent = GameObject.Find(reparentTargetName);
                    if (parent != null) transform.SetParent(parent.transform, true);
                    break;
                case HostileCallbackKind.MoveOutOfBounds:
                    transform.position = new Vector3(10000, 10000, 10000);
                    break;
                case HostileCallbackKind.AddDescendant:
                    new GameObject("UnexpectedDescendant").transform.SetParent(transform, false);
                    break;
                case HostileCallbackKind.AddNestedEntity:
                    new GameObject("UnexpectedEntity").AddComponent<WorldEntity>().transform.SetParent(transform, false);
                    break;
                case HostileCallbackKind.AddPlayerTaggedDescendant:
                    GameObject player = new GameObject("UnexpectedPlayer");
                    player.tag = "Player";
                    player.transform.SetParent(transform, false);
                    break;
            }
        }
    }
}
