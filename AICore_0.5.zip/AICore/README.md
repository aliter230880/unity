# AICore World Director 0.4

A bounded local AI brain for Unity 6000.3. It observes only `WorldEntity` objects, stores explicit knowledge and outcomes in SQLite, plans typed actions, and lets Unity validate every mutation before execution.

This is an extensible world-director foundation, not unrestricted AGI. It never executes generated C#, shell commands, reflection, editor commands, downloads, or arbitrary prefabs.

## What 0.4 supports

- Protocol v2 connection between Unity and the Python brain.
- Persistent, session-scoped population goals with priorities and status.
- Explicit world facts and entity relations published by trusted gameplay code.
- SQLite observations, replay protection, action results, feedback, and placement adaptation.
- Typed `spawn`, `move`, `activate`, and `deactivate` actions behind catalog, bounds, ownership, rate, authority, and approval gates.
- Observe, Approval, Autonomous, and Emergency Stop modes.
- Protocol v1 compatibility when `protocolVersion` and endpoint are changed together.

## Start the brain

From `WorldDirector`:

Windows PowerShell:

```powershell
$env:AICORE_TOKEN = "replace-with-a-random-token-at-least-16-chars"
python brain/server.py --port 8765
```

macOS/Linux:

```bash
export AICORE_TOKEN='replace-with-a-random-token-at-least-16-chars'
python3 brain/server.py --port 8765
```

The service binds only to `127.0.0.1`. Its default database is `brain/state/brain.sqlite3`.

## Install in Unity

1. Open Package Manager, choose **Add package from disk**, and select `WorldDirector/Packages/com.aliterra.aicore/package.json`.
2. Create a `PrefabCatalog` asset and add only developer-approved prefabs.
3. Add `WorldEntity` to scene objects that may be observed.
4. Add `World Director` from the GameObject/AICore menu.
5. Set the same bearer token, keep endpoint `http://127.0.0.1:8765/v2/tick`, assign the catalog and target catalog ID.
6. Start in **Observe**. Move to **Approval** after inspecting plans. Use **Autonomous** only on the authoritative game instance.

## Gameplay integration

Publish deliberate telemetry rather than scraping the whole scene:

```csharp
director.PublishEvent("quest.completed", 1f);
director.PublishKnowledge("weather.current", "rain", "weather", 0.9f);
director.PublishRelation(npcId, buildingId, "lives_in", 0.8f);
director.ActionExecuted += actionId => director.RateAction(actionId, 1f);
```

Facts and relations are sent transactionally and removed from the Unity buffer only after a valid matching response.

## Tests

```bash
cd WorldDirector
python tests/test_brain.py
```

The included validation project targets Unity `6000.3.9f1`. Run its batch validation inside an installed Unity Editor before shipping; this environment validated Python but did not contain Unity.

## Next engineering step

Add game-specific goals beyond population maintenance, such as zone occupancy, economy balance, quests, and construction. Each goal should get a typed schema, deterministic evaluator, explicit reward source, and an executor capability, never a free-form command channel.
