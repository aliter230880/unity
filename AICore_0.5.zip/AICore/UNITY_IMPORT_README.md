# Unity test import

Use `AICore_0.5.unitypackage` to import the runtime, editor tooling, and a small trusted gameplay integration example into an existing Unity project.

The package targets Unity 6000.3+ and does not contain a scene or a prefab. This is intentional: it cannot overwrite the user's project. After import, create a GameObject, add `AICore/World Director`, assign a `PrefabCatalog`, and leave the mode at Observe for the first request.
