# AICore world-director AI — implementation checkpoint

Date: 2026-09-11
Requested workspace: `E:\AI\AI_folder\unity\AICore`
Status: investigation completed; architecture proposed; implementation NOT yet written or tested.

## 1. User intent

The user wants an internal AI for a Unity metaverse, not a chatbot or a small enemy controller. Their intended system should observe the game, remember experience, pursue goals, coordinate game systems, and eventually control the creation and management of game content. They also want the architecture to be reusable in other games.

The latest request was to save a context file if completion was still far away. This file is that checkpoint, not a claim that the AI has been built.

Practical boundaries:
- Deliver an extensible world-director framework, not an unlimited superintelligence.
- Integrate explicitly with each game's systems; universal automatic compatibility is not realistic.
- Persistent memory and outcome-based adaptation are distinct from neural-model training.
- New 3D models, multimedia, and arbitrary asset generation are not part of this implementation. Existing developer-approved prefabs may be instantiated through normal game-runtime APIs.
- Do not give a language model arbitrary C#, shell commands, unrestricted file access, or unrestricted control of the Unity Editor.

## 2. What has actually been done

### Completed

1. Read `E:\AI\AI_folder\unity\AGENTS.md`.
2. Read all four existing AICore documents:
   - `README.md`
   - `CONTEXT.md`
   - `SETUP_GUIDE.md`
   - `TROUBLESHOOTING.md`
3. Inspected `AiCore.unitypackage` in memory using Python's tarfile module. Nothing was extracted or executed.
4. Examined archived source for the central orchestrator, world state, decision engine, event orchestration, and LLM connector. The terminal output was partially truncated, so not every line of every archived script was reviewed.
5. Checked installed Unity editor directories and available build tooling.
6. Selected a proposed architecture: a local Python brain service plus a separate Unity package. This is an engineering recommendation, not a completed implementation or a separately confirmed user choice.
7. Created empty implementation directories listed below.
8. Wrote this checkpoint.

### Not done

- No new Python service source has been written.
- No new Unity C# runtime source has been written.
- No package manifest or assembly definitions have been written.
- No Unity project has been modified or connected.
- No model has been configured, downloaded, trained, or called.
- No tests, compilation, Unity Play Mode checks, or gameplay validation have run.
- No server is running.
- No 3D assets or scenes have been generated.
- No existing package or documentation has been overwritten.

## 3. Existing files and verified package contents

The requested folder originally contained:

```text
E:\AI\AI_folder\unity\AICore\
  AiCore.unitypackage
  README.md
  SETUP_GUIDE.md
  TROUBLESHOOTING.md
  CONTEXT.md
```

The package contains 18 source-file asset paths:

```text
Assets/Scripts/AICore/AICore.cs
Assets/Scripts/AICore/WorldStateManager.cs
Assets/Scripts/AICore/DecisionEngine.cs
Assets/Scripts/AICore/EventOrchestrator.cs
Assets/Scripts/AICore/LLMConnector.cs
Assets/Scripts/AICore/PlayerController.cs
Assets/Scripts/AICore/PlayerHealth.cs
Assets/Scripts/AICore/EnemyAI.cs
Assets/Scripts/AICore/AIDebugUI.cs
Assets/Scripts/AICore/SceneTestRunner.cs
Assets/Scripts/Generators/TerrainGenerator.cs
Assets/Scripts/Generators/EntitySpawner.cs
Assets/Scripts/Generators/HumanoidBuilder.cs
Assets/Editor/AICoreTestRunner.cs
Assets/Editor/AgentTools.cs
Assets/Editor/AnimationSetup.cs
Assets/Editor/PrefabAnimatorSetup.cs
Assets/Editor/PeoplePackSetup.cs
```

Existing namespace: `AIMetaverse` and `AIMetaverse.Editor`.

The old documents refer to `D:\Work\Unity\Projects\AIMetaverse` and Unity `6000.3.9f1`. That project path was NOT independently checked during this task. Their claims of successful tests are dated 2026-08-06 and must not be presented as current validation.

The parent `AGENTS.md` separately describes the AliTerra client at `D:\Work\Unity\Projects\AliTerra09,02` and a Fusion server project. Those paths were not inspected or modified in this task.

## 4. Why the existing implementation does not match the user's goal

### Verified in archived code

- `DecisionEngine.ExecuteFallbackLogic()` is marked as a placeholder and essentially logs state rather than planning meaningful world actions.
- `DecisionEngine.ExecuteLLMDecision()` is also a placeholder; it logs that LLM decision logic would run there.
- `AICore.ThinkNow()` logs a manual thinking request but does not actually invoke a decision cycle.
- `LLMConnector.TestConnectionSync()` checks whether the URL and API key are nonempty. It does not test network connectivity and rejects keyless local services.
- The LLM connector constructs request JSON manually after attempting to serialize anonymous objects with `JsonUtility`; this approach is fragile and must be replaced with typed DTO serialization.
- Response content extraction uses string offsets instead of parsing the chat-completion response structure.
- `EventOrchestrator.ModifyEntity()` finds a GameObject and logs that it was modified, but does not apply a meaningful modification.
- `EventOrchestrator.DestroyEntity()` uses `GameObject.Find()` and destroys the named object, without an ownership or authority boundary.
- `EventOrchestrator.Awake()` may create generator components automatically, coupling orchestration to a particular demo scene.

### Architectural gaps

The reviewed code does not establish a general observation/planning/execution pipeline, persistent outcome memory, explicit gameplay objective evaluation, a reusable adapter contract, or a robust multiplayer authority boundary. No demonstrated self-training mechanism was found in the reviewed core scripts.

The terrain/enemy demo should therefore be treated as an earlier prototype, not as a completed metaverse brain.

### Existing documentation cautions

Some old documents recommend killing all Unity processes or deleting a project's Library directory. Do not follow those instructions automatically: they could interrupt unrelated work. No Unity processes were stopped and no files were deleted during this task.

## 5. Implementation routes considered

### A. Extend the existing demo

Reuse its orchestrator and generators, replace placeholder planning, and add memory. Lowest initial change, but retains coupling to one scene and its object conventions.

### B. Reusable world director + game adapter — recommended

Separate the reasoning and memory service from Unity execution. The brain receives structured observations and proposes typed actions. Unity independently validates and applies only actions permitted by the developer.

Advantages: testable backend, explicit authority, reusable contract, optional local or remote language-model provider, easier extension to other games through adapters.

Cost: a separate service must run; each game needs integration code. This is not a standalone Unity-only deployment and is not yet WebGL/mobile-ready.

### C. Train specialist policies in simulation — later phase

Use controlled training environments for concrete skills such as navigation, combat, or scheduling after reliable observation, reward, and evaluation systems exist. A specialist trained policy does not become a universal world controller.

## 6. Proposed architecture — not implemented

```text
Opt-in Unity entities + trusted gameplay events
                    |
                    v
          Structured world snapshot
                    |
                    v
       Local Python brain service
       - goal management
       - SQLite episodic memory
       - deterministic baseline planner
       - optional LLM planner
       - measured outcome / feedback records
                    |
                    v
           Typed proposed action plan
                    |
                    v
        Unity independent safety gate
        - authority check
        - mode / human approval
        - bounds and ownership
        - prefab allowlist
        - action/rate/entity budgets
                    |
                    v
      Game-specific adapter / executor
                    |
                    v
           Results + later outcomes
```

Suggested package namespace: `AliTerra.AICore`, avoiding the legacy `AIMetaverse` namespace.
Suggested package identity: `com.aliterra.aicore`, version `0.1.0`.
Initial target: installed Unity `6000.3.9f1`; do not claim compatibility until compiled and tested.

### Initial useful capability

Maintain an explicit target count of a developer-selected catalog entry, using only approved existing prefabs. Count active matching entities for the objective, but include deactivated owned objects in the resource budget so repeated deactivation cannot bypass the cap.

An optional language-model planner can later propose richer actions using the same validation boundary. A model being unavailable must never cause surprise world mutations.

### Memory and learning

- SQLite stores observations, plans, action results, and explicit gameplay feedback with bounded retention.
- Successfully executing an API call is not proof of a good gameplay outcome.
- Reward is supplied by trusted game logic or human evaluation and associated with executed action IDs.
- A small outcome-based choice policy can be added and tested, but must be described accurately as adaptation, not model self-training.
- Live self-modification and unrestricted code generation are excluded.

## 7. Draft transport contract — not implemented

Loopback endpoint: `POST http://127.0.0.1:8765/v1/tick`
Authentication: bearer pairing token. No secrets have been created or stored yet.
No wildcard bind or browser CORS access by default.

Request sketch:

```json
{
  "world_id": "sandbox",
  "session_id": "runtime-session-id",
  "observation_id": "unique-observation-id",
  "goal": "Maintain a small population using approved catalog entries",
  "target_catalog_id": "approved-prefab-id",
  "target_count": 3,
  "anchor": { "x": 0, "y": 0, "z": 0 },
  "entities": [
    {
      "id": "entity-id",
      "catalog_id": "approved-prefab-id",
      "kind": "npc",
      "position": { "x": 0, "y": 0, "z": 0 },
      "owned": false
    }
  ],
  "catalog": [{ "id": "approved-prefab-id", "kind": "npc" }],
  "results": [],
  "events": [],
  "feedback": [],
  "allow_mutations": false
}
```

Before implementation, add an explicit `active` boolean to each entity snapshot so the planner can distinguish inactive owned objects from the active population. Include current execution bounds, resource budgets, and supported action types in the request as well; the brain should plan within the same constraints that Unity enforces.

Response sketch:

```json
{
  "plan_id": "unique-plan-id",
  "observation_id": "same-observation-id",
  "source": "rules",
  "summary": "Proposed bounded population adjustment",
  "actions": [
    {
      "id": "unique-action-id",
      "type": "spawn",
      "catalog_id": "approved-prefab-id",
      "target_id": "",
      "position": { "x": 0, "y": 0, "z": 0 },
      "reason": "Population below developer-defined target"
    }
  ],
  "warnings": []
}
```

Initial allowed action types: `spawn`, `move`, `deactivate`.
No arbitrary `destroy`, scripts, reflection calls, editor commands, shell commands, or asset downloads.

Proposed limits:
- Maximum 512 entity observations, 128 catalog entries.
- Maximum 32 results/events/feedback entries per tick.
- Maximum 8 actions per plan and a separately enforced execution rate limit.
- Goal length at most 2,000 characters.
- Identifier length at most 96 ASCII characters from `[A-Za-z0-9_.:-]`.
- Explicit body-size limits and finite numeric validation.
- Every retry must reuse the same observation ID and serialized request until acknowledged.
- Exact observation retries return the same plan; action IDs are deduplicated on execution.
- Keep unacknowledged results until a valid server response is accepted.
- Define deduplication retention and restart/session behavior explicitly before claiming reliable delivery.

## 8. Unity safety and integration requirements

1. Default mode is Observe: no mutations.
2. Approval mode queues a bounded plan for explicit human review.
3. Autonomous mode still enforces all permission and resource checks.
4. `hasWorldAuthority` defaults to false and is checked at execution time.
5. In multiplayer, the real server/Fusion/PUN authority system must drive execution. A boolean alone is not a production networking integration.
6. Only developer-approved prefab assets can spawn; reject scene objects as catalog templates.
7. Existing scene entities are observable but not mutable by default.
8. Movement/deactivation applies only to objects created and owned by the same director.
9. Protect nested entity hierarchies; moving a parent must not indirectly move protected descendants.
10. Validate finite positions, allowed bounds, prefab IDs, entity ownership, duplicate IDs, and rate/entity budgets.
11. Revalidate at execution time; observation-time validation is insufficient.
12. Approval plans expire, and changes to authority or mode invalidate pending plans.
13. Emergency Stop aborts requests, cancels pending plans, and blocks future planning/execution until explicit resume.
14. Network failure must not trigger emergency fallback mutation.
15. A plan is not automatically transactional. Record individual action results, and do not claim full rollback for arbitrary prefab behavior.
16. Use typed serializable public-field DTOs with Unity `JsonUtility`, not manual JSON concatenation.
17. Avoid per-frame whole-scene scans. Use opt-in registration and bounded snapshots.
18. Do not collect chat, personal information, or unrelated project files automatically.
19. Collision checks, NavMesh placement, persistence of spawned entities, and network replication need explicit adapters and tests; they are not magically supplied by Instantiate.

## 9. Directories created for the next implementation step

These are currently empty scaffolding, not working components:

```text
E:\AI\AI_folder\unity\AICore\WorldDirector\
  brain\
  tests\
  Packages\
    com.aliterra.aicore\
      Runtime\
      Editor\
  ValidationProject\
    Assets\Editor\
    Packages\
    ProjectSettings\

E:\AI\AI_folder\unity\AICore\outputs\
  AICORE_CHECKPOINT_2026-09-11.md
```

Suggested next files, NOT created yet:

```text
WorldDirector/brain/server.py
WorldDirector/tests/test_brain.py
WorldDirector/Packages/com.aliterra.aicore/package.json
WorldDirector/Packages/com.aliterra.aicore/Runtime/Protocol.cs
WorldDirector/Packages/com.aliterra.aicore/Runtime/WorldEntity.cs
WorldDirector/Packages/com.aliterra.aicore/Runtime/PrefabCatalog.cs
WorldDirector/Packages/com.aliterra.aicore/Runtime/ActionValidation.cs
WorldDirector/Packages/com.aliterra.aicore/Runtime/WorldDirector.cs
WorldDirector/Packages/com.aliterra.aicore/Editor/WorldDirectorInspector.cs
```

## 10. Available tooling and current constraints

Verified directories include Unity versions:
- `2021.3.16f1`
- `6000.0.32f1`
- `6000.3.9f1`
- `6000.5.3f1`

Managed Python:
`C:\Users\USER\.workbuddy-ai\binaries\python\versions\3.13.12\python.exe`

Unity target binary path implied by the installed editor directory:
`C:\Program Files\Unity\Hub\Editor\6000.3.9f1\Editor\Unity.exe`

`dotnet` is installed, but `dotnet --list-sdks` produced no SDK entries. Do not assume an independent .NET SDK is available.

An attempted command mentioning the C# compiler was blocked by the execution environment. Do not work around that block. Use supported Unity validation or request appropriate permission if required.

Two attempts to delegate work failed before producing results. No delegated code should be assumed to exist. Continue directly unless delegation becomes available.

No package installation was performed. No expert was enabled.

## 11. Recommended next execution sequence

1. Finalize the small transport schema and ownership/authority rules, including active state and execution budgets.
2. Implement a dependency-free Python service with SQLite, strict input validation, loopback binding, pairing authentication, idempotent ticks, and a deterministic population-maintenance planner.
3. Write backend tests before optional LLM integration: authentication, malformed payloads, finite numbers, bounds, action caps, request replay, session separation, feedback attribution, persistence, and failure handling.
4. Implement the Unity package against the same DTO schema, with Observe/Approval/Autonomous modes and an emergency stop.
5. Add a custom Inspector that makes pending plans, outcomes, rejected actions, and authority state visible. Do not auto-modify scenes on import.
6. Create an isolated validation project under WorldDirector. Compile and run checks without touching or stopping any existing game project/editor.
7. Test one explicit end-to-end scenario using user-provided prefab assets and a local service. Clearly separate backend tests, Unity compilation, Play Mode checks, and real-game integration results.
8. Only then add an optional LLM provider, without embedding paid-provider credentials in Unity clients.
9. Add measured feedback adaptation and tests; do not label it neural self-training.
10. Produce a concise integration guide, source archive, and validation report in `outputs`, with limitations and next integration requirements stated explicitly.

## 12. Standing work rules for continuation

- Keep new deliverables inside `E:\AI\AI_folder\unity\AICore`.
- Preserve the old package and documents unless a specific change is justified and backed up.
- The parent project asks for progress updates roughly every 60 seconds during substantive work.
- Do not kill unrelated Unity processes or delete project caches as a routine troubleshooting step.
- Do not modify live AliTerra/AIMetaverse projects without confirming the target and preserving changes appropriately.
- Do not report scaffolding as implementation, compile success as gameplay success, memory as training, or an integration framework as universal superintelligence.

Task status at this checkpoint:
- Inspect existing Unity AI work: completed.
- Implement bounded world-director foundation: in progress, but no implementation source written yet.
- Validate and deliver implementation: pending.
