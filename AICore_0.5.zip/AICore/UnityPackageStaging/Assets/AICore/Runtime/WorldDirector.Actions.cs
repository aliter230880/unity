using System;
using System.Collections.Generic;
using UnityEngine;

namespace AliTerra.AICore
{
    public sealed partial class WorldDirector
    {
        public int OwnedEntityCount
        {
            get
            {
                ownedRoots.RemoveWhere(root => root == null);
                return ownedRoots.Count; // Inactive roots and roots whose marker was removed still consume the cap.
            }
        }

        public bool ApprovePending()
        {
            if (!Application.isPlaying || executing) return false;
            RefreshControls();
            if (pending == null) return false;
            PendingPlan plan = pending;
            pending = null;
            if (mode != DirectorMode.Approval || Now >= plan.ExpiresAt ||
                !ValidatePlan(plan.Response, plan.Observation, out _))
            {
                RejectActions(plan.Response.actions, "Approval is stale or the complete plan no longer validates.");
                status = "Approval rejected; no actions executed.";
                return false;
            }
            ExecutePlan(plan.Response, plan.Observation, plan.ExpiresAt);
            nextThinkAt = Now + SafeInterval();
            return true;
        }

        public bool RejectPending()
        {
            if (!Application.isPlaying || pending == null || executing) return false;
            CancelPending("Rejected by user.");
            status = "Plan rejected; no actions executed.";
            nextThinkAt = Now + SafeInterval();
            return true;
        }

        private double SafeInterval()
        {
            return ActionValidation.IsFinite(intervalSeconds) ? Math.Max(0.1, intervalSeconds) : 5.0;
        }

        private void CancelPending(string message)
        {
            if (pending == null) return;
            PendingPlan plan = pending;
            pending = null;
            RejectActions(plan.Response.actions, message);
        }

        private bool CanExecute(ObservationEnvelope observation, out string error)
        {
            if (!Application.isPlaying || !isActiveAndEnabled || emergencyStopped || !hasWorldAuthority ||
                (mode != DirectorMode.Approval && mode != DirectorMode.Autonomous))
            {
                error = "Execution requires Play Mode, an enabled director, mutation mode and explicit world authority.";
                return false;
            }
            if (!observation.AllowMutations || observation.Epoch != controlEpoch)
            {
                error = "Observation is stale or did not authorize mutations.";
                return false;
            }
            error = null;
            return true;
        }

        private void PruneRateWindow()
        {
            double cutoff = Now - ActionValidation.RateWindowSeconds;
            while (mutationAttempts.Count > 0 && mutationAttempts.Peek() <= cutoff) mutationAttempts.Dequeue();
        }

        private bool ValidatePlan(TickResponse response, ObservationEnvelope observation, out string error)
        {
            if (!CanExecute(observation, out error) || !ActionValidation.ValidateResponse(response, observation.Id, out error))
                return false;
            if (results.Count > ActionValidation.MaxBuffer - response.actions.Length)
            {
                error = "Insufficient acknowledgement capacity; no actions may execute.";
                return false;
            }
            PruneRateWindow();
            if (!ActionValidation.HasRateCapacity(mutationAttempts.Count, response.actions.Length))
            {
                error = "Plan exceeds the shared eight-actions-per-five-seconds limit.";
                return false;
            }
            int plannedSpawns = 0;
            foreach (WorldAction action in response.actions)
            {
                if (!ValidateLiveAction(action, observation, out error)) return false;
                if (action.type == "spawn") plannedSpawns++;
            }
            if (maxOwnedEntities < 0 || (plannedSpawns > 0 && plannedSpawns > maxOwnedEntities - OwnedEntityCount))
            {
                error = "Whole plan exceeds the owned-root cap (inactive roots also count).";
                return false;
            }
            error = null;
            return true;
        }

        private bool ValidateLiveAction(WorldAction action, ObservationEnvelope observation, out string error)
        {
            if (!CanExecute(observation, out error) || !ActionValidation.ValidateActionShape(action, out error)) return false;
            if (attemptedIds.Contains(action.id) || successfulIds.Contains(action.id))
            {
                error = "Action ID was already attempted; replay is forbidden.";
                return false;
            }
            if (!ActionValidation.ValidateBounds(allowedBounds))
            {
                error = "Allowed bounds are invalid.";
                return false;
            }
            if (action.type == "spawn" || action.type == "move")
                if (!ActionValidation.ValidatePosition(action.position, allowedBounds, out error)) return false;
            if (action.type == "spawn")
            {
                if (OwnedEntityCount >= maxOwnedEntities)
                {
                    error = "Owned-root cap reached; inactive roots also count.";
                    return false;
                }
                return TryResolvePrefab(action.catalog_id, observation, out _, out error);
            }
            if (!observation.Entities.TryGetValue(action.target_id, out WorldEntity target) || target == null ||
                target.Id != action.target_id || !target.gameObject.scene.IsValid() || !target.gameObject.scene.isLoaded ||
                !ownedRoots.Contains(target.gameObject))
            {
                error = "Target is unknown, unloaded, destroyed or not spawned by this director.";
                return false;
            }
            if (!target.ValidateOwnedHierarchy(this, out error)) return false;
            if (!ActionValidation.IsFinite(target.transform.position) || !allowedBounds.Contains(target.transform.position))
            {
                error = "Target is outside the allowed bounds or has a non-finite position.";
                return false;
            }
            if (!string.IsNullOrEmpty(action.catalog_id) &&
                (action.catalog_id != target.catalogId || !observation.Catalog.ContainsKey(action.catalog_id)))
            {
                error = "Action catalog ID does not match the observed target catalog.";
                return false;
            }
            if (action.type == "activate")
            {
                if (!reuseInactiveOwnedEntities || target.gameObject.activeSelf || string.IsNullOrEmpty(action.catalog_id))
                {
                    error = "Reactivation requires permission, an inactive owned root and an approved catalog ID.";
                    return false;
                }
                if (!TryResolvePrefab(action.catalog_id, observation, out _, out error)) return false;
            }
            if (action.type == "deactivate" && !target.gameObject.activeSelf)
            {
                error = "Target is already inactive.";
                return false;
            }
            error = null;
            return true;
        }

        private bool TryResolvePrefab(string catalogId, ObservationEnvelope observation, out GameObject prefab, out string error)
        {
            prefab = null;
            if (!observation.Catalog.TryGetValue(catalogId, out PrefabCatalog.Entry advertised) || catalog == null)
            {
                error = "Spawn references an unadvertised catalog ID.";
                return false;
            }
            if (!catalog.TrySnapshot(out PrefabCatalog.Entry[] current, out error)) return false;
            foreach (PrefabCatalog.Entry entry in current)
            {
                if (entry.id != catalogId) continue;
                if (entry.prefab != advertised.prefab || entry.kind != advertised.kind)
                {
                    error = "Catalog entry changed after observation.";
                    return false;
                }
                prefab = entry.prefab;
                error = null;
                return true;
            }
            error = "Catalog entry was removed after observation.";
            return false;
        }

        private void ExecutePlan(TickResponse response, ObservationEnvelope observation, double approvalDeadline = double.PositiveInfinity)
        {
            RefreshControls();
            if (executing || Now >= approvalDeadline || !ValidatePlan(response, observation, out _))
            {
                RejectActions(response.actions, "Plan cannot execute; state changed or validation failed.");
                status = "Plan rejected before execution.";
                return;
            }
            executing = true;
            int successCount = 0;
            try
            {
                // Explicitly non-atomic: earlier actions are NOT rolled back if a later one fails.
                // These are ordinary approved-prefab runtime actions, not content/mesh generation.
                // Collision, navigation and multiplayer replication are deliberately not implemented.
                foreach (WorldAction action in response.actions)
                {
                    RefreshControls();
                    PruneRateWindow();
                    if (Now >= approvalDeadline)
                    {
                        AddResult(action.id, "rejected", "Approval expired before this action could execute.");
                        continue;
                    }
                    if (!ValidateLiveAction(action, observation, out string error))
                    {
                        AddResult(action.id, "rejected", error);
                        continue;
                    }
                    if (!ActionValidation.HasRateCapacity(mutationAttempts.Count, 1))
                    {
                        AddResult(action.id, "rejected", "Mutation rate limit reached.");
                        continue;
                    }
                    // Failed calls can have side effects too: consume both their rate slot and replay ID.
                    mutationAttempts.Enqueue(Now);
                    RememberAttempt(action.id);
                    try
                    {
                        string message;
                        if (action.type == "spawn")
                            message = Spawn(action, observation);
                        else
                        {
                            WorldEntity entity = observation.Entities[action.target_id];
                            if (action.type == "move") entity.transform.position = action.position.ToVector3();
                            else entity.gameObject.SetActive(action.type == "activate");
                            // Trusted OnEnable/OnDisable callbacks can change or destroy the root.
                            if (entity == null || !entity.ValidateOwnedHierarchy(this, out _) ||
                                !ActionValidation.IsFinite(entity.transform.position) || !allowedBounds.Contains(entity.transform.position) ||
                                (action.type == "activate" && !entity.gameObject.activeInHierarchy) ||
                                (action.type == "deactivate" && entity.gameObject.activeSelf))
                                throw new InvalidOperationException("Trusted callback invalidated the action postcondition.");
                            message = action.type == "move" ? "Owned root moved." :
                                action.type == "activate" ? "Reactivated existing owned root; no additional capacity used." :
                                "Owned root deactivated; still counts toward cap.";
                        }
                        AddResult(action.id, "executed", message);
                        RememberSuccess(action.id);
                        LastSuccessfulActionId = action.id;
                        successCount++;
                        if (ActionExecuted != null)
                            foreach (Action<string> subscriber in ActionExecuted.GetInvocationList())
                                try { subscriber(action.id); }
                                catch (Exception) { Debug.LogWarning("AICore: gameplay outcome listener failed; action remains recorded as executed."); }
                    }
                    catch (Exception)
                    {
                        AddResult(action.id, "failed", "Runtime action failed; trusted prefab callbacks may have run. No rollback attempted.");
                    }
                }
                status = emergencyStopped ? "Emergency stopped; remaining plan actions rejected." :
                    "Plan completed non-atomically: " + successCount + "/" + response.actions.Length + " executed.";
            }
            finally { executing = false; }
        }

        private string Spawn(WorldAction action, ObservationEnvelope observation)
        {
            if (!TryResolvePrefab(action.catalog_id, observation, out GameObject prefab, out string error))
                throw new InvalidOperationException(error);
            // Instantiate may run arbitrary TRUSTED user prefab Awake/OnEnable code. It is not a sandbox.
            // Ownership covers the resulting prefab hierarchy, not future objects reparented beneath it.
            GameObject root = Instantiate(prefab, action.position.ToVector3(), prefab.transform.rotation);
            if (root == null) throw new InvalidOperationException("Prefab did not leave a live root.");
            ownedRoots.Add(root); // Retain the cap reservation even if a trusted callback removed its marker.
            WorldEntity entity = root.GetComponent<WorldEntity>();
            if (entity == null) throw new InvalidOperationException("Spawned prefab lost its root WorldEntity.");
            entity.AssignSpawnOwnership(this);
            entity.catalogId = action.catalog_id;
            entity.kind = observation.Catalog[action.catalog_id].kind;
            if (!entity.ValidateOwnedHierarchy(this, out error)) throw new InvalidOperationException(error);
            if (!ActionValidation.IsFinite(root.transform.position) || !allowedBounds.Contains(root.transform.position))
                throw new InvalidOperationException("Trusted prefab callback changed the spawn position outside allowed bounds.");
            return "Spawned owned root " + entity.Id + ".";
        }

        private void RejectActions(WorldAction[] actions, string message)
        {
            foreach (WorldAction action in actions) AddResult(action.id, "rejected", message);
        }

        private void AddResult(string actionId, string resultStatus, string message)
        {
            // Capacity is reserved for the complete plan before approval/execution; never drop acknowledgements.
            if (results.Count >= ActionValidation.MaxBuffer)
                throw new InvalidOperationException("Action result capacity invariant violated.");
            results.Add(new ActionResultDto { action_id = actionId, status = resultStatus, message = message });
        }

        private void RememberAttempt(string id)
        {
            attemptedIds.Add(id);
            attemptedOrder.Enqueue(id);
            while (attemptedOrder.Count > ActionValidation.MaxHistory) attemptedIds.Remove(attemptedOrder.Dequeue());
        }

        private void RememberSuccess(string id)
        {
            successfulIds.Add(id);
            successfulOrder.Enqueue(id);
            while (successfulOrder.Count > ActionValidation.MaxHistory)
            {
                string oldest = successfulOrder.Dequeue();
                successfulIds.Remove(oldest);
                ratedIds.Remove(oldest);
            }
        }
    }
}
