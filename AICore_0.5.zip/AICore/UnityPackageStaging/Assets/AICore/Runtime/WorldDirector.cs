using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.Networking;

namespace AliTerra.AICore
{
    [DisallowMultipleComponent]
    [AddComponentMenu("AICore/World Director")]
    public sealed partial class WorldDirector : MonoBehaviour
    {
        public string worldId = "world";
        [Tooltip("Local brain bearer token. Never place cloud credentials here.")]
        public string token = "";
        public string endpoint = "http://127.0.0.1:8765/v2/tick";
        [Range(1, 2)] public int protocolVersion = 2;
        [TextArea(3, 8)] public string goal = "Observe the opted-in world.";
        public string goalId = "population.primary";
        [Range(1, 100)] public int goalPriority = 50;
        public string targetCatalogId = "";
        [Range(0, 100)] public int targetCount;
        [Tooltip("Reuse eligible inactive roots owned by this director before spawning replacements.")]
        public bool reuseInactiveOwnedEntities = true;
        public Transform anchor;
        public PrefabCatalog catalog;
        [SerializeField, InspectorName("Mode")] private DirectorMode configuredMode = DirectorMode.Observe;
        [SerializeField, InspectorName("Has World Authority")]
        [Tooltip("Set explicitly ONLY on the single-player or authoritative server instance. No network authority is inferred.")]
        private bool configuredAuthority;

        // Property setters invalidate immediately, even if gameplay toggles away and back in one frame.
        public DirectorMode mode
        {
            get { return configuredMode; }
            set { configuredMode = value; if (Application.isPlaying) RefreshControls(); }
        }
        public bool hasWorldAuthority
        {
            get { return configuredAuthority; }
            set { configuredAuthority = value; if (Application.isPlaying) RefreshControls(); }
        }
        [Min(0)] public int maxOwnedEntities = 100;
        public Bounds allowedBounds = new Bounds(Vector3.zero, new Vector3(200, 100, 200));
        [Min(0.1f)] public float intervalSeconds = 5f;
        [Range(1, 60)] public int requestTimeoutSeconds = 10;
        [Range(1, 30)] public float approvalTtlSeconds = 30f;

        private readonly List<ActionResultDto> results = new List<ActionResultDto>();
        private readonly List<WorldEventDto> events = new List<WorldEventDto>();
        private readonly List<ActionFeedbackDto> feedback = new List<ActionFeedbackDto>();
        private readonly List<KnowledgeFactDto> knowledgeUpdates = new List<KnowledgeFactDto>();
        private readonly List<RelationDto> relationUpdates = new List<RelationDto>();
        private readonly HashSet<GameObject> ownedRoots = new HashSet<GameObject>();
        private readonly HashSet<string> attemptedIds = new HashSet<string>(StringComparer.Ordinal);
        private readonly Queue<string> attemptedOrder = new Queue<string>();
        private readonly HashSet<string> successfulIds = new HashSet<string>(StringComparer.Ordinal);
        private readonly Queue<string> successfulOrder = new Queue<string>();
        private readonly HashSet<string> ratedIds = new HashSet<string>(StringComparer.Ordinal);
        private readonly Queue<double> mutationAttempts = new Queue<double>();

        private sealed class ObservationEnvelope
        {
            internal string Body;
            internal string Id;
            internal int ResultCount;
            internal int EventCount;
            internal int FeedbackCount;
            internal int KnowledgeCount;
            internal int RelationCount;
            internal long Epoch;
            internal bool AllowMutations;
            internal readonly Dictionary<string, PrefabCatalog.Entry> Catalog = new Dictionary<string, PrefabCatalog.Entry>(StringComparer.Ordinal);
            internal readonly Dictionary<string, WorldEntity> Entities = new Dictionary<string, WorldEntity>(StringComparer.Ordinal);
        }

        private sealed class PendingPlan
        {
            internal TickResponse Response;
            internal ObservationEnvelope Observation;
            internal double ExpiresAt;
        }

        private Coroutine loop;
        private UnityWebRequest activeRequest;
        private ObservationEnvelope inFlight;
        private PendingPlan pending;
        private string sessionId;
        private int playGeneration = -1;
        private long controlEpoch;
        private DirectorMode previousMode;
        private bool previousAuthority;
        private string previousWorldId;
        private string previousGoal;
        private string previousTarget;
        private int previousCount;
        private int previousCap;
        private bool previousReuse;
        private int previousProtocolVersion;
        private string previousGoalId;
        private int previousGoalPriority;
        private Bounds previousBounds;
        private PrefabCatalog previousCatalog;

        private bool PolicyChanged()
        {
            bool changed = previousWorldId != worldId || previousGoal != goal || previousTarget != targetCatalogId ||
                previousCount != targetCount || previousCap != maxOwnedEntities || previousReuse != reuseInactiveOwnedEntities ||
                previousBounds != allowedBounds || previousCatalog != catalog ||
                previousProtocolVersion != protocolVersion || previousGoalId != goalId ||
                previousGoalPriority != goalPriority;
            previousWorldId = worldId; previousGoal = goal; previousTarget = targetCatalogId;
            previousCount = targetCount; previousCap = maxOwnedEntities; previousReuse = reuseInactiveOwnedEntities;
            previousBounds = allowedBounds; previousCatalog = catalog;
            previousProtocolVersion = protocolVersion; previousGoalId = goalId; previousGoalPriority = goalPriority;
            return changed;
        }
        private bool emergencyStopped;
        private bool executing;
        private double nextThinkAt;
        private string status = "Observe mode; not running.";

        private static double Now { get { return Time.realtimeSinceStartupAsDouble; } }
        public string Status { get { return status; } }
        public string SessionId { get { return sessionId; } }
        public bool IsEmergencyStopped { get { return emergencyStopped; } }
        public bool IsRequestActive { get { return activeRequest != null; } }
        public bool HasPendingPlan { get { return pending != null; } }
        public double PendingSecondsRemaining { get { return pending == null ? 0 : Math.Max(0, pending.ExpiresAt - Now); } }
        public string PendingSummary { get { return pending == null ? "" : pending.Response.summary; } }
        public int BufferedResultCount { get { return results.Count; } }
        public string LastSuccessfulActionId { get; private set; }
        /// <summary>Main-thread notification after success is recorded; gameplay can call RateAction here or later.</summary>
        public event Action<string> ActionExecuted;

        // Return a defensive copy: an inspector or gameplay caller cannot edit an approved plan in place.
        public WorldAction[] GetPendingActions()
        {
            if (pending == null) return Array.Empty<WorldAction>();
            return JsonUtility.FromJson<TickResponse>(JsonUtility.ToJson(pending.Response)).actions;
        }

        private void OnEnable()
        {
            if (!Application.isPlaying) return;
            InitializeSession();
            RefreshControls();
            StartLoop();
        }

        private void InitializeSession()
        {
            if (playGeneration == WorldEntity.Generation) return;
            AbortLoop();
            playGeneration = WorldEntity.Generation;
            sessionId = Guid.NewGuid().ToString("N");
            results.Clear(); events.Clear(); feedback.Clear(); knowledgeUpdates.Clear(); relationUpdates.Clear(); ownedRoots.Clear();
            attemptedIds.Clear(); attemptedOrder.Clear(); successfulIds.Clear(); successfulOrder.Clear();
            ratedIds.Clear(); mutationAttempts.Clear();
            inFlight = null; pending = null; executing = false; emergencyStopped = false;
            controlEpoch++;
            previousMode = mode;
            previousAuthority = hasWorldAuthority;
            nextThinkAt = 0;
            status = "Ready; waiting to observe.";
        }

        private void OnDisable()
        {
            if (playGeneration < 0) return;
            controlEpoch++;
            CancelPending("Director disabled.");
            AbortLoop();
            status = emergencyStopped ? "Emergency stopped." : "Disabled; any HTTP retry retains its original observation.";
        }

        private void Update()
        {
            if (Application.isPlaying) RefreshControls();
        }

        private void RefreshControls()
        {
            bool policyChanged = PolicyChanged();
            if (previousMode != mode || previousAuthority != hasWorldAuthority || policyChanged)
            {
                previousMode = mode;
                previousAuthority = hasWorldAuthority;
                controlEpoch++;
                CancelPending("Mode, authority or population policy changed.");
                status = "Controls changed; stale plans cannot execute.";
            }
            if (pending != null && Now >= pending.ExpiresAt)
            {
                CancelPending("Approval expired.");
                status = "Approval expired; no actions executed.";
            }
        }

        public void SetMode(DirectorMode value) { mode = value; RefreshControls(); }
        public void SetWorldAuthority(bool value) { hasWorldAuthority = value; RefreshControls(); }

        public bool Think()
        {
            if (!Application.isPlaying || !isActiveAndEnabled || emergencyStopped || executing) return false;
            RefreshControls();
            if (pending != null || activeRequest != null) return false;
            nextThinkAt = 0;
            StartLoop();
            return true;
        }

        public void EmergencyStop()
        {
            if (!Application.isPlaying) return;
            emergencyStopped = true;
            controlEpoch++;
            CancelPending("Emergency stop.");
            AbortLoop();
            status = "Emergency stopped. Explicit Resume is required.";
        }

        public void Resume()
        {
            if (!Application.isPlaying || !emergencyStopped) return;
            emergencyStopped = false;
            controlEpoch++;
            nextThinkAt = 0;
            status = "Resumed; any interrupted observation will be retried without executing its stale plan.";
            if (isActiveAndEnabled) StartLoop();
        }

        /// <summary>Trusted gameplay API; call on Unity's main thread. No automatic health, chat or PII capture.</summary>
        public bool PublishEvent(string kind, float value)
        {
            if (!Application.isPlaying || !isActiveAndEnabled || emergencyStopped ||
                !ActionValidation.IsValidId(kind) || !ActionValidation.IsFinite(value) || events.Count >= ActionValidation.MaxBuffer)
                return false;
            events.Add(new WorldEventDto { kind = kind, value = value });
            return true;
        }

        /// <summary>One rating per recent successful action, bounded and main-thread only.</summary>
        public bool RateAction(string actionId, float reward)
        {
            if (!Application.isPlaying || !isActiveAndEnabled || emergencyStopped ||
                !ActionValidation.IsValidId(actionId) || !ActionValidation.IsFinite(reward) ||
                !successfulIds.Contains(actionId) || ratedIds.Contains(actionId) || feedback.Count >= ActionValidation.MaxBuffer)
                return false;
            ratedIds.Add(actionId);
            feedback.Add(new ActionFeedbackDto { action_id = actionId, reward = reward });
            return true;
        }

        /// <summary>Queues an explicit bounded world fact for protocol v2. No automatic player-data scraping.</summary>
        public bool PublishKnowledge(string key, string value, string category = "custom", float confidence = 0.5f)
        {
            if (!Application.isPlaying || !isActiveAndEnabled || emergencyStopped || protocolVersion != 2 ||
                string.IsNullOrEmpty(key) || key.Length > 256 || value == null || value.Length > 2000 ||
                !ActionValidation.IsKnowledgeCategory(category) || !ActionValidation.IsUnitInterval(confidence) ||
                knowledgeUpdates.Count >= 100) return false;
            knowledgeUpdates.Add(new KnowledgeFactDto
                { key = key, value = value, category = category, confidence = confidence });
            return true;
        }

        /// <summary>Queues a bounded relationship between opted-in entity IDs for protocol v2.</summary>
        public bool PublishRelation(string sourceId, string targetId, string type, float strength = 0.5f)
        {
            if (!Application.isPlaying || !isActiveAndEnabled || emergencyStopped || protocolVersion != 2 ||
                !ActionValidation.IsValidId(sourceId) || !ActionValidation.IsValidId(targetId) ||
                string.IsNullOrEmpty(type) || type.Length > 64 || !ActionValidation.IsUnitInterval(strength) ||
                relationUpdates.Count >= 50) return false;
            relationUpdates.Add(new RelationDto
                { source_id = sourceId, target_id = targetId, type = type, strength = strength });
            return true;
        }

        private void StartLoop()
        {
            if (loop == null && !emergencyStopped && isActiveAndEnabled) loop = StartCoroutine(PlanningLoop());
        }

        private void AbortLoop()
        {
            // The immutable envelope and its acknowledgement prefix survive abort/disable/resume.
            if (activeRequest != null) activeRequest.Abort();
            if (loop != null) StopCoroutine(loop);
            loop = null;
            if (activeRequest != null) activeRequest.Dispose();
            activeRequest = null;
        }

        private IEnumerator PlanningLoop()
        {
            yield return null;
            while (isActiveAndEnabled && !emergencyStopped)
            {
                RefreshControls();
                if (pending != null || executing || Now < nextThinkAt) { yield return null; continue; }
                double interval = ActionValidation.IsFinite(intervalSeconds) ? Math.Max(0.1, intervalSeconds) : 5.0;
                nextThinkAt = Now + interval;
                if (inFlight == null)
                {
                    if (!TryBuildObservation(out ObservationEnvelope envelope, out string buildError))
                    {
                        status = buildError;
                        yield return null;
                        continue;
                    }
                    inFlight = envelope;
                }
                if (!TryCreateRequest(out UnityWebRequest request, out LimitedDownloadHandler download, out string requestError))
                {
                    status = requestError;
                    yield return null;
                    continue;
                }
                activeRequest = request;
                UnityWebRequestAsyncOperation operation = null;
                try { operation = request.SendWebRequest(); }
                catch (Exception) { status = "HTTP request could not start; retaining the exact observation for retry."; }
                if (operation != null)
                {
                    status = "Waiting for local brain.";
                    double deadline = Now + Mathf.Clamp(requestTimeoutSeconds, 1, 60);
                    while (!operation.isDone && Now < deadline) yield return null;
                    if (!operation.isDone)
                    {
                        request.Abort();
                        status = "Request timed out; retaining the exact observation for retry.";
                    }
                    else if (request.result != UnityWebRequest.Result.Success)
                        status = download.TooLarge ? "Response exceeded the byte limit; observation retained." :
                            "HTTP failed (" + request.responseCode + "); retaining the exact observation for retry.";
                    else
                        ProcessResponse(download);
                }
                if (activeRequest == request)
                {
                    activeRequest = null;
                    request.Dispose();
                }
                nextThinkAt = Now + interval;
                yield return null;
            }
            loop = null;
        }

        private bool TryCreateRequest(out UnityWebRequest request, out LimitedDownloadHandler download, out string error)
        {
            request = null;
            download = null;
            if (!Uri.TryCreate(endpoint, UriKind.Absolute, out Uri uri) || !uri.IsLoopback ||
                (uri.Scheme != "http" && uri.Scheme != "https") || !string.IsNullOrEmpty(uri.UserInfo) ||
                !string.IsNullOrEmpty(uri.Fragment))
            {
                error = "Endpoint must be an absolute loopback HTTP(S) URL without user information or a fragment.";
                return false;
            }
            if (string.IsNullOrWhiteSpace(token) || token.Length > 4096)
            {
                error = "Set the local brain bearer token in the Inspector.";
                return false;
            }
            foreach (char character in token)
            {
                if (character <= 32 || character >= 127)
                {
                    error = "Bearer token must contain printable ASCII without whitespace.";
                    return false;
                }
            }
            try
            {
                download = new LimitedDownloadHandler();
                request = new UnityWebRequest(uri.AbsoluteUri, "POST");
                request.downloadHandler = download;
                request.uploadHandler = new UploadHandlerRaw(Encoding.UTF8.GetBytes(inFlight.Body));
                request.SetRequestHeader("Content-Type", "application/json");
                request.SetRequestHeader("Accept", "application/json");
                request.SetRequestHeader("Authorization", "Bearer " + token);
                request.timeout = Mathf.Clamp(requestTimeoutSeconds, 1, 60);
                request.redirectLimit = 0; // Never forward the local bearer token via redirects.
                error = null;
                return true;
            }
            catch (Exception)
            {
                if (request != null) request.Dispose();
                else if (download != null) download.Dispose();
                request = null;
                error = "Could not construct the local request; observation retained.";
                return false;
            }
        }

        private bool TryBuildObservation(out ObservationEnvelope envelope, out string error)
        {
            envelope = null;
            if (!ActionValidation.IsValidId(worldId) || (protocolVersion != 1 && protocolVersion != 2) ||
                goal == null || goal.Length > ActionValidation.MaxGoalLength ||
                targetCount < 0 || targetCount > 100 || maxOwnedEntities < 0 || !ActionValidation.ValidateBounds(allowedBounds) ||
                (mode != DirectorMode.Observe && mode != DirectorMode.Approval && mode != DirectorMode.Autonomous))
            {
                error = "Invalid world ID, goal, target count, mode, ownership cap or bounds.";
                return false;
            }
            if (protocolVersion == 2 && (!ActionValidation.IsValidId(goalId) || goalPriority < 1 || goalPriority > 100))
            {
                error = "Protocol v2 requires a valid goal ID and priority.";
                return false;
            }
            Vector3 origin = anchor == null ? transform.position : anchor.position;
            if (!ActionValidation.IsFinite(origin)) { error = "Anchor must be finite."; return false; }
            PrefabCatalog.Entry[] entries = Array.Empty<PrefabCatalog.Entry>();
            if (catalog != null && !catalog.TrySnapshot(out entries, out error)) return false;
            var observation = new ObservationEnvelope();
            var catalogDtos = new CatalogDto[entries.Length];
            for (int i = 0; i < entries.Length; i++)
            {
                observation.Catalog.Add(entries[i].id, entries[i]);
                catalogDtos[i] = new CatalogDto { id = entries[i].id, kind = entries[i].kind };
            }
            if ((!string.IsNullOrEmpty(targetCatalogId) &&
                 (!ActionValidation.IsValidId(targetCatalogId) || !observation.Catalog.ContainsKey(targetCatalogId))) ||
                (targetCount > 0 && string.IsNullOrEmpty(targetCatalogId)))
            {
                error = "Target catalog ID must identify an approved catalog entry when a target is requested.";
                return false;
            }
            WorldEntity[] snapshot = WorldEntity.Snapshot();
            Array.Sort(snapshot, (left, right) =>
            {
                int ownership = right.IsOwnedBy(this).CompareTo(left.IsOwnedBy(this));
                return ownership != 0 ? ownership : string.CompareOrdinal(left.Id, right.Id);
            });
            var observed = new List<EntityDto>();
            bool incomplete = false;
            int observedOwned = 0;
            foreach (WorldEntity entity in snapshot)
            {
                if (entity == null || !entity.gameObject.scene.isLoaded) continue;
                if (!ActionValidation.IsValidId(entity.Id) || !ActionValidation.IsValidId(entity.catalogId) ||
                    !ActionValidation.IsValidId(entity.kind) || !ActionValidation.IsFinite(entity.transform.position))
                {
                    incomplete = true; // Do not silently infer population from filtered-out entities.
                    continue;
                }
                if (observed.Count >= ActionValidation.MaxEntities) { incomplete = true; break; }
                bool owned = entity.IsOwnedBy(this);
                if (owned) observedOwned++;
                observation.Entities.Add(entity.Id, entity);
                observed.Add(new EntityDto
                {
                    id = entity.Id, catalog_id = entity.catalogId, kind = entity.kind,
                    position = new PositionDto(entity.transform.position), owned = owned,
                    active = entity.gameObject.activeInHierarchy,
                    reactivatable = owned && !entity.gameObject.activeSelf &&
                        entity.ValidateOwnedHierarchy(this, out _) && allowedBounds.Contains(entity.transform.position)
                });
            }
            int ownedCount = OwnedEntityCount;
            incomplete |= observedOwned != ownedCount; // Lost markers still reserve capacity.
            PruneRateWindow();
            observation.Id = Guid.NewGuid().ToString("N");
            observation.Epoch = controlEpoch;
            observation.AllowMutations = hasWorldAuthority && mode != DirectorMode.Observe && !emergencyStopped && !incomplete;
            observation.ResultCount = results.Count;
            observation.EventCount = events.Count;
            observation.FeedbackCount = feedback.Count;
            observation.KnowledgeCount = knowledgeUpdates.Count;
            observation.RelationCount = relationUpdates.Count;
            GoalDto[] goals = protocolVersion == 2 && !string.IsNullOrEmpty(targetCatalogId)
                ? new[] { new GoalDto { goal_id = goalId, catalog_id = targetCatalogId, target_count = targetCount,
                    priority = goalPriority, status = "active", description = goal } }
                : Array.Empty<GoalDto>();
            observation.Body = JsonUtility.ToJson(new TickRequest
            {
                protocol_version = protocolVersion,
                world_id = worldId, session_id = sessionId, observation_id = observation.Id,
                goal = goal, target_catalog_id = targetCatalogId ?? "", target_count = targetCount,
                anchor = new PositionDto(origin), entities = observed.ToArray(), catalog = catalogDtos,
                results = results.ToArray(), events = events.ToArray(), feedback = feedback.ToArray(),
                allow_mutations = observation.AllowMutations,
                allow_reactivation = reuseInactiveOwnedEntities,
                entities_truncated = incomplete,
                goals = goals,
                knowledge_updates = protocolVersion == 2 ? knowledgeUpdates.ToArray() : Array.Empty<KnowledgeFactDto>(),
                relations = protocolVersion == 2 ? relationUpdates.ToArray() : Array.Empty<RelationDto>(),
                capabilities = new CapabilitiesDto
                    { action_types = new[] { "spawn", "move", "activate", "deactivate" } },
                limits = new LimitsDto
                {
                    min = new PositionDto(allowedBounds.min), max = new PositionDto(allowedBounds.max),
                    max_owned_entities = maxOwnedEntities, owned_entity_count = ownedCount,
                    action_budget = Math.Max(0, Math.Min(ActionValidation.MaxActions - mutationAttempts.Count,
                        ActionValidation.MaxBuffer - results.Count))
                }
            });
            envelope = observation;
            error = null;
            return true;
        }

        private void ProcessResponse(LimitedDownloadHandler download)
        {
            if (!download.TryGetText(out string json)) { status = "Invalid UTF-8 or oversized response; observation retained."; return; }
            TickResponse response;
            try { response = JsonUtility.FromJson<TickResponse>(json); }
            catch (Exception) { status = "Invalid JSON response; observation retained."; return; }
            if (!ActionValidation.ValidateResponse(response, inFlight.Id, out string error))
            {
                status = error + " Original observation retained for retry.";
                return;
            }
            ObservationEnvelope observation = inFlight;
            // Only a valid matching response acknowledges the exact prefixes serialized in this envelope.
            results.RemoveRange(0, observation.ResultCount);
            events.RemoveRange(0, observation.EventCount);
            feedback.RemoveRange(0, observation.FeedbackCount);
            knowledgeUpdates.RemoveRange(0, observation.KnowledgeCount);
            relationUpdates.RemoveRange(0, observation.RelationCount);
            inFlight = null;
            RefreshControls();
            if (response.actions.Length == 0) { status = "Observation acknowledged; no actions proposed."; return; }
            if (!ValidatePlan(response, observation, out error))
            {
                RejectActions(response.actions, error);
                status = "Plan rejected: " + error;
                return;
            }
            if (mode == DirectorMode.Approval)
            {
                double ttl = ActionValidation.IsFinite(approvalTtlSeconds) ? Math.Max(1, Math.Min(30, approvalTtlSeconds)) : 30;
                pending = new PendingPlan { Response = response, Observation = observation, ExpiresAt = Now + ttl };
                status = "Plan awaiting approval; planning paused.";
            }
            else
                ExecutePlan(response, observation);
        }

        private sealed class LimitedDownloadHandler : DownloadHandlerScript
        {
            private readonly byte[] bytes = new byte[ActionValidation.MaxResponseBytes];
            private int count;
            internal bool TooLarge { get; private set; }
            internal LimitedDownloadHandler() : base(new byte[8192]) { }
            protected override void ReceiveContentLengthHeader(ulong contentLength)
            {
                if (contentLength > ActionValidation.MaxResponseBytes) TooLarge = true;
            }
            protected override bool ReceiveData(byte[] data, int dataLength)
            {
                if (TooLarge || dataLength < 0 || dataLength > bytes.Length - count)
                {
                    TooLarge = true;
                    return false;
                }
                if (dataLength == 0) return true;
                if (data == null || dataLength > data.Length) return false;
                Buffer.BlockCopy(data, 0, bytes, count, dataLength);
                count += dataLength;
                return true;
            }
            internal bool TryGetText(out string text)
            {
                text = null;
                if (TooLarge || count == 0) return false;
                try { text = new UTF8Encoding(false, true).GetString(bytes, 0, count); return true; }
                catch (DecoderFallbackException) { return false; }
            }
        }
    }
}
