using System;
using System.Collections.Generic;
using UnityEngine;

namespace AliTerra.AICore
{
    [CreateAssetMenu(menuName = "AICore/Prefab Catalog", fileName = "PrefabCatalog")]
    public sealed class PrefabCatalog : ScriptableObject
    {
        [Serializable]
        public sealed class Entry
        {
            public string id;
            public string kind = "prop";
            [Tooltip("Approved user-owned prefab asset, never a scene object. Root must have exactly one WorldEntity.")]
            public GameObject prefab;
        }

        public Entry[] entries = Array.Empty<Entry>();

        public static bool ValidateEntry(Entry entry, out string error)
        {
            if (entry == null || !ActionValidation.IsValidId(entry.id) || !ActionValidation.IsValidId(entry.kind))
            {
                error = "Catalog entry has an invalid ID or kind.";
                return false;
            }
            if (entry.prefab == null || entry.prefab.scene.IsValid() || entry.prefab.transform.parent != null)
            {
                error = "Catalog templates must be prefab asset roots, not scene objects or prefab children.";
                return false;
            }
            if (!entry.prefab.activeSelf)
            {
                error = "Catalog prefab roots must be active.";
                return false;
            }
            WorldEntity root = entry.prefab.GetComponent<WorldEntity>();
            WorldEntity[] markers = entry.prefab.GetComponentsInChildren<WorldEntity>(true);
            if (root == null || markers.Length != 1 || markers[0] != root)
            {
                error = "Prefab requires one root WorldEntity and no nested WorldEntity.";
                return false;
            }
            if (string.Equals(entry.kind, "player", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(root.kind, "player", StringComparison.OrdinalIgnoreCase))
            {
                error = "Player prefabs are not eligible for director mutations.";
                return false;
            }
            foreach (Transform child in entry.prefab.GetComponentsInChildren<Transform>(true))
            {
                if (child.CompareTag("Player"))
                {
                    error = "Prefabs containing Player-tagged objects are protected.";
                    return false;
                }
            }
            error = null;
            return true;
        }

        public bool TrySnapshot(out Entry[] snapshot, out string error)
        {
            snapshot = null;
            if (entries == null || entries.Length > ActionValidation.MaxCatalog)
            {
                error = "Catalog is missing or exceeds 128 entries.";
                return false;
            }
            var ids = new HashSet<string>(StringComparer.Ordinal);
            var copy = new Entry[entries.Length];
            for (int i = 0; i < entries.Length; i++)
            {
                Entry entry = entries[i];
                if (!ValidateEntry(entry, out error)) return false;
                if (!ids.Add(entry.id))
                {
                    error = "Catalog IDs must be unique.";
                    return false;
                }
                copy[i] = new Entry { id = entry.id, kind = entry.kind, prefab = entry.prefab };
            }
            snapshot = copy;
            error = null;
            return true;
        }
    }
}
