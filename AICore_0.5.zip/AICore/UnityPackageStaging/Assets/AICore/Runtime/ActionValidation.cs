using System;
using System.Collections.Generic;
using UnityEngine;

namespace AliTerra.AICore
{
    /// <summary>Pure validation helpers; these methods never mutate a scene.</summary>
    public static class ActionValidation
    {
        public const int MaxIdLength = 96;
        public const int MaxGoalLength = 2000;
        public const int MaxEntities = 512;
        public const int MaxCatalog = 128;
        public const int MaxBuffer = 32;
        public const int MaxActions = 8;
        public const int MaxResponseBytes = 65536;
        public const int MaxHistory = 2048;
        public const double RateWindowSeconds = 5.0;
        public const double MaxApprovalSeconds = 30.0;

        public static bool IsValidId(string value)
        {
            if (string.IsNullOrEmpty(value) || value.Length > MaxIdLength) return false;
            foreach (char c in value)
            {
                if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
                      (c >= '0' && c <= '9') || c == '_' || c == '.' || c == ':' || c == '-'))
                    return false;
            }
            return true;
        }

        public static bool IsFinite(float value) { return !float.IsNaN(value) && !float.IsInfinity(value); }
        public static bool IsFinite(Vector3 value) { return IsFinite(value.x) && IsFinite(value.y) && IsFinite(value.z); }
        public static bool IsUnitInterval(float value) { return IsFinite(value) && value >= 0f && value <= 1f; }

        public static bool IsKnowledgeCategory(string value)
        {
            switch (value)
            {
                case "terrain": case "economy": case "population": case "narrative":
                case "performance": case "weather": case "entity": case "player":
                case "system": case "custom": return true;
                default: return false;
            }
        }

        public static bool ValidateBounds(Bounds bounds)
        {
            Vector3 size = bounds.size;
            return IsFinite(bounds.center) && IsFinite(size) && IsFinite(bounds.min) && IsFinite(bounds.max) &&
                   size.x > 0 && size.y > 0 && size.z > 0;
        }

        public static bool ValidatePosition(PositionDto position, Bounds bounds, out string error)
        {
            if (position == null || !IsFinite(position.ToVector3())) return Fail("Position must be finite.", out error);
            if (!ValidateBounds(bounds) || !bounds.Contains(position.ToVector3()))
                return Fail("Position is outside the allowed bounds.", out error);
            error = null;
            return true;
        }

        public static bool ValidateActionShape(WorldAction action, out string error)
        {
            if (action == null || !IsValidId(action.id)) return Fail("Invalid action ID.", out error);
            if (action.type != "spawn" && action.type != "move" && action.type != "deactivate" && action.type != "activate")
                return Fail("Unsupported action type.", out error);
            if (action.reason != null && action.reason.Length > MaxGoalLength)
                return Fail("Action reason is too long.", out error);
            if (!OptionalId(action.catalog_id) || !OptionalId(action.target_id))
                return Fail("Invalid catalog or target ID.", out error);
            if (action.type == "spawn" && (!IsValidId(action.catalog_id) || !string.IsNullOrEmpty(action.target_id)))
                return Fail("Spawn requires a catalog ID and no target ID.", out error);
            if (action.type != "spawn" && (!IsValidId(action.target_id) || !Guid.TryParse(action.target_id, out _)))
                return Fail("Mutation requires an existing GUID target.", out error);
            if ((action.type == "spawn" || action.type == "move") && action.position == null)
                return Fail("Spawn and move require a position.", out error);
            if (action.position != null && !IsFinite(action.position.ToVector3()))
                return Fail("Action position is not finite.", out error);
            error = null;
            return true;
        }

        public static bool ValidateResponse(TickResponse response, string expectedObservationId, out string error)
        {
            if (response == null || !IsValidId(response.plan_id) || !IsValidId(response.observation_id))
                return Fail("Invalid response identifiers.", out error);
            if (!string.Equals(response.observation_id, expectedObservationId, StringComparison.Ordinal))
                return Fail("Observation ID mismatch; response ignored.", out error);
            if (string.IsNullOrEmpty(response.source) || response.source.Length > MaxIdLength ||
                (response.summary != null && response.summary.Length > 4000))
                return Fail("Invalid response metadata.", out error);
            if (response.actions == null || response.actions.Length > MaxActions ||
                response.warnings == null || response.warnings.Length > MaxBuffer)
                return Fail("Missing or oversized response arrays.", out error);
            foreach (string warning in response.warnings)
                if (warning == null || warning.Length > MaxGoalLength) return Fail("Invalid warning.", out error);
            var ids = new HashSet<string>(StringComparer.Ordinal);
            foreach (WorldAction action in response.actions)
            {
                if (!ValidateActionShape(action, out error)) return false;
                if (!ids.Add(action.id)) return Fail("Duplicate action IDs in one plan.", out error);
            }
            error = null;
            return true;
        }

        public static bool HasRateCapacity(int attemptsInWindow, int plannedActions)
        {
            return attemptsInWindow >= 0 && plannedActions >= 0 && plannedActions <= MaxActions &&
                   attemptsInWindow <= MaxActions - plannedActions;
        }

        private static bool OptionalId(string value) { return string.IsNullOrEmpty(value) || IsValidId(value); }
        private static bool Fail(string message, out string error) { error = message; return false; }
    }
}
