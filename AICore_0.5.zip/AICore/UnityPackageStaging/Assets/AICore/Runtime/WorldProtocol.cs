using System;
using UnityEngine;

namespace AliTerra.AICore
{
    public enum DirectorMode { Observe, Approval, Autonomous }

    [Serializable]
    public sealed class PositionDto
    {
        public float x;
        public float y;
        public float z;

        public PositionDto() { }
        public PositionDto(Vector3 value) { x = value.x; y = value.y; z = value.z; }
        public Vector3 ToVector3() { return new Vector3(x, y, z); }
    }

    [Serializable]
    public sealed class EntityDto
    {
        public string id;
        public string catalog_id;
        public string kind;
        public PositionDto position;
        public bool owned;
        public bool active;
        public bool reactivatable;
    }

    [Serializable]
    public sealed class CatalogDto
    {
        public string id;
        public string kind;
    }

    [Serializable]
    public sealed class ActionResultDto
    {
        public string action_id;
        public string status;
        public string message;
    }

    [Serializable]
    public sealed class WorldEventDto
    {
        public string kind;
        public float value;
    }

    [Serializable]
    public sealed class ActionFeedbackDto
    {
        public string action_id;
        public float reward;
    }

    [Serializable]
    public sealed class LimitsDto
    {
        public PositionDto min;
        public PositionDto max;
        public int max_owned_entities;
        public int owned_entity_count;
        public int action_budget;
    }

    [Serializable]
    public sealed class GoalDto
    {
        public string goal_id;
        public string catalog_id;
        public int target_count;
        public int priority = 1;
        public string status = "active";
        public string description;
    }

    [Serializable]
    public sealed class KnowledgeFactDto
    {
        public string key;
        public string value;
        public string category = "custom";
        public float confidence = 0.5f;
    }

    [Serializable]
    public sealed class RelationDto
    {
        public string source_id;
        public string target_id;
        public string type;
        public float strength = 0.5f;
    }

    [Serializable]
    public sealed class CapabilitiesDto
    {
        public string[] action_types;
    }

    [Serializable]
    public sealed class TickRequest
    {
        public int protocol_version = 2;
        public bool entities_truncated;
        public bool allow_reactivation;
        public LimitsDto limits;
        public string world_id;
        public string session_id;
        public string observation_id;
        public string goal;
        public string target_catalog_id;
        public int target_count;
        public PositionDto anchor;
        public EntityDto[] entities;
        public CatalogDto[] catalog;
        public ActionResultDto[] results;
        public WorldEventDto[] events;
        public ActionFeedbackDto[] feedback;
        public bool allow_mutations;
        public GoalDto[] goals;
        public KnowledgeFactDto[] knowledge_updates;
        public RelationDto[] relations;
        public CapabilitiesDto capabilities;
    }

    [Serializable]
    public sealed class WorldAction
    {
        public string id;
        public string type;
        public string catalog_id;
        public string target_id;
        public PositionDto position;
        public string reason;
        public string goal_id;
    }

    [Serializable]
    public sealed class GoalStatsDto
    {
        public int total_goals;
        public int active;
        public int satisfied;
        public int failed;
        public int paused;
    }

    [Serializable]
    public sealed class KnowledgeSummaryDto
    {
        public int fact_count;
        public int relation_count;
        public int pattern_count;
    }

    [Serializable]
    public sealed class TickResponse
    {
        public string plan_id;
        public string observation_id;
        public string source;
        public string summary;
        public WorldAction[] actions;
        public string[] warnings;
        public GoalStatsDto goal_stats;
        public KnowledgeSummaryDto knowledge_summary;
    }
}
