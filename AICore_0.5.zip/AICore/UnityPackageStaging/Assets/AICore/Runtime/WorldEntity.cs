using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace AliTerra.AICore
{
    [DisallowMultipleComponent]
    [AddComponentMenu("AICore/World Entity")]
    public sealed class WorldEntity : MonoBehaviour
    {
        [Tooltip("Explicit observation category. Use ASCII letters, digits, underscore, dot, colon or dash.")]
        public string kind = "prop";
        public string catalogId = "scene";

        // Ownership is intentionally not serialized or editable in the Inspector.
        [NonSerialized] private string entityId;
        [NonSerialized] private WorldDirector owner;
        [NonSerialized] private int registrationGeneration = -1;
        private HashSet<Transform> spawnedHierarchy;

        private static readonly HashSet<WorldEntity> Registry = new HashSet<WorldEntity>();
        private static readonly Dictionary<string, WorldEntity> ById = new Dictionary<string, WorldEntity>(StringComparer.Ordinal);
        internal static int Generation { get; private set; }

        public string Id { get { return entityId; } }
        public bool IsOwned { get { return owner != null; } }
        public bool IsOwnedBy(WorldDirector director) { return director != null && owner == director; }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetRegistry()
        {
            Registry.Clear();
            ById.Clear();
            Generation++;
            SceneManager.sceneLoaded -= RegisterScene;
            SceneManager.sceneLoaded += RegisterScene;
            SceneManager.sceneUnloaded -= OnSceneUnloaded;
            SceneManager.sceneUnloaded += OnSceneUnloaded;
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        private static void RegisterLoadedScenes()
        {
            for (int i = 0; i < SceneManager.sceneCount; i++)
                RegisterScene(SceneManager.GetSceneAt(i), LoadSceneMode.Additive);
        }

        private static void RegisterScene(Scene scene, LoadSceneMode loadMode)
        {
            if (!Application.isPlaying || !scene.IsValid() || !scene.isLoaded) return;
            // One scan per scene load, including initially inactive opt-in objects; never per frame.
            foreach (GameObject root in scene.GetRootGameObjects())
                foreach (WorldEntity entity in root.GetComponentsInChildren<WorldEntity>(true))
                    Register(entity);
        }

        private void Awake() { Register(this); }
        private void OnEnable() { Register(this); }
        private void OnDestroy()
        {
            Registry.Remove(this);
            if (entityId != null && ById.TryGetValue(entityId, out WorldEntity current) && current == this)
                ById.Remove(entityId);
        }

        private static void Register(WorldEntity entity)
        {
            if (!Application.isPlaying || entity == null || !entity.gameObject.scene.IsValid()) return;
            if (entity.registrationGeneration != Generation)
            {
                entity.registrationGeneration = Generation;
                entity.owner = null;
                entity.spawnedHierarchy = null;
                entity.entityId = Guid.NewGuid().ToString("N");
            }
            if (!Guid.TryParse(entity.entityId, out _) ||
                (ById.TryGetValue(entity.entityId, out WorldEntity existing) && existing != null && existing != entity))
                entity.entityId = Guid.NewGuid().ToString("N");
            ById[entity.entityId] = entity;
            Registry.Add(entity);
        }

        private static void OnSceneUnloaded(Scene scene) { PruneDestroyed(); }

        private static void PruneDestroyed()
        {
            // Unity may skip OnDestroy on an object that has never been active.
            Registry.RemoveWhere(entity =>
            {
                if (entity != null) return false;
                if (!ReferenceEquals(entity, null) && entity.entityId != null &&
                    ById.TryGetValue(entity.entityId, out WorldEntity current) && ReferenceEquals(current, entity))
                    ById.Remove(entity.entityId);
                return true;
            });
        }

        /// <summary>Snapshot contains inactive registered entities; callers may filter loaded scenes.</summary>
        public static WorldEntity[] Snapshot()
        {
            PruneDestroyed();
            var result = new WorldEntity[Registry.Count];
            Registry.CopyTo(result);
            return result;
        }

        internal void AssignSpawnOwnership(WorldDirector director)
        {
            Register(this);
            if (owner != null) throw new InvalidOperationException("Entity already has an owner.");
            if (entityId != null && ById.TryGetValue(entityId, out WorldEntity current) && current == this)
                ById.Remove(entityId);
            entityId = Guid.NewGuid().ToString("N");
            ById[entityId] = this;
            owner = director;
            spawnedHierarchy = new HashSet<Transform>(GetComponentsInChildren<Transform>(true));
        }

        internal bool ValidateOwnedHierarchy(WorldDirector director, out string error)
        {
            if (!IsOwnedBy(director) || spawnedHierarchy == null)
            {
                error = "Target is not owned by this director.";
                return false;
            }
            if (string.Equals(kind, "player", StringComparison.OrdinalIgnoreCase))
            {
                error = "Player entities are protected even if they were originally spawned by this director.";
                return false;
            }
            if (transform.parent != null)
            {
                error = "Owned root was reparented; mutation is forbidden.";
                return false;
            }
            foreach (WorldEntity entity in GetComponentsInChildren<WorldEntity>(true))
            {
                if (entity != this)
                {
                    error = "Target contains another opted-in entity.";
                    return false;
                }
            }
            foreach (Transform child in GetComponentsInChildren<Transform>(true))
            {
                if (child.CompareTag("Player"))
                {
                    error = "Player-tagged roots and descendants are protected.";
                    return false;
                }
                if (!spawnedHierarchy.Contains(child))
                {
                    error = "Target contains a descendant not present at spawn.";
                    return false;
                }
            }
            error = null;
            return true;
        }
    }
}
