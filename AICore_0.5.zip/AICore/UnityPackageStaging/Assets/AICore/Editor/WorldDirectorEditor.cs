using UnityEditor;
using UnityEngine;

namespace AliTerra.AICore.Editor
{
    [CustomEditor(typeof(WorldDirector))]
    public sealed class WorldDirectorEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            SerializedProperty property = serializedObject.GetIterator();
            bool enterChildren = true;
            while (property.NextVisible(enterChildren))
            {
                enterChildren = false;
                if (property.name == "m_Script")
                {
                    using (new EditorGUI.DisabledScope(true)) EditorGUILayout.PropertyField(property);
                }
                else if (property.name == "token")
                    property.stringValue = EditorGUILayout.PasswordField(new GUIContent("Bearer Token", "Local brain token only; never use a cloud credential."), property.stringValue);
                else
                    EditorGUILayout.PropertyField(property, true);
            }
            bool changed = serializedObject.ApplyModifiedProperties();
            WorldDirector director = (WorldDirector)target;
            if (Application.isPlaying && changed)
            {
                // Apply invalidation immediately rather than waiting for the next runtime Update.
                director.SetMode(director.mode);
                director.SetWorldAuthority(director.hasWorldAuthority);
            }
            EditorGUILayout.Space();
            EditorGUILayout.HelpBox("Only explicitly opted-in entities are observed. Only this director's spawned roots can be mutated. World authority is manual and defaults OFF. Prefab callbacks are trusted; no collision, navigation or network replication is provided.", MessageType.Info);
            EditorGUILayout.LabelField("Runtime Status", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(director.Status, director.IsEmergencyStopped ? MessageType.Warning : MessageType.None);
            if (!Application.isPlaying)
            {
                EditorGUILayout.LabelField("Controls are available in Play Mode only.");
                return;
            }
            EditorGUILayout.LabelField("Owned roots (including inactive)", director.OwnedEntityCount.ToString());
            EditorGUILayout.LabelField("Buffered acknowledgements", director.BufferedResultCount.ToString());
            if (director.HasPendingPlan)
            {
                EditorGUILayout.LabelField("Pending approval", director.PendingSecondsRemaining.ToString("F1") + " seconds remaining");
                DrawUntrustedLabel(director.PendingSummary);
                foreach (WorldAction action in director.GetPendingActions())
                {
                    using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
                    {
                        DrawUntrustedLabel(action.id + " / " + action.type);
                        if (!string.IsNullOrEmpty(action.catalog_id)) DrawUntrustedLabel("Catalog: " + action.catalog_id);
                        if (!string.IsNullOrEmpty(action.target_id)) DrawUntrustedLabel("Target: " + action.target_id);
                        if (action.position != null) DrawUntrustedLabel("Position: " + action.position.ToVector3());
                        if (!string.IsNullOrEmpty(action.reason)) DrawUntrustedLabel(action.reason);
                    }
                }
            }
            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUI.DisabledScope(!director.isActiveAndEnabled || director.IsEmergencyStopped || director.IsRequestActive || director.HasPendingPlan))
                    if (GUILayout.Button("Think")) director.Think();
                using (new EditorGUI.DisabledScope(!director.isActiveAndEnabled || director.IsEmergencyStopped ||
                    !director.HasPendingPlan || !director.hasWorldAuthority || director.mode != DirectorMode.Approval))
                    if (GUILayout.Button("Approve")) director.ApprovePending();
                using (new EditorGUI.DisabledScope(!director.HasPendingPlan))
                    if (GUILayout.Button("Reject")) director.RejectPending();
            }
            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUI.DisabledScope(director.IsEmergencyStopped))
                    if (GUILayout.Button("Emergency Stop")) director.EmergencyStop();
                using (new EditorGUI.DisabledScope(!director.IsEmergencyStopped))
                    if (GUILayout.Button("Resume")) director.Resume();
            }
            Repaint();
        }

        private static void DrawUntrustedLabel(string text)
        {
            var style = new GUIStyle(EditorStyles.wordWrappedLabel) { richText = false };
            EditorGUILayout.LabelField(text ?? "", style);
        }

        [MenuItem("GameObject/AICore/World Director", false, 10)]
        private static void CreateDirector(MenuCommand command)
        {
            // An explicit menu invocation creates only an empty object and its disabled-by-default authority setting.
            var gameObject = new GameObject("World Director");
            Undo.RegisterCreatedObjectUndo(gameObject, "Create World Director");
            GameObjectUtility.SetParentAndAlign(gameObject, command.context as GameObject);
            Undo.AddComponent<WorldDirector>(gameObject);
            Selection.activeGameObject = gameObject;
        }
    }

    [CustomEditor(typeof(WorldEntity))]
    public sealed class WorldEntityEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            DrawDefaultInspector();
            WorldEntity entity = (WorldEntity)target;
            using (new EditorGUI.DisabledScope(true))
            {
                EditorGUILayout.TextField("Runtime Entity ID", entity.Id ?? "Assigned in Play Mode");
                EditorGUILayout.Toggle("Owned (runtime only)", entity.IsOwned);
            }
            EditorGUILayout.HelpBox("Adding this component opts the object into observation, not mutation. Preexisting scene objects are never made owned by the Inspector.", MessageType.Info);
        }
    }
}
