using System;
using UnityEngine;
using AliTerra.AICore;

namespace AliTerra.AICore.Examples
{
    /// <summary>Minimal trusted gameplay integration example. Attach beside a WorldDirector.</summary>
    public sealed class AICoreQuickStart : MonoBehaviour
    {
        [SerializeField] private WorldDirector director;

        private void Reset() { director = GetComponent<WorldDirector>(); }

        public void PublishWeather(string weather)
        {
            if (director != null) director.PublishKnowledge("weather.current", weather, "weather", 0.9f);
        }

        public void PublishQuestCompleted()
        {
            if (director != null) director.PublishEvent("quest.completed", 1f);
        }

        public void RateLastAction(float reward)
        {
            if (director != null && !string.IsNullOrEmpty(director.LastSuccessfulActionId))
                director.RateAction(director.LastSuccessfulActionId, Mathf.Clamp(reward, -1f, 1f));
        }
    }
}
