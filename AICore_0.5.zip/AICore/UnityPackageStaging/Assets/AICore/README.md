# AICore Unity test package

This folder is the importable Unity form of AICore 0.4.0. After import, add `AICore/World Director` to a GameObject, assign a `PrefabCatalog`, set the local bearer token, and start the local brain from the companion `AICore_0.5.zip` archive.

Default endpoint: `http://127.0.0.1:8765/v2/tick`
Default mode: Observe

For a first safe test: add `WorldEntity` to one non-player object, use a small approved prefab catalog, keep Observe mode, and click Think in the Inspector. No scene mutation occurs in Observe mode.
