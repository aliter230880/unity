"""Bounded, session-scoped population goals with an authoritative goal snapshot.

A goal describes a measurable target, never an executable natural-language instruction.
Satisfied goals are re-evaluated every complete observation, including target zero.
The caller owns the transaction when commit=False.
"""
from __future__ import annotations

import re
import sqlite3
import time
from typing import Any

MAX_GOALS = 16
MAX_PRIORITY = 100
GOAL_STATUSES = ("active", "satisfied", "failed", "paused")
ID = re.compile(r"[A-Za-z0-9_.:\-]{1,96}\Z")


class GoalError(ValueError):
    pass


def validate_goal(goal: Any) -> dict:
    if not isinstance(goal, dict):
        raise GoalError("Goal must be an object.")
    for field in ("goal_id", "catalog_id"):
        if not isinstance(goal.get(field), str) or not ID.fullmatch(goal[field]):
            raise GoalError(f"Invalid {field}.")
    for field, default, upper in (("target_count", 0, 100), ("priority", 1, MAX_PRIORITY)):
        value = goal.get(field, default)
        if type(value) is not int or not 0 <= value <= upper:
            raise GoalError(f"{field} must be an integer from 0 to {upper}.")
    if goal.get("status", "active") not in GOAL_STATUSES:
        raise GoalError("Invalid goal status.")
    if not isinstance(goal.get("description", ""), str) or len(goal.get("description", "")) > 500:
        raise GoalError("Invalid goal description.")
    return {"goal_id": goal["goal_id"], "catalog_id": goal["catalog_id"],
            "target_count": goal.get("target_count", 0), "priority": goal.get("priority", 1),
            "status": goal.get("status", "active"), "description": goal.get("description", "")}


class GoalManager:
    SCHEMA = """
    CREATE TABLE IF NOT EXISTS goals (
        world TEXT NOT NULL, session TEXT NOT NULL, goal_id TEXT NOT NULL,
        catalog_id TEXT NOT NULL, target_count INTEGER NOT NULL,
        priority INTEGER NOT NULL DEFAULT 1, status TEXT NOT NULL DEFAULT 'active',
        description TEXT NOT NULL DEFAULT '', created REAL NOT NULL, satisfied_at REAL,
        satisfaction_history TEXT NOT NULL DEFAULT '[]', outcome_count INTEGER NOT NULL DEFAULT 0,
        outcome_reward REAL NOT NULL DEFAULT 0.0, PRIMARY KEY(world, session, goal_id));
    CREATE INDEX IF NOT EXISTS goal_active ON goals(world, session, status, priority DESC);
    """

    def __init__(self, db: sqlite3.Connection):
        self.db = db
        self.db.executescript(self.SCHEMA)
        self.db.commit()

    def upsert_goal(self, world: str, session: str, goal: dict, *, commit: bool = True) -> dict:
        goal = validate_goal(goal)
        existing = self.get_goal(world, session, goal["goal_id"])
        if existing:
            changed = any(existing[k] != goal[k] for k in ("catalog_id", "target_count"))
            status = goal["status"]
            if not changed and status == "active" and existing["status"] == "satisfied":
                status = "satisfied"  # Repeated client snapshots must not inflate outcomes.
            self.db.execute(
                """UPDATE goals SET catalog_id=?,target_count=?,priority=?,status=?,description=?,
                   satisfied_at=CASE WHEN ? THEN NULL ELSE satisfied_at END
                   WHERE world=? AND session=? AND goal_id=?""",
                (goal["catalog_id"], goal["target_count"], goal["priority"], status,
                 goal["description"], changed, world, session, goal["goal_id"]))
        else:
            count = self.db.execute("SELECT COUNT(*) FROM goals WHERE world=? AND session=?", (world, session)).fetchone()[0]
            if count >= MAX_GOALS:
                raise GoalError("Goal storage limit reached for this session.")
            self.db.execute(
                """INSERT INTO goals(world,session,goal_id,catalog_id,target_count,priority,status,description,created)
                   VALUES(?,?,?,?,?,?,?,?,?)""",
                (world, session, goal["goal_id"], goal["catalog_id"], goal["target_count"],
                 goal["priority"], goal["status"], goal["description"], time.time()))
        if commit:
            self.db.commit()
        return self.get_goal(world, session, goal["goal_id"])

    def sync(self, world: str, session: str, goals: list[dict]) -> None:
        """Replace desired goals, retaining history for IDs still present; never commits."""
        incoming = {g["goal_id"] for g in goals}
        for existing in self.all_goals(world, session):
            if existing["goal_id"] not in incoming:
                self.db.execute("DELETE FROM goals WHERE world=? AND session=? AND goal_id=?",
                                (world, session, existing["goal_id"]))
        for goal in goals:
            self.upsert_goal(world, session, goal, commit=False)

    def get_goal(self, world: str, session: str, goal_id: str) -> dict | None:
        row = self.db.execute("SELECT * FROM goals WHERE world=? AND session=? AND goal_id=?",
                              (world, session, goal_id)).fetchone()
        return dict(row) if row else None

    def active_goals(self, world: str, session: str) -> list[dict]:
        return [g for g in self.all_goals(world, session) if g["status"] == "active"]

    def all_goals(self, world: str, session: str) -> list[dict]:
        return [dict(row) for row in self.db.execute(
            "SELECT * FROM goals WHERE world=? AND session=? ORDER BY priority DESC,created ASC,goal_id ASC",
            (world, session))]

    def update_status(self, world: str, session: str, goal_id: str, status: str,
                      reward: float = 0.0, *, commit: bool = True):
        if status not in GOAL_STATUSES:
            raise GoalError("Invalid goal status.")
        self.db.execute(
            """UPDATE goals SET status=?,satisfied_at=?,outcome_count=outcome_count+1,
               outcome_reward=outcome_reward+? WHERE world=? AND session=? AND goal_id=? AND status<>?""",
            (status, time.time() if status == "satisfied" else None, reward, world, session, goal_id, status))
        if commit:
            self.db.commit()

    def check_satisfaction(self, world: str, session: str, goal: dict, active_count: int) -> tuple[str, float]:
        if goal["status"] in ("paused", "failed"):
            return goal["status"], 0.0
        # A deficit or excess is repairable, not an automatic failure. Do not invent gameplay reward.
        return ("satisfied" if active_count == goal["target_count"] else "active"), 0.0

    def adaptive_priority(self, goal: dict) -> int:
        # Developer priority is authoritative. Outcome-based placement learning lives in Brain.
        return goal["priority"]

    def stats(self, world: str, session: str) -> dict:
        goals = self.all_goals(world, session)
        return {"total_goals": len(goals), **{s: sum(g["status"] == s for g in goals) for s in GOAL_STATUSES}}
