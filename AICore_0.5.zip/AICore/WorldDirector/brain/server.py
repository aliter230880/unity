"""AICore local world director. Python 3.13+, standard library only.

Protocols v1/v2: bounded population maintenance, persistent goals/knowledge,
transactional replay and attributed placement feedback. No model training,
arbitrary code execution or arbitrary asset generation.
"""
from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import math
import os
from pathlib import Path
import re
import sqlite3
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any

from goals import GoalManager, GoalError, validate_goal, MAX_GOALS
from knowledge import KnowledgeBase, KnowledgeError, validate_fact, validate_relation, CATEGORIES
from planner import MultiObjectivePlanner, validate_capabilities
from copy import deepcopy
from urllib.parse import urlsplit, parse_qs

MAX_BODY = 1_048_576
ID = re.compile(r"[A-Za-z0-9_.:\-]{1,96}\Z")
STRATEGIES = ("compact", "spread")


class ProtocolError(ValueError):
    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.status = status


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ProtocolError(message)


def identifier(value: Any, label: str, optional: bool = False) -> None:
    require(isinstance(value, str) and ((optional and value == "") or bool(ID.fullmatch(value))),
            f"Invalid {label}.")


def integer(value: Any, label: str, low: int, high: int) -> None:
    require(type(value) is int and low <= value <= high, f"Invalid {label}.")


def number(value: Any, label: str) -> None:
    require(type(value) in (int, float), f"Invalid {label}.")
    try:
        finite = math.isfinite(value) and abs(value) <= 3.4e38
    except OverflowError:
        finite = False
    require(finite, f"Nonfinite or oversized {label}.")


def position(value: Any, label: str) -> None:
    require(isinstance(value, dict) and set(value) == {"x", "y", "z"}, f"Invalid {label}.")
    for axis in "xyz":
        number(value[axis], label + "." + axis)


def text(value: Any, label: str, limit: int) -> None:
    require(isinstance(value, str) and len(value) <= limit, f"Invalid {label}.")


def array(value: Any, label: str, limit: int) -> None:
    require(isinstance(value, list) and len(value) <= limit, f"Invalid {label}.")
    require(all(isinstance(item, dict) for item in value), f"Invalid {label} item.")


def validate_request(data: Any, expected_version: int = 1) -> dict:
    require(isinstance(data, dict), "Request must be an object.")
    require(type(data.get("protocol_version")) is int and data["protocol_version"] == expected_version,
            f"protocol_version {expected_version} is required for this endpoint.")
    for name in ("world_id", "session_id", "observation_id"):
        identifier(data.get(name), name)
    text(data.get("goal"), "goal", 2000)
    identifier(data.get("target_catalog_id"), "target_catalog_id", optional=True)
    integer(data.get("target_count"), "target_count", 0, 100)
    position(data.get("anchor"), "anchor")
    for name in ("allow_mutations", "entities_truncated"):
        require(type(data.get(name)) is bool, f"{name} must be a boolean.")
    require(type(data.get("allow_reactivation", False)) is bool, "allow_reactivation must be a boolean.")
    limits = data.get("limits")
    require(isinstance(limits, dict), "Execution limits are required.")
    for name in ("min", "max"):
        position(limits.get(name), "limits." + name)
    require(all(limits["min"][a] < limits["max"][a] for a in "xyz"), "Invalid bounds.")
    integer(limits.get("max_owned_entities"), "max_owned_entities", 0, 2_147_483_647)
    integer(limits.get("owned_entity_count"), "owned_entity_count", 0, 2_147_483_647)
    integer(limits.get("action_budget"), "action_budget", 0, 8)
    for name, limit in (("entities", 512), ("catalog", 128), ("results", 32), ("events", 32), ("feedback", 32)):
        array(data.get(name), name, limit)
    catalog_ids = set()
    for entry in data["catalog"]:
        identifier(entry.get("id"), "catalog.id")
        identifier(entry.get("kind"), "catalog.kind")
        require(entry["id"] not in catalog_ids, "Duplicate catalog ID.")
        catalog_ids.add(entry["id"])
    require(not data["target_catalog_id"] or data["target_catalog_id"] in catalog_ids, "Target is not in catalog.")
    require(data["target_count"] == 0 or bool(data["target_catalog_id"]), "A positive target needs a catalog ID.")
    entity_ids = set()
    for entry in data["entities"]:
        identifier(entry.get("id"), "entity.id")
        for name in ("catalog_id", "kind"):
            identifier(entry.get(name), "entity." + name)
        position(entry.get("position"), "entity.position")
        require(type(entry.get("active")) is bool and type(entry.get("owned")) is bool, "Entity flags must be booleans.")
        require(type(entry.get("reactivatable", False)) is bool, "entity.reactivatable must be a boolean.")
        require(entry["id"] not in entity_ids, "Duplicate entity ID.")
        entity_ids.add(entry["id"])
    observed_owned = sum(e["owned"] for e in data["entities"])
    require(observed_owned <= limits["owned_entity_count"],
            "Observed owned entities exceed reported ownership count.")
    require(data["entities_truncated"] or observed_owned == limits["owned_entity_count"],
            "Complete snapshot ownership count must match reported ownership count.")
    for entry in data["results"]:
        identifier(entry.get("action_id"), "result.action_id")
        require(entry.get("status") in ("executed", "failed", "rejected"), "Invalid action result status.")
        text(entry.get("message"), "result.message", 2000)
    for entry in data["events"]:
        identifier(entry.get("kind"), "event.kind")
        number(entry.get("value"), "event.value")
    for entry in data["feedback"]:
        identifier(entry.get("action_id"), "feedback.action_id")
        number(entry.get("reward"), "feedback.reward")
    if expected_version == 2:
        array(data.get("goals"), "goals", MAX_GOALS)
        array(data.get("knowledge_updates", []), "knowledge_updates", 100)
        array(data.get("relations", []), "relations", 50)
        require(not data.get("world_state"), "Use explicit knowledge_updates; world_state is not implemented.")
        seen_goals, seen_catalogs = set(), set()
        try:
            validate_capabilities(data.get("capabilities", {}))
            for raw_goal in data["goals"]:
                goal = validate_goal(raw_goal)
                require(goal["goal_id"] not in seen_goals, "Duplicate goal ID.")
                require(goal["catalog_id"] in catalog_ids, "Goal catalog is not approved.")
                require(goal["catalog_id"] not in seen_catalogs, "Conflicting goals for the same catalog.")
                seen_goals.add(goal["goal_id"])
                seen_catalogs.add(goal["catalog_id"])
            for fact in data.get("knowledge_updates", []):
                validate_fact(fact)
            for relation in data.get("relations", []):
                validate_relation(relation)
        except (GoalError, KnowledgeError, ValueError, OverflowError) as error:
            raise ProtocolError(str(error)) from error
    return data


def reject_constant(value: str) -> None:
    raise ProtocolError("Nonfinite JSON constant is forbidden.")


def unique_object(pairs: list) -> dict:
    result = {}
    for key, value in pairs:
        require(key not in result, "Duplicate JSON key.")
        result[key] = value
    return result


def decode_request(raw: bytes, expected_version: int = 1) -> dict:
    require(len(raw) <= MAX_BODY, "Request is too large.")
    try:
        data = json.loads(raw.decode("utf-8"), parse_constant=reject_constant, object_pairs_hook=unique_object)
    except (UnicodeDecodeError, json.JSONDecodeError, RecursionError, ValueError) as error:
        if isinstance(error, ProtocolError):
            raise
        raise ProtocolError("Invalid UTF-8 JSON.") from error
    return validate_request(data, expected_version)


def canonical(data: Any) -> str:
    return json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False)


class Brain:
    """Transactionally cache plans and learn only from attributed executed actions.

    IDs are scoped by world AND session. Reusing an observation ID with different
    contents is a conflict, never a second plan. No request can execute system code.
    """
    def __init__(self, database: str | Path):
        self.path = str(database)
        self.lock = threading.RLock()
        self.db = sqlite3.connect(self.path, timeout=5, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=FULL")
        # Bounded storage; on exhaustion fail closed rather than forget replay IDs.
        self.db.execute("PRAGMA max_page_count=16384")
        self.db.executescript("""
            CREATE TABLE IF NOT EXISTS observations (
                world TEXT, session TEXT, observation TEXT, digest TEXT NOT NULL,
                response TEXT NOT NULL, events TEXT NOT NULL,
                created TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY(world, session, observation));
            CREATE TABLE IF NOT EXISTS actions (
                world TEXT, session TEXT, action TEXT, catalog TEXT, strategy TEXT,
                type TEXT, status TEXT, reward REAL,
                PRIMARY KEY(world, session, action));
            CREATE INDEX IF NOT EXISTS action_learning ON actions(world, catalog, strategy);
            CREATE TABLE IF NOT EXISTS learning (
                world TEXT, catalog TEXT, strategy TEXT, samples INTEGER NOT NULL,
                reward_sum REAL NOT NULL, PRIMARY KEY(world, catalog, strategy));
        """)
        self.db.commit()
        # Extended systems: goal management and knowledge base
        self.goals = GoalManager(self.db)
        self.knowledge = KnowledgeBase(self.db)

    def close(self) -> None:
        with self.lock:
            self.db.close()

    def tick(self, request: dict) -> dict:
        data = validate_request(request)
        encoded = canonical(data)
        digest = hashlib.sha256(encoded.encode("utf-8")).hexdigest()
        scope = (data["world_id"], data["session_id"])
        key = (*scope, data["observation_id"])
        with self.lock:
            try:
                self.db.execute("BEGIN IMMEDIATE")
                previous = self.db.execute(
                    "SELECT digest,response FROM observations WHERE world=? AND session=? AND observation=?", key).fetchone()
                if previous:
                    if previous["digest"] != digest:
                        raise ProtocolError("Observation ID already exists with different contents.", 409)
                    self.db.commit()
                    return json.loads(previous["response"])
                warnings = self._ingest(data, scope)
                actions, summary, strategy = self._plan(data, warnings)
                plan_id = "p_" + hashlib.sha256(canonical(key).encode()).hexdigest()[:32]
                for index, action in enumerate(actions):
                    action["id"] = plan_id + "_" + str(index)
                    self.db.execute("INSERT INTO actions(world,session,action,catalog,strategy,type) VALUES(?,?,?,?,?,?)",
                                    (*scope, action["id"], action["catalog_id"], strategy, action["type"]))
                response = {"plan_id": plan_id, "observation_id": data["observation_id"],
                            "source": "local_population_v1", "summary": summary,
                            "actions": actions, "warnings": list(dict.fromkeys(warnings))[:32]}
                self.db.execute("INSERT INTO observations(world,session,observation,digest,response,events) VALUES(?,?,?,?,?,?)",
                                (*key, digest, canonical(response), canonical(data["events"])))
                self.db.commit()
                return response
            except BaseException:
                self.db.rollback()
                raise

    def tick_v2(self, request: dict) -> dict:
        """Atomic v2 tick: authoritative goals, memory, results and replay commit together."""
        data = validate_request(request, expected_version=2)
        digest = hashlib.sha256(canonical(data).encode("utf-8")).hexdigest()
        scope = (data["world_id"], data["session_id"])
        key = (*scope, data["observation_id"])
        with self.lock:
            try:
                self.db.execute("BEGIN IMMEDIATE")
                previous = self.db.execute(
                    "SELECT digest,response FROM observations WHERE world=? AND session=? AND observation=?", key).fetchone()
                if previous:
                    if previous["digest"] != digest:
                        raise ProtocolError("Observation ID already exists with different contents.", 409)
                    self.db.commit()
                    return json.loads(previous["response"])
                self.goals.sync(*scope, [validate_goal(g) for g in data["goals"]])
                for fact in data.get("knowledge_updates", []):
                    self.knowledge.upsert_fact(scope[0], fact, commit=False)
                for relation in data.get("relations", []):
                    self.knowledge.upsert_relation(scope[0], relation, commit=False)
                warnings = self._ingest(data, scope)
                actions, summary = self._plan_multi(data, scope, warnings)
                plan_id = "p2_" + hashlib.sha256(canonical(key).encode()).hexdigest()[:32]
                for index, action in enumerate(actions):
                    action["id"] = plan_id + "_" + str(index)
                    strategy = action.pop("_strategy", "")
                    self.db.execute(
                        "INSERT INTO actions(world,session,action,catalog,strategy,type) VALUES(?,?,?,?,?,?)",
                        (*scope, action["id"], action["catalog_id"], strategy, action["type"]))
                memory = self.knowledge.world_summary(scope[0])
                response = {
                    "plan_id": plan_id, "observation_id": data["observation_id"],
                    "source": "multi_objective_v2", "summary": summary[:4000], "actions": actions,
                    "warnings": list(dict.fromkeys(warnings))[:32], "goal_stats": self.goals.stats(*scope),
                    "knowledge_summary": {k: memory[k] for k in ("fact_count", "relation_count", "pattern_count", "categories")}}
                self.db.execute(
                    "INSERT INTO observations(world,session,observation,digest,response,events) VALUES(?,?,?,?,?,?)",
                    (*key, digest, canonical(response), canonical(data["events"])))
                self.db.commit()
                return response
            except BaseException:
                self.db.rollback()
                raise

    def _plan_multi(self, data: dict, scope: tuple, warnings: list) -> tuple[list, str]:
        if data["entities_truncated"]:
            warnings.append("Snapshot is incomplete; refusing to infer population.")
            return [], "No action on a truncated world snapshot."
        # Satisfaction is an observed state, not a neural or gameplay reward.
        goals = self.goals.all_goals(*scope)
        for goal in goals:
            count = sum(e["owned"] and e["active"] and e["catalog_id"] == goal["catalog_id"] for e in data["entities"])
            status, _ = self.goals.check_satisfaction(*scope, goal, count)
            if status != goal["status"]:
                self.goals.update_status(*scope, goal["goal_id"], status, commit=False)
            goal["status"] = status
        if not data["allow_mutations"]:
            return [], "Observing only; mutation permission is off."
        if not goals:
            return [], "No explicit goals; observing only."
        capabilities = validate_capabilities(data.get("capabilities", {}))["action_types"]
        if not capabilities or data["limits"]["action_budget"] == 0:
            return [], "No action budget or permitted capabilities."
        projected = deepcopy(data)
        # Reuse the vetted single-target planner and reserve resources across goals.
        allocations = MultiObjectivePlanner.allocate_budget(goals, data["limits"]["action_budget"])
        actions, summaries = [], []
        for goal in allocations:
            if goal["status"] != "active" or not goal["allocated_budget"]:
                continue
            projected["target_catalog_id"] = goal["catalog_id"]
            projected["target_count"] = goal["target_count"]
            projected["limits"]["action_budget"] = goal["allocated_budget"]
            projected["allow_reactivation"] = data.get("allow_reactivation", False) and "activate" in capabilities
            if "spawn" not in capabilities:
                projected["limits"]["max_owned_entities"] = projected["limits"]["owned_entity_count"]
            proposed, summary, strategy = self._plan(projected, warnings)
            summaries.append(goal["goal_id"] + ": " + summary)
            for action in proposed:
                if action["type"] not in capabilities:
                    warnings.append("Action omitted because the game did not advertise its capability.")
                    continue
                action["goal_id"] = goal["goal_id"]
                action["_strategy"] = strategy if action["type"] == "spawn" else ""
                actions.append(action)
                if action["type"] == "spawn":
                    projected["limits"]["owned_entity_count"] += 1
                    kind = next(c["kind"] for c in data["catalog"] if c["id"] == action["catalog_id"])
                    projected["entities"].append({"id": "projected-" + str(len(actions)),
                        "catalog_id": action["catalog_id"], "kind": kind, "owned": True,
                        "active": True, "position": action["position"]})
                elif action["type"] in ("activate", "deactivate"):
                    target = next(e for e in projected["entities"] if e["id"] == action["target_id"])
                    target["active"] = action["type"] == "activate"
        return actions, " | ".join(summaries) if summaries else "All enabled goals are satisfied or paused."

    def _ingest(self, data: dict, scope: tuple) -> list[str]:
        warnings = []
        for result in data["results"]:
            row = self.db.execute("SELECT status FROM actions WHERE world=? AND session=? AND action=?",
                                  (*scope, result["action_id"])).fetchone()
            if row is None:
                warnings.append("Unknown result ignored; it may belong to an older database.")
            elif row["status"] is None:
                self.db.execute("UPDATE actions SET status=? WHERE world=? AND session=? AND action=?",
                                (result["status"], *scope, result["action_id"]))
            elif row["status"] != result["status"]:
                warnings.append("Conflicting result ignored; first terminal status retained.")
        for rating in data["feedback"]:
            row = self.db.execute("SELECT * FROM actions WHERE world=? AND session=? AND action=?",
                                  (*scope, rating["action_id"])).fetchone()
            if row is None or row["status"] != "executed":
                warnings.append("Feedback requires an executed action in this world/session; ignored.")
                continue
            if row["reward"] is not None:
                continue
            reward = max(-1.0, min(1.0, float(rating["reward"])))
            if reward != rating["reward"]:
                warnings.append("Feedback reward was clamped to [-1, 1].")
            self.db.execute("UPDATE actions SET reward=? WHERE world=? AND session=? AND action=?",
                            (reward, *scope, rating["action_id"]))
            if row["type"] == "spawn" and row["strategy"] in STRATEGIES:
                self.db.execute("""INSERT INTO learning VALUES(?,?,?,?,?)
                    ON CONFLICT(world,catalog,strategy) DO UPDATE SET
                    samples=samples+1,reward_sum=reward_sum+excluded.reward_sum""",
                                (scope[0], row["catalog"], row["strategy"], 1, reward))
        return warnings

    def _strategy(self, world: str, catalog: str) -> str:
        rows = {row["strategy"]: row for row in self.db.execute(
            "SELECT * FROM learning WHERE world=? AND catalog=?", (world, catalog))}
        issued = {row["strategy"]: row["count"] for row in self.db.execute(
            "SELECT strategy,COUNT(*) AS count FROM actions WHERE world=? AND catalog=? AND type='spawn' GROUP BY strategy",
            (world, catalog))}
        total = sum(row["samples"] for row in rows.values())
        def score(strategy: str) -> tuple:
            row = rows.get(strategy)
            # Explore unrated strategies, alternating by issued count if no feedback exists.
            if row is None:
                return (1, -issued.get(strategy, 0))
            mean = row["reward_sum"] / row["samples"]
            return (0, mean + math.sqrt(2 * math.log(max(2, total)) / row["samples"]))
        return max(STRATEGIES, key=score)

    @staticmethod
    def _inside(point: dict, limits: dict) -> bool:
        return all(limits["min"][a] <= point[a] <= limits["max"][a] for a in "xyz")

    def _plan(self, data: dict, warnings: list[str]) -> tuple[list, str, str]:
        if not data["allow_mutations"]:
            return [], "Observing only; mutation permission is off.", ""
        if data["entities_truncated"]:
            warnings.append("Snapshot is incomplete; refusing to infer population.")
            return [], "No action on a truncated world snapshot.", ""
        target = data["target_catalog_id"]
        if not target:
            return [], "No explicit population target configured.", ""
        limits = data["limits"]
        budget = limits["action_budget"]
        entry = next(item for item in data["catalog"] if item["id"] == target)
        if entry["kind"].lower() == "player":
            warnings.append("Player catalogs cannot be controlled.")
            return [], "Protected catalog; no actions.", ""
        population = sorted((e for e in data["entities"] if e["owned"] and e["active"]
                             and e["catalog_id"] == target), key=lambda e: e["id"])
        difference = data["target_count"] - len(population)
        if difference == 0:
            return [], f"Target satisfied: {len(population)} active owned entities.", ""
        if budget == 0:
            return [], "Waiting for execution budget.", ""
        if difference < 0:
            eligible = [e for e in population if e["kind"].lower() != "player" and self._inside(e["position"], limits)]
            actions = [{"type": "deactivate", "catalog_id": target, "target_id": e["id"],
                        "reason": "Reduce active owned population to the explicit target."}
                       for e in eligible[:min(-difference, budget)]]
            warnings.append("Deactivated roots still consume the ownership cap; no automatic deletion.")
            return actions, f"Proposing {len(actions)} deactivations.", ""
        reactivations = []
        if data.get("allow_reactivation", False):
            reactivations = sorted((e for e in data["entities"] if e["owned"] and not e["active"]
                                    and e.get("reactivatable", False) and e["catalog_id"] == target
                                    and e["kind"].lower() != "player" and self._inside(e["position"], limits)),
                                   key=lambda e: e["id"])[:min(difference, budget)]
        actions = [{"type": "activate", "catalog_id": target, "target_id": e["id"],
                    "reason": "Reuse an inactive owned entity to meet the explicit population target."}
                   for e in reactivations]
        capacity = max(0, limits["max_owned_entities"] - limits["owned_entity_count"])
        remaining = min(difference - len(reactivations), budget - len(reactivations))
        count = min(remaining, capacity)
        if remaining > capacity:
            warnings.append("Ownership cap reached, including inactive roots.")
        strategy = self._strategy(data["world_id"], target) if count else ""
        spacing = 2.0 if strategy == "compact" else 5.0
        occupied = [e["position"] for e in data["entities"] if e["active"]]
        occupied.extend(e["position"] for e in reactivations)
        spawn_count = 0
        # Bounded candidate search. Separation is point-based, not a collider/navmesh guarantee.
        for slot in range(256):
            if spawn_count >= count:
                break
            radius = spacing * math.sqrt(slot + 1)
            angle = slot * 2.399963229728653
            point = {"x": data["anchor"]["x"] + radius * math.cos(angle),
                     "y": data["anchor"]["y"],
                     "z": data["anchor"]["z"] + radius * math.sin(angle)}
            if not self._inside(point, limits):
                continue
            if any(sum((point[a] - other[a]) ** 2 for a in "xyz") < 1.0 for other in occupied):
                continue
            actions.append({"type": "spawn", "catalog_id": target, "target_id": "", "position": point,
                            "reason": f"Maintain explicit population target using {strategy} placement."})
            occupied.append(point)
            spawn_count += 1
        if spawn_count < count:
            warnings.append("Not enough bounded point-separated positions; fewer spawns proposed.")
        placement = f" ({strategy})" if spawn_count else ""
        summary = (f"Active owned population {len(population)}/{data['target_count']}; proposing "
                   f"{len(reactivations)} activations and {spawn_count} spawns{placement}.")
        if len(actions) < difference:
            summary += " Population deficit remains."
        return actions, summary, strategy

    def stats(self) -> dict:
        with self.lock:
            return {"observations": self.db.execute("SELECT COUNT(*) FROM observations").fetchone()[0],
                    "actions": self.db.execute("SELECT COUNT(*) FROM actions").fetchone()[0],
                    "rated_actions": self.db.execute("SELECT COUNT(*) FROM actions WHERE reward IS NOT NULL").fetchone()[0],
                    "learning": [dict(row) for row in self.db.execute("SELECT * FROM learning ORDER BY world,catalog,strategy")]}


class LocalServer(HTTPServer):
    # Serial requests deliberately bound CPU, memory, and concurrent database work.
    allow_reuse_address = True
    request_queue_size = 8

    def get_request(self):
        sock, address = super().get_request()
        sock.settimeout(5)
        return sock, address


def make_server(brain: Brain, token: str, port: int = 8765) -> LocalServer:
    require(isinstance(token, str) and 16 <= len(token) <= 4096 and
            all(32 < ord(c) < 127 for c in token), "Token must be 16-4096 printable ASCII characters without spaces.")

    class Handler(BaseHTTPRequestHandler):
        server_version = "AICore/0.3"
        sys_version = ""

        def log_message(self, format, *args):
            # Do not log request contents, URLs, or bearer tokens.
            pass

        def reply(self, code: int, body: dict):
            encoded = canonical(body).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(encoded)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("Connection", "close")
            self.end_headers()
            try:
                self.wfile.write(encoded)
            except (BrokenPipeError, ConnectionResetError):
                pass

        def authorized(self) -> bool:
            headers = self.headers.get_all("Authorization", [])
            if len(headers) != 1 or not hmac.compare_digest(headers[0].encode("utf-8"), ("Bearer " + token).encode("utf-8")):
                self.reply(401, {"error": "Authentication required."})
                return False
            # No CORS/browser access; Unity's client does not send Origin.
            if self.headers.get("Origin") is not None:
                self.reply(403, {"error": "Browser-origin requests are not allowed."})
                return False
            return True

        def do_GET(self):
            if not self.authorized():
                return
            try:
                parsed = urlsplit(self.path)
                if self.path == "/health":
                    self.reply(200, {"status": "ok", "protocol_versions": [1, 2],
                        "planner": "multi_objective", "model_training": False,
                        "capabilities": ["population_goals", "knowledge_storage", "placement_feedback"],
                        "action_types": ["spawn", "move", "activate", "deactivate"]})
                elif self.path == "/v1/stats":
                    self.reply(200, brain.stats())
                elif parsed.path in ("/v1/goals", "/v1/knowledge"):
                    require(len(parsed.query) <= 2048, "Query is too long.")
                    params = parse_qs(parsed.query, keep_blank_values=True, max_num_fields=8)
                    require(all(len(v) == 1 for v in params.values()), "Duplicate query parameter.")
                    params = {k: v[0] for k, v in params.items()}
                    world = params.get("world", "")
                    identifier(world, "world")
                    with brain.lock:
                        if parsed.path == "/v1/goals":
                            session = params.get("session", "")
                            identifier(session, "session")
                            body = {"goals": brain.goals.all_goals(world, session), "stats": brain.goals.stats(world, session)}
                        else:
                            raw_limit = params.get("limit", "50")
                            require(raw_limit.isascii() and raw_limit.isdigit() and len(raw_limit) <= 3,
                                    "limit must be 1-200.")
                            limit = int(raw_limit)
                            integer(limit, "limit", 1, 200)
                            category, search = params.get("category", ""), params.get("q", "")
                            require(not category or category in CATEGORIES, "Unknown fact category.")
                            text(search, "query", 256)
                            memory = brain.knowledge.world_summary(world)
                            body = {"facts": brain.knowledge.query_facts(world, search, category, limit),
                                    "summary": {k: memory[k] for k in ("fact_count", "relation_count", "pattern_count", "categories")}}
                    self.reply(200, body)
                else:
                    self.reply(404, {"error": "Unknown endpoint."})
            except (ValueError, OverflowError) as error:
                self.reply(400, {"error": str(error)})
            except sqlite3.Error:
                self.reply(503, {"error": "Storage unavailable."})

        def do_POST(self):
            if not self.authorized():
                return
            if self.path not in ("/v1/tick", "/v2/tick"):
                self.reply(404, {"error": "Unknown endpoint."})
                return
            if self.headers.get("Transfer-Encoding") is not None:
                self.reply(400, {"error": "Transfer encoding is unsupported."})
                return
            lengths = self.headers.get_all("Content-Length", [])
            if len(lengths) != 1 or not lengths[0].isascii() or not lengths[0].isdigit() or len(lengths[0]) > 10:
                self.reply(411, {"error": "One valid Content-Length is required."})
                return
            size = int(lengths[0])
            if size <= 0 or size > MAX_BODY:
                self.reply(413, {"error": "Request size limit exceeded."})
                return
            if self.headers.get_content_type() != "application/json":
                self.reply(415, {"error": "Content-Type application/json required."})
                return
            try:
                raw = self.rfile.read(size)
                require(len(raw) == size, "Incomplete request body.")
                if self.path == "/v2/tick":
                    self.reply(200, brain.tick_v2(decode_request(raw, expected_version=2)))
                else:
                    self.reply(200, brain.tick(decode_request(raw)))
            except ProtocolError as error:
                self.reply(error.status, {"error": str(error)})
            except (TimeoutError, ConnectionError):
                self.close_connection = True
            except sqlite3.Error:
                self.reply(503, {"error": "Storage unavailable or full; no new plan committed."})
            except Exception:
                self.reply(500, {"error": "Planner error; request was not acknowledged."})

    return LocalServer(("127.0.0.1", port), Handler)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--db", type=Path, default=Path(__file__).resolve().parent / "state" / "brain.sqlite3")
    args = parser.parse_args()
    token = os.environ.get("AICORE_TOKEN", "")
    if not token:
        parser.error("Set AICORE_TOKEN to a random local token of at least 16 characters. Never use cloud API credentials.")
    if not 1 <= args.port <= 65535:
        parser.error("Port must be between 1 and 65535.")
    try:
        require(16 <= len(token) <= 4096 and all(32 < ord(c) < 127 for c in token), "Invalid AICORE_TOKEN.")
    except ProtocolError as error:
        parser.error(str(error))
    args.db.parent.mkdir(parents=True, exist_ok=True)
    brain = Brain(args.db)
    server = make_server(brain, token, args.port)
    print(f"AICore listening at http://127.0.0.1:{args.port}; database: {args.db}", flush=True)
    print("Bounded population goals, knowledge storage and placement feedback. Ctrl+C to stop.", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        brain.close()


if __name__ == "__main__":
    main()
