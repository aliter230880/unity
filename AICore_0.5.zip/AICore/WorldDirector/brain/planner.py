"""Shared-budget helpers for the supported population planner.

Only the four Unity executor actions are advertised. Environment/terrain/behavior
adapters are not implemented and must not be presented as working capabilities.
"""
from __future__ import annotations

CORE_ACTIONS = ("spawn", "move", "activate", "deactivate")


def validate_capabilities(caps) -> dict:
    if not isinstance(caps, dict):
        raise ValueError("capabilities must be an object.")
    unknown = set(caps) - {"action_types"}
    if unknown:
        raise ValueError("Unsupported capability fields; only action_types is implemented.")
    actions = caps.get("action_types", list(CORE_ACTIONS))
    if not isinstance(actions, list) or len(actions) > len(CORE_ACTIONS):
        raise ValueError("action_types must be a bounded list.")
    if any(not isinstance(a, str) or a not in CORE_ACTIONS for a in actions):
        raise ValueError("Unsupported action capability.")
    if len(set(actions)) != len(actions):
        raise ValueError("Duplicate action capability.")
    # Explicit [] means no actions, never a permissive fallback.
    return {"action_types": list(actions)}


class MultiObjectivePlanner:
    @staticmethod
    def allocate_budget(goals: list[dict], budget: int) -> list[dict]:
        result = [dict(g, allocated_budget=0) for g in goals]
        active = sorted((g for g in result if g.get("status") == "active"),
                        key=lambda g: (-g.get("priority", 1), g["goal_id"]))
        remaining = max(0, budget)
        # First provide a slot per goal, where possible; redistribute proportionally.
        for goal in active:
            if not remaining:
                break
            goal["allocated_budget"] = 1
            remaining -= 1
        while remaining and active:
            goal = max(active, key=lambda g: max(1, g.get("priority", 1)) / (g["allocated_budget"] + 1))
            goal["allocated_budget"] += 1
            remaining -= 1
        return sorted(result, key=lambda g: (-g.get("priority", 1), g["goal_id"]))
