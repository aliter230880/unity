"""Knowledge base for AICore brain.

Stores facts about the world, entity relationships, and learned patterns.
This is NOT a neural model or embedding store. It is a structured fact
repository that the planner can query to make informed decisions.

Knowledge is:
  - World-scoped (facts about "world-1" don't leak to "world-2")
  - Categorized (terrain, economy, population, narrative, performance)
  - Confidence-weighted (0.0 to 1.0)
  - Bounded (max 10,000 facts per world to prevent unbounded growth)
  - Timestamped (facts decay in confidence over time unless refreshed)
"""
from __future__ import annotations

import json
import math
import sqlite3
import time
from typing import Any

MAX_FACTS_PER_WORLD = 10_000
MAX_RELATIONS_PER_WORLD = 5_000
MAX_PATTERNS_PER_WORLD = 1_000
CATEGORIES = ("terrain", "economy", "population", "narrative", "performance",
              "weather", "entity", "player", "system", "custom")
CONFIDENCE_DECAY_SECONDS = 3600.0  # Facts lose 50% confidence per hour unless refreshed


class KnowledgeError(ValueError):
    pass


def validate_fact(fact: Any) -> dict:
    if not isinstance(fact, dict):
        raise KnowledgeError("Fact must be an object.")
    key = fact.get("key", "")
    if not isinstance(key, str) or not key or len(key) > 256:
        raise KnowledgeError("Invalid fact key.")
    value = fact.get("value")
    if not isinstance(value, (str, int, float, bool)) or (isinstance(value, str) and len(value) > 2000):
        raise KnowledgeError("Fact value must be a primitive or short string.")
    category = fact.get("category", "custom")
    if category not in CATEGORIES:
        raise KnowledgeError(f"category must be one of {CATEGORIES}.")
    confidence = fact.get("confidence", 0.5)
    if not isinstance(confidence, (int, float)) or not math.isfinite(confidence) or confidence < 0 or confidence > 1:
        raise KnowledgeError("confidence must be 0.0-1.0.")
    if type(confidence) is bool:
        raise KnowledgeError("confidence must be numeric, not boolean.")
    if type(value) in (int, float):
        try:
            if not math.isfinite(value) or abs(value) > 3.4e38:
                raise KnowledgeError("Fact value must be finite and bounded.")
        except OverflowError as error:
            raise KnowledgeError("Fact value is too large.") from error
    return {"key": key, "value": value, "category": category, "confidence": float(confidence)}


def validate_relation(rel: Any) -> dict:
    if not isinstance(rel, dict):
        raise KnowledgeError("Relation must be an object.")
    source = rel.get("source_id", "")
    target = rel.get("target_id", "")
    if not isinstance(source, str) or not source or len(source) > 96:
        raise KnowledgeError("Invalid relation source_id.")
    if not isinstance(target, str) or not target or len(target) > 96:
        raise KnowledgeError("Invalid relation target_id.")
    rel_type = rel.get("type", "")
    if not isinstance(rel_type, str) or not rel_type or len(rel_type) > 64:
        raise KnowledgeError("Invalid relation type.")
    strength = rel.get("strength", 0.5)
    if not isinstance(strength, (int, float)) or not math.isfinite(strength) or strength < 0 or strength > 1:
        raise KnowledgeError("relation strength must be 0.0-1.0.")
    if type(strength) is bool:
        raise KnowledgeError("strength must be numeric, not boolean.")
    return {"source_id": source, "target_id": target, "type": rel_type, "strength": float(strength)}


class KnowledgeBase:
    """Structured world knowledge with confidence-weighted facts and relations."""

    SCHEMA = """
    CREATE TABLE IF NOT EXISTS facts (
        world TEXT NOT NULL,
        key TEXT NOT NULL,
        value TEXT NOT NULL,
        category TEXT NOT NULL DEFAULT 'custom',
        confidence REAL NOT NULL DEFAULT 0.5,
        updated REAL NOT NULL,
        access_count INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY(world, key)
    );
    CREATE INDEX IF NOT EXISTS fact_category ON facts(world, category);
    CREATE INDEX IF NOT EXISTS fact_confidence ON facts(world, confidence DESC);

    CREATE TABLE IF NOT EXISTS relations (
        world TEXT NOT NULL,
        source_id TEXT NOT NULL,
        target_id TEXT NOT NULL,
        type TEXT NOT NULL,
        strength REAL NOT NULL DEFAULT 0.5,
        updated REAL NOT NULL,
        PRIMARY KEY(world, source_id, target_id, type)
    );
    CREATE INDEX IF NOT EXISTS relation_source ON relations(world, source_id);
    CREATE INDEX IF NOT EXISTS relation_target ON relations(world, target_id);

    CREATE TABLE IF NOT EXISTS patterns (
        world TEXT NOT NULL,
        pattern_type TEXT NOT NULL,
        pattern_data TEXT NOT NULL,
        reward REAL NOT NULL DEFAULT 0.0,
        samples INTEGER NOT NULL DEFAULT 0,
        updated REAL NOT NULL,
        id INTEGER PRIMARY KEY AUTOINCREMENT
    );
    CREATE INDEX IF NOT EXISTS pattern_type ON patterns(world, pattern_type);
    """

    def __init__(self, db: sqlite3.Connection):
        self.db = db
        self.db.executescript(self.SCHEMA)
        self.db.commit()

    def upsert_fact(self, world: str, fact: dict, *, commit: bool = True) -> None:
        fact = validate_fact(fact)
        now = time.time()
        self.db.execute(
            """INSERT INTO facts(world, key, value, category, confidence, updated)
               VALUES(?,?,?,?,?,?)
               ON CONFLICT(world, key) DO UPDATE SET
               value=excluded.value, category=excluded.category,
               confidence=excluded.confidence, updated=excluded.updated""",
            (world, fact["key"], str(fact["value"]), fact["category"],
             fact["confidence"], now))
        self._enforce_limit(world)
        if commit:
            self.db.commit()

    def upsert_facts(self, world: str, facts: list[dict]) -> list[str]:
        warnings = []
        for fact in facts:
            try:
                self.upsert_fact(world, fact)
            except (KnowledgeError, sqlite3.Error) as e:
                warnings.append(f"Fact rejected: {e}")
        return warnings

    def get_fact(self, world: str, key: str) -> dict | None:
        self.db.execute(
            "UPDATE facts SET access_count=access_count+1 WHERE world=? AND key=?",
            (world, key))
        self.db.commit()
        row = self.db.execute(
            "SELECT * FROM facts WHERE world=? AND key=?", (world, key)).fetchone()
        if row is None:
            return None
        # Apply time-based confidence decay
        now = time.time()
        age = now - row["updated"]
        decayed_confidence = row["confidence"] * (0.5 ** (age / CONFIDENCE_DECAY_SECONDS))
        return {"key": row["key"], "value": row["value"], "category": row["category"],
                "confidence": decayed_confidence, "age_seconds": age,
                "access_count": row["access_count"]}

    def facts_by_category(self, world: str, category: str, limit: int = 100) -> list[dict]:
        rows = self.db.execute(
            "SELECT * FROM facts WHERE world=? AND category=? ORDER BY confidence DESC LIMIT ?",
            (world, category, limit)).fetchall()
        now = time.time()
        result = []
        for row in rows:
            age = now - row["updated"]
            confidence = row["confidence"] * (0.5 ** (age / CONFIDENCE_DECAY_SECONDS))
            result.append({"key": row["key"], "value": row["value"],
                          "category": row["category"], "confidence": confidence,
                          "age_seconds": age, "access_count": row["access_count"]})
        return result

    def upsert_relation(self, world: str, relation: dict, *, commit: bool = True) -> None:
        relation = validate_relation(relation)
        now = time.time()
        self.db.execute(
            """INSERT INTO relations(world, source_id, target_id, type, strength, updated)
               VALUES(?,?,?,?,?,?)
               ON CONFLICT(world, source_id, target_id, type) DO UPDATE SET
               strength=excluded.strength, updated=excluded.updated""",
            (world, relation["source_id"], relation["target_id"],
             relation["type"], relation["strength"], now))
        count = self.db.execute(
            "SELECT COUNT(*) FROM relations WHERE world=?", (world,)).fetchone()[0]
        if count > MAX_RELATIONS_PER_WORLD:
            # Evict weakest oldest relations
            self.db.execute(
                """DELETE FROM relations WHERE rowid IN (
                   SELECT rowid FROM relations WHERE world=? ORDER BY strength ASC, updated ASC LIMIT ?)""",
                (world, count - MAX_RELATIONS_PER_WORLD))
        if commit:
            self.db.commit()

    def get_relations(self, world: str, entity_id: str, limit: int = 50) -> list[dict]:
        rows = self.db.execute(
            """SELECT * FROM relations WHERE world=? AND (source_id=? OR target_id=?)
               ORDER BY strength DESC LIMIT ?""",
            (world, entity_id, entity_id, limit)).fetchall()
        return [dict(row) for row in rows]

    def record_pattern(self, world: str, pattern_type: str, pattern_data: dict, reward: float = 0.0) -> None:
        now = time.time()
        data_json = json.dumps(pattern_data, sort_keys=True, separators=(",", ":"))
        existing = self.db.execute(
            "SELECT id, samples, reward FROM patterns WHERE world=? AND pattern_type=? AND pattern_data=?",
            (world, pattern_type, data_json)).fetchone()
        if existing:
            new_reward = (existing["reward"] * existing["samples"] + reward) / (existing["samples"] + 1)
            self.db.execute(
                "UPDATE patterns SET samples=samples+1, reward=?, updated=? WHERE id=?",
                (new_reward, now, existing["id"]))
        else:
            self.db.execute(
                "INSERT INTO patterns(world, pattern_type, pattern_data, reward, samples, updated) VALUES(?,?,?,?,?,?)",
                (world, pattern_type, data_json, reward, 1, now))
            count = self.db.execute(
                "SELECT COUNT(*) FROM patterns WHERE world=?", (world,)).fetchone()[0]
            if count > MAX_PATTERNS_PER_WORLD:
                self.db.execute(
                    """DELETE FROM patterns WHERE id IN (
                       SELECT id FROM patterns WHERE world=? ORDER BY reward ASC, samples ASC LIMIT ?)""",
                    (world, count - MAX_PATTERNS_PER_WORLD))
        self.db.commit()

    def best_patterns(self, world: str, pattern_type: str, limit: int = 10) -> list[dict]:
        rows = self.db.execute(
            "SELECT * FROM patterns WHERE world=? AND pattern_type=? ORDER BY reward DESC, samples DESC LIMIT ?",
            (world, pattern_type, limit)).fetchall()
        result = []
        for row in rows:
            result.append({
                "pattern_type": row["pattern_type"],
                "pattern_data": json.loads(row["pattern_data"]),
                "reward": row["reward"],
                "samples": row["samples"],
                "updated": row["updated"]
            })
        return result

    def query_facts(self, world: str, query: str = "", category: str = "", limit: int = 50) -> list[dict]:
        sql = "SELECT * FROM facts WHERE world=?"
        params = [world]
        if category and category in CATEGORIES:
            sql += " AND category=?"
            params.append(category)
        if query:
            sql += " AND key LIKE ?"
            params.append(f"%{query}%")
        sql += " ORDER BY confidence DESC, updated DESC LIMIT ?"
        params.append(limit)
        rows = self.db.execute(sql, params).fetchall()
        now = time.time()
        result = []
        for row in rows:
            age = now - row["updated"]
            confidence = row["confidence"] * (0.5 ** (age / CONFIDENCE_DECAY_SECONDS))
            result.append({"key": row["key"], "value": row["value"],
                          "category": row["category"], "confidence": confidence,
                          "age_seconds": age, "access_count": row["access_count"]})
        return result

    def _enforce_limit(self, world: str) -> None:
        count = self.db.execute(
            "SELECT COUNT(*) FROM facts WHERE world=?", (world,)).fetchone()[0]
        if count > MAX_FACTS_PER_WORLD:
            self.db.execute(
                """DELETE FROM facts WHERE rowid IN (
                   SELECT rowid FROM facts WHERE world=? ORDER BY confidence ASC, access_count ASC, updated ASC LIMIT ?)""",
                (world, count - MAX_FACTS_PER_WORLD))

    def world_summary(self, world: str) -> dict:
        fact_count = self.db.execute(
            "SELECT COUNT(*) FROM facts WHERE world=?", (world,)).fetchone()[0]
        relation_count = self.db.execute(
            "SELECT COUNT(*) FROM relations WHERE world=?", (world,)).fetchone()[0]
        pattern_count = self.db.execute(
            "SELECT COUNT(*) FROM patterns WHERE world=?", (world,)).fetchone()[0]
        categories = {}
        for cat in CATEGORIES:
            c = self.db.execute(
                "SELECT COUNT(*) FROM facts WHERE world=? AND category=?", (world, cat)).fetchone()[0]
            if c > 0:
                categories[cat] = c
        top_facts = self.query_facts(world, limit=10)
        return {
            "fact_count": fact_count,
            "relation_count": relation_count,
            "pattern_count": pattern_count,
            "categories": categories,
            "top_facts": top_facts,
        }
