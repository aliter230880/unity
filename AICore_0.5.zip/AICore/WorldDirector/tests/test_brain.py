from __future__ import annotations

from copy import deepcopy
import http.client
import importlib.util
import json
from pathlib import Path
import tempfile
import sys
import threading
import unittest


TEST_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(TEST_ROOT.parent / "brain"))
spec = importlib.util.spec_from_file_location("population_server", TEST_ROOT.parent / "brain" / "server.py")
server = importlib.util.module_from_spec(spec)
spec.loader.exec_module(server)


def entity(entity_id="entity-1", **changes):
    value = {"id": entity_id, "catalog_id": "crate", "kind": "prop", "active": True,
             "owned": True, "position": {"x": 0.0, "y": 0.0, "z": 0.0}}
    value.update(changes)
    return value


def request(entities=(), **changes):
    safe_entities = entities if isinstance(entities, (list, tuple)) else ()
    entity_payload = list(entities) if isinstance(entities, (list, tuple)) else entities
    observed_owned = sum(e.get("owned", False) for e in safe_entities if isinstance(e, dict))
    value = {
        "protocol_version": 1, "world_id": "world-1", "session_id": "session-1",
        "observation_id": "observation-1", "goal": "Maintain the explicit crate population.",
        "target_catalog_id": "crate", "target_count": 3,
        "anchor": {"x": 0.0, "y": 0.0, "z": 0.0},
        "allow_mutations": True, "entities_truncated": False,
        "limits": {"min": {"x": -100.0, "y": -100.0, "z": -100.0},
                   "max": {"x": 100.0, "y": 100.0, "z": 100.0},
                   "max_owned_entities": 100, "owned_entity_count": observed_owned,
                   "action_budget": 8},
        "entities": entity_payload, "catalog": [{"id": "crate", "kind": "prop"},
                                               {"id": "other", "kind": "prop"}],
        "results": [], "events": [], "feedback": [],
    }
    value.update(changes)
    return value


def result(action_id, status="executed"):
    return {"action_id": action_id, "status": status, "message": "Execution result."}


def feedback(action_id, reward=1.0):
    return {"action_id": action_id, "reward": reward}


class RequestValidationTests(unittest.TestCase):
    def test_legacy_request_and_optional_boolean_values(self):
        data = request([entity()])
        original = deepcopy(data)
        self.assertEqual(server.decode_request(server.canonical(data).encode()), original)
        self.assertEqual(data, original)
        self.assertNotIn("allow_reactivation", data)
        self.assertNotIn("reactivatable", data["entities"][0])
        for allow in (True, False):
            for reusable in (True, False):
                with self.subTest(allow=allow, reusable=reusable):
                    server.validate_request(request([entity(reactivatable=reusable)], allow_reactivation=allow))

    def test_invalid_optional_flags_are_rejected_even_in_observe_mode(self):
        for flag in ("allow_reactivation", "reactivatable"):
            for value in (None, 0, 1, -1, 0.0, "true", "false", [], {}):
                with self.subTest(flag=flag, value=value):
                    data = request([entity()], allow_mutations=False)
                    destination = data if flag == "allow_reactivation" else data["entities"][0]
                    destination[flag] = value
                    with self.assertRaises(server.ProtocolError):
                        server.validate_request(data)

    def test_missing_required_fields(self):
        for field in request():
            with self.subTest(field=field):
                data = request()
                del data[field]
                with self.assertRaises(server.ProtocolError):
                    server.validate_request(data)
        for field in entity():
            with self.subTest(entity_field=field):
                item = entity()
                del item[field]
                data = request()
                data["entities"] = [item]
                with self.assertRaises(server.ProtocolError):
                    server.validate_request(data)

    def test_malformed_utf8_json_and_nonobject_roots(self):
        for raw in (b"", b"{", b"null", b"[]", b"true", b"12", b"\xff", b'{} trailing',
                    b"[" * 2000 + b"]" * 2000):
            with self.subTest(raw=raw[:40]):
                with self.assertRaises(server.ProtocolError):
                    server.decode_request(raw)

    def test_duplicate_json_keys_at_root_and_nested_levels(self):
        raw = server.canonical(request()).encode()
        duplicates = (b'{"protocol_version":1,' + raw[1:],
                      raw.replace(b'"anchor":{', b'"anchor":{"x":0,'),
                      raw.replace(b'"limits":{', b'"limits":{"action_budget":8,'))
        for malformed in duplicates:
            with self.subTest(raw=malformed[:80]):
                with self.assertRaisesRegex(server.ProtocolError, "Duplicate JSON key"):
                    server.decode_request(malformed)

    def test_nonfinite_json_and_oversized_body(self):
        raw = server.canonical(request()).encode()
        for value in (b"NaN", b"Infinity", b"-Infinity", b"1e309", b"9" * 5000):
            with self.subTest(value=value[:20]):
                malformed = raw.replace(b'"x":0.0', b'"x":' + value, 1)
                self.assertNotEqual(malformed, raw)
                with self.assertRaises(server.ProtocolError):
                    server.decode_request(malformed)
        with self.assertRaises(server.ProtocolError):
            server.decode_request(b" " * (server.MAX_BODY + 1))

    def test_invalid_integer_fields(self):
        fields = (("protocol_version",), ("target_count",), ("limits", "action_budget"),
                  ("limits", "owned_entity_count"), ("limits", "max_owned_entities"))
        for path in fields:
            for value in (True, False, None, "1", 1.0, -1, 2_147_483_648):
                with self.subTest(path=path, value=value):
                    data = request()
                    destination = data if len(path) == 1 else data[path[0]]
                    destination[path[-1]] = value
                    with self.assertRaises(server.ProtocolError):
                        server.validate_request(data)
        for field, value in (("protocol_version", 2), ("target_count", 101)):
            with self.assertRaises(server.ProtocolError):
                server.validate_request(request(**{field: value}))
        data = request()
        data["limits"]["action_budget"] = 9
        with self.assertRaises(server.ProtocolError):
            server.validate_request(data)

    def test_invalid_numeric_positions_events_and_feedback(self):
        for location in ("anchor", "entity", "min", "max", "event", "feedback"):
            for value in (True, None, "0", float("nan"), float("inf"), -float("inf"), 3.5e38, 10 ** 400):
                with self.subTest(location=location, value=str(value)[:30]):
                    data = request([entity()])
                    if location == "anchor":
                        data["anchor"]["x"] = value
                    elif location == "entity":
                        data["entities"][0]["position"]["z"] = value
                    elif location in ("min", "max"):
                        data["limits"][location]["y"] = value
                    elif location == "event":
                        data["events"] = [{"kind": "score", "value": value}]
                    else:
                        data["feedback"] = [feedback("action-1", value)]
                    with self.assertRaises(server.ProtocolError):
                        server.validate_request(data)

    def test_invalid_bounds_and_position_shape(self):
        for axis in "xyz":
            for maximum in (-100, -101):
                with self.subTest(axis=axis, maximum=maximum):
                    data = request()
                    data["limits"]["max"][axis] = maximum
                    with self.assertRaises(server.ProtocolError):
                        server.validate_request(data)
        for point in (None, [], {"x": 0, "y": 0}, {"x": 0, "y": 0, "z": 0, "w": 0}):
            with self.subTest(point=point):
                with self.assertRaises(server.ProtocolError):
                    server.validate_request(request(anchor=point))

    def test_invalid_identifiers_catalog_and_duplicate_ids(self):
        for value in (None, "", "has spaces", "x" * 97, 1):
            with self.subTest(value=value):
                with self.assertRaises(server.ProtocolError):
                    server.validate_request(request(world_id=value))
        for data in (request([entity(), entity()]),
                     request(catalog=[{"id": "crate", "kind": "prop"}] * 2),
                     request(target_catalog_id="missing"), request(target_catalog_id="")):
            with self.subTest(data=data):
                with self.assertRaises(server.ProtocolError):
                    server.validate_request(data)

    def test_invalid_collection_shapes_and_limits(self):
        for field, limit in (("entities", 512), ("catalog", 128), ("results", 32), ("events", 32), ("feedback", 32)):
            for value in (None, {}, [1], [{}] * (limit + 1)):
                with self.subTest(field=field, size=len(value) if value is not None else None):
                    with self.assertRaises(server.ProtocolError):
                        server.validate_request(request(**{field: value}))

    def test_existing_flags_remain_strict(self):
        for flag in ("allow_mutations", "entities_truncated", "active", "owned"):
            for value in (None, 0, 1, "false"):
                with self.subTest(flag=flag, value=value):
                    data = request([entity()])
                    destination = data if flag in data else data["entities"][0]
                    destination[flag] = value
                    with self.assertRaises(server.ProtocolError):
                        server.validate_request(data)

    def test_complete_snapshot_requires_exact_owned_count(self):
        for reported in (0, 1, 2, 3):
            with self.subTest(reported=reported):
                data = request([entity("active"), entity("inactive", active=False), entity("foreign", owned=False)])
                data["limits"]["owned_entity_count"] = reported
                if reported == 2:
                    server.validate_request(data)
                else:
                    with self.assertRaises(server.ProtocolError):
                        server.validate_request(data)

    def test_truncated_snapshot_allows_only_observed_count_or_more(self):
        for reported in (0, 1, 2):
            with self.subTest(reported=reported):
                data = request([entity()], entities_truncated=True)
                data["limits"]["owned_entity_count"] = reported
                if reported >= 1:
                    server.validate_request(data)
                else:
                    with self.assertRaises(server.ProtocolError):
                        server.validate_request(data)

    def test_missing_owned_marker_requires_incomplete_snapshot(self):
        data = request([entity(owned=False)])
        data["limits"]["owned_entity_count"] = 1
        with self.assertRaisesRegex(server.ProtocolError, "Complete snapshot"):
            server.validate_request(data)
        data["entities_truncated"] = True
        server.validate_request(data)


class BrainTestCase(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory(prefix="brain-test-", dir=TEST_ROOT)
        self.addCleanup(directory.cleanup)
        self.database = Path(directory.name) / "brain.sqlite3"
        self.assertEqual(self.database.parent.parent, TEST_ROOT)
        self.brain = server.Brain(self.database)
        self.addCleanup(lambda: self.brain.close())
        self.sequence = 0

    def tick(self, data=None, **changes):
        self.sequence += 1
        data = deepcopy(data) if data is not None else request()
        data["observation_id"] = f"observation-{self.sequence}"
        data.update(changes)
        return self.brain.tick(data)

    def stored_action(self, action_id, world="world-1", session="session-1"):
        row = self.brain.db.execute("SELECT * FROM actions WHERE world=? AND session=? AND action=?",
                                    (world, session, action_id)).fetchone()
        return dict(row) if row is not None else None


class PopulationTests(BrainTestCase):
    def test_observe_never_mutates(self):
        data = request([entity(active=False, reactivatable=True)], allow_reactivation=True, allow_mutations=False)
        response = self.tick(data)
        self.assertEqual(response["actions"], [])
        self.assertIn("Observing only", response["summary"])
        self.assertEqual(self.brain.stats()["actions"], 0)

    def test_zero_budget_prevents_spawn_activate_and_deactivate(self):
        for target in (0, 3):
            with self.subTest(target=target):
                data = request([entity("active"), entity("inactive", active=False, reactivatable=True)],
                               target_count=target, allow_reactivation=True)
                data["limits"]["action_budget"] = 0
                self.assertEqual(self.tick(data)["actions"], [])

    def test_player_catalog_is_protected(self):
        for kind in ("player", "PlAyEr", "PLAYER"):
            with self.subTest(kind=kind):
                data = request([entity(active=False, reactivatable=True)], allow_reactivation=True)
                data["catalog"][0]["kind"] = kind
                response = self.tick(data)
                self.assertEqual(response["actions"], [])
                self.assertIn("Player catalogs cannot be controlled.", response["warnings"])

    def test_truncated_snapshot_never_infers_population(self):
        for target in (0, 3):
            with self.subTest(target=target):
                data = request([entity(), entity("inactive", active=False, reactivatable=True)],
                               target_count=target, allow_reactivation=True, entities_truncated=True)
                data["limits"]["owned_entity_count"] += 1
                response = self.tick(data)
                self.assertEqual(response["actions"], [])
                self.assertTrue(any("incomplete" in warning for warning in response["warnings"]))

    def test_no_explicit_target_does_not_use_goal_text(self):
        response = self.tick(target_catalog_id="", target_count=0, goal="Spawn lots of crates anyway.")
        self.assertEqual(response["actions"], [])

    def test_target_met_after_execution_does_not_propose_duplicates(self):
        first = self.tick(target_count=3)
        self.assertEqual(len(first["actions"]), 3)
        self.assertEqual(len({action["id"] for action in first["actions"]}), 3)
        entities = [entity(f"spawned-{index}", position=action["position"])
                    for index, action in enumerate(first["actions"])]
        second = self.tick(request(entities, target_count=3, allow_reactivation=True))
        self.assertEqual(second["actions"], [])
        self.assertIn("Target satisfied: 3", second["summary"])
        self.assertEqual(first["source"], "local_population_v1")

    def test_inactive_owned_roots_of_other_catalogs_consume_cap(self):
        data = request([entity("inactive", active=False, catalog_id="other"), entity("foreign", owned=False)])
        data["limits"]["max_owned_entities"] = 2
        response = self.tick(data)
        self.assertEqual([action["type"] for action in response["actions"]], ["spawn"])
        self.assertIn("0 activations and 1 spawns", response["summary"])
        self.assertTrue(any("cap" in warning for warning in response["warnings"]))

    def test_no_spawning_at_or_above_cap(self):
        for cap in (0, 1):
            with self.subTest(cap=cap):
                data = request([entity(active=False)])
                data["limits"]["max_owned_entities"] = cap
                response = self.tick(data)
                self.assertEqual(response["actions"], [])
                self.assertIn("0 activations and 0 spawns", response["summary"])
                self.assertIn("deficit remains", response["summary"])

    def test_reuses_same_guid_at_and_above_full_cap(self):
        guid = "644f5803-2eb4-4f74-9f9e-dae8e2b4db21"
        for cap in (0, 1):
            with self.subTest(cap=cap):
                data = request([entity(guid, active=False, reactivatable=True)], target_count=1, allow_reactivation=True)
                data["limits"]["max_owned_entities"] = cap
                response = self.tick(data)
                self.assertEqual(len(response["actions"]), 1)
                action = response["actions"][0]
                self.assertEqual(set(action), {"id", "type", "target_id", "catalog_id", "reason"})
                self.assertEqual((action["type"], action["target_id"], action["catalog_id"]), ("activate", guid, "crate"))
                self.assertTrue(action["reason"])
                self.assertIn("1 activations and 0 spawns", response["summary"])
                self.assertNotIn("deficit remains", response["summary"])

    def test_omitted_allow_reactivation_defaults_false(self):
        data = request([entity(active=False, reactivatable=True)], target_count=1)
        response = self.tick(data)
        self.assertEqual([action["type"] for action in response["actions"]], ["spawn"])
        self.assertNotIn("allow_reactivation", data)

    def test_false_allow_reactivation_disables_reuse(self):
        data = request([entity(active=False, reactivatable=True)], target_count=1, allow_reactivation=False)
        self.assertEqual([action["type"] for action in self.tick(data)["actions"]], ["spawn"])

    def test_omitted_entity_reactivatable_defaults_false(self):
        data = request([entity(active=False)], target_count=1, allow_reactivation=True)
        self.assertEqual([action["type"] for action in self.tick(data)["actions"]], ["spawn"])

    def test_reactivation_candidates_are_sorted_by_stable_id(self):
        entities = [entity(key, active=False, reactivatable=True) for key in ("c-guid", "a-guid", "b-guid")]
        data = request(entities, target_count=2, allow_reactivation=True)
        for ordered in (entities, list(reversed(entities))):
            response = self.tick(data, entities=ordered)
            self.assertEqual([action["target_id"] for action in response["actions"]], ["a-guid", "b-guid"])
            self.assertEqual(len({action["target_id"] for action in response["actions"]}), 2)

    def test_reactivation_respects_deficit_and_action_budget(self):
        entities = [entity(f"guid-{index}", active=False, reactivatable=True) for index in range(10)]
        for target, budget, expected in ((1, 8, 1), (10, 3, 3), (10, 8, 8)):
            with self.subTest(target=target, budget=budget):
                data = request(entities, target_count=target, allow_reactivation=True)
                data["limits"]["action_budget"] = budget
                actions = self.tick(data)["actions"]
                self.assertEqual(len(actions), expected)
                self.assertTrue(all(action["type"] == "activate" for action in actions))

    def test_nonowned_player_nonreactivatable_and_wrong_catalog_are_not_reused(self):
        entities = [entity("eligible", active=False, reactivatable=True),
                    entity("foreign", active=False, owned=False, reactivatable=True),
                    entity("player", active=False, kind="PlAyEr", reactivatable=True),
                    entity("disabled", active=False, reactivatable=False),
                    entity("omitted", active=False),
                    entity("other", active=False, catalog_id="other", reactivatable=True),
                    entity("active", reactivatable=True)]
        data = request(entities, target_count=10, allow_reactivation=True)
        data["limits"]["max_owned_entities"] = data["limits"]["owned_entity_count"]
        actions = self.tick(data)["actions"]
        self.assertEqual([(a["type"], a["target_id"]) for a in actions], [("activate", "eligible")])

    def test_reactivation_bounds_are_inclusive_on_every_axis(self):
        for axis in "xyz":
            for coordinate, expected in ((-101, 0), (-100, 1), (100, 1), (101, 0)):
                with self.subTest(axis=axis, coordinate=coordinate):
                    point = {"x": 0, "y": 0, "z": 0}
                    point[axis] = coordinate
                    data = request([entity(active=False, reactivatable=True, position=point)],
                                   target_count=1, allow_reactivation=True)
                    data["limits"]["max_owned_entities"] = 1
                    self.assertEqual(len(self.tick(data)["actions"]), expected)

    def test_mixed_activation_and_spawn_share_budget_not_cap(self):
        entities = [entity(key, active=False, reactivatable=True) for key in ("b", "a")]
        for budget, cap, expected in ((4, 10, ["activate", "activate", "spawn", "spawn"]),
                                      (4, 3, ["activate", "activate", "spawn"]),
                                      (2, 10, ["activate", "activate"])):
            with self.subTest(budget=budget, cap=cap):
                data = request(entities, target_count=6, allow_reactivation=True)
                data["limits"].update(action_budget=budget, max_owned_entities=cap)
                response = self.tick(data)
                self.assertEqual([action["type"] for action in response["actions"]], expected)
                self.assertEqual([action["target_id"] for action in response["actions"][:2]], ["a", "b"])
                self.assertIn(f"2 activations and {expected.count('spawn')} spawns", response["summary"])
                self.assertIn("deficit remains", response["summary"])

    def test_reactivated_and_active_positions_block_subsequent_spawns(self):
        entities = [entity("reuse", active=False, reactivatable=True, position={"x": 2.0, "y": 0.0, "z": 0.0}),
                    entity("foreign", owned=False, position={"x": 0.0, "y": 0.0, "z": 0.0})]
        response = self.tick(request(entities, target_count=5, allow_reactivation=True))
        self.assertEqual([a["type"] for a in response["actions"]], ["activate"] + ["spawn"] * 4)
        occupied = [e["position"] for e in entities]
        for action in response["actions"][1:]:
            point = action["position"]
            self.assertTrue(server.Brain._inside(point, request()["limits"]))
            for other in occupied:
                self.assertGreaterEqual(sum((point[axis] - other[axis]) ** 2 for axis in "xyz"), 1.0)
            occupied.append(point)
        self.assertNotEqual(response["actions"][1]["position"], entities[0]["position"])

    def test_compact_and_spread_placement_are_preserved(self):
        for spacing, strategy in ((2.0, "compact"), (5.0, "spread")):
            with self.subTest(strategy=strategy):
                response = self.tick(target_count=1)
                action = response["actions"][0]
                self.assertEqual(action["position"], {"x": spacing, "y": 0.0, "z": 0.0})
                self.assertEqual(action["target_id"], "")
                self.assertIn(strategy, action["reason"])
                self.assertIn(strategy, response["summary"])

    def test_tight_bounds_report_actual_counts_not_requested_spawns(self):
        data = request([entity(active=False, reactivatable=True)], target_count=3, allow_reactivation=True)
        data["limits"].update(min={axis: -0.1 for axis in "xyz"}, max={axis: 0.1 for axis in "xyz"})
        response = self.tick(data)
        self.assertEqual([a["type"] for a in response["actions"]], ["activate"])
        self.assertIn("1 activations and 0 spawns", response["summary"])
        self.assertIn("deficit remains", response["summary"])
        self.assertTrue(any("point-separated" in warning for warning in response["warnings"]))

    def test_downsize_only_deactivates_sorted_eligible_owned_entities(self):
        entities = [entity(key) for key in ("c", "b", "a")]
        entities += [entity("player", kind="Player"), entity("foreign", owned=False),
                     entity("inactive", active=False), entity("other", catalog_id="other"),
                     entity("outside", position={"x": 101, "y": 0, "z": 0})]
        data = request(entities, target_count=1, allow_reactivation=True)
        data["limits"]["action_budget"] = 2
        response = self.tick(data)
        self.assertEqual([(a["type"], a["target_id"]) for a in response["actions"]],
                         [("deactivate", "a"), ("deactivate", "b")])
        self.assertTrue(all("position" not in action for action in response["actions"]))
        self.assertIn("2 deactivations", response["summary"])
        self.assertTrue(any("still consume" in warning for warning in response["warnings"]))

    def test_downsize_then_reactivate_preserves_guid_at_full_cap(self):
        data = request([entity("stable-guid", reactivatable=True)], target_count=0, allow_reactivation=True)
        data["limits"]["max_owned_entities"] = 1
        down = self.tick(data)["actions"][0]
        self.assertEqual(down["type"], "deactivate")
        data["entities"][0]["active"] = False
        data["target_count"] = 1
        data["results"] = [result(down["id"])]
        up = self.tick(data)["actions"][0]
        self.assertEqual((up["type"], up["target_id"]), ("activate", down["target_id"]))


class ReplayTests(BrainTestCase):
    def test_same_request_is_idempotent_and_key_order_is_irrelevant(self):
        data = request([entity(active=False, reactivatable=True)], allow_reactivation=True)
        first = self.brain.tick(data)
        stats = self.brain.stats()
        reordered = dict(reversed(list(deepcopy(data).items())))
        self.assertEqual(self.brain.tick(reordered), first)
        self.assertEqual(self.brain.stats(), stats)
        first["actions"].clear()
        self.assertTrue(self.brain.tick(data)["actions"])

    def test_different_body_for_same_observation_conflicts_without_writes(self):
        data = request(target_count=1)
        first = self.brain.tick(data)
        stats = self.brain.stats()
        for changes in ({"target_count": 2}, {"allow_reactivation": False},
                        {"results": [result(first["actions"][0]["id"])],
                         "feedback": [feedback(first["actions"][0]["id"])]}):
            with self.subTest(changes=changes):
                changed = deepcopy(data)
                changed.update(changes)
                with self.assertRaises(server.ProtocolError) as raised:
                    self.brain.tick(changed)
                self.assertEqual(raised.exception.status, 409)
                self.assertEqual(self.brain.stats(), stats)
                self.assertIsNone(self.stored_action(first["actions"][0]["id"])["status"])

    def test_observation_and_action_ids_are_scoped_to_world_and_session(self):
        plans = []
        for world, session in (("world-1", "session-1"), ("world-2", "session-1"), ("world-1", "session-2")):
            data = request(world_id=world, session_id=session, target_count=1)
            response = self.brain.tick(data)
            plans.append(response)
            self.assertEqual(self.brain.tick(data), response)
        self.assertEqual(len({plan["plan_id"] for plan in plans}), 3)
        self.assertEqual(len({plan["actions"][0]["id"] for plan in plans}), 3)
        self.assertEqual(self.brain.stats()["observations"], 3)

    def test_invalid_request_does_not_create_observation_or_action(self):
        data = request(allow_reactivation=1)
        with self.assertRaises(server.ProtocolError):
            self.brain.tick(data)
        self.assertEqual(self.brain.stats(), {"observations": 0, "actions": 0, "rated_actions": 0, "learning": []})


class LearningTests(BrainTestCase):
    def test_proposals_and_unattributed_events_do_not_train(self):
        self.tick(target_count=1)
        self.tick(allow_mutations=False, events=[{"kind": "reward", "value": 100}])
        self.assertEqual(self.brain.stats()["learning"], [])
        self.assertEqual(self.brain.stats()["rated_actions"], 0)

    def test_feedback_requires_executed_spawn_and_can_be_retried_after_execution(self):
        action = self.tick(target_count=1)["actions"][0]
        ignored = self.tick(allow_mutations=False, feedback=[feedback(action["id"])])
        self.assertTrue(any("executed action" in warning for warning in ignored["warnings"]))
        self.assertEqual(self.brain.stats()["learning"], [])
        self.assertIsNone(self.stored_action(action["id"])["reward"])
        self.tick(allow_mutations=False, results=[result(action["id"])])
        self.assertEqual(self.brain.stats()["learning"], [])
        self.tick(allow_mutations=False, feedback=[feedback(action["id"], 0.75)])
        self.assertEqual(self.brain.stats()["learning"],
                         [{"world": "world-1", "catalog": "crate", "strategy": "compact", "samples": 1, "reward_sum": 0.75}])

    def test_failed_and_rejected_spawns_never_train(self):
        for status in ("failed", "rejected"):
            with self.subTest(status=status):
                action = self.tick(target_count=1)["actions"][0]
                self.tick(allow_mutations=False, results=[result(action["id"], status)], feedback=[feedback(action["id"])])
                response = self.tick(allow_mutations=False, results=[result(action["id"])], feedback=[feedback(action["id"])])
                self.assertTrue(any("Conflicting result" in warning for warning in response["warnings"]))
                self.assertEqual(self.stored_action(action["id"])["status"], status)
                self.assertIsNone(self.stored_action(action["id"])["reward"])
        self.assertEqual(self.brain.stats()["learning"], [])

    def test_reward_is_applied_once_across_duplicates_and_observation_replays(self):
        action = self.tick(target_count=1)["actions"][0]
        data = request(allow_mutations=False, observation_id="rating",
                       results=[result(action["id"])] * 2,
                       feedback=[feedback(action["id"], 0.5), feedback(action["id"], -1)])
        response = self.brain.tick(data)
        self.assertEqual(self.brain.tick(deepcopy(data)), response)
        self.tick(allow_mutations=False, feedback=[feedback(action["id"], -1)])
        learning = self.brain.stats()["learning"]
        self.assertEqual(len(learning), 1)
        self.assertEqual((learning[0]["samples"], learning[0]["reward_sum"]), (1, 0.5))
        self.assertEqual(self.stored_action(action["id"])["reward"], 0.5)
        self.assertEqual(self.brain.stats()["rated_actions"], 1)

    def test_reward_clamping_and_zero_reward_are_terminal(self):
        for reward, expected in ((5, 1.0), (-5, -1.0), (0, 0.0)):
            with self.subTest(reward=reward):
                action = self.tick(target_count=1)["actions"][0]
                response = self.tick(allow_mutations=False, results=[result(action["id"])], feedback=[feedback(action["id"], reward)])
                self.assertEqual(self.stored_action(action["id"])["reward"], expected)
                self.assertEqual(any("clamped" in warning for warning in response["warnings"]), reward != expected)
                self.tick(allow_mutations=False, feedback=[feedback(action["id"], 0.25)])
                self.assertEqual(self.stored_action(action["id"])["reward"], expected)
        self.assertEqual(sum(row["samples"] for row in self.brain.stats()["learning"]), 3)
        self.assertEqual(sum(row["reward_sum"] for row in self.brain.stats()["learning"]), 0.0)

    def test_unknown_action_feedback_and_results_are_ignored(self):
        response = self.tick(allow_mutations=False, results=[result("unknown")], feedback=[feedback("unknown")])
        self.assertEqual(len(response["warnings"]), 2)
        self.assertEqual(self.brain.stats()["actions"], 0)
        self.assertEqual(self.brain.stats()["learning"], [])

    def test_results_and_rewards_cannot_cross_world_or_session(self):
        action = self.tick(target_count=1)["actions"][0]
        for world, session in (("world-2", "session-1"), ("world-1", "session-2")):
            with self.subTest(world=world, session=session):
                response = self.tick(allow_mutations=False, world_id=world, session_id=session,
                                     results=[result(action["id"])], feedback=[feedback(action["id"])])
                self.assertTrue(response["warnings"])
                self.assertIsNone(self.stored_action(action["id"])["status"])
        self.tick(allow_mutations=False, results=[result(action["id"])])
        for world, session in (("world-2", "session-1"), ("world-1", "session-2")):
            self.tick(allow_mutations=False, world_id=world, session_id=session, feedback=[feedback(action["id"])])
            self.assertIsNone(self.stored_action(action["id"])["reward"])
        self.tick(allow_mutations=False, feedback=[feedback(action["id"])])
        self.assertEqual(self.brain.stats()["learning"][0]["world"], "world-1")
        self.assertEqual(self.brain.stats()["learning"][0]["samples"], 1)
        other_world = self.tick(world_id="world-2", target_count=1)["actions"][0]
        self.assertIn("compact", other_world["reason"])

    def test_learning_uses_original_spawn_catalog_and_strategy_not_current_target(self):
        action = self.tick(target_count=1)["actions"][0]
        self.tick(allow_mutations=False, target_catalog_id="other",
                  results=[result(action["id"])], feedback=[feedback(action["id"], 0.25)])
        row = self.brain.stats()["learning"][0]
        self.assertEqual((row["catalog"], row["strategy"], row["reward_sum"]), ("crate", "compact", 0.25))
        other_catalog = self.tick(target_catalog_id="other", target_count=1)["actions"][0]
        self.assertIn("compact", other_catalog["reason"])

    def test_activation_feedback_is_stored_without_training_or_exploration_credit(self):
        data = request([entity(active=False, reactivatable=True)], target_count=1, allow_reactivation=True)
        data["limits"]["max_owned_entities"] = 1
        action = self.tick(data)["actions"][0]
        self.tick(allow_mutations=False, results=[result(action["id"])], feedback=[feedback(action["id"], 0.5)])
        self.assertEqual(self.stored_action(action["id"])["reward"], 0.5)
        self.assertEqual(self.brain.stats()["rated_actions"], 1)
        self.assertEqual(self.brain.stats()["learning"], [])
        spawn = self.tick(target_count=1)["actions"][0]
        self.assertIn("compact", spawn["reason"])

    def test_mixed_plan_only_executed_spawn_updates_placement_bandit(self):
        data = request([entity(active=False, reactivatable=True)], target_count=3, allow_reactivation=True)
        activation, executed, failed = self.tick(data)["actions"]
        self.tick(allow_mutations=False,
                  results=[result(activation["id"]), result(executed["id"]), result(failed["id"], "failed")],
                  feedback=[feedback(activation["id"], -1), feedback(executed["id"], 0.75), feedback(failed["id"], 1)])
        self.assertEqual(self.brain.stats()["rated_actions"], 2)
        self.assertEqual(self.brain.stats()["learning"],
                         [{"world": "world-1", "catalog": "crate", "strategy": "compact", "samples": 1, "reward_sum": 0.75}])

    def test_deactivation_feedback_does_not_train_placement(self):
        action = self.tick(request([entity()], target_count=0))["actions"][0]
        self.assertEqual(action["type"], "deactivate")
        self.tick(allow_mutations=False, results=[result(action["id"])], feedback=[feedback(action["id"])])
        self.assertEqual(self.brain.stats()["rated_actions"], 1)
        self.assertEqual(self.brain.stats()["learning"], [])

    def test_learning_and_idempotency_persist_after_reopening_sqlite(self):
        data = request(target_count=1, observation_id="persistent-plan")
        response = self.brain.tick(data)
        action = response["actions"][0]
        self.tick(allow_mutations=False, results=[result(action["id"])], feedback=[feedback(action["id"], 0.8)])
        before = self.brain.stats()
        self.brain.close()
        self.brain = server.Brain(self.database)
        self.assertEqual(self.brain.stats(), before)
        self.assertEqual(self.brain.tick(data), response)
        self.assertEqual(self.brain.stats(), before)
        self.tick(allow_mutations=False, feedback=[feedback(action["id"], -1)])
        self.assertEqual(self.brain.stats()["learning"], before["learning"])
        next_action = self.tick(target_count=1, session_id="session-2")["actions"][0]
        self.assertIn("spread", next_action["reason"])
        self.assertEqual(next_action["position"], {"x": 5.0, "y": 0.0, "z": 0.0})


class ProtocolV2Tests(BrainTestCase):
    @staticmethod
    def v2(**changes):
        data = request()
        data.update({
            "protocol_version": 2,
            "goals": [{"goal_id": "population.crates", "catalog_id": "crate",
                       "target_count": 2, "priority": 50, "status": "active",
                       "description": "Keep two approved crates active."}],
            "knowledge_updates": [{"key": "weather.current", "value": "rain",
                                   "category": "weather", "confidence": 0.9}],
            "relations": [],
            "capabilities": {"action_types": ["spawn", "activate", "deactivate", "move"]},
        })
        data.update(changes)
        return data

    def test_v2_persists_goal_knowledge_and_action_attribution(self):
        response = self.brain.tick_v2(self.v2())
        self.assertEqual(response["source"], "multi_objective_v2")
        self.assertEqual(len(response["actions"]), 2)
        self.assertTrue(all(a["goal_id"] == "population.crates" for a in response["actions"]))
        self.assertEqual(response["goal_stats"]["active"], 1)
        self.assertEqual(response["knowledge_summary"]["fact_count"], 1)
        fact = self.brain.knowledge.get_fact("world-1", "weather.current")
        self.assertEqual((fact["value"], fact["category"]), ("rain", "weather"))

    def test_v2_observe_mode_records_explicit_facts_without_mutation(self):
        response = self.brain.tick_v2(self.v2(allow_mutations=False))
        self.assertEqual(response["actions"], [])
        self.assertIn("Observing only", response["summary"])
        self.assertEqual(response["knowledge_summary"]["fact_count"], 1)

    def test_v2_replay_and_conflict(self):
        data = self.v2()
        first = self.brain.tick_v2(data)
        self.assertEqual(self.brain.tick_v2(deepcopy(data)), first)
        changed = deepcopy(data)
        changed["knowledge_updates"][0]["value"] = "sun"
        with self.assertRaises(server.ProtocolError) as caught:
            self.brain.tick_v2(changed)
        self.assertEqual(caught.exception.status, 409)


class HTTPTests(BrainTestCase):
    TOKEN = "local-test-token-0123456789"

    def setUp(self):
        super().setUp()
        self.httpd = server.make_server(self.brain, self.TOKEN, port=0)
        self.addCleanup(self.httpd.server_close)
        self.thread = threading.Thread(target=self.httpd.serve_forever, kwargs={"poll_interval": 0.01}, daemon=True)
        self.thread.start()
        self.addCleanup(self.stop_server)
        self.host, self.port = self.httpd.server_address
        self.assertEqual(self.host, "127.0.0.1")
        self.assertGreater(self.port, 0)

    def stop_server(self):
        self.httpd.shutdown()
        self.thread.join(timeout=5)
        self.assertFalse(self.thread.is_alive(), "Loopback HTTP server did not stop.")

    def exchange(self, method="POST", path="/v1/tick", body=None, headers=None, authorize=True):
        outgoing = {"Authorization": "Bearer " + self.TOKEN} if authorize else {}
        if method == "POST":
            outgoing["Content-Type"] = "application/json"
            if body is None:
                body = server.canonical(request()).encode()
        outgoing.update(headers or {})
        connection = http.client.HTTPConnection(self.host, self.port, timeout=5)
        try:
            connection.request(method, path, body=body, headers=outgoing)
            response = connection.getresponse()
            return response.status, json.loads(response.read()), dict(response.getheaders())
        finally:
            connection.close()

    def exchange_raw_headers(self, headers):
        connection = http.client.HTTPConnection(self.host, self.port, timeout=5)
        try:
            connection.putrequest("POST", "/v1/tick")
            connection.putheader("Authorization", "Bearer " + self.TOKEN)
            connection.putheader("Content-Type", "application/json")
            for name, value in headers:
                connection.putheader(name, value)
            connection.endheaders()
            response = connection.getresponse()
            return response.status, json.loads(response.read())
        finally:
            connection.close()

    def test_auth_is_required_for_health_stats_and_tick(self):
        for method, path in (("GET", "/health"), ("GET", "/v1/stats"), ("POST", "/v1/tick")):
            for headers in ({}, {"Authorization": "Bearer incorrect-token"}):
                with self.subTest(method=method, path=path, headers=headers):
                    status, body, _ = self.exchange(method, path, body=b"", headers=headers, authorize=False)
                    self.assertEqual(status, 401)
                    self.assertIn("error", body)
        self.assertEqual(self.brain.stats()["observations"], 0)

    def test_duplicate_authorization_is_rejected(self):
        status, _ = self.exchange_raw_headers([("Authorization", "Bearer " + self.TOKEN), ("Content-Length", "2")])
        self.assertEqual(status, 401)

    def test_browser_origin_is_rejected_even_with_valid_auth(self):
        for origin in ("null", "http://127.0.0.1", ""):
            for method, path in (("GET", "/health"), ("GET", "/v1/stats"), ("POST", "/v1/tick")):
                with self.subTest(origin=origin, method=method):
                    status, body, headers = self.exchange(method, path, body=b"", headers={"Origin": origin})
                    self.assertEqual(status, 403)
                    self.assertIn("Browser-origin", body["error"])
                    self.assertNotIn("Access-Control-Allow-Origin", headers)
        self.assertEqual(self.brain.stats()["observations"], 0)

    def test_health_and_stats_endpoints(self):
        status, body, headers = self.exchange("GET", "/health")
        self.assertEqual(status, 200)
        self.assertEqual(body, {"status": "ok", "protocol_versions": [1, 2], "planner": "multi_objective",
                               "model_training": False,
                               "capabilities": ["population_goals", "knowledge_storage", "placement_feedback"],
                               "action_types": ["spawn", "move", "activate", "deactivate"]})
        self.assertEqual(headers["Cache-Control"], "no-store")
        self.assertEqual(headers["Connection"], "close")
        self.assertEqual(headers["Content-Type"], "application/json; charset=utf-8")
        self.assertEqual(int(headers["Content-Length"]), len(server.canonical(body).encode()))
        status, body, _ = self.exchange("GET", "/v1/stats")
        self.assertEqual(status, 200)
        self.assertEqual(body, self.brain.stats())

    def test_valid_tick_returns_activation_then_spawn_with_protocol_one(self):
        data = request([entity("reuse-guid", active=False, reactivatable=True)], target_count=2, allow_reactivation=True)
        data["limits"].update(action_budget=2, max_owned_entities=2)
        status, body, _ = self.exchange(body=server.canonical(data).encode(),
                                        headers={"Content-Type": "application/json; charset=utf-8"})
        self.assertEqual(status, 200)
        self.assertEqual(body["source"], "local_population_v1")
        self.assertEqual(body["observation_id"], data["observation_id"])
        self.assertEqual([a["type"] for a in body["actions"]], ["activate", "spawn"])
        self.assertEqual(body["actions"][0]["target_id"], "reuse-guid")
        self.assertNotIn("position", body["actions"][0])
        self.assertIn("1 activations and 1 spawns", body["summary"])
        status, stats, _ = self.exchange("GET", "/v1/stats")
        self.assertEqual((status, stats["observations"], stats["actions"]), (200, 1, 2))

    def test_legacy_tick_omitting_reactivation_flag_still_spawns(self):
        status, body, _ = self.exchange()
        self.assertEqual(status, 200)
        self.assertEqual([a["type"] for a in body["actions"]], ["spawn"] * 3)

    def test_http_replay_and_different_body_conflict(self):
        status, first, _ = self.exchange()
        self.assertEqual(status, 200)
        self.assertEqual(self.exchange()[:2], (200, first))
        changed = request(target_count=1)
        status, body, _ = self.exchange(body=server.canonical(changed).encode())
        self.assertEqual(status, 409)
        self.assertIn("different contents", body["error"])
        self.assertEqual(self.brain.stats()["observations"], 1)

    def test_malformed_duplicate_and_invalid_flags_return_400(self):
        raw = server.canonical(request()).encode()
        payloads = (b"{", b"\xff", b'{"protocol_version":1,' + raw[1:],
                    raw.replace(b'"x":0.0', b'"x":NaN', 1),
                    server.canonical(request(allow_reactivation="true")).encode(),
                    server.canonical(request([entity(reactivatable=1)])).encode())
        for payload in payloads:
            with self.subTest(payload=payload[:80]):
                status, body, _ = self.exchange(body=payload)
                self.assertEqual(status, 400)
                self.assertIn("error", body)
        self.assertEqual(self.brain.stats()["observations"], 0)

    def test_oversized_and_empty_content_lengths_are_rejected_before_body_read(self):
        for size in (0, server.MAX_BODY + 1):
            with self.subTest(size=size):
                status, body, _ = self.exchange(body=b"", headers={"Content-Length": str(size)})
                self.assertEqual(status, 413)
                self.assertIn("size limit", body["error"])
        self.assertEqual(self.brain.stats()["observations"], 0)

    def test_unsupported_media_type_returns_415(self):
        for media in ("text/plain", "application/octet-stream"):
            with self.subTest(media=media):
                status, body, _ = self.exchange(body=b"", headers={"Content-Type": media, "Content-Length": "2"})
                self.assertEqual(status, 415)
                self.assertIn("application/json", body["error"])
        self.assertEqual(self.brain.stats()["observations"], 0)

    def test_invalid_or_missing_content_length_returns_411(self):
        for headers in ([], [("Content-Length", "-1")], [("Content-Length", "abc")],
                        [("Content-Length", "99999999999")],
                        [("Content-Length", "2"), ("Content-Length", "2")]):
            with self.subTest(headers=headers):
                status, body = self.exchange_raw_headers(headers)
                self.assertEqual(status, 411)
                self.assertIn("Content-Length", body["error"])

    def test_transfer_encoding_is_rejected(self):
        status, body = self.exchange_raw_headers([("Transfer-Encoding", "chunked"), ("Content-Length", "2")])
        self.assertEqual(status, 400)
        self.assertIn("Transfer encoding", body["error"])

    def test_unknown_endpoints_return_404(self):
        for method, path in (("GET", "/unknown"), ("POST", "/unknown"), ("GET", "/v1/tick"),
                             ("POST", "/health"), ("GET", "/health?extra=1")):
            with self.subTest(method=method, path=path):
                status, body, _ = self.exchange(method, path, body=b"")
                self.assertEqual(status, 404)
                self.assertIn("Unknown endpoint", body["error"])


if __name__ == "__main__":
    unittest.main()
