using System;
using System.Collections.Generic;
using UnityEngine;
using Object = UnityEngine.Object;

namespace AliTerra.AICore.Validation
{
    // Created only by RunChecks.RunRuntime after entering an empty Play Mode scene.
    public sealed class AICoreRuntimeProbe : MonoBehaviour
    {
        private enum Stage { Observe, NoAuthority, CancelApproval, RejectApproval, PolicyApproval, ExecuteApproval,
            Stable, Deactivate, Reactivate, ReusedStable, AutonomousSpawn, AutonomousStable, Truncated }
        private WorldEntity spawnedEntity;
        private int executionNotifications;
        private readonly List<GameObject> overflowEntities = new List<GameObject>();
        private Stage stage;
        private GameObject prefab;
        private string serviceToken;
        private string serviceEndpoint;
        private WorldDirector director;
        private PrefabCatalog catalog;
        private GameObject directorRoot;
        private GameObject sceneRoot;
        private WorldEntity sceneEntity;
        private string startingStatus;
        private double deadline;
        private bool sawRequest;
        private bool started;

        public bool IsComplete { get; private set; }
        public string Failure { get; private set; }
        public List<string> PassedChecks { get; } = new List<string>();

        public void Configure(GameObject fixture, string token, string endpoint)
        {
            prefab = fixture;
            serviceToken = token;
            serviceEndpoint = endpoint;
        }

        private void OnEnable() { Application.logMessageReceived += OnUnityLog; }
        private void OnDisable() { Application.logMessageReceived -= OnUnityLog; }

        private void Start()
        {
            try
            {
                Check("runtime.play-mode", Application.isPlaying);
                Check("runtime.prefab-is-nonvisual-asset", prefab != null && !prefab.scene.IsValid()
                    && prefab.GetComponents<Component>().Length == 2 && prefab.transform.childCount == 0);
                catalog = ScriptableObject.CreateInstance<PrefabCatalog>();
                catalog.entries = new[] { new PrefabCatalog.Entry { id = "validation-prop", kind = "prop", prefab = prefab } };
                Check("runtime.catalog-valid", catalog.TrySnapshot(out _, out _));

                sceneRoot = new GameObject("UnownedValidationEntity");
                sceneEntity = sceneRoot.AddComponent<WorldEntity>();
                sceneEntity.catalogId = "validation-scene";
                Check("runtime.scene-entity-guid", Guid.TryParse(sceneEntity.Id, out _));
                Check("runtime.scene-entity-unowned", !sceneEntity.IsOwned);
                string sceneId = sceneEntity.Id;
                sceneRoot.SetActive(false);
                Check("runtime.inactive-entity-retains-id-and-registration", sceneEntity.Id == sceneId
                    && Array.Exists(WorldEntity.Snapshot(), entity => entity == sceneEntity));

                directorRoot = new GameObject("ValidationWorldDirector");
                directorRoot.SetActive(false);
                director = directorRoot.AddComponent<WorldDirector>();
                director.token = serviceToken;
                if (!string.IsNullOrWhiteSpace(serviceEndpoint)) director.endpoint = serviceEndpoint;
                Uri endpoint;
                Check("runtime.loopback-endpoint", Uri.TryCreate(director.endpoint, UriKind.Absolute, out endpoint)
                    && endpoint.IsLoopback && (endpoint.Scheme == "http" || endpoint.Scheme == "https")
                    && string.IsNullOrEmpty(endpoint.UserInfo) && string.IsNullOrEmpty(endpoint.Fragment));
                director.worldId = "validation-" + Guid.NewGuid().ToString("N");
                director.catalog = catalog;
                director.targetCatalogId = "validation-prop";
                director.targetCount = 1;
                director.goal = "Maintain exactly one owned validation-prop near the anchor using the approved catalog.";
                director.allowedBounds = new Bounds(Vector3.zero, new Vector3(100, 100, 100));
                director.maxOwnedEntities = 2;
                director.intervalSeconds = 3600;
                director.requestTimeoutSeconds = 5;
                director.approvalTtlSeconds = 30;
                director.mode = DirectorMode.Observe;
                director.hasWorldAuthority = true;
                director.ActionExecuted += id => { executionNotifications++; };
                directorRoot.SetActive(true);
                Check("runtime.session-guid", Guid.TryParse(director.SessionId, out _));
                Check("runtime.no-initial-ownership", director.OwnedEntityCount == 0 && !sceneEntity.IsOwnedBy(director));
                Check("runtime.event-invalid-id", !director.PublishEvent("bad id", 1));
                Check("runtime.event-nan", !director.PublishEvent("event", float.NaN));
                Check("runtime.event-infinity", !director.PublishEvent("event", float.PositiveInfinity));
                for (int i = 0; i < ActionValidation.MaxBuffer; i++)
                    if (!director.PublishEvent("validation-event", i)) throw new InvalidOperationException("Event buffer filled before its declared capacity.");
                Check("runtime.event-buffer-cap", !director.PublishEvent("overflow", 1));
                Check("runtime.unknown-action-rating-rejected", !director.RateAction("unknown-action", 1));
                Check("runtime.no-pending-approval", !director.ApprovePending() && !director.RejectPending());
                BeginResponse(Stage.Observe, false);
                started = true;
            }
            catch (Exception ex) { Fail(ex.Message); }
        }

        private void BeginResponse(Stage next, bool think)
        {
            stage = next;
            sawRequest = false;
            startingStatus = director.Status;
            deadline = Time.realtimeSinceStartupAsDouble + 20;
            if (think && !director.Think()) throw new InvalidOperationException("Think refused in stage " + stage + ".");
        }

        private void Update()
        {
            if (!started || IsComplete) return;
            try
            {
                if (Time.realtimeSinceStartupAsDouble >= deadline)
                    throw new InvalidOperationException("Response timeout in " + stage + ". Director status: " + director.Status);
                if (director.IsRequestActive) { sawRequest = true; return; }
                // A fast local reply can complete between Updates; a changed terminal status also signals completion.
                if (!sawRequest && director.Status == startingStatus) return;
                switch (stage)
                {
                    case Stage.Observe:
                        Check("runtime.observe-valid-service-response", AcknowledgedWithoutApproval());
                        Check("runtime.observe-blocks-mutation-despite-authority", director.OwnedEntityCount == 0 && !director.HasPendingPlan);
                        Check("runtime.valid-response-acknowledges-events", director.PublishEvent("after-ack", 1));
                        director.SetMode(DirectorMode.Autonomous);
                        director.SetWorldAuthority(false);
                        BeginResponse(Stage.NoAuthority, true);
                        break;
                    case Stage.NoAuthority:
                        Check("runtime.no-authority-valid-service-response", AcknowledgedWithoutApproval());
                        Check("runtime.autonomous-without-authority-blocks-mutation", director.OwnedEntityCount == 0 && !director.HasPendingPlan);
                        director.SetMode(DirectorMode.Approval);
                        director.SetWorldAuthority(true);
                        BeginResponse(Stage.CancelApproval, true);
                        break;
                    case Stage.CancelApproval:
                        ValidatePending("cancel");
                        WorldAction original = director.GetPendingActions()[0];
                        WorldAction[] changed = director.GetPendingActions();
                        changed[0].id = "tampered";
                        changed[0].position.x = float.NaN;
                        changed[0].catalog_id = "tampered";
                        WorldAction fresh = director.GetPendingActions()[0];
                        Check("runtime.pending-actions-defensive-deep-copy", fresh.id == original.id
                            && fresh.catalog_id == original.catalog_id && fresh.position.ToVector3() == original.position.ToVector3());
                        director.SetWorldAuthority(false);
                        Check("runtime.authority-revocation-cancels-plan", !director.HasPendingPlan && !director.ApprovePending() && director.OwnedEntityCount == 0);
                        director.SetWorldAuthority(true);
                        Check("runtime.authority-restoration-does-not-revive-plan", !director.HasPendingPlan && !director.ApprovePending());
                        BeginResponse(Stage.RejectApproval, true);
                        break;
                    case Stage.RejectApproval:
                        ValidatePending("reject");
                        Check("runtime.reject-pending", director.RejectPending());
                        Check("runtime.rejected-plan-does-not-mutate", !director.HasPendingPlan && director.OwnedEntityCount == 0 && !director.ApprovePending());
                        BeginResponse(Stage.PolicyApproval, true);
                        break;
                    case Stage.PolicyApproval:
                        ValidatePending("policy");
                        director.targetCount = 2;
                        Check("runtime.changed-target-invalidates-approval", !director.ApprovePending() && !director.HasPendingPlan && director.OwnedEntityCount == 0);
                        director.targetCount = 1;
                        BeginResponse(Stage.ExecuteApproval, true);
                        break;
                    case Stage.ExecuteApproval:
                        ValidatePending("execute");
                        WorldAction action = director.GetPendingActions()[0];
                        Check("runtime.approve-pending", director.ApprovePending());
                        Check("runtime.approval-spawns-exactly-one-owned-root", director.OwnedEntityCount == 1 && !director.HasPendingPlan);
                        WorldEntity owned = Array.Find(WorldEntity.Snapshot(), entity => entity != null && entity.IsOwnedBy(director));
                        Check("runtime.spawned-entity-ownership-and-guid", owned != null && owned.IsOwned && Guid.TryParse(owned.Id, out _));
                        Check("runtime.spawned-position-matches-approved-action", owned.transform.position == action.position.ToVector3()
                            && director.allowedBounds.Contains(owned.transform.position));
                        Check("runtime.spawned-catalog", owned.catalogId == "validation-prop" && owned.kind == "prop");
                        Check("runtime.preexisting-entity-remains-unowned", !sceneEntity.IsOwned && sceneEntity.transform.position == Vector3.zero && !sceneRoot.activeSelf);
                        Check("runtime.success-result-buffered", director.BufferedResultCount == 1);
                        Check("runtime.invalid-rating-rejected", !director.RateAction(action.id, float.NaN));
                        Check("runtime.successful-action-can-be-rated-once", director.RateAction(action.id, 1) && !director.RateAction(action.id, 1));
                        Check("runtime.approval-cannot-replay", !director.ApprovePending() && director.OwnedEntityCount == 1);
                        spawnedEntity = owned;
                        Check("runtime.execution-notification-and-id", executionNotifications == 1 && director.LastSuccessfulActionId == action.id);
                        BeginResponse(Stage.Stable, true);
                        break;
                    case Stage.Stable:
                        Check("runtime.next-tick-recognizes-active-population", AcknowledgedWithoutApproval() && !director.HasPendingPlan && director.OwnedEntityCount == 1);
                        Check("runtime.results-and-feedback-acknowledged", director.BufferedResultCount == 0);
                        director.targetCount = 0;
                        director.maxOwnedEntities = 0;
                        BeginResponse(Stage.Deactivate, true);
                        break;
                    case Stage.Deactivate:
                        Check("runtime.downsize-plan", director.HasPendingPlan && director.GetPendingActions().Length == 1
                            && director.GetPendingActions()[0].type == "deactivate");
                        Check("runtime.downsize-works-above-lowered-cap", director.ApprovePending() && !spawnedEntity.gameObject.activeSelf && director.OwnedEntityCount == 1);
                        Check("runtime.inactive-root-retains-registration", Array.Exists(WorldEntity.Snapshot(), entity => entity == spawnedEntity));
                        director.targetCount = 1;
                        director.maxOwnedEntities = 1;
                        BeginResponse(Stage.Reactivate, true);
                        break;
                    case Stage.Reactivate:
                        Check("runtime.reuse-plan-at-full-cap", director.HasPendingPlan && director.GetPendingActions().Length == 1
                            && director.GetPendingActions()[0].type == "activate" && director.GetPendingActions()[0].target_id == spawnedEntity.Id);
                        Check("runtime.reuse-same-root-no-capacity-growth", director.ApprovePending() && spawnedEntity.gameObject.activeInHierarchy && director.OwnedEntityCount == 1);
                        BeginResponse(Stage.ReusedStable, true);
                        break;
                    case Stage.ReusedStable:
                        Check("runtime.reused-population-stable", AcknowledgedWithoutApproval() && !director.HasPendingPlan && director.OwnedEntityCount == 1);
                        director.targetCount = 2;
                        director.maxOwnedEntities = 2;
                        director.SetMode(DirectorMode.Autonomous);
                        BeginResponse(Stage.AutonomousSpawn, true);
                        break;
                    case Stage.AutonomousSpawn:
                        Check("runtime.autonomous-executes-with-authority", !director.HasPendingPlan && director.OwnedEntityCount == 2
                            && executionNotifications == 4 && director.Status.StartsWith("Plan completed", StringComparison.Ordinal));
                        BeginResponse(Stage.AutonomousStable, true);
                        break;
                    case Stage.AutonomousStable:
                        Check("runtime.autonomous-population-stable", AcknowledgedWithoutApproval() && !director.HasPendingPlan && director.OwnedEntityCount == 2);
                        for (int i = 0; i <= ActionValidation.MaxEntities; i++)
                        {
                            var extra = new GameObject("ObservationOverflow");
                            extra.AddComponent<WorldEntity>();
                            overflowEntities.Add(extra);
                        }
                        director.targetCount = 3;
                        director.maxOwnedEntities = 3;
                        BeginResponse(Stage.Truncated, true);
                        break;
                    case Stage.Truncated:
                        Check("runtime.truncated-snapshot-fails-closed", AcknowledgedWithoutApproval() && !director.HasPendingPlan
                            && director.OwnedEntityCount == 2 && executionNotifications == 4);
                        director.EmergencyStop();
                        Check("runtime.emergency-stop-gates", director.IsEmergencyStopped && !director.IsRequestActive
                            && !director.HasPendingPlan && !director.Think() && !director.PublishEvent("stopped", 1));
                        director.enabled = false;
                        director.enabled = true;
                        Check("runtime.reenable-does-not-resume", director.IsEmergencyStopped && !director.Think());
                        director.Resume();
                        Check("runtime.explicit-resume", !director.IsEmergencyStopped);
                        director.EmergencyStop();
                        IsComplete = true;
                        break;
                }
            }
            catch (Exception ex) { Fail(ex.Message); }
        }

        private bool AcknowledgedWithoutApproval()
        {
            return director.Status.StartsWith("Observation acknowledged;", StringComparison.Ordinal)
                || director.Status.StartsWith("Plan rejected:", StringComparison.Ordinal);
        }

        private void ValidatePending(string phase)
        {
            Check("runtime." + phase + "-plan-awaits-approval", director.HasPendingPlan && director.OwnedEntityCount == 0);
            WorldAction[] actions = director.GetPendingActions();
            Check("runtime." + phase + "-plan-is-single-spawn", actions.Length == 1 && actions[0].type == "spawn"
                && actions[0].catalog_id == "validation-prop" && actions[0].position != null);
            Check("runtime." + phase + "-pending-ttl", director.PendingSecondsRemaining > 0
                && director.PendingSecondsRemaining <= ActionValidation.MaxApprovalSeconds);
            Check("runtime." + phase + "-think-blocked-while-pending", !director.Think());
        }

        private void Check(string name, bool condition)
        {
            if (!condition) throw new InvalidOperationException(name + " failed. Director status: " + (director == null ? "not created" : director.Status));
            PassedChecks.Add(name);
        }

        private void OnUnityLog(string condition, string stackTrace, LogType type)
        {
            if (!IsComplete && (type == LogType.Error || type == LogType.Exception || type == LogType.Assert))
                Fail("Unity error: " + condition);
        }

        private void Fail(string message)
        {
            if (IsComplete) return;
            Failure = string.IsNullOrEmpty(serviceToken) ? message : message.Replace(serviceToken, "[redacted]");
            IsComplete = true;
            Stop();
        }

        public void Stop()
        {
            if (director != null) director.EmergencyStop();
        }

        private void OnDestroy()
        {
            Stop();
            if (director != null)
                foreach (WorldEntity entity in WorldEntity.Snapshot())
                    if (entity != null && entity.IsOwnedBy(director)) Object.Destroy(entity.gameObject);
            if (directorRoot != null) Object.Destroy(directorRoot);
            if (sceneRoot != null) Object.Destroy(sceneRoot);
            if (catalog != null) Object.Destroy(catalog);
        }
    }
}
