using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

namespace AliTerra.AICore.Validation
{
    [InitializeOnLoad]
    public static class RunChecks
    {
        private const string StateKey = "AICore.Validation.Runtime";
        private const string ReportKey = StateKey + ".Report";
        private const string FixtureKey = StateKey + ".Fixture";
        private const string DeadlineKey = StateKey + ".Deadline";
        private static ValidationReport report;
        private static AICoreRuntimeProbe probe;
        private static bool finishing;

        [Serializable]
        private sealed class CheckResult
        {
            public string name;
            public bool passed;
            public string detail;
        }

        [Serializable]
        private sealed class ValidationReport
        {
            public string suite;
            public string unity_version;
            public string started_utc;
            public string finished_utc;
            public int passed;
            public int failed;
            public List<CheckResult> checks = new List<CheckResult>();
        }

        static RunChecks()
        {
            // SessionState survives the domain reload on entering Play Mode; no disk checkpoint is needed.
            if (SessionState.GetBool(StateKey, false)) AttachRuntime();
        }

        public static void Run()
        {
            Begin("edit-mode");
            Test("harness.batch-only", RequireBatch);
            if (report.failed == 0) RunCore();
            Finish();
        }

        public static void RunRuntime()
        {
            Begin("edit-mode-and-runtime");
            Test("harness.batch-only", RequireBatch);
            if (report.failed == 0) RunCore();
            Test("runtime.token-configured", () =>
                Require(!string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable("AICORE_TOKEN")),
                    "Set AICORE_TOKEN to the already-running local service token."));
            Test("runtime.no-quit-flag", () => Require(!Environment.GetCommandLineArgs().Any(
                arg => string.Equals(arg, "-quit", StringComparison.OrdinalIgnoreCase)),
                "RunRuntime owns shutdown; omit -quit so Play Mode can execute."));
            if (report.failed != 0) { Finish(); return; }

            try
            {
                EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
                string folder = CreateFixtureFolder();
                SessionState.SetString(FixtureKey, folder);
                GameObject root = new GameObject("ValidationProp");
                try
                {
                    root.AddComponent<WorldEntity>();
                    Require(PrefabUtility.SaveAsPrefabAsset(root, folder + "/ValidationProp.prefab") != null,
                        "Could not save the nonvisual runtime fixture.");
                }
                finally { Object.DestroyImmediate(root); }
                SessionState.SetString(ReportKey, JsonUtility.ToJson(report));
                SessionState.SetString(DeadlineKey, DateTime.UtcNow.AddSeconds(120).Ticks.ToString());
                SessionState.SetBool(StateKey, true);
                AttachRuntime();
                EditorApplication.EnterPlaymode();
            }
            catch (Exception ex)
            {
                Record("runtime.bootstrap", false, ex.Message);
                FinishRuntime();
            }
        }

        private static void RequireBatch()
        {
            Require(Application.isBatchMode, "Use a batchmode Unity process, not an interactive editor.");
            Require(!EditorApplication.isPlayingOrWillChangePlaymode, "Checks must start in Edit Mode.");
        }

        private static void Begin(string suite)
        {
            finishing = false;
            report = new ValidationReport
            {
                suite = suite, unity_version = Application.unityVersion,
                started_utc = DateTime.UtcNow.ToString("O")
            };
        }

        private static void RunCore()
        {
            Application.logMessageReceived += CaptureUnityError;
            try
            {
                TestIds();
                TestPositions();
                TestActions();
                TestResponses();
                TestRateBudget();
                TestContracts();
                Test("catalog.fixtures", TestCatalog);
                Test("director.edit-mode-gates", TestEditModeDirector);
            }
            catch (Exception ex) { Record("harness.unexpected", false, ex.Message); }
            finally { Application.logMessageReceived -= CaptureUnityError; }
        }

        private static void TestIds()
        {
            Test("id.accepted-alphabet-and-length", () =>
            {
                Require(ActionValidation.IsValidId("Az09_.:-"), "Allowed ID alphabet rejected.");
                Require(ActionValidation.IsValidId(new string('a', ActionValidation.MaxIdLength)), "Boundary length rejected.");
            });
            string[] invalid = { null, "", "has space", "a/b", "a\\b", "a\nb", "a\tb", "a\0b", "\u00e9", new string('a', ActionValidation.MaxIdLength + 1) };
            for (int i = 0; i < invalid.Length; i++)
            {
                string value = invalid[i];
                Test("id.rejected-" + i, () => Require(!ActionValidation.IsValidId(value), "Invalid ID accepted."));
            }
        }

        private static Bounds ValidBounds() { return new Bounds(Vector3.zero, new Vector3(20, 20, 20)); }
        private static PositionDto Position(float x = 0, float y = 0, float z = 0)
        {
            return new PositionDto(new Vector3(x, y, z));
        }

        private static void TestPositions()
        {
            Test("position.finite-and-inclusive-boundaries", () =>
            {
                Require(ActionValidation.IsFinite(0) && ActionValidation.IsFinite(float.MaxValue), "Finite scalar rejected.");
                Bounds bounds = ValidBounds();
                Require(ActionValidation.ValidateBounds(bounds), "Valid bounds rejected.");
                foreach (Vector3 point in new[] { Vector3.zero, bounds.min, bounds.max })
                {
                    bool valid = ActionValidation.ValidatePosition(new PositionDto(point), bounds, out string error);
                    Accept(valid, error);
                }
            });
            Test("position.null-and-out-of-bounds", () =>
            {
                foreach (PositionDto point in new[] { null, Position(10.01f), Position(-10.01f), Position(0, 10.01f), Position(0, -10.01f), Position(0, 0, 10.01f), Position(0, 0, -10.01f) })
                {
                    bool valid = ActionValidation.ValidatePosition(point, ValidBounds(), out string error);
                    Reject(valid, error);
                }
            });
            Test("position.nonfinite-every-axis", () =>
            {
                foreach (float value in new[] { float.NaN, float.PositiveInfinity, float.NegativeInfinity })
                {
                    Require(!ActionValidation.IsFinite(value), "Nonfinite scalar accepted.");
                    foreach (PositionDto point in new[] { Position(value), Position(0, value), Position(0, 0, value) })
                    {
                        Require(!ActionValidation.IsFinite(point.ToVector3()), "Nonfinite vector accepted.");
                        bool valid = ActionValidation.ValidatePosition(point, ValidBounds(), out string error);
                        Reject(valid, error);
                    }
                }
            });
            Test("bounds.zero-negative-nonfinite-overflow", () =>
            {
                Bounds[] invalid =
                {
                    new Bounds(Vector3.zero, new Vector3(0, 1, 1)),
                    new Bounds(Vector3.zero, new Vector3(1, -1, 1)),
                    new Bounds(Vector3.zero, new Vector3(1, 1, 0)),
                    new Bounds(new Vector3(float.NaN, 0, 0), Vector3.one),
                    new Bounds(Vector3.zero, new Vector3(1, float.PositiveInfinity, 1)),
                    new Bounds(new Vector3(float.MaxValue, 0, 0), new Vector3(float.MaxValue, 1, 1))
                };
                foreach (Bounds bounds in invalid)
                {
                    Require(!ActionValidation.ValidateBounds(bounds), "Invalid bounds accepted.");
                    bool valid = ActionValidation.ValidatePosition(Position(), bounds, out string error);
                    Reject(valid, error);
                }
            });
        }

        private static WorldAction Spawn(string id = "spawn-1")
        {
            return new WorldAction { id = id, type = "spawn", catalog_id = "validation-prop", position = Position(), reason = "Validation" };
        }

        private static void TestActions()
        {
            string target = "123456781234123412341234567890ab";
            Test("action.valid-spawn-move-deactivate", () =>
            {
                WorldAction[] actions =
                {
                    Spawn(),
                    new WorldAction { id = "move-1", type = "move", target_id = target, position = Position() },
                    new WorldAction { id = "off-1", type = "deactivate", target_id = target },
                    new WorldAction { id = "on-1", type = "activate", target_id = target, catalog_id = "validation-prop" }
                };
                foreach (WorldAction action in actions)
                {
                    bool valid = ActionValidation.ValidateActionShape(action, out string error);
                    Accept(valid, error);
                }
            });
            Test("action.null", () => { bool valid = ActionValidation.ValidateActionShape(null, out string error); Reject(valid, error); });
            var mutations = new Dictionary<string, Action<WorldAction>>
            {
                { "invalid-id", a => a.id = "bad id" },
                { "unknown-type", a => a.type = "destroy" },
                { "missing-catalog", a => a.catalog_id = null },
                { "invalid-catalog", a => a.catalog_id = "bad/id" },
                { "spawn-with-target", a => a.target_id = target },
                { "missing-position", a => a.position = null },
                { "nan-position", a => a.position.x = float.NaN },
                { "infinite-position", a => a.position.z = float.NegativeInfinity },
                { "oversized-reason", a => a.reason = new string('r', ActionValidation.MaxGoalLength + 1) },
                { "move-without-target", a => a.type = "move" },
                { "move-nonguid-target", a => { a.type = "move"; a.target_id = "not-a-guid"; } },
                { "move-invalid-target", a => { a.type = "move"; a.target_id = "bad/id"; } },
                { "deactivate-without-target", a => a.type = "deactivate" }
            };
            foreach (var mutation in mutations)
                Test("action." + mutation.Key, () =>
                {
                    WorldAction action = Spawn();
                    mutation.Value(action);
                    bool valid = ActionValidation.ValidateActionShape(action, out string error);
                    Reject(valid, error);
                });
            Test("action.shape-does-not-replace-bounds-check", () =>
            {
                WorldAction action = Spawn();
                action.position = Position(100);
                bool shaped = ActionValidation.ValidateActionShape(action, out string shapeError);
                Accept(shaped, shapeError);
                bool positioned = ActionValidation.ValidatePosition(action.position, ValidBounds(), out string positionError);
                Reject(positioned, positionError);
            });
        }

        private static TickResponse Response()
        {
            return new TickResponse
            {
                plan_id = "plan-1", observation_id = "observation-1", source = "validation",
                summary = "Contract test", actions = new[] { Spawn() }, warnings = Array.Empty<string>()
            };
        }

        private static void TestResponses()
        {
            Test("response.valid-roundtrip-and-empty-plan", () =>
            {
                TickResponse response = JsonUtility.FromJson<TickResponse>(JsonUtility.ToJson(Response()));
                bool valid = ActionValidation.ValidateResponse(response, "observation-1", out string error);
                Accept(valid, error);
                Require(response.actions[0].catalog_id == "validation-prop" && response.actions[0].position.x == 0, "Action fields lost.");
                response.actions = Array.Empty<WorldAction>();
                valid = ActionValidation.ValidateResponse(response, "observation-1", out error);
                Accept(valid, error);
            });
            Test("response.null", () => { bool valid = ActionValidation.ValidateResponse(null, "observation-1", out string error); Reject(valid, error); });
            var mutations = new Dictionary<string, Action<TickResponse>>
            {
                { "invalid-plan-id", r => r.plan_id = "bad id" },
                { "invalid-observation-id", r => r.observation_id = null },
                { "observation-mismatch", r => r.observation_id = "observation-2" },
                { "observation-case-mismatch", r => r.observation_id = "Observation-1" },
                { "missing-source", r => r.source = "" },
                { "oversized-source", r => r.source = new string('s', ActionValidation.MaxIdLength + 1) },
                { "oversized-summary", r => r.summary = new string('s', 4001) },
                { "missing-actions", r => r.actions = null },
                { "too-many-actions", r => r.actions = new WorldAction[ActionValidation.MaxActions + 1] },
                { "null-action", r => r.actions = new WorldAction[] { null } },
                { "malformed-action", r => r.actions[0].type = "teleport" },
                { "duplicate-actions", r => r.actions = new[] { Spawn("same-id"), Spawn("same-id") } },
                { "missing-warnings", r => r.warnings = null },
                { "too-many-warnings", r => r.warnings = new string[ActionValidation.MaxBuffer + 1] },
                { "null-warning", r => r.warnings = new string[] { null } },
                { "oversized-warning", r => r.warnings = new[] { new string('w', ActionValidation.MaxGoalLength + 1) } }
            };
            foreach (var mutation in mutations)
                Test("response." + mutation.Key, () =>
                {
                    TickResponse response = Response();
                    mutation.Value(response);
                    bool valid = ActionValidation.ValidateResponse(response, "observation-1", out string error);
                    Reject(valid, error);
                });
            Test("response.maximum-valid-arrays", () =>
            {
                TickResponse response = Response();
                response.actions = Enumerable.Range(0, ActionValidation.MaxActions).Select(i => Spawn("action-" + i)).ToArray();
                response.warnings = Enumerable.Repeat("warning", ActionValidation.MaxBuffer).ToArray();
                bool valid = ActionValidation.ValidateResponse(response, "observation-1", out string error);
                Accept(valid, error);
            });
            Test("response.malformed-json-and-missing-fields", () =>
            {
                foreach (string json in new[] { "not-json", "{", "{}", "{\"plan_id\":\"p\",\"observation_id\":\"observation-1\"}" })
                {
                    TickResponse response;
                    try { response = JsonUtility.FromJson<TickResponse>(json); }
                    catch (ArgumentException) { continue; }
                    bool valid = ActionValidation.ValidateResponse(response, "observation-1", out string error);
                    Reject(valid, error);
                }
            });
        }

        private static void TestRateBudget()
        {
            Test("rate.exhaustive-boundaries", () =>
            {
                for (int attempts = -1; attempts <= ActionValidation.MaxActions + 1; attempts++)
                    for (int planned = -1; planned <= ActionValidation.MaxActions + 1; planned++)
                    {
                        bool expected = attempts >= 0 && planned >= 0 && attempts + planned <= ActionValidation.MaxActions;
                        Require(ActionValidation.HasRateCapacity(attempts, planned) == expected,
                            "Unexpected capacity at attempts=" + attempts + ", planned=" + planned);
                    }
                Require(!ActionValidation.HasRateCapacity(int.MaxValue, 1), "Overflow attempt count accepted.");
                Require(!ActionValidation.HasRateCapacity(1, int.MaxValue), "Overflow plan count accepted.");
                Require(!ActionValidation.HasRateCapacity(int.MinValue, 0), "Negative extreme accepted.");
            });
        }

        private static FieldInfo Field(Type owner, string name, Type type)
        {
            FieldInfo field = owner.GetField(name, BindingFlags.Instance | BindingFlags.Public);
            Require(field != null, owner.Name + "." + name + " is missing.");
            Require(field.FieldType == type, owner.Name + "." + name + " has the wrong type.");
            return field;
        }

        private static void TestContracts()
        {
            Test("contract.protocol-version-default", () =>
                Require((int)Field(typeof(TickRequest), "protocol_version", typeof(int)).GetValue(new TickRequest()) == 1,
                    "A new TickRequest must default protocol_version to 1."));
            foreach (bool flag in new[] { false, true })
                Test("contract.new-fields-roundtrip-" + flag.ToString().ToLowerInvariant(), () =>
                {
                    FieldInfo version = Field(typeof(TickRequest), "protocol_version", typeof(int));
                    FieldInfo truncated = Field(typeof(TickRequest), "entities_truncated", typeof(bool));
                    FieldInfo active = Field(typeof(EntityDto), "active", typeof(bool));
                    Type limitsType = typeof(TickRequest).Assembly.GetType("AliTerra.AICore.LimitsDto");
                    Require(limitsType != null, "LimitsDto is missing.");
                    FieldInfo limitsField = Field(typeof(TickRequest), "limits", limitsType);
                    FieldInfo min = Field(limitsType, "min", typeof(PositionDto));
                    FieldInfo max = Field(limitsType, "max", typeof(PositionDto));
                    FieldInfo cap = Field(limitsType, "max_owned_entities", typeof(int));
                    FieldInfo owned = Field(limitsType, "owned_entity_count", typeof(int));
                    FieldInfo budget = Field(limitsType, "action_budget", typeof(int));
                    string boolean = flag ? "true" : "false";
                    string json = "{\"protocol_version\":1,\"world_id\":\"validation\",\"session_id\":\"session-1\",\"observation_id\":\"observation-1\","
                        + "\"entities_truncated\":" + boolean + ",\"allow_mutations\":false,"
                        + "\"limits\":{\"min\":{\"x\":-11,\"y\":-12,\"z\":-13},\"max\":{\"x\":21,\"y\":22,\"z\":23},"
                        + "\"max_owned_entities\":19,\"owned_entity_count\":7,\"action_budget\":3},"
                        + "\"entities\":[{\"id\":\"entity-1\",\"catalog_id\":\"validation-prop\",\"kind\":\"prop\",\"position\":{\"x\":1,\"y\":2,\"z\":3},\"owned\":true,\"active\":" + boolean + "}]}";
                    TickRequest request = JsonUtility.FromJson<TickRequest>(json);
                    for (int round = 0; round < 2; round++)
                    {
                        Require((int)version.GetValue(request) == 1, "Protocol version lost.");
                        Require((bool)truncated.GetValue(request) == flag, "Truncation flag lost.");
                        Require(request.entities != null && request.entities.Length == 1, "Entity array lost.");
                        Require((bool)active.GetValue(request.entities[0]) == flag, "Active flag lost.");
                        Require(request.entities[0].owned && request.entities[0].position.ToVector3() == new Vector3(1, 2, 3), "Existing entity fields lost.");
                        object limits = limitsField.GetValue(request);
                        Require(limits != null, "Limits object lost.");
                        Require(((PositionDto)min.GetValue(limits)).ToVector3() == new Vector3(-11, -12, -13), "Minimum bounds lost.");
                        Require(((PositionDto)max.GetValue(limits)).ToVector3() == new Vector3(21, 22, 23), "Maximum bounds lost.");
                        Require((int)cap.GetValue(limits) == 19 && (int)owned.GetValue(limits) == 7 && (int)budget.GetValue(limits) == 3, "Integer limits lost.");
                        string serialized = JsonUtility.ToJson(request);
                        foreach (string name in new[] { "protocol_version", "entities_truncated", "limits", "min", "max", "max_owned_entities", "owned_entity_count", "action_budget", "active" })
                            Require(serialized.Contains("\"" + name + "\":"), "Serialized field missing: " + name);
                        Require(serialized.Contains("\"active\":" + boolean) && serialized.Contains("\"entities_truncated\":" + boolean), "Boolean JSON representation changed.");
                        request = JsonUtility.FromJson<TickRequest>(serialized);
                    }
                });
        }

        private static string CreateFixtureFolder()
        {
            const string root = "Assets/ValidationFixtures";
            if (!AssetDatabase.IsValidFolder(root)) AssetDatabase.CreateFolder("Assets", "ValidationFixtures");
            string folder = root + "/Run_" + Guid.NewGuid().ToString("N");
            Require(!string.IsNullOrEmpty(AssetDatabase.CreateFolder(root, Path.GetFileName(folder))), "Cannot create isolated fixture folder.");
            return folder;
        }

        private sealed class Fixtures : IDisposable
        {
            private readonly string folder;
            private readonly Scene scene;
            public Fixtures()
            {
                folder = CreateFixtureFolder();
                scene = EditorSceneManager.NewPreviewScene();
            }
            public GameObject SceneObject(string name)
            {
                var root = new GameObject(name);
                SceneManager.MoveGameObjectToScene(root, scene);
                return root;
            }
            public GameObject Prefab(string name, Action<GameObject> configure = null, bool marker = true)
            {
                GameObject root = SceneObject(name);
                try
                {
                    if (marker) root.AddComponent<WorldEntity>();
                    configure?.Invoke(root);
                    GameObject asset = PrefabUtility.SaveAsPrefabAsset(root, folder + "/" + name + ".prefab");
                    Require(asset != null, "Cannot create fixture " + name);
                    return asset;
                }
                finally { Object.DestroyImmediate(root); }
            }
            public void Dispose()
            {
                EditorSceneManager.ClosePreviewScene(scene);
                Require(AssetDatabase.DeleteAsset(folder), "Could not remove temporary fixture assets.");
            }
        }

        private static PrefabCatalog.Entry Entry(GameObject prefab, string id = "validation-prop", string kind = "prop")
        {
            return new PrefabCatalog.Entry { id = id, kind = kind, prefab = prefab };
        }

        private static void TestCatalog()
        {
            using (var fixtures = new Fixtures())
            {
                GameObject good = fixtures.Prefab("Valid");
                Test("catalog.valid-nonvisual-prefab", () =>
                {
                    Require(good.GetComponents<Component>().Length == 2 && good.transform.childCount == 0,
                        "Fixture must contain only Transform and WorldEntity.");
                    bool valid = PrefabCatalog.ValidateEntry(Entry(good), out string error);
                    Accept(valid, error);
                });
                GameObject sceneObject = fixtures.SceneObject("NotAnAsset");
                sceneObject.AddComponent<WorldEntity>();
                GameObject hierarchy = fixtures.Prefab("Hierarchy", root => new GameObject("Child").transform.SetParent(root.transform));
                var bad = new Dictionary<string, PrefabCatalog.Entry>
                {
                    { "null-entry", null },
                    { "invalid-id", Entry(good, "bad id") },
                    { "invalid-kind", Entry(good, kind: "bad/kind") },
                    { "null-prefab", Entry(null) },
                    { "scene-template", Entry(sceneObject) },
                    { "prefab-child", Entry(hierarchy.transform.GetChild(0).gameObject) },
                    { "inactive-root", Entry(fixtures.Prefab("Inactive", root => root.SetActive(false))) },
                    { "missing-marker", Entry(fixtures.Prefab("NoMarker", marker: false)) },
                    { "nested-marker", Entry(fixtures.Prefab("Nested", root =>
                        { var child = new GameObject("NestedEntity"); child.transform.SetParent(root.transform); child.AddComponent<WorldEntity>(); child.SetActive(false); })) },
                    { "entry-player-kind", Entry(good, kind: "PlAyEr") },
                    { "root-player-kind", Entry(fixtures.Prefab("PlayerKind", root => root.GetComponent<WorldEntity>().kind = "PLAYER")) },
                    { "root-player-tag", Entry(fixtures.Prefab("PlayerTag", root => root.tag = "Player")) },
                    { "inactive-child-player-tag", Entry(fixtures.Prefab("PlayerChild", root =>
                        { var child = new GameObject("Protected"); child.transform.SetParent(root.transform); child.tag = "Player"; child.SetActive(false); })) }
                };
                foreach (var pair in bad)
                    Test("catalog.reject-" + pair.Key, () =>
                    {
                        bool valid = PrefabCatalog.ValidateEntry(pair.Value, out string error);
                        Reject(valid, error);
                    });
                PrefabCatalog catalog = ScriptableObject.CreateInstance<PrefabCatalog>();
                try
                {
                    Test("catalog.empty-snapshot", () =>
                    {
                        bool valid = catalog.TrySnapshot(out PrefabCatalog.Entry[] entries, out string error);
                        Accept(valid, error);
                        Require(entries.Length == 0, "Empty catalog should be valid.");
                    });
                    Test("catalog.snapshot-defensive-copy", () =>
                    {
                        catalog.entries = new[] { Entry(good) };
                        bool valid = catalog.TrySnapshot(out PrefabCatalog.Entry[] copy, out string error);
                        Accept(valid, error);
                        Require(!ReferenceEquals(copy, catalog.entries) && !ReferenceEquals(copy[0], catalog.entries[0]), "Snapshot aliases mutable entries.");
                        Require(copy[0].prefab == good && copy[0].id == "validation-prop" && copy[0].kind == "prop", "Snapshot changed entry fields.");
                        copy[0].id = "changed";
                        copy[0].kind = "changed";
                        copy[0].prefab = null;
                        Require(catalog.entries[0].id == "validation-prop" && catalog.entries[0].kind == "prop" && catalog.entries[0].prefab == good, "Snapshot mutation leaked.");
                    });
                    Test("catalog.duplicate-ids", () =>
                    {
                        catalog.entries = new[] { Entry(good), Entry(good) };
                        bool valid = catalog.TrySnapshot(out _, out string error);
                        Reject(valid, error);
                    });
                    Test("catalog.null-oversized-and-invalid-arrays", () =>
                    {
                        foreach (PrefabCatalog.Entry[] entries in new[] { null, new PrefabCatalog.Entry[ActionValidation.MaxCatalog + 1], new PrefabCatalog.Entry[] { null }, new[] { Entry(sceneObject) } })
                        {
                            catalog.entries = entries;
                            bool valid = catalog.TrySnapshot(out _, out string error);
                            Reject(valid, error);
                        }
                    });
                    Test("catalog.maximum-size", () =>
                    {
                        catalog.entries = Enumerable.Range(0, ActionValidation.MaxCatalog).Select(i => Entry(good, "entry-" + i)).ToArray();
                        bool valid = catalog.TrySnapshot(out PrefabCatalog.Entry[] copy, out string error);
                        Accept(valid, error);
                        Require(copy.Length == ActionValidation.MaxCatalog, "Maximum catalog truncated.");
                    });
                }
                finally { Object.DestroyImmediate(catalog); }
            }
        }

        private static void TestEditModeDirector()
        {
            GameObject root = new GameObject("EditModeDirector");
            try
            {
                WorldDirector director = root.AddComponent<WorldDirector>();
                WorldEntity entity = root.AddComponent<WorldEntity>();
                Require(director.mode == DirectorMode.Observe && !director.hasWorldAuthority, "Unsafe defaults.");
                Require(director.OwnedEntityCount == 0 && !entity.IsOwned && !entity.IsOwnedBy(director), "Scene entity acquired ownership.");
                Require(!director.Think() && !director.ApprovePending() && !director.RejectPending(), "Edit Mode allowed runtime controls.");
                Require(!director.PublishEvent("test", 1) && !director.RateAction("action", 1), "Edit Mode accepted runtime telemetry.");
                Require(director.GetPendingActions().Length == 0 && !director.HasPendingPlan && !director.IsRequestActive, "Unexpected pending work.");
            }
            finally { Object.DestroyImmediate(root); }
        }

        private static void AttachRuntime()
        {
            EditorApplication.playModeStateChanged -= OnPlayModeChanged;
            EditorApplication.playModeStateChanged += OnPlayModeChanged;
            EditorApplication.update -= PollRuntime;
            EditorApplication.update += PollRuntime;
        }

        private static void OnPlayModeChanged(PlayModeStateChange state)
        {
            if (!SessionState.GetBool(StateKey, false)) return;
            if (state == PlayModeStateChange.EnteredPlayMode)
            {
                try
                {
                    if (probe != null) return;
                    string path = SessionState.GetString(FixtureKey, "") + "/ValidationProp.prefab";
                    GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(path);
                    Require(prefab != null, "Runtime prefab did not survive domain reload.");
                    probe = new GameObject("AICoreRuntimeProbe").AddComponent<AICoreRuntimeProbe>();
                    probe.Configure(prefab, Environment.GetEnvironmentVariable("AICORE_TOKEN"),
                        Environment.GetEnvironmentVariable("AICORE_ENDPOINT"));
                }
                catch (Exception ex)
                {
                    RestoreReport();
                    Record("runtime.enter-play-mode", false, ex.Message);
                    FinishRuntime();
                }
            }
            else if (state == PlayModeStateChange.EnteredEditMode)
            {
                RestoreReport();
                Record("runtime.unexpected-play-mode-exit", false, "Play Mode ended before the probe completed.");
                FinishRuntime();
            }
        }

        private static void RestoreReport()
        {
            if (report == null) report = JsonUtility.FromJson<ValidationReport>(SessionState.GetString(ReportKey, ""));
            if (report == null) Begin("runtime-recovery");
        }

        private static void PollRuntime()
        {
            if (!SessionState.GetBool(StateKey, false) || finishing) return;
            try
            {
                RestoreReport();
                long deadline;
                if (!long.TryParse(SessionState.GetString(DeadlineKey, ""), out deadline) || DateTime.UtcNow.Ticks > deadline)
                {
                    Record("runtime.watchdog", false, "Runtime validation exceeded its 120-second watchdog.");
                    FinishRuntime();
                    return;
                }
                if (probe == null || !probe.IsComplete) return;
                foreach (string name in probe.PassedChecks) Record(name, true, "");
                if (!string.IsNullOrEmpty(probe.Failure)) Record("runtime.failure", false, probe.Failure);
                FinishRuntime();
            }
            catch (Exception ex)
            {
                RestoreReport();
                Record("runtime.poll", false, ex.Message);
                FinishRuntime();
            }
        }

        private static void FinishRuntime()
        {
            SessionState.SetBool(StateKey, false);
            EditorApplication.update -= PollRuntime;
            EditorApplication.playModeStateChanged -= OnPlayModeChanged;
            if (probe != null) probe.Stop();
            string folder = SessionState.GetString(FixtureKey, "");
            Test("runtime.fixture-cleanup", () =>
            {
                if (!string.IsNullOrEmpty(folder)) Require(AssetDatabase.DeleteAsset(folder), "Runtime fixture cleanup failed.");
            });
            SessionState.EraseString(FixtureKey);
            SessionState.EraseString(ReportKey);
            SessionState.EraseString(DeadlineKey);
            Finish();
        }

        private static void CaptureUnityError(string condition, string stackTrace, LogType type)
        {
            if (type == LogType.Error || type == LogType.Exception || type == LogType.Assert)
                Record("unity.error", false, condition);
        }

        private static void Test(string name, Action test)
        {
            try { test(); Record(name, true, ""); }
            catch (Exception ex) { Record(name, false, ex.GetType().Name + ": " + ex.Message); }
        }

        private static string Redact(string value)
        {
            string token = Environment.GetEnvironmentVariable("AICORE_TOKEN");
            return string.IsNullOrEmpty(token) ? value : value.Replace(token, "[redacted]");
        }

        private static void Record(string name, bool passed, string detail)
        {
            detail = Redact(detail ?? "");
            report.checks.Add(new CheckResult { name = name, passed = passed, detail = detail });
            if (passed) report.passed++; else report.failed++;
            Debug.Log("[AICoreValidation] " + (passed ? "PASS " : "FAIL ") + name + (detail.Length == 0 ? "" : ": " + detail));
        }

        private static void Require(bool condition, string message)
        {
            if (!condition) throw new InvalidOperationException(message);
        }
        private static void Accept(bool valid, string error) { Require(valid && error == null, "Expected acceptance: " + error); }
        private static void Reject(bool valid, string error) { Require(!valid && !string.IsNullOrEmpty(error), "Expected rejection with an explanation."); }

        private static void Finish()
        {
            if (finishing) return;
            finishing = true;
            report.finished_utc = DateTime.UtcNow.ToString("O");
            string configuredPath = Environment.GetEnvironmentVariable("AICORE_VALIDATION_REPORT");
            if (!string.IsNullOrWhiteSpace(configuredPath))
            {
                try
                {
                    string project = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
                    string path = Path.GetFullPath(Path.IsPathRooted(configuredPath) ? configuredPath : Path.Combine(project, configuredPath));
                    Require(path.StartsWith(project + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase),
                        "Report path must stay inside ValidationProject.");
                    Require(string.Equals(Path.GetExtension(path), ".json", StringComparison.OrdinalIgnoreCase), "Report path must have a .json extension.");
                    Require(!path.StartsWith(Path.Combine(project, "Assets") + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)
                        && !path.StartsWith(Path.Combine(project, "Packages") + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)
                        && !path.StartsWith(Path.Combine(project, "ProjectSettings") + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase),
                        "Write reports outside Assets, Packages and ProjectSettings.");
                    Directory.CreateDirectory(Path.GetDirectoryName(path));
                    File.WriteAllText(path, Redact(JsonUtility.ToJson(report, true)));
                }
                catch (Exception ex) { Record("report.write", false, ex.Message); }
            }
            Debug.Log("[AICoreValidation] Completed: " + report.passed + " passed; " + report.failed + " failed.");
            if (Application.isBatchMode) EditorApplication.Exit(report.failed == 0 ? 0 : 1);
        }
    }
}
