# Implementation update, 2026-09-12

## Added

- Upgraded the Unity transport DTOs and default endpoint to protocol v2.
- Connected Unity's single configured population objective to the brain's persistent goal manager.
- Added trusted gameplay APIs `PublishKnowledge` and `PublishRelation` with bounded buffers and validation.
- Added v2 capability advertisement and response DTOs for goal and knowledge summaries.
- Made knowledge and relation acknowledgement transactional with the matching observation.
- Added goal attribution to Unity actions.
- Added category and confidence validation helpers.
- Fixed stale Python test construction and health-contract expectations.
- Added protocol v2 tests for persistent goals, knowledge, observe-only ingestion, replay, and conflict detection.
- Bumped the Unity package to 0.4.0.

## Validation

- Python syntax compilation: passed.
- Python unit and integration tests: 69 passed.
- Unity compilation/runtime validation: not run here because Unity Editor and a C# compiler were not installed.

## Deliberate limits

No arbitrary code execution, runtime asset downloading, unrestricted destruction, automatic player-data capture, or self-modifying model training was added. Adaptation remains outcome-based placement selection using attributed gameplay feedback.
